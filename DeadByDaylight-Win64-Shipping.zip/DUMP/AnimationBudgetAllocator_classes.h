// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x30 (Inherited: 0x30)
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x27f69a0
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x27f68e0
};

// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xb90 (Inherited: 0xb70)
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	char pad_B70[0x18]; // 0xb70(0x18)
	char bAutoRegisterWithBudgetAllocator : 1; // 0xb88(0x01)
	char bAutoCalculateSignificance : 1; // 0xb88(0x01)
	char bShouldUseActorRenderedFlag : 1; // 0xb88(0x01)
	char pad_B88_3 : 5; // 0xb88(0x01)
	char pad_B89[0x7]; // 0xb89(0x07)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator // (Final|Native|Public|BlueprintCallable) // @ game+0x27f6b30
};

