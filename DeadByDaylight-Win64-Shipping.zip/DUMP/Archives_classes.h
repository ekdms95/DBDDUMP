// Class Archives.AfterExitOpenQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UAfterExitOpenQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnExitGateOpened(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.AfterExitOpenQEEvaluator.OnExitGateOpened // (Final|Native|Public|HasOutParms) // @ game+0x2b49f60
};

// Class Archives.BloodPointsQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UBloodPointsQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnFinishedPlaying(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.BloodPointsQEEvaluator.OnFinishedPlaying // (Final|Native|Public|HasOutParms) // @ game+0x2b4a180
};

// Class Archives.ContextualQuestUtilities
// Size: 0x30 (Inherited: 0x30)
struct UContextualQuestUtilities : UBlueprintFunctionLibrary {

	bool PlayerHasToCompleteAssociatedQuest(struct ADBDPlayer* Player, struct FName SpecialBehaviourId); // Function Archives.ContextualQuestUtilities.PlayerHasToCompleteAssociatedQuest // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b4b720
	bool PlayerHasAssociatedQuest(struct ADBDPlayer* Player, struct FName SpecialBehaviourId); // Function Archives.ContextualQuestUtilities.PlayerHasAssociatedQuest // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b4b640
};

// Class Archives.CustomDistanceEvaluatorCondition
// Size: 0x50 (Inherited: 0x48)
struct UCustomDistanceEvaluatorCondition : UEvaluatorCondition {
	char pad_48[0x8]; // 0x48(0x08)
};

// Class Archives.CustomValueLessThanAmountQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UCustomValueLessThanAmountQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.CustomValueMoreThanAmountQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UCustomValueMoreThanAmountQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.CustomValuePercentQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UCustomValuePercentQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.CustomValueQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UCustomValueQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.DifferentSurvivorsNearMeQEEvaluator
// Size: 0xe8 (Inherited: 0x90)
struct UDifferentSurvivorsNearMeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
	struct TSet<struct ADBDPlayer*> _foundSurvivors; // 0x98(0x50)
};

// Class Archives.DoBeforeEscapeQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UDoBeforeEscapeQEEvaluator : UQuestEventEvaluatorBase {

	void OnEscaped(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.DoBeforeEscapeQEEvaluator.OnEscaped // (Final|Native|Public|HasOutParms) // @ game+0x2b4a070
};

// Class Archives.DoBeforeHookQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UDoBeforeHookQEEvaluator : UQuestEventEvaluatorBase {

	void OnHooked(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.DoBeforeHookQEEvaluator.OnHooked // (Final|Native|Public|HasOutParms) // @ game+0x2b4a860
};

// Class Archives.DuringEndGameCollapseQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UDuringEndGameCollapseQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnEndGameCollapseStart(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.DuringEndGameCollapseQEEvaluator.OnEndGameCollapseStart // (Final|Native|Private|HasOutParms) // @ game+0x2b49f60
};

// Class Archives.EarnEmblemQualityQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UEarnEmblemQualityQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x10]; // 0x90(0x10)

	void OnFinishedPlaying(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.EarnEmblemQualityQEEvaluator.OnFinishedPlaying // (Final|Native|Public|HasOutParms) // @ game+0x2b4a290
};

// Class Archives.EndOfGameQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UEndOfGameQEEvaluator : UQuestEventEvaluatorBase {

	void OnFinishedPlaying(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.EndOfGameQEEvaluator.OnFinishedPlaying // (Final|Native|Public|HasOutParms) // @ game+0x2b4a3a0
};

// Class Archives.EventCountComparisonQEEvaluator
// Size: 0xc0 (Inherited: 0x90)
struct UEventCountComparisonQEEvaluator : UQuestEventEvaluatorBase {
	struct TArray<struct FGameplayTag> _incrementCountEvents; // 0x90(0x10)
	struct TArray<struct FGameplayTag> _resetCountEvents; // 0xa0(0x10)
	enum class EventCountComparisonOperator _comparisonOperator; // 0xb0(0x01)
	char pad_B1[0xf]; // 0xb1(0x0f)
};

// Class Archives.EventInTimeQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UEventInTimeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.EventOccurredBetweenQEEvaluator
// Size: 0xb0 (Inherited: 0x90)
struct UEventOccurredBetweenQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x10]; // 0x90(0x10)
	struct FGameplayTag _middleEvent; // 0xa0(0x0c)
	bool outerEventsDifferentTargets; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
};

// Class Archives.GeneratorsNeededCountQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UGeneratorsNeededCountQEEvaluator : UEndOfGameQEEvaluator {
};

// Class Archives.Glyph
// Size: 0x448 (Inherited: 0x318)
struct AGlyph : ASpecialBehaviourInteractable {
	struct TArray<struct ADBDPlayer*> _playersWithVisibility; // 0x318(0x10)
	struct TArray<struct ADBDPlayer*> _oldPlayersWithVisibility; // 0x328(0x10)
	struct FName _specialBehaviourId; // 0x338(0x0c)
	enum class EAllowedPlayerType _allowedPlayerType; // 0x344(0x01)
	char pad_345[0x3]; // 0x345(0x03)
	struct TWeakObjectPtr<struct ADBDPlayer> lastPlayerToStartInteraction; // 0x348(0x08)
	struct UGlyphInteraction* _glyphInteraction; // 0x350(0x08)
	struct UGlyphInteraction* _glyphInteractionKiller; // 0x358(0x08)
	struct UChargeableComponent* _glyphInteractionChargeable; // 0x360(0x08)
	struct UChargeableComponent* _glyphInteractionChargeableKiller; // 0x368(0x08)
	struct UInteractor* _glyphInteractor; // 0x370(0x08)
	struct UPrimitiveComponent* _glyphInteractionZone; // 0x378(0x08)
	struct UDBDOutlineComponent* _outlineComponent; // 0x380(0x08)
	struct UStaticMeshComponent* _glyphMesh; // 0x388(0x08)
	struct UNearTrackedActorComponent* _nearTrackedActorComponent; // 0x390(0x08)
	struct FGameplayTag _associatedSurvivorScoreEvent; // 0x398(0x0c)
	struct FGameplayTag _associatedKillerScoreEvent; // 0x3a4(0x0c)
	struct FDBDTunableRowHandle _glyphInteractionSecondsToCharge; // 0x3b0(0x28)
	struct FDBDTunableRowHandle _glyphInteractionSecondsToChargeKiller; // 0x3d8(0x28)
	struct FDBDTunableRowHandle _glyphDetectionRange; // 0x400(0x28)
	struct FLinearColor _auraColorWhileInteracting; // 0x428(0x10)
	struct TArray<struct ADBDPlayer*> _playersThatInteractedWithGlyph; // 0x438(0x10)

	void OnRep_PlayersWithVisibility(); // Function Archives.Glyph.OnRep_PlayersWithVisibility // (Final|Native|Protected) // @ game+0x2b4aec0
	bool DoesLocalPlayerHaveVisibility(); // Function Archives.Glyph.DoesLocalPlayerHaveVisibility // (Final|Native|Protected|BlueprintCallable) // @ game+0x2b498a0
	void Cosmetic_OnStoppedInteracting(); // Function Archives.Glyph.Cosmetic_OnStoppedInteracting // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnStartedInteracting(struct ADBDPlayer* interactingPlayer, float interactionDuration); // Function Archives.Glyph.Cosmetic_OnStartedInteracting // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnInteractionCompleted(struct ADBDPlayer* interactingPlayer); // Function Archives.Glyph.Cosmetic_OnInteractionCompleted // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnGlyphVisibilityChanged(struct ADBDPlayer* interactingPlayer, bool IsVisible); // Function Archives.Glyph.Cosmetic_OnGlyphVisibilityChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnPlayerBreachedRangeThreshold(bool isWithinRange, struct AActor* trackedActor); // Function Archives.Glyph.Authority_OnPlayerBreachedRangeThreshold // (Final|Native|Private) // @ game+0x2b49760
	void Authority_OnIntroCompleted(); // Function Archives.Glyph.Authority_OnIntroCompleted // (Final|Native|Private) // @ game+0x2b49740
	void Authority_OnInteractionCompleted(struct ADBDPlayer* interactingPlayer); // Function Archives.Glyph.Authority_OnInteractionCompleted // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class Archives.GlyphInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct UGlyphInteraction : UChargeableInteractionDefinition {
	char pad_680[0x20]; // 0x680(0x20)
};

// Class Archives.HasEventHappenedEvaluatorCondition
// Size: 0x58 (Inherited: 0x48)
struct UHasEventHappenedEvaluatorCondition : UEvaluatorCondition {
	struct FGameplayTag _firstGameEvent; // 0x48(0x0c)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Archives.HasGameplayTagEvaluatorCondition
// Size: 0x58 (Inherited: 0x48)
struct UHasGameplayTagEvaluatorCondition : UEvaluatorCondition {
	struct TArray<struct FGameplayTag> _gameplayTagList; // 0x48(0x10)
};

// Class Archives.HasItemNoChargesQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UHasItemNoChargesQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.ItemRarityQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UItemRarityQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.HasItemRarityQEEvaluator
// Size: 0x98 (Inherited: 0x98)
struct UHasItemRarityQEEvaluator : UItemRarityQEEvaluator {
};

// Class Archives.HasItemTypeQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UHasItemTypeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.HasModifierOfTypeEvaluatorCondition
// Size: 0x58 (Inherited: 0x48)
struct UHasModifierOfTypeEvaluatorCondition : UEvaluatorCondition {
	struct TArray<struct FGameplayTag> _gameplayModifierList; // 0x48(0x10)
};

// Class Archives.HasStatusEffectEvaluatorCondition
// Size: 0x58 (Inherited: 0x48)
struct UHasStatusEffectEvaluatorCondition : UEvaluatorCondition {
	struct TArray<struct FName> _statusEffectList; // 0x48(0x10)
};

// Class Archives.NearKillerQEEvaluator
// Size: 0xc0 (Inherited: 0x90)
struct UNearKillerQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x30]; // 0x90(0x30)

	void OnRangeChanged(bool InRange); // Function Archives.NearKillerQEEvaluator.OnRangeChanged // (Final|Native|Private) // @ game+0x2b4ae30
};

// Class Archives.HideNearKillerQEEvaluator
// Size: 0xe8 (Inherited: 0xc0)
struct UHideNearKillerQEEvaluator : UNearKillerQEEvaluator {
	char pad_C0[0x28]; // 0xc0(0x28)

	void OnSlashHarpoonedCamper(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.HideNearKillerQEEvaluator.OnSlashHarpoonedCamper // (Final|Native|Private|HasOutParms) // @ game+0x2b4b100
	void OnHarpoonHit(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.HideNearKillerQEEvaluator.OnHarpoonHit // (Final|Native|Private|HasOutParms) // @ game+0x2b4a750
	void OnFinishedPlaying(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.HideNearKillerQEEvaluator.OnFinishedPlaying // (Final|Native|Public|HasOutParms) // @ game+0x2b4a4b0
	void OnChaseStart(struct ADBDPlayer* chasedSurvivor); // Function Archives.HideNearKillerQEEvaluator.OnChaseStart // (Final|Native|Private) // @ game+0x2b49bb0
	void OnChaseEnd(struct ADBDPlayer* chasedSurvivor, float chaseTime); // Function Archives.HideNearKillerQEEvaluator.OnChaseEnd // (Final|Native|Private) // @ game+0x2b49ae0
	void OnCamperBreakFreeFromHarpoon(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.HideNearKillerQEEvaluator.OnCamperBreakFreeFromHarpoon // (Final|Native|Private|HasOutParms) // @ game+0x2b499d0
};

// Class Archives.MaxEventCountQEEvaluator
// Size: 0xc8 (Inherited: 0x90)
struct UMaxEventCountQEEvaluator : UQuestEventEvaluatorBase {
	struct TArray<struct FGameplayTag> _incrementEventCount; // 0x90(0x10)
	struct TArray<struct FGameplayTag> _decrementEventCount; // 0xa0(0x10)
	struct TArray<struct FGameplayTag> _stopEventCount; // 0xb0(0x10)
	char pad_C0[0x8]; // 0xc0(0x08)

	void OnStopEventCount(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.MaxEventCountQEEvaluator.OnStopEventCount // (Final|Native|Private|HasOutParms) // @ game+0x2b4b210
	void OnIncrementEventCount(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.MaxEventCountQEEvaluator.OnIncrementEventCount // (Final|Native|Private|HasOutParms) // @ game+0x2b4a970
	void OnDecrementEventCount(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.MaxEventCountQEEvaluator.OnDecrementEventCount // (Final|Native|Private|HasOutParms) // @ game+0x2b49e50
};

// Class Archives.HitDifferentInFrenzyMaxCountQEEvaluator
// Size: 0x118 (Inherited: 0xc8)
struct UHitDifferentInFrenzyMaxCountQEEvaluator : UMaxEventCountQEEvaluator {
	struct TSet<struct TWeakObjectPtr<struct AActor>> _targetList; // 0xc8(0x50)
};

// Class Archives.SurvivorHookSameTimeQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct USurvivorHookSameTimeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnSurvivorUnhooked(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.SurvivorHookSameTimeQEEvaluator.OnSurvivorUnhooked // (Native|Protected|HasOutParms) // @ game+0x2b4b530
	void OnSurvivorHooked(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.SurvivorHookSameTimeQEEvaluator.OnSurvivorHooked // (Native|Protected|HasOutParms) // @ game+0x2b4b3a0
};

// Class Archives.HookSameTimeBasementQEEvaluator
// Size: 0x98 (Inherited: 0x98)
struct UHookSameTimeBasementQEEvaluator : USurvivorHookSameTimeQEEvaluator {
};

// Class Archives.InDirectionOfKillerQEEvaluator
// Size: 0xa8 (Inherited: 0x90)
struct UInDirectionOfKillerQEEvaluator : UQuestEventEvaluatorBase {
	struct ADBDPlayer* _killer; // 0x90(0x08)
	char pad_98[0x10]; // 0x98(0x10)
};

// Class Archives.InflictMadnessBaseQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UInflictMadnessBaseQEEvaluator : UQuestEventEvaluatorBase {
	int32_t _requiredTier; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// Class Archives.InjuredDyingHookManyQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UInjuredDyingHookManyQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.InjuredDyingMultipleQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UInjuredDyingMultipleQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.InLockerNearKillerQEEvaluator
// Size: 0xc8 (Inherited: 0xc0)
struct UInLockerNearKillerQEEvaluator : UNearKillerQEEvaluator {
	char pad_C0[0x8]; // 0xc0(0x08)

	void OnClosetHideExit(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.InLockerNearKillerQEEvaluator.OnClosetHideExit // (Final|Native|Private|HasOutParms) // @ game+0x2b49d40
	void OnClosetHideEnter(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.InLockerNearKillerQEEvaluator.OnClosetHideEnter // (Final|Native|Private|HasOutParms) // @ game+0x2b49c30
};

// Class Archives.InstigatorHookCountQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UInstigatorHookCountQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.InstigatorInBasementQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UInstigatorInBasementQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.InstigatorInBasementPercentQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UInstigatorInBasementPercentQEEvaluator : UInstigatorInBasementQEEvaluator {
};

// Class Archives.IsInteractingEvaluatorCondition
// Size: 0x48 (Inherited: 0x48)
struct UIsInteractingEvaluatorCondition : UEvaluatorCondition {
};

// Class Archives.ItemConsumedQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UItemConsumedQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnItemConsumed(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.ItemConsumedQEEvaluator.OnItemConsumed // (Final|Native|Private|HasOutParms) // @ game+0x2b4aa80
};

// Class Archives.ItemPerformedQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UItemPerformedQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.ItemPerformedPercentQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UItemPerformedPercentQEEvaluator : UItemPerformedQEEvaluator {
};

// Class Archives.ItemUsedQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UItemUsedQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnItemUsed(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.ItemUsedQEEvaluator.OnItemUsed // (Final|Native|Private|HasOutParms) // @ game+0x2b4aca0
};

// Class Archives.KillerNearRedHerringGeneratorQEEvaluator
// Size: 0xf0 (Inherited: 0x90)
struct UKillerNearRedHerringGeneratorQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x60]; // 0x90(0x60)
};

// Class Archives.LivingSurvivorsCountQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct ULivingSurvivorsCountQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x10]; // 0x90(0x10)

	void OnSurvivorRemoved(struct ACamperPlayer* survivorRemoved); // Function Archives.LivingSurvivorsCountQEEvaluator.OnSurvivorRemoved // (Final|Native|Private) // @ game+0x2b4b4b0
	void OnSurvivorAdded(struct ACamperPlayer* survivorAdded); // Function Archives.LivingSurvivorsCountQEEvaluator.OnSurvivorAdded // (Final|Native|Private) // @ game+0x2b4b320
};

// Class Archives.MaxSameTargetQEEvaluator
// Size: 0xe0 (Inherited: 0x90)
struct UMaxSameTargetQEEvaluator : UQuestEventEvaluatorBase {
	struct TMap<struct TWeakObjectPtr<struct AActor>, int32_t> _targetList; // 0x90(0x50)
};

// Class Archives.MultipleEventsInTimeFrameQEEvaluator
// Size: 0xa8 (Inherited: 0x90)
struct UMultipleEventsInTimeFrameQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x18]; // 0x90(0x18)
};

// Class Archives.NearMeEvaluatorCondition
// Size: 0x50 (Inherited: 0x48)
struct UNearMeEvaluatorCondition : UEvaluatorCondition {
	char pad_48[0x4]; // 0x48(0x04)
	bool _questOwnerCanBeSubjectOfEvent; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// Class Archives.NearPalletVaultWallQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UNearPalletVaultWallQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.NearTrackedActorComponent
// Size: 0xe0 (Inherited: 0xb8)
struct UNearTrackedActorComponent : UActorComponent {
	struct FMulticastInlineDelegate IsWithinRangeDelegate; // 0xb8(0x10)
	float _distanceThreshold; // 0xc8(0x04)
	char pad_CC[0x14]; // 0xcc(0x14)

	void StopTrackingActor(struct AActor* Actor); // Function Archives.NearTrackedActorComponent.StopTrackingActor // (Final|Native|Public|BlueprintCallable) // @ game+0x2b4b900
	void StartTrackingActor(struct AActor* Actor); // Function Archives.NearTrackedActorComponent.StartTrackingActor // (Final|Native|Public|BlueprintCallable) // @ game+0x2b4b880
	void SetDistanceThreshold(float value); // Function Archives.NearTrackedActorComponent.SetDistanceThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0x2b4b800
	void OnIsWithinRangeChanged__DelegateSignature(bool isWithinRange, struct AActor* trackedActor); // DelegateFunction Archives.NearTrackedActorComponent.OnIsWithinRangeChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	bool IsActorWithinRange(struct AActor* Actor); // Function Archives.NearTrackedActorComponent.IsActorWithinRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b49940
};

// Class Archives.NurseChainBlinkNumberQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UNurseChainBlinkNumberQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.OniDashHitDiffInTimeQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UOniDashHitDiffInTimeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
	struct AActor* _previousTarget; // 0x98(0x08)
};

// Class Archives.PlagueCorruptUniqueTargetsQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UPlagueCorruptUniqueTargetsQEEvaluator : UQuestEventEvaluatorBase {
	struct AActor* _previousTarget; // 0x90(0x08)
	char pad_98[0x8]; // 0x98(0x08)
};

// Class Archives.QuestEventsHandler
// Size: 0x100 (Inherited: 0xb8)
struct UQuestEventsHandler : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TArray<struct UQuestEventEvaluatorBase*> _evaluatorList; // 0xc0(0x10)
	char pad_D0[0x30]; // 0xd0(0x30)

	void OnPlayergameStateChanged(enum class EGameState GameState); // Function Archives.QuestEventsHandler.OnPlayergameStateChanged // (Final|Native|Private) // @ game+0x2b4adb0
	void OnGameEnded(enum class EEndGameReason reason); // Function Archives.QuestEventsHandler.OnGameEnded // (Final|Native|Private) // @ game+0x2b4a6d0
	void OnFinishedPlaying(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.QuestEventsHandler.OnFinishedPlaying // (Final|Native|Private|HasOutParms) // @ game+0x2b4a5c0
	void DBD_ShowInGameCurrentQuestInfos(); // Function Archives.QuestEventsHandler.DBD_ShowInGameCurrentQuestInfos // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_InGameAddProgressionToCurrentQuest(int32_t amount); // Function Archives.QuestEventsHandler.DBD_InGameAddProgressionToCurrentQuest // (Final|Exec|Native|Public) // @ game+0x2b49820
};

// Class Archives.QuestEventsHandlerTest
// Size: 0x108 (Inherited: 0x100)
struct UQuestEventsHandlerTest : UQuestEventsHandler {
	struct ADBDPlayer* _dbdPlayer; // 0x100(0x08)
};

// Class Archives.QuestEventsHandlerUtilities
// Size: 0x30 (Inherited: 0x30)
struct UQuestEventsHandlerUtilities : UBlueprintFunctionLibrary {

	void InitializeQuestEventHandler(struct UQuestEventsHandler* QuestEventsHandler); // Function Archives.QuestEventsHandlerUtilities.InitializeQuestEventHandler // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2b498d0
};

// Class Archives.RecentlyActiveStateTagEvaluatorCondition
// Size: 0x88 (Inherited: 0x48)
struct URecentlyActiveStateTagEvaluatorCondition : UEvaluatorCondition {
	char pad_48[0x4]; // 0x48(0x04)
	struct FGameplayTag _stateTag; // 0x4c(0x0c)
	char pad_58[0x30]; // 0x58(0x30)
};

// Class Archives.RepairCoopQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct URepairCoopQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.ReturnTheFavorQEEvaluator
// Size: 0xe0 (Inherited: 0x90)
struct UReturnTheFavorQEEvaluator : UQuestEventEvaluatorBase {
	struct TSet<struct TWeakObjectPtr<struct ADBDPlayer>> _instigatorList; // 0x90(0x50)
};

// Class Archives.ScreamSpecialCaseQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UScreamSpecialCaseQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.SearchItemRarityQEEvaluator
// Size: 0x98 (Inherited: 0x98)
struct USearchItemRarityQEEvaluator : UItemRarityQEEvaluator {

	void OnItemSpawnedFromChest(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.SearchItemRarityQEEvaluator.OnItemSpawnedFromChest // (Final|Native|Public|HasOutParms) // @ game+0x2b4ab90
};

// Class Archives.SecondHookStageReachedQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct USecondHookStageReachedQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.SkillCheckConsecutiveQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct USkillCheckConsecutiveQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)

	void OnSkillCheckSuccess(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.SkillCheckConsecutiveQEEvaluator.OnSkillCheckSuccess // (Final|Native|Private|HasOutParms) // @ game+0x2b4aff0
	void OnSkillCheckFail(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function Archives.SkillCheckConsecutiveQEEvaluator.OnSkillCheckFail // (Final|Native|Private|HasOutParms) // @ game+0x2b4aee0
};

// Class Archives.SlasherIsCarryingQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct USlasherIsCarryingQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.StateTagEvaluatorCondition
// Size: 0x58 (Inherited: 0x48)
struct UStateTagEvaluatorCondition : UEvaluatorCondition {
	struct FGameplayTag _gameplayTag; // 0x48(0x0c)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Archives.SurvivorNearMeEvaluatorCondition
// Size: 0x50 (Inherited: 0x48)
struct USurvivorNearMeEvaluatorCondition : UEvaluatorCondition {
	char pad_48[0x8]; // 0x48(0x08)
};

// Class Archives.TargetInBasementQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UTargetInBasementQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.TargetIsObsessionQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UTargetIsObsessionQEEvaluator : UQuestEventEvaluatorBase {
};

// Class Archives.TargetNearPalletVaultWallQEEvaluator
// Size: 0x98 (Inherited: 0x90)
struct UTargetNearPalletVaultWallQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class Archives.TargetOfEventRecentlyQEEvaluator
// Size: 0xa8 (Inherited: 0x90)
struct UTargetOfEventRecentlyQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x8]; // 0x90(0x08)
	struct FGameplayTag _firstGameEvent; // 0x98(0x0c)
	bool _secondEventOnSelf; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
};

// Class Archives.TargetTriggeredEventRecentlyQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UTargetTriggeredEventRecentlyQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x4]; // 0x90(0x04)
	struct FGameplayTag _gameEvent; // 0x94(0x0c)
};

// Class Archives.TotemsAtEndTrialCountQEEvaluator
// Size: 0x90 (Inherited: 0x90)
struct UTotemsAtEndTrialCountQEEvaluator : UEndOfGameQEEvaluator {
};

// Class Archives.UniqueTargetIncrementQEEvaluator
// Size: 0xe0 (Inherited: 0x90)
struct UUniqueTargetIncrementQEEvaluator : UQuestEventEvaluatorBase {
	struct TSet<struct TWeakObjectPtr<struct AActor>> _targetList; // 0x90(0x50)
};

// Class Archives.UniqueTargetsInTimeQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UUniqueTargetsInTimeQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x10]; // 0x90(0x10)
};

// Class Archives.WithPulledUpPalletQEEvaluator
// Size: 0xa0 (Inherited: 0x90)
struct UWithPulledUpPalletQEEvaluator : UQuestEventEvaluatorBase {
	char pad_90[0x10]; // 0x90(0x10)
};

