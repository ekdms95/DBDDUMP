// Enum Archives.EventCountComparisonOperator
enum class EventCountComparisonOperator : uint8 {
	EqualTo,
	GreaterThan,
	GreaterThanEqualTo,
	LessThan,
	LessThanEqualTo,
	EventCountComparisonOperator_MAX,
};

// Enum Archives.EAllowedPlayerType
enum class EAllowedPlayerType : uint8 {
	All,
	KillerOnly,
	SurvivorOnly,
	EAllowedPlayerType_MAX,
};

