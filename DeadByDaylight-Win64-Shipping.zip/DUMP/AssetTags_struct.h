// Enum AssetTags.ECollectionScriptingShareType
enum class ECollectionScriptingShareType : uint8 {
	Local,
	Private,
	Shared,
	ECollectionScriptingShareType_MAX,
};

