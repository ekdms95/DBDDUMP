// BlueprintGeneratedClass Audio.Audio_C
// Size: 0x240 (Inherited: 0x238)
struct AAudio_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)

	void ReceiveBeginPlay(); // Function Audio.Audio_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_Audio(int32_t EntryPoint); // Function Audio.Audio_C.ExecuteUbergraph_Audio // (Final|UbergraphFunction) // @ game+0x3873200
};

