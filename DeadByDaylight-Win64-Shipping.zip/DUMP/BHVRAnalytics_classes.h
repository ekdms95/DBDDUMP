// Class BHVRAnalytics.BHVRAnalytics
// Size: 0x30 (Inherited: 0x30)
struct UBHVRAnalytics : UBlueprintFunctionLibrary {
};

