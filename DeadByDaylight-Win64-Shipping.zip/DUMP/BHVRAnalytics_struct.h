// ScriptStruct BHVRAnalytics.BaseSingleStructIndexAnalytics
// Size: 0x18 (Inherited: 0x00)
struct FBaseSingleStructIndexAnalytics {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString SessionGuid; // 0x08(0x10)
};

