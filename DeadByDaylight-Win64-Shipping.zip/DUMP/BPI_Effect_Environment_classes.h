// BlueprintGeneratedClass BPI_Effect_Environment.BPI_Effect_Environment_C
// Size: 0x30 (Inherited: 0x30)
struct UBPI_Effect_Environment_C : UInterface {

	void KNY_StartSnowstorm(); // Function BPI_Effect_Environment.BPI_Effect_Environment_C.KNY_StartSnowstorm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

