// BlueprintGeneratedClass BP_BloodwebGenerator.BP_BloodwebGenerator_C
// Size: 0xf8 (Inherited: 0xf0)
struct UBP_BloodwebGenerator_C : UBloodwebGenerator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xf0(0x08)

	void ReceiveBeginPlay_2(); // Function BP_BloodwebGenerator.BP_BloodwebGenerator_C.ReceiveBeginPlay_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ReceiveActorBeginOverlap_2(struct AActor* OtherActor); // Function BP_BloodwebGenerator.BP_BloodwebGenerator_C.ReceiveActorBeginOverlap_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ReceiveTick_2(float DeltaSeconds); // Function BP_BloodwebGenerator.BP_BloodwebGenerator_C.ReceiveTick_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_BP_BloodwebGenerator(int32_t EntryPoint); // Function BP_BloodwebGenerator.BP_BloodwebGenerator_C.ExecuteUbergraph_BP_BloodwebGenerator // (Final|UbergraphFunction) // @ game+0x3873200
};

