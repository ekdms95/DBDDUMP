// BlueprintGeneratedClass BP_BloodwebManager.BP_BloodwebManager_C
// Size: 0xd8 (Inherited: 0xd8)
struct UBP_BloodwebManager_C : UBloodwebManager {
};

