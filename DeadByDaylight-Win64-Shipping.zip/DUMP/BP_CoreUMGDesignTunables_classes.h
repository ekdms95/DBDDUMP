// BlueprintGeneratedClass BP_CoreUMGDesignTunables.BP_CoreUMGDesignTunables_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_CoreUMGDesignTunables_C : UDBDCoreUMGDesignTunables {
};

