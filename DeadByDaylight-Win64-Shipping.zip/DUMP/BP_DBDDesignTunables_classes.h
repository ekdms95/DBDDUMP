// BlueprintGeneratedClass BP_DBDDesignTunables.BP_DBDDesignTunables_C
// Size: 0x240 (Inherited: 0x240)
struct UBP_DBDDesignTunables_C : UDBDDesignTunables {
};

