// BlueprintGeneratedClass BP_DBDGameInstance.BP_DBDGameInstance_C
// Size: 0x980 (Inherited: 0x980)
struct UBP_DBDGameInstance_C : UDBDGameInstance {
};

