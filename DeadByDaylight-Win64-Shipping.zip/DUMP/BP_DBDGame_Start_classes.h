// BlueprintGeneratedClass BP_DBDGame_Start.BP_DBDGame_Start_C
// Size: 0x3e0 (Inherited: 0x3d8)
struct ABP_DBDGame_Start_C : ADBDGame_Start {
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)
};

