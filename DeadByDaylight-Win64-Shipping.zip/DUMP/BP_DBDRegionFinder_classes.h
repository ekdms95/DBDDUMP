// BlueprintGeneratedClass BP_DBDRegionFinder.BP_DBDRegionFinder_C
// Size: 0xa8 (Inherited: 0xa8)
struct UBP_DBDRegionFinder_C : URegionFinder {

	void ConstructionScript(); // Function BP_DBDRegionFinder.BP_DBDRegionFinder_C.ConstructionScript // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

