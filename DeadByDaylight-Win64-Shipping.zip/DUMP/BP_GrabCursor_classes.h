// WidgetBlueprintGeneratedClass BP_GrabCursor.BP_GrabCursor_C
// Size: 0x270 (Inherited: 0x268)
struct UBP_GrabCursor_C : UCoreCursor {
	struct UImage* Image_18; // 0x268(0x08)
};

