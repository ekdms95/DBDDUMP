// WidgetBlueprintGeneratedClass BP_HandCursor.BP_HandCursor_C
// Size: 0x270 (Inherited: 0x268)
struct UBP_HandCursor_C : UCoreCursor {
	struct UImage* Image_11; // 0x268(0x08)
};

