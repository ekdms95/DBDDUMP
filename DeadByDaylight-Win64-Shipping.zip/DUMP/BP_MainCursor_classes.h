// WidgetBlueprintGeneratedClass BP_MainCursor.BP_MainCursor_C
// Size: 0x270 (Inherited: 0x268)
struct UBP_MainCursor_C : UCoreCursor {
	struct UImage* Image_80; // 0x268(0x08)
};

