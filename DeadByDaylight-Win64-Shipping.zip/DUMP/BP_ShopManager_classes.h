// BlueprintGeneratedClass BP_ShopManager.BP_ShopManager_C
// Size: 0x5f8 (Inherited: 0x5f8)
struct UBP_ShopManager_C : UShopManager {
};

