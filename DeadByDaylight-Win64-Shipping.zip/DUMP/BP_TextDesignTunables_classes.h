// BlueprintGeneratedClass BP_TextDesignTunables.BP_TextDesignTunables_C
// Size: 0x120 (Inherited: 0x118)
struct UBP_TextDesignTunables_C : UDBDTextDesignTunables {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x118(0x08)

	void ReceiveBeginPlay(); // Function BP_TextDesignTunables.BP_TextDesignTunables_C.ReceiveBeginPlay // (BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ReceiveTick(float DeltaSeconds); // Function BP_TextDesignTunables.BP_TextDesignTunables_C.ReceiveTick // (BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_BP_TextDesignTunables(int32_t EntryPoint); // Function BP_TextDesignTunables.BP_TextDesignTunables_C.ExecuteUbergraph_BP_TextDesignTunables // (Final|UbergraphFunction) // @ game+0x3873200
};

