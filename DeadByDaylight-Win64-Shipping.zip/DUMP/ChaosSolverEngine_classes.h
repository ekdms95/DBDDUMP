// Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UChaosDebugDrawComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UChaosEventListenerComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x278 (Inherited: 0xc0)
struct UChaosGameplayEventDispatcher : UChaosEventListenerComponent {
	char pad_C0[0x110]; // 0xc0(0x110)
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations; // 0x1d0(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations; // 0x220(0x50)
	char pad_270[0x8]; // 0x270(0x08)
};

// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x30 (Inherited: 0x30)
struct UChaosNotifyHandlerInterface : UInterface {
};

// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x30 (Inherited: 0x30)
struct UChaosSolverEngineBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo PhysicsCollision); // Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x56c9410
};

// Class ChaosSolverEngine.ChaosSolver
// Size: 0x30 (Inherited: 0x30)
struct UChaosSolver : UObject {
};

// Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x2b8 (Inherited: 0x230)
struct AChaosSolverActor : AActor {
	float TimeStepMultiplier; // 0x230(0x04)
	int32_t CollisionIterations; // 0x234(0x04)
	int32_t PushOutIterations; // 0x238(0x04)
	int32_t PushOutPairIterations; // 0x23c(0x04)
	float ClusterConnectionFactor; // 0x240(0x04)
	enum class EClusterConnectionTypeEnum ClusterUnionConnectionType; // 0x244(0x01)
	bool DoGenerateCollisionData; // 0x245(0x01)
	char pad_246[0x2]; // 0x246(0x02)
	struct FSolverCollisionFilterSettings CollisionFilterSettings; // 0x248(0x10)
	bool DoGenerateBreakingData; // 0x258(0x01)
	char pad_259[0x3]; // 0x259(0x03)
	struct FSolverBreakingFilterSettings BreakingFilterSettings; // 0x25c(0x10)
	bool DoGenerateTrailingData; // 0x26c(0x01)
	char pad_26D[0x3]; // 0x26d(0x03)
	struct FSolverTrailingFilterSettings TrailingFilterSettings; // 0x270(0x10)
	bool bHasFloor; // 0x280(0x01)
	char pad_281[0x3]; // 0x281(0x03)
	float FloorHeight; // 0x284(0x04)
	float MassScale; // 0x288(0x04)
	bool bGenerateContactGraph; // 0x28c(0x01)
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl; // 0x28d(0x03)
	struct UBillboardComponent* SpriteComponent; // 0x290(0x08)
	char pad_298[0x18]; // 0x298(0x18)
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // 0x2b0(0x08)

	void SetSolverActive(bool bActive); // Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive // (Native|Public|BlueprintCallable) // @ game+0x3279000
	void SetAsCurrentWorldSolver(); // Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver // (Final|Native|Public|BlueprintCallable) // @ game+0x56c9500
};

// Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x70 (Inherited: 0x48)
struct UChaosSolverSettings : UDeveloperSettings {
	char pad_48[0x8]; // 0x48(0x08)
	struct FSoftClassPath DefaultChaosSolverActorClass; // 0x50(0x20)
};

