// Class CommandletPlugin.CatalogValidationCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UCatalogValidationCommandlet : UCommandlet {
};

// Class CommandletPlugin.CustomizationValidationCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UCustomizationValidationCommandlet : UCommandlet {
};

// Class CommandletPlugin.DataTableToCsvCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UDataTableToCsvCommandlet : UCommandlet {
};

// Class CommandletPlugin.FixCustomizationAccessorySocketCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UFixCustomizationAccessorySocketCommandlet : UCommandlet {
};

// Class CommandletPlugin.GenerateCurveFloatNetIdTableCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UGenerateCurveFloatNetIdTableCommandlet : UCommandlet {
};

// Class CommandletPlugin.GenerateStoreCustomizationExclusionFileCommandlet
// Size: 0x90 (Inherited: 0x88)
struct UGenerateStoreCustomizationExclusionFileCommandlet : UCommandlet {
	char pad_88[0x8]; // 0x88(0x08)
};

// Class CommandletPlugin.JournalsValidationCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UJournalsValidationCommandlet : UCommandlet {
};

// Class CommandletPlugin.LoadoutExportCommandlet
// Size: 0xb0 (Inherited: 0x88)
struct ULoadoutExportCommandlet : UCommandlet {
	char pad_88[0x28]; // 0x88(0x28)
};

// Class CommandletPlugin.StoryDescriptionValidationCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UStoryDescriptionValidationCommandlet : UCommandlet {
};

// Class CommandletPlugin.UpdateJournalVignetteCinematicsCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UUpdateJournalVignetteCinematicsCommandlet : UCommandlet {
};

