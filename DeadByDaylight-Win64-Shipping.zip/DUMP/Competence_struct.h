// ScriptStruct Competence.GameplayFlagCache
// Size: 0xa0 (Inherited: 0x00)
struct FGameplayFlagCache {
	char pad_0[0xa0]; // 0x00(0xa0)
};

// ScriptStruct Competence.GameplayModifierData
// Size: 0x30 (Inherited: 0x00)
struct FGameplayModifierData {
	struct TArray<struct UBaseModifierCondition*> Conditions; // 0x00(0x10)
	struct TArray<struct FGamePlayModifier> Modifiers; // 0x10(0x10)
	struct TArray<struct FGameplayTag> TaggedFlags; // 0x20(0x10)
};

// ScriptStruct Competence.GamePlayModifier
// Size: 0x10 (Inherited: 0x00)
struct FGamePlayModifier {
	struct FGameplayTag Type; // 0x00(0x0c)
	float ModifierValue; // 0x0c(0x04)
};

// ScriptStruct Competence.GameplayModifierCache
// Size: 0xa0 (Inherited: 0x00)
struct FGameplayModifierCache {
	char pad_0[0xa0]; // 0x00(0xa0)
};

