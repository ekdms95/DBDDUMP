// BlueprintGeneratedClass ConsecutiveWakeUpPenaltyProficiency.ConsecutiveWakeUpPenaltyProficiency_C
// Size: 0x48 (Inherited: 0x48)
struct UConsecutiveWakeUpPenaltyProficiency_C : UInteractionProficiency {

	float GetValue(struct UChargeableInteractionDefinition* chargeableInteraction, struct ADBDPlayer* Player); // Function ConsecutiveWakeUpPenaltyProficiency.ConsecutiveWakeUpPenaltyProficiency_C.GetValue // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
};

