// Enum CoreUtilities.RealCaseGapEnum
enum class RealCaseGapEnum : uint8 {
	None,
	SavefileDeserializationFailure,
	EarnPlayerXpParamError,
	RealCaseGapEnum_MAX,
};

// Enum CoreUtilities.OutOfOrderEnum
enum class OutOfOrderEnum : uint8 {
	Value1,
	Value2,
	Value3,
	OutOfOrderEnum_MAX,
};

// Enum CoreUtilities.GapEnum
enum class GapEnum : uint8 {
	Value1,
	Value2,
	Value3,
	GapEnum_MAX,
};

// Enum CoreUtilities.SimpleEnum
enum class SimpleEnum : uint8 {
	Value1,
	Value2,
	Value3,
	SimpleEnum_MAX,
};

// ScriptStruct CoreUtilities.DelegateHandleWrapper
// Size: 0x08 (Inherited: 0x00)
struct FDelegateHandleWrapper {
	char pad_0[0x8]; // 0x00(0x08)
};

