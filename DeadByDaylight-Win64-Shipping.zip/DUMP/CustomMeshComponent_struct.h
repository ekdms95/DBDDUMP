// ScriptStruct CustomMeshComponent.CustomMeshTriangle
// Size: 0x24 (Inherited: 0x00)
struct FCustomMeshTriangle {
	struct FVector Vertex0; // 0x00(0x0c)
	struct FVector Vertex1; // 0x0c(0x0c)
	struct FVector Vertex2; // 0x18(0x0c)
};

