// ScriptStruct Customization.CharmIdSlot
// Size: 0x10 (Inherited: 0x00)
struct FCharmIdSlot {
	int8_t SlotIndex; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName CharmId; // 0x04(0x0c)
};

// ScriptStruct Customization.PlayerCustomization
// Size: 0x20 (Inherited: 0x00)
struct FPlayerCustomization {
	struct TArray<struct FName> _customizationMeshes; // 0x00(0x10)
	struct TArray<struct FCharmIdSlot> _customizationCharms; // 0x10(0x10)
};

