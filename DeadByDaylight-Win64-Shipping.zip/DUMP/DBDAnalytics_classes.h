// Class DBDAnalytics.AnalyticsDelegates
// Size: 0x38 (Inherited: 0x38)
struct UAnalyticsDelegates : UGameInstanceSubsystem {
};

// Class DBDAnalytics.AnalyticsFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UAnalyticsFunctionLibrary : UBlueprintFunctionLibrary {

	void StartSurvivorTutorialSectionAnalytics(struct UObject* WorldContextObject, enum class ESurvivorTutorialSections tutorialSection); // Function DBDAnalytics.AnalyticsFunctionLibrary.StartSurvivorTutorialSectionAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba7670
	void StartKillerTutorialSectionAnalytics(struct UObject* WorldContextObject, enum class EKillerTutorialSections tutorialSection); // Function DBDAnalytics.AnalyticsFunctionLibrary.StartKillerTutorialSectionAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba75c0
	void IncrementHookSpawned(); // Function DBDAnalytics.AnalyticsFunctionLibrary.IncrementHookSpawned // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba74c0
	void EndSurvivorTutorialSectionAnalytics(struct UObject* WorldContextObject, enum class ESurvivorTutorialSections tutorialSection); // Function DBDAnalytics.AnalyticsFunctionLibrary.EndSurvivorTutorialSectionAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba73a0
	void EndKillerTutorialSectionAnalytics(struct UObject* WorldContextObject, enum class EKillerTutorialSections tutorialSection); // Function DBDAnalytics.AnalyticsFunctionLibrary.EndKillerTutorialSectionAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba72f0
};

// Class DBDAnalytics.AnalyticsManager
// Size: 0x2ff0 (Inherited: 0x38)
struct UAnalyticsManager : UAbstractAnalyticsManager {
	char pad_38[0x2fb8]; // 0x38(0x2fb8)
};

// Class DBDAnalytics.ClosetAnalytics
// Size: 0x30 (Inherited: 0x30)
struct UClosetAnalytics : UBlueprintFunctionLibrary {

	void RecordClosetSearchSuccess(struct ASlasherPlayer* killer); // Function DBDAnalytics.ClosetAnalytics.RecordClosetSearchSuccess // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba7550
	void RecordClosetSearchFail(struct ASlasherPlayer* killer); // Function DBDAnalytics.ClosetAnalytics.RecordClosetSearchFail // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba74e0
	void IncrementClosetEnter(struct ACamperPlayer* survivor); // Function DBDAnalytics.ClosetAnalytics.IncrementClosetEnter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2ba7450
};

// Class DBDAnalytics.EmblemAnalyticsComponent
// Size: 0x170 (Inherited: 0xb8)
struct UEmblemAnalyticsComponent : UActorComponent {
	char pad_B8[0xb8]; // 0xb8(0xb8)
};

// Class DBDAnalytics.InteractionAnalyticsComponent
// Size: 0x140 (Inherited: 0xb8)
struct UInteractionAnalyticsComponent : UActorComponent {
	char pad_B8[0x88]; // 0xb8(0x88)
};

// Class DBDAnalytics.PerkAnalyticsLibrary
// Size: 0x30 (Inherited: 0x30)
struct UPerkAnalyticsLibrary : UBlueprintFunctionLibrary {

	void SendTinkererUndetectableInterruptAnalytics(struct ADBDPlayer* interruptedPlayer, struct ADBDPlayer* Slasher); // Function DBDAnalytics.PerkAnalyticsLibrary.SendTinkererUndetectableInterruptAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb22b0
	void SendTinkererUndetectableHitNearGeneratorAnalytics(struct ADBDPlayer* hitPlayer, struct ADBDPlayer* Slasher); // Function DBDAnalytics.PerkAnalyticsLibrary.SendTinkererUndetectableHitNearGeneratorAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb2200
	void SendLightbornAuraRevealedAnalytics(struct ADBDPlayer* revealedPlayer, struct ADBDPlayer* Slasher); // Function DBDAnalytics.PerkAnalyticsLibrary.SendLightbornAuraRevealedAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb2150
	void SendKnockoutSurvivorFoundAnalytics(struct ADBDPlayer* findingSurvivor, struct ADBDPlayer* foundSurvivor); // Function DBDAnalytics.PerkAnalyticsLibrary.SendKnockoutSurvivorFoundAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb20a0
	void SendFranklinsHitSurvivorNearDroppedItemAnalytics(struct ADBDPlayer* hitSurvivor, struct ADBDPlayer* Slasher); // Function DBDAnalytics.PerkAnalyticsLibrary.SendFranklinsHitSurvivorNearDroppedItemAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1ff0
	void SendFranklinsConsumeItemAnalytics(struct ADBDPlayer* previousOwner); // Function DBDAnalytics.PerkAnalyticsLibrary.SendFranklinsConsumeItemAnalytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1f80
};

// Class DBDAnalytics.PigAnalytics
// Size: 0x30 (Inherited: 0x30)
struct UPigAnalytics : UBlueprintFunctionLibrary {

	void RecordRBTSearch(struct ACamperPlayer* searchingPlayer, bool success); // Function DBDAnalytics.PigAnalytics.RecordRBTSearch // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1ec0
	void OnRBTAttached_Analytics(struct ASlasherPlayer* attacher, struct ACamperPlayer* attachee); // Function DBDAnalytics.PigAnalytics.OnRBTAttached_Analytics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1e10
	void IncrementRBTTimerActived(struct ACamperPlayer* attachedPlayer); // Function DBDAnalytics.PigAnalytics.IncrementRBTTimerActived // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1da0
	void IncrementRBTKilledCount(struct ACamperPlayer* playerKilled, bool killedByExecutionZone); // Function DBDAnalytics.PigAnalytics.IncrementRBTKilledCount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1ce0
};

// Class DBDAnalytics.PulldownAnalytics
// Size: 0x30 (Inherited: 0x30)
struct UPulldownAnalytics : UBlueprintFunctionLibrary {

	void IncrementPalletStun(struct ACamperPlayer* survivor); // Function DBDAnalytics.PulldownAnalytics.IncrementPalletStun // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1c70
	void IncrementPalletSpawned(struct AActor* Actor); // Function DBDAnalytics.PulldownAnalytics.IncrementPalletSpawned // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1c00
	void IncrementPalletDrop(struct ACamperPlayer* survivor); // Function DBDAnalytics.PulldownAnalytics.IncrementPalletDrop // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1b90
	void IncrementPalletDestroy(struct ASlasherPlayer* killer); // Function DBDAnalytics.PulldownAnalytics.IncrementPalletDestroy // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb1b20
};

// Class DBDAnalytics.SurvivorInteractionAnalytics
// Size: 0x30 (Inherited: 0x30)
struct USurvivorInteractionAnalytics : UBlueprintFunctionLibrary {

	void RecordHealSuccess(struct ACamperPlayer* survivor); // Function DBDAnalytics.SurvivorInteractionAnalytics.RecordHealSuccess // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb4110
	void RecordHatchEscape(struct ACamperPlayer* survivor); // Function DBDAnalytics.SurvivorInteractionAnalytics.RecordHatchEscape // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb40a0
	void IncrementUnhookCount(struct ACamperPlayer* survivor); // Function DBDAnalytics.SurvivorInteractionAnalytics.IncrementUnhookCount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb4030
	void IncrementHealCount(struct ACamperPlayer* survivor); // Function DBDAnalytics.SurvivorInteractionAnalytics.IncrementHealCount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bb3fc0
};

