// Enum DBDAnalytics.ECharacterStatus
enum class ECharacterStatus : uint8 {
	Crawling,
	BeingPickedUp,
	BeingCarried,
	BeingHealed,
	BeingMended,
	BeingPutDown,
	BeingPutOnHook,
	BeingPulledFromCloset,
	BeingKilled,
	OnHook,
	ECharacterStatus_MAX,
};

// Enum DBDAnalytics.EHealthStatus
enum class EHealthStatus : uint8 {
	Healthy,
	Wounded,
	DeepWounded,
	Dying,
	EHealthStatus_MAX,
};

// Enum DBDAnalytics.EDoorStatus
enum class EDoorStatus : uint8 {
	Closed,
	Powered,
	Open,
	EDoorStatus_MAX,
};

// Enum DBDAnalytics.EHatchStatus
enum class EHatchStatus : uint8 {
	Hidden,
	Visible,
	Open,
	Closed,
	ClosedOrHidden,
	EHatchStatus_MAX,
};

// Enum DBDAnalytics.ESurvivorTutorialSections
enum class ESurvivorTutorialSections : uint8 {
	Intro,
	Skillchecks,
	Killer,
	Stealth,
	Hook,
	Health,
	Rescue,
	Escape,
	ESurvivorTutorialSections_MAX,
};

// Enum DBDAnalytics.EKillerTutorialSections
enum class EKillerTutorialSections : uint8 {
	Intro,
	Chase,
	Escape,
	EKillerTutorialSections_MAX,
};

// ScriptStruct DBDAnalytics.ArchiveVignetteVideoAnalytics
// Size: 0xb8 (Inherited: 0x68)
struct FArchiveVignetteVideoAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ArchiveId; // 0x68(0x10)
	struct FString VignetteId; // 0x78(0x10)
	struct FString VideoId; // 0x88(0x10)
	struct FString StartVideoTimestamp; // 0x98(0x10)
	double VideoTimeSpent; // 0xa8(0x08)
	bool WasVideoWatchUntilEnd; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// ScriptStruct DBDAnalytics.ArchiveVignetteEntryAnalytics
// Size: 0xc8 (Inherited: 0x68)
struct FArchiveVignetteEntryAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ArchiveId; // 0x68(0x10)
	struct FString VignetteId; // 0x78(0x10)
	int32_t EntryId; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FString SelectEntryTimestamp; // 0x90(0x10)
	double EntryTimeSpent; // 0xa0(0x08)
	bool IsTaggedAsNew; // 0xa8(0x01)
	bool HasVoiceOver; // 0xa9(0x01)
	bool StartWithAutoplayEnable; // 0xaa(0x01)
	bool IsAutoplayEnableWhenDeselectingEntry; // 0xab(0x01)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FString StartVoiceoverTimestamp; // 0xb0(0x10)
	double VoiceoverLongestTimeSpent; // 0xc0(0x08)
};

// ScriptStruct DBDAnalytics.BotReplacementAnalytics
// Size: 0xb8 (Inherited: 0x68)
struct FBotReplacementAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString KrakenMatchId; // 0x78(0x10)
	enum class EPlayerRole Role; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	float MatchTime; // 0x8c(0x04)
	struct FString characterName; // 0x90(0x10)
	struct FString ReplacedCharacterMirrorsId; // 0xa0(0x10)
	enum class EAIDifficultyLevel BotDifficultyLevel; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// ScriptStruct DBDAnalytics.Gameplay_ChaseAnalytics
// Size: 0x148 (Inherited: 0x68)
struct FGameplay_ChaseAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	bool IsABot; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FString MirrorsIdSurvivor; // 0x80(0x10)
	float CoordXStartKiller; // 0x90(0x04)
	float CoordYStartKiller; // 0x94(0x04)
	float CoordZStartKiller; // 0x98(0x04)
	float CoordXEndKiller; // 0x9c(0x04)
	float CoordYEndKiller; // 0xa0(0x04)
	float CoordZEndKiller; // 0xa4(0x04)
	int32_t PalletsDestroyedByKiller; // 0xa8(0x04)
	int32_t WindowsVaultedByKiller; // 0xac(0x04)
	int32_t PalletsVaultedByKiller; // 0xb0(0x04)
	int32_t BasicAttackSwingsByKiller; // 0xb4(0x04)
	int32_t BasicAttackHitsByKiller; // 0xb8(0x04)
	int32_t SpecialAttackAttemptsByKiller; // 0xbc(0x04)
	int32_t SpecialAttackHitsByKiller; // 0xc0(0x04)
	float DistanceCoveredKiller; // 0xc4(0x04)
	float CoordXStartSurvivor; // 0xc8(0x04)
	float CoordYStartSurvivor; // 0xcc(0x04)
	float CoordZStartSurvivor; // 0xd0(0x04)
	float CoordXEndSurvivor; // 0xd4(0x04)
	float CoordYEndSurvivor; // 0xd8(0x04)
	float CoordZEndSurvivor; // 0xdc(0x04)
	int32_t PalletsDroppedBySurvivor; // 0xe0(0x04)
	int32_t PalletsStunnedBySurvivor; // 0xe4(0x04)
	int32_t WindowsVaultedBySurvivor; // 0xe8(0x04)
	int32_t PalletsVaultedBySurvivor; // 0xec(0x04)
	int32_t StartingHealthOfSurvivor; // 0xf0(0x04)
	int32_t EndingHealthOfSurvivor; // 0xf4(0x04)
	int32_t AmountHealedOfSurvivor; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct FString StartingTileSurvivor; // 0x100(0x10)
	struct FString EndingTileSurvivor; // 0x110(0x10)
	int32_t AmountOfTilesVisitedSurvivor; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct TArray<struct FString> TilesVisitedSurvivor; // 0x128(0x10)
	float DistanceCoveredSurvivor; // 0x138(0x04)
	float DisplacementSurvivor; // 0x13c(0x04)
	float ChaseStartTimeInSecond; // 0x140(0x04)
	float ChaseEndTimeInSecond; // 0x144(0x04)
};

// ScriptStruct DBDAnalytics.ChatAnalytics
// Size: 0xd8 (Inherited: 0x68)
struct FChatAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString SenderMirrorsId; // 0x68(0x10)
	struct FString SenderPlayerName; // 0x78(0x10)
	struct FString MatchID; // 0x88(0x10)
	struct FString ChatContent; // 0x98(0x10)
	struct FString OriginalChatContent; // 0xa8(0x10)
	struct FString ChatContext; // 0xb8(0x10)
	struct FString InGameTimestamp; // 0xc8(0x10)
};

// ScriptStruct DBDAnalytics.ClientLoginAnalytics
// Size: 0x128 (Inherited: 0x68)
struct FClientLoginAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ClientOptions; // 0x68(0x10)
	struct FString ClientMatchId; // 0x78(0x10)
	struct FString ClientGameType; // 0x88(0x10)
	struct FString ClientRole; // 0x98(0x10)
	struct FString ClientSurvivorIndex; // 0xa8(0x10)
	struct FString ClientKillerIndex; // 0xb8(0x10)
	struct FString ClientPlatformAccountId; // 0xc8(0x10)
	struct FString ClientMirrorsId; // 0xd8(0x10)
	struct FString ClientPlatform; // 0xe8(0x10)
	struct FString ClientProvider; // 0xf8(0x10)
	struct FString ClientName; // 0x108(0x10)
	struct FString LoginResult; // 0x118(0x10)
};

// ScriptStruct DBDAnalytics.CrossfriendsAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FCrossfriendsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString action; // 0x68(0x10)
	struct FString TargetKrakenUserId; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.CrowdChoiceVoteResultAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FCrowdChoiceVoteResultAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PollId; // 0x68(0x10)
	struct FString VoteOption; // 0x78(0x10)
	int32_t VoteCount; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// ScriptStruct DBDAnalytics.CrowdChoiceSummaryResultAnalytics
// Size: 0xc0 (Inherited: 0x68)
struct FCrowdChoiceSummaryResultAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PollId; // 0x68(0x10)
	struct FString PollType; // 0x78(0x10)
	struct FString status; // 0x88(0x10)
	float PollDuration; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct TArray<float> VoteTimestamps; // 0xa0(0x10)
	struct TArray<int32_t> NewVotesPerTimestampInterval; // 0xb0(0x10)
};

// ScriptStruct DBDAnalytics.CrowdChoiceOnGameRoundStartedAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FCrowdChoiceOnGameRoundStartedAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PollId; // 0x68(0x10)
	struct FString MatchID; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.CrowdPlayLobbyEventsAnalytics
// Size: 0xa8 (Inherited: 0x68)
struct FCrowdPlayLobbyEventsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString CrowdPlayId; // 0x68(0x10)
	struct FString LobbyEventName; // 0x78(0x10)
	struct FString InviteId; // 0x88(0x10)
	struct FString playerID; // 0x98(0x10)
};

// ScriptStruct DBDAnalytics.CrowdPlayLobbyResultsAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FCrowdPlayLobbyResultsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString CrowdPlayId; // 0x68(0x10)
	struct FString MatchID; // 0x78(0x10)
	int32_t PartySize; // 0x88(0x04)
	int32_t NbrQueueToPlayMembers; // 0x8c(0x04)
	int32_t NbrGamesInSameSession; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct DBDAnalytics.CurrencyBalanceAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FCurrencyBalanceAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString CurrencyName; // 0x68(0x10)
	int32_t CurrencyBalance; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct DBDAnalytics.CustomerSupportClientLoginAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FCustomerSupportClientLoginAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PlayerName; // 0x68(0x10)
	struct FString Provider; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.CustomerSupportAnalytics
// Size: 0x68 (Inherited: 0x68)
struct FCustomerSupportAnalytics : FUniquelyIdentifiedAnalytic {
};

// ScriptStruct DBDAnalytics.CustomizationBaseAnalytics
// Size: 0xd0 (Inherited: 0x68)
struct FCustomizationBaseAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString CustomizationSlot1; // 0x68(0x10)
	struct FString CustomizationSlot2; // 0x78(0x10)
	struct FString CustomizationSlot3; // 0x88(0x10)
	struct FString Charm1; // 0x98(0x10)
	struct FString Charm2; // 0xa8(0x10)
	struct FString Charm3; // 0xb8(0x10)
	enum class EPlayerRole Role; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// ScriptStruct DBDAnalytics.CustomizationLobbyAnalytics
// Size: 0xe0 (Inherited: 0xd0)
struct FCustomizationLobbyAnalytics : FCustomizationBaseAnalytics {
	struct FString LobbyId; // 0xd0(0x10)
};

// ScriptStruct DBDAnalytics.CustomizationAnalytics
// Size: 0xe0 (Inherited: 0xd0)
struct FCustomizationAnalytics : FCustomizationBaseAnalytics {
	struct FString MatchID; // 0xd0(0x10)
};

// ScriptStruct DBDAnalytics.DailyRitualAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FDailyRitualAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString status; // 0x68(0x10)
	struct FString ritualId; // 0x78(0x10)
	float HoursElapsed; // 0x88(0x04)
	int32_t NbGameElapsed; // 0x8c(0x04)
	int32_t Progress; // 0x90(0x04)
	int32_t Threshold; // 0x94(0x04)
	int32_t PendingRituals; // 0x98(0x04)
	int32_t SpecificCharacter; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.DDoSDetectionAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FDDoSDetectionAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString Severity; // 0x68(0x10)
	struct FString MatchID; // 0x78(0x10)
	int32_t NonConnPacketCounter; // 0x88(0x04)
	int32_t NetConnPacketCounter; // 0x8c(0x04)
	int32_t DisconnPacketCounter; // 0x90(0x04)
	int32_t BadPacketCounter; // 0x94(0x04)
	int32_t ErrorPacketCounter; // 0x98(0x04)
	int32_t DroppedPacketCounter; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.DedicatedServerStatusAnalytics
// Size: 0xf0 (Inherited: 0x68)
struct FDedicatedServerStatusAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString DSSessionProvider; // 0x68(0x10)
	struct FString ServerStatus; // 0x78(0x10)
	struct FString GameLiftSessionId; // 0x88(0x10)
	struct FString MatchID; // 0x98(0x10)
	struct FString SessionEndReason; // 0xa8(0x10)
	struct FString FleetId; // 0xb8(0x10)
	struct FString IpAddress; // 0xc8(0x10)
	int32_t Port; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct FString DnsName; // 0xe0(0x10)
};

// ScriptStruct DBDAnalytics.DetailedHitAnalytics
// Size: 0x100 (Inherited: 0x68)
struct FDetailedHitAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString InstigatorMirrorsId; // 0x78(0x10)
	struct FString TargetMirrorsId; // 0x88(0x10)
	float Ping; // 0x98(0x04)
	float HitTimestamp; // 0x9c(0x04)
	bool IsValidHit; // 0xa0(0x01)
	bool IsValidDistance; // 0xa1(0x01)
	bool IsValidCollision; // 0xa2(0x01)
	char pad_A3[0x1]; // 0xa3(0x01)
	float RecorderCacheTimespan; // 0xa4(0x04)
	float MaximumDistance; // 0xa8(0x04)
	float CapsuleInflation; // 0xac(0x04)
	struct FString InstigatorName; // 0xb0(0x10)
	struct FString HitPrimitiveName; // 0xc0(0x10)
	float InstigatorCoordinateX; // 0xd0(0x04)
	float InstigatorCoordinateY; // 0xd4(0x04)
	float InstigatorCoordinateZ; // 0xd8(0x04)
	float InstigatorRotationX; // 0xdc(0x04)
	float InstigatorRotationY; // 0xe0(0x04)
	float InstigatorRotationZ; // 0xe4(0x04)
	float TargetLocationInstigatorTimestamp; // 0xe8(0x04)
	float TargetCoordinateX; // 0xec(0x04)
	float TargetCoordinateY; // 0xf0(0x04)
	float TargetCoordinateZ; // 0xf4(0x04)
	float Distance; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// ScriptStruct DBDAnalytics.DisconnectionAnalytics
// Size: 0xe0 (Inherited: 0x68)
struct FDisconnectionAnalytics : FUniquelyIdentifiedAnalytic {
	float TimeSinceLastPacket; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString GameFlowStep; // 0x70(0x10)
	struct FString UnrealMapName; // 0x80(0x10)
	struct FString MapName; // 0x90(0x10)
	struct FString ThemeName; // 0xa0(0x10)
	struct FString FailureType; // 0xb0(0x10)
	struct FString ErrorString; // 0xc0(0x10)
	struct FString MatchID; // 0xd0(0x10)
};

// ScriptStruct DBDAnalytics.DisconnectionDetailsAnalytics
// Size: 0xc0 (Inherited: 0x68)
struct FDisconnectionDetailsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PlayerPlatform; // 0x68(0x10)
	struct FString MatchID; // 0x78(0x10)
	int32_t InGameTime; // 0x88(0x04)
	enum class EPlayerRole Role; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	struct FString reason; // 0x90(0x10)
	enum class EHealthStatus Health; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct TArray<enum class ECharacterStatus> CharacterStatus; // 0xa8(0x10)
	int32_t GeneratorActivated; // 0xb8(0x04)
	enum class EHatchStatus HatchStatus; // 0xbc(0x01)
	enum class EDoorStatus DoorStatus; // 0xbd(0x01)
	enum class EGameState DisconnectionType; // 0xbe(0x01)
	char pad_BF[0x1]; // 0xbf(0x01)
};

// ScriptStruct DBDAnalytics.EACAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FEACAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString LogMessage; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.EACClientViolationAnalytics
// Size: 0x88 (Inherited: 0x78)
struct FEACClientViolationAnalytics : FEACAnalytics {
	struct FString ViolationCase; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.EACClientInitAnalytics
// Size: 0x80 (Inherited: 0x78)
struct FEACClientInitAnalytics : FEACAnalytics {
	char ValidationErrorType; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// ScriptStruct DBDAnalytics.EACServerValidateAnalytics
// Size: 0x80 (Inherited: 0x80)
struct FEACServerValidateAnalytics : FEACClientInitAnalytics {
};

// ScriptStruct DBDAnalytics.EACClientAuthChallengeAnalytics
// Size: 0x80 (Inherited: 0x80)
struct FEACClientAuthChallengeAnalytics : FEACClientInitAnalytics {
};

// ScriptStruct DBDAnalytics.EACClientAuthInitAnalytics
// Size: 0x80 (Inherited: 0x80)
struct FEACClientAuthInitAnalytics : FEACClientInitAnalytics {
};

// ScriptStruct DBDAnalytics.EmblemProgressionAnalytics
// Size: 0xb0 (Inherited: 0x68)
struct FEmblemProgressionAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString EmblemId; // 0x78(0x10)
	float EmblemValue; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FString EmblemQuality; // 0x90(0x10)
	struct TArray<struct FEmblemProgressionDetailsAnalytics> ProgressionDetails; // 0xa0(0x10)
};

// ScriptStruct DBDAnalytics.EmblemProgressionDetailsAnalytics
// Size: 0x18 (Inherited: 0x00)
struct FEmblemProgressionDetailsAnalytics {
	struct FString ProgressionType; // 0x00(0x10)
	float ProgressionPoint; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DBDAnalytics.EndpointLatencyAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FEndpointLatencyAnalytics : FUniquelyIdentifiedAnalytic {
	struct TArray<struct FEndpointLatencyData> Endpoints; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.EndpointLatencyData
// Size: 0x18 (Inherited: 0x00)
struct FEndpointLatencyData {
	struct FString ID; // 0x00(0x10)
	uint32_t Latency; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DBDAnalytics.EnvironmentAnalytics
// Size: 0x188 (Inherited: 0x68)
struct FEnvironmentAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString Environment; // 0x68(0x10)
	struct FString Endpoint; // 0x78(0x10)
	struct FString Language; // 0x88(0x10)
	struct FString SelectedCountry; // 0x98(0x10)
	struct FString Timezone; // 0xa8(0x10)
	struct FString DeviceProfile; // 0xb8(0x10)
	struct FString GpuAdapter; // 0xc8(0x10)
	struct FString GpuProviderName; // 0xd8(0x10)
	struct FString GpuDriverVersion; // 0xe8(0x10)
	struct FString Cpu; // 0xf8(0x10)
	int32_t QualitySetting; // 0x108(0x04)
	bool IsFullScreen; // 0x10c(0x01)
	bool IsAutomaticResolution; // 0x10d(0x01)
	char pad_10E[0x2]; // 0x10e(0x02)
	int32_t ScreenResolutionSetting; // 0x110(0x04)
	int32_t EngineResolutionX; // 0x114(0x04)
	int32_t EngineResolutionY; // 0x118(0x04)
	char pad_11C[0x4]; // 0x11c(0x04)
	struct FString Provider; // 0x120(0x10)
	struct FString Device; // 0x130(0x10)
	struct FString OperatingSystem; // 0x140(0x10)
	struct FString KrakenVersion; // 0x150(0x10)
	struct FString ContentVersion; // 0x160(0x10)
	bool IsUsingKeyboard; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct FString ControllerType; // 0x178(0x10)
};

// ScriptStruct DBDAnalytics.ErrorAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FErrorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ErrorCategory; // 0x68(0x10)
	struct FString LogMessage; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.FallOutOfWorldAnalytics
// Size: 0xb0 (Inherited: 0x68)
struct FFallOutOfWorldAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString FallOutMirrorsId; // 0x78(0x10)
	float X; // 0x88(0x04)
	float Y; // 0x8c(0x04)
	float Z; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FString TileName; // 0x98(0x10)
	float ElapsedMatchTime; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct DBDAnalytics.FrameHikeAnalytics
// Size: 0x108 (Inherited: 0x68)
struct FFrameHikeAnalytics : FUniquelyIdentifiedAnalytic {
	float FrameDeltaTime; // 0x68(0x04)
	float TimeSinceApplicationStarted; // 0x6c(0x04)
	float CurrentTimeoutThreshold; // 0x70(0x04)
	bool IsOverConnectionTimeLimit; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	struct FString CurrentMap; // 0x78(0x10)
	struct FString GameFlowStep; // 0x88(0x10)
	struct FString CurrentGameFlowContext; // 0x98(0x10)
	struct FString PreviousGameFlowContext; // 0xa8(0x10)
	struct FString NavigationContext; // 0xb8(0x10)
	struct FString PreviousNavigationContext; // 0xc8(0x10)
	struct FString RecentLogs; // 0xd8(0x10)
	struct FString KrakenMatchId; // 0xe8(0x10)
	float FlushAsyncLoadingTime; // 0xf8(0x04)
	int32_t FlushAsyncLoadingCount; // 0xfc(0x04)
	int32_t SyncLoadCount; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
};

// ScriptStruct DBDAnalytics.FreeTrialLoginAnalytics
// Size: 0x68 (Inherited: 0x68)
struct FFreeTrialLoginAnalytics : FUniquelyIdentifiedAnalytic {
};

// ScriptStruct DBDAnalytics.GameConsoleLogAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FGameConsoleLogAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString GameConsoleLog; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.GameInitAnalytics
// Size: 0xb8 (Inherited: 0x68)
struct FGameInitAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString InitGuid; // 0x68(0x10)
	struct FString ProgressionName; // 0x78(0x10)
	bool success; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FString LoadCompleteState; // 0x90(0x10)
	float ElapsedTime; // 0xa0(0x04)
	uint32_t FailureCount; // 0xa4(0x04)
	struct FString AdditionalInfo; // 0xa8(0x10)
};

// ScriptStruct DBDAnalytics.Gameplay_PigKillerAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FGameplay_PigKillerAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t AmbushHitCount; // 0x78(0x04)
	int32_t RbtKilledCount; // 0x7c(0x04)
	int32_t Rbt1GeneratorCount; // 0x80(0x04)
	int32_t Rbt2GeneratorCount; // 0x84(0x04)
	int32_t Rbt3GeneratorCount; // 0x88(0x04)
	int32_t Rbt4GeneratorCount; // 0x8c(0x04)
	int32_t Rbt5GeneratorCount; // 0x90(0x04)
	float CrouchDuration; // 0x94(0x04)
	int32_t RbtExitKill; // 0x98(0x04)
	int32_t RbtHookKill; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.Gameplay_KillerAnalytics
// Size: 0x120 (Inherited: 0x68)
struct FGameplay_KillerAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	float Speed; // 0x78(0x04)
	int32_t BloodlustTier1Count; // 0x7c(0x04)
	int32_t BloodlustTier2Count; // 0x80(0x04)
	int32_t BloodlustTier3Count; // 0x84(0x04)
	float BloodlustTier1Duration; // 0x88(0x04)
	float BloodlustTier2Duration; // 0x8c(0x04)
	float BloodlustTier3Duration; // 0x90(0x04)
	float BloodlustSpeed; // 0x94(0x04)
	int32_t ChaseCount; // 0x98(0x04)
	int32_t ChaseCountFail; // 0x9c(0x04)
	int32_t ChaseCountSuccess; // 0xa0(0x04)
	int32_t ChaseCountTier1Fail; // 0xa4(0x04)
	int32_t ChaseCountTier1Success; // 0xa8(0x04)
	int32_t ChaseCountTier2Fail; // 0xac(0x04)
	int32_t ChaseCountTier2Success; // 0xb0(0x04)
	int32_t ChaseCountTier3Fail; // 0xb4(0x04)
	int32_t ChaseCountTier3Success; // 0xb8(0x04)
	int32_t HookCount; // 0xbc(0x04)
	int32_t MurderCount; // 0xc0(0x04)
	int32_t PalletSpawned; // 0xc4(0x04)
	int32_t PalletProcedural; // 0xc8(0x04)
	int32_t PalletProceduralSetCount; // 0xcc(0x04)
	uint32_t PalletGenerationId; // 0xd0(0x04)
	int32_t PalletGeneric; // 0xd4(0x04)
	int32_t PalletDestroyed; // 0xd8(0x04)
	int32_t BreakableWallSpawned; // 0xdc(0x04)
	int32_t BreakableWallDestroyed; // 0xe0(0x04)
	int32_t DropCount; // 0xe4(0x04)
	int32_t HitCloseCount; // 0xe8(0x04)
	int32_t HitCloseCountSuccess; // 0xec(0x04)
	int32_t HitFarCount; // 0xf0(0x04)
	int32_t HitFarCountSuccess; // 0xf4(0x04)
	int32_t HitSpecialCount; // 0xf8(0x04)
	int32_t HitSpecialCountSuccess; // 0xfc(0x04)
	int32_t ClosetOpen; // 0x100(0x04)
	int32_t ClosetOpenSuccess; // 0x104(0x04)
	int32_t EscapeesHatchCount; // 0x108(0x04)
	float SecondesAtLeastOneSurvivorHooked; // 0x10c(0x04)
	uint32_t AmountTilesVisited; // 0x110(0x04)
	float StartX; // 0x114(0x04)
	float StartY; // 0x118(0x04)
	float StartZ; // 0x11c(0x04)
};

// ScriptStruct DBDAnalytics.Gameplay_PigSurvivorAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FGameplay_PigSurvivorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t RbtAttachedCount; // 0x78(0x04)
	int32_t ActivatedRbtTimerCount; // 0x7c(0x04)
	int32_t RbtSuccessSearchCount; // 0x80(0x04)
	int32_t RbtFailedSearchCount; // 0x84(0x04)
	int32_t RbtDisabledPreActivation; // 0x88(0x04)
	int32_t RbtDisabledPostActivation; // 0x8c(0x04)
	float RbtChaseDuration; // 0x90(0x04)
	float RbtAverageTimeLeftBeforeDisable; // 0x94(0x04)
	float RbtDuration; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.Gameplay_SurvivorAnalytics
// Size: 0xf8 (Inherited: 0x68)
struct FGameplay_SurvivorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	float Speed; // 0x78(0x04)
	float InjuredSpeed; // 0x7c(0x04)
	float InjuredDuration; // 0x80(0x04)
	float HealthyDuration; // 0x84(0x04)
	float KODuration; // 0x88(0x04)
	int32_t PalletSpawned; // 0x8c(0x04)
	int32_t PalletProcedural; // 0x90(0x04)
	int32_t PalletProceduralSetCount; // 0x94(0x04)
	uint32_t PalletGenerationId; // 0x98(0x04)
	int32_t PalletGeneric; // 0x9c(0x04)
	int32_t PalletDrop; // 0xa0(0x04)
	int32_t PalletStun; // 0xa4(0x04)
	int32_t UnhookCount; // 0xa8(0x04)
	int32_t HealCount; // 0xac(0x04)
	int32_t HealCountSuccess; // 0xb0(0x04)
	int32_t ClosetEnter; // 0xb4(0x04)
	int32_t Hatch; // 0xb8(0x04)
	int32_t SkillCheckCount; // 0xbc(0x04)
	int32_t SkillCheckCountGood; // 0xc0(0x04)
	int32_t SkillCheckCountGreat; // 0xc4(0x04)
	float ChaseDuration; // 0xc8(0x04)
	int32_t NumChases; // 0xcc(0x04)
	int32_t HitBySlasherCount; // 0xd0(0x04)
	uint32_t AmountTilesVisited; // 0xd4(0x04)
	float StartX; // 0xd8(0x04)
	float StartY; // 0xdc(0x04)
	float StartZ; // 0xe0(0x04)
	int32_t EmotePoint; // 0xe4(0x04)
	int32_t EmoteCome; // 0xe8(0x04)
	float CrouchingDuration; // 0xec(0x04)
	int32_t CrouchingCount; // 0xf0(0x04)
	float CrawlingDuration; // 0xf4(0x04)
};

// ScriptStruct DBDAnalytics.GPUAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FGPUAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString MapName; // 0x78(0x10)
	struct FString Marker; // 0x88(0x10)
	float AverageMS; // 0x98(0x04)
	float StdDevMs; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.HeartbeatAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FHeartbeatAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString BeatTime; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.HookAnalytics
// Size: 0x110 (Inherited: 0x68)
struct FHookAnalytics : FUniquelyIdentifiedAnalytic {
	float HookStartTime; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString MirrorsIdSurvivor; // 0x70(0x10)
	char SurvivorIsABot; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FString MirrorsIdKiller; // 0x88(0x10)
	char KillerIsABot; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FString MirrorsIdRescuer; // 0xa0(0x10)
	char RescuerIsABot; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32_t TimesOnHook; // 0xb4(0x04)
	struct FString Outcome; // 0xb8(0x10)
	float HookDuration; // 0xc8(0x04)
	int32_t EscapeAttemptStart; // 0xcc(0x04)
	int32_t EscapeAttemptFull; // 0xd0(0x04)
	int32_t SurvivorsRemaining; // 0xd4(0x04)
	int32_t NumberOfActiveSurvivorsStart; // 0xd8(0x04)
	int32_t NumberOfActiveSurvivorsEnd; // 0xdc(0x04)
	int32_t NumberOfActiveSurvivorsTotal; // 0xe0(0x04)
	float DurationCampFace; // 0xe4(0x04)
	float DurationCampHard; // 0xe8(0x04)
	float DurationCampSoft; // 0xec(0x04)
	int32_t NumberOfRescuers; // 0xf0(0x04)
	float TimeForFirstRescuer; // 0xf4(0x04)
	struct FString MatchID; // 0xf8(0x10)
	bool ReverseBearTrapOn; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
};

// ScriptStruct DBDAnalytics.InteractionAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FInteractionAnalytics : FUniquelyIdentifiedAnalytic {
	enum class EPlayerRole Role; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t InterruptionSuccessCount; // 0x6c(0x04)
	int32_t InterruptionFailureCount; // 0x70(0x04)
	int32_t InteractionPredictedCount; // 0x74(0x04)
	int32_t InteractionAuthorizedCount; // 0x78(0x04)
	int32_t InteractionDeniedByRaceConditionCount; // 0x7c(0x04)
	int32_t InteractionDeniedByTimeoutCount; // 0x80(0x04)
	int32_t InteractionDeniedByErrorCount; // 0x84(0x04)
};

// ScriptStruct DBDAnalytics.InvalidLoadoutAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FInvalidLoadoutAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t SlasherPerkCount; // 0x68(0x04)
	int32_t PowerAddonCount; // 0x6c(0x04)
	int32_t CamperPerkCount; // 0x70(0x04)
	int32_t ItemAddonCount; // 0x74(0x04)
	struct FString CallingFunctionName; // 0x78(0x10)
	int32_t characterId; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// ScriptStruct DBDAnalytics.NewKillerTutorialAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FNewKillerTutorialAnalytics : FUniquelyIdentifiedAnalytic {
	bool IsKickGeneratorComplete; // 0x68(0x01)
	bool IsFollowSurvivorComplete; // 0x69(0x01)
	char pad_6A[0x2]; // 0x6a(0x02)
	int32_t TimeToCompleteAreaOne; // 0x6c(0x04)
	bool IsDestroyPalletComplete; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t TimeToCompleteAreaTwo; // 0x74(0x04)
	bool IsBeartrapComplete; // 0x78(0x01)
	bool IsHitSurvivorComplete; // 0x79(0x01)
	bool IsKoSurvivorComplete; // 0x7a(0x01)
	bool IsPickupSurvivorComplete; // 0x7b(0x01)
	bool IsHookSurvivorComplete; // 0x7c(0x01)
	bool IsCloseHatchComplete; // 0x7d(0x01)
	bool IsKillSurvivorComplete; // 0x7e(0x01)
	char pad_7F[0x1]; // 0x7f(0x01)
	int32_t TimeToCompleteAreaThree; // 0x80(0x04)
	int32_t TotalTimeInTutorial; // 0x84(0x04)
	struct FString tutorialId; // 0x88(0x10)
};

// ScriptStruct DBDAnalytics.KillerTutorialAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FKillerTutorialAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t SecondsSpentInTutorial; // 0x68(0x04)
	int32_t SecondsSpentInIntroSection; // 0x6c(0x04)
	int32_t SecondsSpentInChaseSection; // 0x70(0x04)
	int32_t SecondsSpentInEscapeSection; // 0x74(0x04)
	bool WasLungeAttackObjectiveCompleted; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// ScriptStruct DBDAnalytics.KrakenRequestAnalytics
// Size: 0xd8 (Inherited: 0x68)
struct FKrakenRequestAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString KrakenUrl; // 0x68(0x10)
	struct FString Method; // 0x78(0x10)
	struct FString Route; // 0x88(0x10)
	struct FString status; // 0x98(0x10)
	int32_t ResponseCode; // 0xa8(0x04)
	int32_t ProviderError; // 0xac(0x04)
	uint32_t AttemptCount; // 0xb0(0x04)
	bool success; // 0xb4(0x01)
	bool CanRetry; // 0xb5(0x01)
	bool WillRetry; // 0xb6(0x01)
	char pad_B7[0x1]; // 0xb7(0x01)
	struct FString Country; // 0xb8(0x10)
	float AttemptElapsedTime; // 0xc8(0x04)
	float TotalElapsedTime; // 0xcc(0x04)
	float TotalElapsedTimeCapped; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// ScriptStruct DBDAnalytics.LevelLoadingTimeoutAnalytics
// Size: 0x70 (Inherited: 0x68)
struct FLevelLoadingTimeoutAnalytics : FUniquelyIdentifiedAnalytic {
	float TimeElapsed; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct DBDAnalytics.LevelLoadingStepAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FLevelLoadingStepAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString LoadingStep; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.LoadingTimeoutAnalytics
// Size: 0xc0 (Inherited: 0x68)
struct FLoadingTimeoutAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString match_id; // 0x68(0x10)
	struct FString lobby_id; // 0x78(0x10)
	struct FString timeout_timestamp; // 0x88(0x10)
	float total_load_time; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct FString current_map_name; // 0xa0(0x10)
	struct FString transition_id; // 0xb0(0x10)
};

// ScriptStruct DBDAnalytics.LoadingStepAnalytics
// Size: 0xd0 (Inherited: 0x68)
struct FLoadingStepAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString match_id; // 0x68(0x10)
	struct FString lobby_id; // 0x78(0x10)
	struct FString step_change_timestamp; // 0x88(0x10)
	struct FString loading_step; // 0x98(0x10)
	float time_on_prev_step; // 0xa8(0x04)
	float total_load_time; // 0xac(0x04)
	struct FString current_map_name; // 0xb0(0x10)
	struct FString transition_id; // 0xc0(0x10)
};

// ScriptStruct DBDAnalytics.LoadoutBaseAnalytics
// Size: 0xf0 (Inherited: 0x68)
struct FLoadoutBaseAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString LoadoutItem; // 0x68(0x10)
	struct FString LoadoutItemAddOn1; // 0x78(0x10)
	struct FString LoadoutItemAddOn2; // 0x88(0x10)
	struct FString LoadoutPerk1; // 0x98(0x10)
	struct FString LoadoutPerk2; // 0xa8(0x10)
	struct FString LoadoutPerk3; // 0xb8(0x10)
	struct FString LoadoutPerk4; // 0xc8(0x10)
	struct FString LoadoutOffering; // 0xd8(0x10)
	enum class EPlayerRole Role; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	int32_t Rank; // 0xec(0x04)
};

// ScriptStruct DBDAnalytics.LoadOutLobbyAnalytics
// Size: 0x118 (Inherited: 0xf0)
struct FLoadOutLobbyAnalytics : FLoadoutBaseAnalytics {
	int32_t Level; // 0xf0(0x04)
	int32_t Prestige; // 0xf4(0x04)
	struct FString characterName; // 0xf8(0x10)
	struct FString LobbyId; // 0x108(0x10)
};

// ScriptStruct DBDAnalytics.LoadOutAnalytics
// Size: 0x100 (Inherited: 0xf0)
struct FLoadOutAnalytics : FLoadoutBaseAnalytics {
	struct FString MatchID; // 0xf0(0x10)
};

// ScriptStruct DBDAnalytics.LogMirrorsAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FLogMirrorsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString LogMirrors; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.LogPresencePluginAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FLogPresencePluginAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString Context; // 0x68(0x10)
	struct FString Message; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.MapCoordAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FMapCoordAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct TArray<struct FMapCoordData> MapItem; // 0x78(0x10)
};

// ScriptStruct DBDAnalytics.MapCoordData
// Size: 0x30 (Inherited: 0x00)
struct FMapCoordData {
	struct FString Type; // 0x00(0x10)
	struct FString Actor; // 0x10(0x10)
	int32_t X; // 0x20(0x04)
	int32_t Y; // 0x24(0x04)
	int32_t Z; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DBDAnalytics.MatchInfoAnalytics
// Size: 0x148 (Inherited: 0x68)
struct FMatchInfoAnalytics : FUniquelyIdentifiedAnalytic {
	enum class EGameType gameMode; // 0x68(0x01)
	enum class EPlayerRole Role; // 0x69(0x01)
	bool IsABot; // 0x6a(0x01)
	enum class EAIDifficultyLevel BotDifficultyLevel; // 0x6b(0x01)
	int32_t PartySize; // 0x6c(0x04)
	struct FString characterName; // 0x70(0x10)
	int32_t Rank; // 0x80(0x04)
	int32_t Level; // 0x84(0x04)
	int32_t Prestige; // 0x88(0x04)
	int32_t Pips; // 0x8c(0x04)
	int32_t PipsTotal; // 0x90(0x04)
	int32_t MapSeed; // 0x94(0x04)
	struct FString MapName; // 0x98(0x10)
	struct FString PartyHostMirrorsId; // 0xa8(0x10)
	struct FString LobbyId; // 0xb8(0x10)
	struct FString MatchID; // 0xc8(0x10)
	struct FString KrakenMatchId; // 0xd8(0x10)
	struct FString PlayerName; // 0xe8(0x10)
	struct FString SelectedCountry; // 0xf8(0x10)
	bool FirstTimePlaying; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	int32_t CumulativeMatches; // 0x10c(0x04)
	int32_t CumulativeMatchesAsSurvivor; // 0x110(0x04)
	int32_t CumulativeMatchesAsKiller; // 0x114(0x04)
	struct FString LastMatchTimestamp; // 0x118(0x10)
	float ExactPing; // 0x128(0x04)
	bool hasAnActiveArchiveQuest; // 0x12c(0x01)
	bool archiveQuestCanProgress; // 0x12d(0x01)
	bool IsUsingKeyboard; // 0x12e(0x01)
	char pad_12F[0x1]; // 0x12f(0x01)
	struct FString ControllerType; // 0x130(0x10)
	bool IsTutorialBotMatch; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
};

// ScriptStruct DBDAnalytics.MatchmakingAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FMatchmakingAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchmakingSessionGuid; // 0x68(0x10)
	enum class EPlayerRole PlayerRole; // 0x78(0x01)
	enum class EGameType GameType; // 0x79(0x01)
	char pad_7A[0x2]; // 0x7a(0x02)
	int32_t PartySize; // 0x7c(0x04)
};

// ScriptStruct DBDAnalytics.MatchmakingLobbyAnalytics
// Size: 0xc8 (Inherited: 0x80)
struct FMatchmakingLobbyAnalytics : FMatchmakingAnalytics {
	struct FString LobbyStartTime; // 0x80(0x10)
	struct FString LobbyEndTime; // 0x90(0x10)
	struct FString LobbyResult; // 0xa0(0x10)
	struct FString KrakenMatchId; // 0xb0(0x10)
	int32_t Rank; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// ScriptStruct DBDAnalytics.MatchmakingQueueAnalytics
// Size: 0xb8 (Inherited: 0x80)
struct FMatchmakingQueueAnalytics : FMatchmakingAnalytics {
	struct FString QueueStartTime; // 0x80(0x10)
	struct FString QueueEndTime; // 0x90(0x10)
	struct FString QueueResult; // 0xa0(0x10)
	int32_t Rank; // 0xb0(0x04)
	bool CrossPlayEnabled; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
};

// ScriptStruct DBDAnalytics.MatchmakingSearchCompleteAnalytics
// Size: 0x148 (Inherited: 0x68)
struct FMatchmakingSearchCompleteAnalytics : FUniquelyIdentifiedAnalytic {
	bool success; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t NumMatches; // 0x6c(0x04)
	bool UsedFallback; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FString ConnectingToUser; // 0x78(0x10)
	struct FString SearchParams; // 0x88(0x10)
	struct FString SearchResultSettings; // 0x98(0x10)
	char pad_A8[0xa0]; // 0xa8(0xa0)
};

// ScriptStruct DBDAnalytics.MatchmakingHostCreatedAnalytics
// Size: 0xd8 (Inherited: 0x68)
struct FMatchmakingHostCreatedAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t NumPublicConnections; // 0x68(0x04)
	int32_t NumPrivateConnections; // 0x6c(0x04)
	bool ShouldAdvertise; // 0x70(0x01)
	bool IsLANMatch; // 0x71(0x01)
	bool AllowInvites; // 0x72(0x01)
	bool UsesPresence; // 0x73(0x01)
	bool AllowJoinViaPresenceFriendsOnly; // 0x74(0x01)
	bool AllowJoinInProgress; // 0x75(0x01)
	bool AllowJoinViaPresence; // 0x76(0x01)
	bool success; // 0x77(0x01)
	struct FString HostSettings; // 0x78(0x10)
	char pad_88[0x50]; // 0x88(0x50)
};

// ScriptStruct DBDAnalytics.MatchmakingJoinCompleteAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FMatchmakingJoinCompleteAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString SessionName; // 0x68(0x10)
	int32_t Result; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct DBDAnalytics.MatchmakingJoinSessionAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FMatchmakingJoinSessionAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString Log; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.MatchmakingApproveLoginAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FMatchmakingApproveLoginAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t CurrentPlayers; // 0x68(0x04)
	bool success; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct FString Error; // 0x70(0x10)
	struct FString JoiningUserID; // 0x80(0x10)
};

// ScriptStruct DBDAnalytics.WaitTimeAnalytics
// Size: 0xe8 (Inherited: 0x68)
struct FWaitTimeAnalytics : FUniquelyIdentifiedAnalytic {
	float EnterLobbyWaitTime; // 0x68(0x04)
	float EnterMatchWaitTime; // 0x6c(0x04)
	struct FString MatchWaitStartUtc; // 0x70(0x10)
	struct FString MatchWaitStopUtc; // 0x80(0x10)
	struct FString LobbyWaitStartUtc; // 0x90(0x10)
	struct FString LobbyWaitStopUtc; // 0xa0(0x10)
	struct FString LobbyWaitStopReason; // 0xb0(0x10)
	struct FString MatchID; // 0xc0(0x10)
	enum class EGameType gameMode; // 0xd0(0x01)
	enum class EPlayerRole Role; // 0xd1(0x01)
	char pad_D2[0x2]; // 0xd2(0x02)
	int32_t PartySize; // 0xd4(0x04)
	int32_t Rank; // 0xd8(0x04)
	int32_t RankDifference; // 0xdc(0x04)
	int32_t DaysSinceReset; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// ScriptStruct DBDAnalytics.QueueAnalytics
// Size: 0x120 (Inherited: 0x68)
struct FQueueAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t TimesQueuedSurvivor; // 0x68(0x04)
	int32_t TimesQueuedKiller; // 0x6c(0x04)
	int32_t MatchesAsSurvivor; // 0x70(0x04)
	int32_t MatchesAsKiller; // 0x74(0x04)
	struct FString SelectedCountry; // 0x78(0x10)
	struct FString PlayerName; // 0x88(0x10)
	bool FirstTimePlaying; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	int32_t CumulativeMatches; // 0x9c(0x04)
	int32_t CumulativeMatchesAsSurvivor; // 0xa0(0x04)
	int32_t CumulativeMatchesAsKiller; // 0xa4(0x04)
	struct FString LastMatchTimestamp; // 0xa8(0x10)
	struct FString SessionStartTimestamp; // 0xb8(0x10)
	struct FString SessionEndTimestamp; // 0xc8(0x10)
	struct FString LastSessionTimestamp; // 0xd8(0x10)
	int32_t CumulativeSessions; // 0xe8(0x04)
	float CumulativePlaytime; // 0xec(0x04)
	float TimeInCharacterMenu; // 0xf0(0x04)
	float TimeInBloodwebMenu; // 0xf4(0x04)
	float TimeInLoadoutMenu; // 0xf8(0x04)
	float TimeInCustomizationMenu; // 0xfc(0x04)
	float TimeInFearMarket; // 0x100(0x04)
	float TimeInTallyScreen; // 0x104(0x04)
	float TimeInGameMatch; // 0x108(0x04)
	float TimeInHelpMenu; // 0x10c(0x04)
	float TimeInOfflineLobby; // 0x110(0x04)
	float TimeInOfflineLobbySurvivorGroup; // 0x114(0x04)
	float TimeInOnlineLobby; // 0x118(0x04)
	float TimeInOnlineLobbySurvivorGroup; // 0x11c(0x04)
};

// ScriptStruct DBDAnalytics.MatchRatingAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FMatchRatingAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t Rating; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString MatchID; // 0x70(0x10)
};

// ScriptStruct DBDAnalytics.MemoryUsageAnalytics
// Size: 0xa8 (Inherited: 0x68)
struct FMemoryUsageAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString GameFlowStep; // 0x68(0x10)
	int64_t TotalPhysical; // 0x78(0x08)
	int64_t TotalVirtual; // 0x80(0x08)
	int64_t PeakUsedPhysical; // 0x88(0x08)
	int64_t PeakUsedVirtual; // 0x90(0x08)
	int64_t AvailablePhysical; // 0x98(0x08)
	int64_t AvailableVirtual; // 0xa0(0x08)
};

// ScriptStruct DBDAnalytics.MenuFlowAnalytics
// Size: 0xc0 (Inherited: 0x68)
struct FMenuFlowAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString CurrentContext; // 0x68(0x10)
	struct FString PreviousContext; // 0x78(0x10)
	float TimeOnPreviousContext; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FString ContextChangeTimetamp; // 0x90(0x10)
	struct FString MatchID; // 0xa0(0x10)
	struct FString LobbyId; // 0xb0(0x10)
};

// ScriptStruct DBDAnalytics.StoreMenuFlowAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FStoreMenuFlowAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString EventTimestamp; // 0x68(0x10)
	struct FString EventName; // 0x78(0x10)
	struct FString Data; // 0x88(0x10)
};

// ScriptStruct DBDAnalytics.PartyJoinFailureAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FPartyJoinFailureAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString PartyMembersFriendshipStatus; // 0x68(0x10)
	uint32_t NumKrakenConfirmedFriendsInParty; // 0x78(0x04)
	uint32_t NumPlatformAcceptedFriendsInParty; // 0x7c(0x04)
};

// ScriptStruct DBDAnalytics.PerformanceAnalytics
// Size: 0x1d8 (Inherited: 0x68)
struct FPerformanceAnalytics : FUniquelyIdentifiedAnalytic {
	float AverageFPS; // 0x68(0x04)
	float MinFPS; // 0x6c(0x04)
	float MaxFPS; // 0x70(0x04)
	float AverageFrameTime; // 0x74(0x04)
	float MinFrameTime; // 0x78(0x04)
	float MaxFrameTime; // 0x7c(0x04)
	float StandardDeviationFrameTime; // 0x80(0x04)
	float PercentBelow60msFrameTime; // 0x84(0x04)
	float PercentBelow47msFrameTime; // 0x88(0x04)
	float PercentBelow34msFrameTime; // 0x8c(0x04)
	float PercentBelow17msFrameTime; // 0x90(0x04)
	float PercentHitchesFrameTime; // 0x94(0x04)
	float AverageRenderThreadTime; // 0x98(0x04)
	float MinRenderThreadTime; // 0x9c(0x04)
	float MaxRenderThreadTime; // 0xa0(0x04)
	float StandardDeviationRenderThreadTime; // 0xa4(0x04)
	float PercentBelow60msRenderThreadTime; // 0xa8(0x04)
	float PercentBelow47msRenderThreadTime; // 0xac(0x04)
	float PercentBelow34msRenderThreadTime; // 0xb0(0x04)
	float PercentBelow17msRenderThreadTime; // 0xb4(0x04)
	float PercentHitchesRenderThreadTime; // 0xb8(0x04)
	float AverageGameThreadTime; // 0xbc(0x04)
	float MinGameThreadTime; // 0xc0(0x04)
	float MaxGameThreadTime; // 0xc4(0x04)
	float StandardDeviationGameThreadTime; // 0xc8(0x04)
	float PercentBelow60msGameThreadTime; // 0xcc(0x04)
	float PercentBelow47msGameThreadTime; // 0xd0(0x04)
	float PercentBelow34msGameThreadTime; // 0xd4(0x04)
	float PercentBelow17msGameThreadTime; // 0xd8(0x04)
	float PercentHitchesGameThreadTime; // 0xdc(0x04)
	float AverageRhiThreadTime; // 0xe0(0x04)
	float MinRhiThreadTime; // 0xe4(0x04)
	float MaxRhiThreadTime; // 0xe8(0x04)
	float StandardDeviationRhiThreadTime; // 0xec(0x04)
	float PercentBelow60msRhiThreadTime; // 0xf0(0x04)
	float PercentBelow47msRhiThreadTime; // 0xf4(0x04)
	float PercentBelow34msRhiThreadTime; // 0xf8(0x04)
	float PercentBelow17msRhiThreadTime; // 0xfc(0x04)
	float PercentHitchesRhiThreadTime; // 0x100(0x04)
	float AverageGpuTime; // 0x104(0x04)
	float MinGpuTime; // 0x108(0x04)
	float MaxGpuTime; // 0x10c(0x04)
	float StandardDeviationGpuTime; // 0x110(0x04)
	float PercentBelow60msGpuTime; // 0x114(0x04)
	float PercentBelow47msGpuTime; // 0x118(0x04)
	float PercentBelow34msGpuTime; // 0x11c(0x04)
	float PercentBelow17msGpuTime; // 0x120(0x04)
	float PercentHitchesGpuTime; // 0x124(0x04)
	float AverageSlateTickTime; // 0x128(0x04)
	float AverageSlateRenderThreadTime; // 0x12c(0x04)
	float AverageSlateDrawWindowTime; // 0x130(0x04)
	float AdaptiveShadowMapAverageNumShadowPrimitivesPerCapture; // 0x134(0x04)
	float AdaptiveShadowMapAverageActiveLightsPerFrame; // 0x138(0x04)
	float AdaptiveShadowMapPercentageOfFrameCapturingTiles; // 0x13c(0x04)
	int32_t TotalFrames; // 0x140(0x04)
	float ResolutionQuality; // 0x144(0x04)
	int32_t ViewDistanceQuality; // 0x148(0x04)
	int32_t AntiAliasingQuality; // 0x14c(0x04)
	int32_t ShadowQuality; // 0x150(0x04)
	int32_t TextureQuality; // 0x154(0x04)
	int32_t EffectsQuality; // 0x158(0x04)
	int32_t FoliageQuality; // 0x15c(0x04)
	struct FString Scenario; // 0x160(0x10)
	struct FString Theme; // 0x170(0x10)
	struct FString MapName; // 0x180(0x10)
	int32_t TileListCount; // 0x190(0x04)
	int32_t Seed; // 0x194(0x04)
	struct FString characterName; // 0x198(0x10)
	struct FString Cpu; // 0x1a8(0x10)
	struct FString GpuAdapter; // 0x1b8(0x10)
	struct FString MatchID; // 0x1c8(0x10)
};

// ScriptStruct DBDAnalytics.PerformanceChartingAnalytics
// Size: 0x1a8 (Inherited: 0x68)
struct FPerformanceChartingAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString Scenario; // 0x68(0x10)
	struct FString Theme; // 0x78(0x10)
	struct FString map_name; // 0x88(0x10)
	int32_t tile_spawn_count; // 0x98(0x04)
	int32_t Seed; // 0x9c(0x04)
	struct FString match_id; // 0xa0(0x10)
	struct FString character_name; // 0xb0(0x10)
	struct FString cpu_name; // 0xc0(0x10)
	struct FString gpu_name; // 0xd0(0x10)
	struct FString Resolution; // 0xe0(0x10)
	int32_t graphics_quality_level; // 0xf0(0x04)
	char pad_F4[0x4]; // 0xf4(0x04)
	struct FString hitch_times; // 0xf8(0x10)
	float target_30_fps; // 0x108(0x04)
	float target_60_fps; // 0x10c(0x04)
	float target_120_fps; // 0x110(0x04)
	float measured_perf_time; // 0x114(0x04)
	float mvp; // 0x118(0x04)
	float avg_fps; // 0x11c(0x04)
	float hitches_per_minute; // 0x120(0x04)
	float avg_hitch; // 0x124(0x04)
	float frame_time_avg; // 0x128(0x04)
	float frame_time_max; // 0x12c(0x04)
	float frame_time_min; // 0x130(0x04)
	float game_thread_avg; // 0x134(0x04)
	float game_thread_hitches_per_min; // 0x138(0x04)
	float game_thread_bound_frames; // 0x13c(0x04)
	float render_thread_avg; // 0x140(0x04)
	float render_thread_hitches_per_min; // 0x144(0x04)
	float render_thread_bound_frames; // 0x148(0x04)
	float rhi_thread_avg; // 0x14c(0x04)
	float rhi_thread_hitches_per_min; // 0x150(0x04)
	float rhi_thread_bound_frames; // 0x154(0x04)
	float gpu_avg; // 0x158(0x04)
	float gpu_hitches_per_min; // 0x15c(0x04)
	float gpu_bound_frames; // 0x160(0x04)
	float draw_calls_avg; // 0x164(0x04)
	float draw_calls_max; // 0x168(0x04)
	float draw_calls_min; // 0x16c(0x04)
	float drawn_prims_avg; // 0x170(0x04)
	float drawn_prims_max; // 0x174(0x04)
	float drawn_prims_min; // 0x178(0x04)
	float cpu_memory_peak; // 0x17c(0x04)
	float cpu_memory_used; // 0x180(0x04)
	float streaming_memory_peak; // 0x184(0x04)
	float streaming_memory_used; // 0x188(0x04)
	float physical_memory_peak; // 0x18c(0x04)
	float physical_memory_used; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
	struct FString texturegroups_guid; // 0x198(0x10)
};

// ScriptStruct DBDAnalytics.PerkAcquisitionAnalytics
// Size: 0xb0 (Inherited: 0x68)
struct FPerkAcquisitionAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString characterName; // 0x68(0x10)
	struct FString PerkId; // 0x78(0x10)
	struct FString PerkSource; // 0x88(0x10)
	struct FString Duplicate; // 0x98(0x10)
	int32_t PerkLevel; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct DBDAnalytics.BasePerkAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FBasePerkAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	float ElapsedMatchTime; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct DBDAnalytics.FranklinsHitNearDroppedItemAnalytics
// Size: 0xa0 (Inherited: 0x80)
struct FFranklinsHitNearDroppedItemAnalytics : FBasePerkAnalytics {
	struct FString HitSurvivorMirrorsId; // 0x80(0x10)
	struct FString AttackingSlasherMirrorsId; // 0x90(0x10)
};

// ScriptStruct DBDAnalytics.FranklinsDemiseConsumedItemAnalytics
// Size: 0x90 (Inherited: 0x80)
struct FFranklinsDemiseConsumedItemAnalytics : FBasePerkAnalytics {
	struct FString PreviousOwnerSurvivorMirrorsId; // 0x80(0x10)
};

// ScriptStruct DBDAnalytics.KnockoutSurvivorFoundAnalytics
// Size: 0xa0 (Inherited: 0x80)
struct FKnockoutSurvivorFoundAnalytics : FBasePerkAnalytics {
	struct FString RescuingSurvivorMirrorsId; // 0x80(0x10)
	struct FString FoundSurvivorMirrorsId; // 0x90(0x10)
};

// ScriptStruct DBDAnalytics.TinkererUndetectableInterruptAnalytics
// Size: 0xa0 (Inherited: 0x80)
struct FTinkererUndetectableInterruptAnalytics : FBasePerkAnalytics {
	struct FString InterruptedSurvivorMirrorsId; // 0x80(0x10)
	struct FString InterruptingSlasherMirrorsId; // 0x90(0x10)
};

// ScriptStruct DBDAnalytics.TinkererUndetectableHitNearGeneratorAnalytics
// Size: 0xa0 (Inherited: 0x80)
struct FTinkererUndetectableHitNearGeneratorAnalytics : FBasePerkAnalytics {
	struct FString HitSurvivorMirrorsId; // 0x80(0x10)
	struct FString AttackingSlasherMirrorsId; // 0x90(0x10)
};

// ScriptStruct DBDAnalytics.LightbornAuraRevealedAnalytics
// Size: 0xa0 (Inherited: 0x80)
struct FLightbornAuraRevealedAnalytics : FBasePerkAnalytics {
	struct FString RevealedSurvivorMirrorsId; // 0x80(0x10)
	struct FString FlashlightedSlasherMirrorsId; // 0x90(0x10)
};

// ScriptStruct DBDAnalytics.PlayerStatusEffectUpdateAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FPlayerStatusEffectUpdateAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t ElapsedMatchTime; // 0x78(0x04)
	int32_t NbOfConcurrentStatusEffects; // 0x7c(0x04)
	struct TArray<struct FString> StatusEffects; // 0x80(0x10)
};

// ScriptStruct DBDAnalytics.PostGameAnalyticsBase
// Size: 0xb0 (Inherited: 0x68)
struct FPostGameAnalyticsBase : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t BloodwebPoints; // 0x78(0x04)
	float GameDuration; // 0x7c(0x04)
	struct FString characterName; // 0x80(0x10)
	int32_t Rank; // 0x90(0x04)
	int32_t PipsGainedOrLost; // 0x94(0x04)
	struct FString MatchEndReason; // 0x98(0x10)
	bool IsTutorialBotMatch; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// ScriptStruct DBDAnalytics.PostGame_KillerAnalytics
// Size: 0x110 (Inherited: 0xb0)
struct FPostGame_KillerAnalytics : FPostGameAnalyticsBase {
	int32_t Brutality; // 0xb0(0x04)
	int32_t Deviousness; // 0xb4(0x04)
	int32_t Hunter; // 0xb8(0x04)
	int32_t Sacrifice; // 0xbc(0x04)
	int32_t EscapeesCount; // 0xc0(0x04)
	int32_t SacrificedCount; // 0xc4(0x04)
	int32_t KilledCount; // 0xc8(0x04)
	int32_t DisconnectCount; // 0xcc(0x04)
	int32_t BotCount; // 0xd0(0x04)
	int32_t TimeOpenGate; // 0xd4(0x04)
	struct FString SurvivorSpawningPosition; // 0xd8(0x10)
	int32_t GeneratorsDone; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FString EGS_starter; // 0xf0(0x10)
	float EGS_time; // 0x100(0x04)
	float EGS_duration; // 0x104(0x04)
	int32_t EGS_sacrifice; // 0x108(0x04)
	bool EGS_reachEnd; // 0x10c(0x01)
	bool UsedController; // 0x10d(0x01)
	bool UsedKeyboard; // 0x10e(0x01)
	char pad_10F[0x1]; // 0x10f(0x01)
};

// ScriptStruct DBDAnalytics.PostGame_SurvivorAnalytics
// Size: 0xe0 (Inherited: 0xb0)
struct FPostGame_SurvivorAnalytics : FPostGameAnalyticsBase {
	int32_t Objectives; // 0xb0(0x04)
	int32_t Survival; // 0xb4(0x04)
	int32_t Altruism; // 0xb8(0x04)
	int32_t Boldness; // 0xbc(0x04)
	struct FString Outcome; // 0xc0(0x10)
	enum class ECamperDamageState damageState; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	int32_t HookedCount; // 0xd4(0x04)
	bool UsedController; // 0xd8(0x01)
	bool UsedKeyboard; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// ScriptStruct DBDAnalytics.ProceduralGenerationAnalytics
// Size: 0x180 (Inherited: 0x68)
struct FProceduralGenerationAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t GenerationSeed; // 0x68(0x04)
	int32_t MapSeed; // 0x6c(0x04)
	struct FString MapName; // 0x70(0x10)
	struct FString Procedural_MeatLocker_Small; // 0x80(0x10)
	struct FString Procedural_MeatLocker_Big; // 0x90(0x10)
	struct FString Procedural_Searchable; // 0xa0(0x10)
	struct FString Procedural_EdgeObjects; // 0xb0(0x10)
	struct FString Procedural_LivingWorldObjects; // 0xc0(0x10)
	struct FString Procedural_Hatch; // 0xd0(0x10)
	struct FString Procedural_BookShelves; // 0xe0(0x10)
	struct FString Procedural_BreakableWalls; // 0xf0(0x10)
	struct FString Procedural_Totems; // 0x100(0x10)
	struct FString Procedural_QuadrantSpawn; // 0x110(0x10)
	int32_t PalletSpawned; // 0x120(0x04)
	int32_t PalletProceduralMin; // 0x124(0x04)
	int32_t PalletProceduralMax; // 0x128(0x04)
	int32_t PalletProcedural; // 0x12c(0x04)
	int32_t PalletProceduralSetCount; // 0x130(0x04)
	uint32_t PalletGenerationId; // 0x134(0x04)
	int32_t PalletGeneric; // 0x138(0x04)
	char pad_13C[0x4]; // 0x13c(0x04)
	struct FString KillerSpawn; // 0x140(0x10)
	struct FString SurvivorSpawn; // 0x150(0x10)
	struct FString MatchID; // 0x160(0x10)
	int32_t HookSpawned; // 0x170(0x04)
	bool UseFixedMaps; // 0x174(0x01)
	char pad_175[0x3]; // 0x175(0x03)
	float NavmeshGenerationTime; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
};

// ScriptStruct DBDAnalytics.ReportAnalytics
// Size: 0x100 (Inherited: 0x68)
struct FReportAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ClientIdTransmitter; // 0x68(0x10)
	struct FString ClientIdReceiver; // 0x78(0x10)
	struct FString MirrorsIdTransmitter; // 0x88(0x10)
	struct FString MirrorsIdReceiver; // 0x98(0x10)
	enum class EPlayerRole RoleTransmitter; // 0xa8(0x01)
	enum class EPlayerRole RoleReceiver; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
	struct FString MatchID; // 0xb0(0x10)
	struct FString gameMode; // 0xc0(0x10)
	struct FString ReportType; // 0xd0(0x10)
	struct FString ReportCategory; // 0xe0(0x10)
	struct FString Comments; // 0xf0(0x10)
};

// ScriptStruct DBDAnalytics.RTMAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FRTMAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString RTMType; // 0x68(0x10)
	uint32_t RTMSize; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FString CurrentGameFlowStep; // 0x80(0x10)
};

// ScriptStruct DBDAnalytics.S3CommandErrorAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FS3CommandErrorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString URL; // 0x68(0x10)
	struct FString Verb; // 0x78(0x10)
	int32_t ResponseCode; // 0x88(0x04)
	bool InvalidRequest; // 0x8c(0x01)
	bool InvalidResponse; // 0x8d(0x01)
	bool DecryptionFailure; // 0x8e(0x01)
	bool BadResponse; // 0x8f(0x01)
	bool ContentModifiedError; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct DBDAnalytics.S3CommandAnalytics
// Size: 0xc8 (Inherited: 0x68)
struct FS3CommandAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t RequestContentLength; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString ContentType; // 0x70(0x10)
	float ElapsedTime; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FString status; // 0x88(0x10)
	struct FString URL; // 0x98(0x10)
	struct FString Verb; // 0xa8(0x10)
	int32_t ResponseContentLength; // 0xb8(0x04)
	int32_t ResponseCode; // 0xbc(0x04)
	bool success; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// ScriptStruct DBDAnalytics.SaveGameLoadResultAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FSaveGameLoadResultAnalytics : FUniquelyIdentifiedAnalytic {
	bool LoadSuccessful; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FString Message; // 0x70(0x10)
};

// ScriptStruct DBDAnalytics.SaveGameSaveResultAnalytics
// Size: 0x70 (Inherited: 0x68)
struct FSaveGameSaveResultAnalytics : FUniquelyIdentifiedAnalytic {
	bool SaveSuccessful; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t ResponseCode; // 0x6c(0x04)
};

// ScriptStruct DBDAnalytics.SaveGameErrorAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FSaveGameErrorAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t ErrorCode; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString Category; // 0x70(0x10)
	struct FString ErrorDetails; // 0x80(0x10)
	uint32_t KrakenErrorCode; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct DBDAnalytics.SaveGameSummaryCharacterStatsAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FSaveGameSummaryCharacterStatsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString SavedCharacterStats; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.SerializableSaveGameSummaryCharacterData
// Size: 0x10 (Inherited: 0x00)
struct FSerializableSaveGameSummaryCharacterData {
	struct TArray<struct FCharacterSpecificData> CharacterStats; // 0x00(0x10)
};

// ScriptStruct DBDAnalytics.CharacterSpecificData
// Size: 0x14 (Inherited: 0x00)
struct FCharacterSpecificData {
	struct FName Name; // 0x00(0x0c)
	int32_t Level; // 0x0c(0x04)
	int32_t PrestigeLevel; // 0x10(0x04)
};

// ScriptStruct DBDAnalytics.SaveGameSummaryPlayerStatsAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FSaveGameSummaryPlayerStatsAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString OwnedPerks; // 0x68(0x10)
	struct FString PlayerStatsProgression; // 0x78(0x10)
	int32_t BloodwebPoints; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	int64_t CumulativePlaytime; // 0x90(0x08)
};

// ScriptStruct DBDAnalytics.SerializablePlayerStatsProgression
// Size: 0x10 (Inherited: 0x00)
struct FSerializablePlayerStatsProgression {
	struct TArray<struct FStatsProgressionData> StatsProgression; // 0x00(0x10)
};

// ScriptStruct DBDAnalytics.StatsProgressionData
// Size: 0x10 (Inherited: 0x00)
struct FStatsProgressionData {
	struct FName Name; // 0x00(0x0c)
	float value; // 0x0c(0x04)
};

// ScriptStruct DBDAnalytics.SerializablePlayerPerks
// Size: 0x50 (Inherited: 0x00)
struct FSerializablePlayerPerks {
	struct TMap<struct FName, int32_t> Perks; // 0x00(0x50)
};

// ScriptStruct DBDAnalytics.DetailedScoreAnalytics
// Size: 0xc8 (Inherited: 0x68)
struct FDetailedScoreAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString ScorerMirrorsId; // 0x68(0x10)
	struct FString TargetMirrorsId; // 0x78(0x10)
	struct FString MatchID; // 0x88(0x10)
	struct FName ScoreTypeId; // 0x98(0x0c)
	int32_t ScoreExperience; // 0xa4(0x04)
	float ElapsedMatchTime; // 0xa8(0x04)
	float InstigatorCoordinateX; // 0xac(0x04)
	float InstigatorCoordinateY; // 0xb0(0x04)
	float InstigatorCoordinateZ; // 0xb4(0x04)
	float TargetCoordinateX; // 0xb8(0x04)
	float TargetCoordinateY; // 0xbc(0x04)
	float TargetCoordinateZ; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// ScriptStruct DBDAnalytics.ScoreAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FScoreAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FName ScoreTypeId; // 0x78(0x0c)
	int32_t ScoreCount; // 0x84(0x04)
	float ScoreBloodwebPoints; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// ScriptStruct DBDAnalytics.ShopAnalytics
// Size: 0x78 (Inherited: 0x68)
struct FShopAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString LogMessage; // 0x68(0x10)
};

// ScriptStruct DBDAnalytics.SpecialEventAnalytics
// Size: 0xa0 (Inherited: 0x68)
struct FSpecialEventAnalytics : FUniquelyIdentifiedAnalytic {
	enum class EPlayerRole Role; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FString MatchID; // 0x70(0x10)
	struct FName EventName; // 0x80(0x0c)
	struct FName Challenge; // 0x8c(0x0c)
	int32_t amount; // 0x98(0x04)
	int32_t CummulativeAmount; // 0x9c(0x04)
};

// ScriptStruct DBDAnalytics.StadiaLivestreamAnalytics
// Size: 0x90 (Inherited: 0x68)
struct FStadiaLivestreamAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString StreamStartTime; // 0x68(0x10)
	struct FString UserId; // 0x78(0x10)
	bool CrowdPlayEnabled; // 0x88(0x01)
	bool CrowdChoiceEnabled; // 0x89(0x01)
	char pad_8A[0x6]; // 0x8a(0x06)
};

// ScriptStruct DBDAnalytics.FrameTravelTimeAnalytics
// Size: 0xc0 (Inherited: 0x68)
struct FFrameTravelTimeAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString DynamicRange; // 0x78(0x10)
	struct FString PixelDensity; // 0x88(0x10)
	struct FString RenderResolution; // 0x98(0x10)
	float FrameIssuedToClientArrivalTotalTime; // 0xa8(0x04)
	float FrameIssuedToBeginRenderingTime; // 0xac(0x04)
	float FrameRenderingTime; // 0xb0(0x04)
	float FrameEncodingTime; // 0xb4(0x04)
	float FrameFinishedEncodingToClientArrivalTime; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// ScriptStruct DBDAnalytics.StadiaStreamAnalytics
// Size: 0xc8 (Inherited: 0x68)
struct FStadiaStreamAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct FString DynamicRange; // 0x78(0x10)
	struct FString PixelDensity; // 0x88(0x10)
	struct FString RenderResolution; // 0x98(0x10)
	float NetworkDelayForInputTime; // 0xa8(0x04)
	float NetworkDelayForVideoTime; // 0xac(0x04)
	float PercentFramesAbove60FPS; // 0xb0(0x04)
	float PercentFramesBelow60FPS; // 0xb4(0x04)
	float PercentFramesBelow45FPS; // 0xb8(0x04)
	float PercentFramesBelow30FPS; // 0xbc(0x04)
	float PercentFramesBelow20FPS; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// ScriptStruct DBDAnalytics.NewSurvivorTutorialAnalytics
// Size: 0xa8 (Inherited: 0x68)
struct FNewSurvivorTutorialAnalytics : FUniquelyIdentifiedAnalytic {
	bool IsLookAroundComplete; // 0x68(0x01)
	bool IsWalkAroundComplete; // 0x69(0x01)
	bool IsRunningComplete; // 0x6a(0x01)
	bool IsCrouchComplete; // 0x6b(0x01)
	bool IsFirstVaultComplete; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	int32_t TimeToCompleteAreaOne; // 0x70(0x04)
	bool IsGeneratorComplete; // 0x74(0x01)
	bool IsSecondVaultComplete; // 0x75(0x01)
	char pad_76[0x2]; // 0x76(0x02)
	int32_t TimeToCompleteAreaTwo; // 0x78(0x04)
	bool IsBeartrapComplete; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
	int32_t TimeToCompleteAreaThree; // 0x80(0x04)
	bool IsPalletComplete; // 0x84(0x01)
	bool IsUnhookMegComplete; // 0x85(0x01)
	bool IsLockerComplete; // 0x86(0x01)
	bool IsGetUnhookedComplete; // 0x87(0x01)
	bool IsHealMegComplete; // 0x88(0x01)
	bool IsGetHealedComplete; // 0x89(0x01)
	bool IsOpenGateComplete; // 0x8a(0x01)
	bool IsEscapeComplete; // 0x8b(0x01)
	int32_t TimeToCompleteAreaFour; // 0x8c(0x04)
	int32_t TotalTimeInTutorial; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FString tutorialId; // 0x98(0x10)
};

// ScriptStruct DBDAnalytics.SurvivorTutorialAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FSurvivorTutorialAnalytics : FUniquelyIdentifiedAnalytic {
	int32_t SecondsSpentInTutorial; // 0x68(0x04)
	int32_t SecondsSpentInIntroSection; // 0x6c(0x04)
	int32_t SecondsSpentInSkillchecksSection; // 0x70(0x04)
	int32_t SecondsSpentInKillerSection; // 0x74(0x04)
	int32_t SecondsSpentInStealthSection; // 0x78(0x04)
	int32_t SecondsSpentInHookSection; // 0x7c(0x04)
	int32_t SecondsSpentInHealthSection; // 0x80(0x04)
	int32_t SecondsSpentInRescueSection; // 0x84(0x04)
	int32_t SecondsSpentInEscapeSection; // 0x88(0x04)
	bool WasScratchMarksAndWildlifeEventTriggered; // 0x8c(0x01)
	bool WasRushedActionEventTriggered; // 0x8d(0x01)
	bool WasSuccessfulStealthEventTriggered; // 0x8e(0x01)
	bool WasStealthObjectiveCompleted; // 0x8f(0x01)
	bool WasHatchEscapeObjectiveCompleted; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct DBDAnalytics.SyncLoadAnalytics
// Size: 0xb8 (Inherited: 0x68)
struct FSyncLoadAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString AssetName; // 0x68(0x10)
	float LoadTimeMilliseconds; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FString DeviceProfileName; // 0x80(0x10)
	struct FString BuildConfiguration; // 0x90(0x10)
	int32_t ChangelistNumber; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FString MapName; // 0xa8(0x10)
};

// ScriptStruct DBDAnalytics.TexturegroupChartingAnalytics
// Size: 0xb8 (Inherited: 0x68)
struct FTexturegroupChartingAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString texturegroup_name; // 0x68(0x10)
	struct FString texturegroups_guid; // 0x78(0x10)
	struct FString map_name; // 0x88(0x10)
	int32_t avg_qty_streaming; // 0x98(0x04)
	int32_t max_qty_streaming; // 0x9c(0x04)
	int32_t avg_memory_streaming; // 0xa0(0x04)
	int32_t max_memory_streaming; // 0xa4(0x04)
	int32_t avg_qty_non_streaming; // 0xa8(0x04)
	int32_t max_qty_non_streaming; // 0xac(0x04)
	int32_t avg_memory_non_streaming; // 0xb0(0x04)
	int32_t max_memory_non_streaming; // 0xb4(0x04)
};

// ScriptStruct DBDAnalytics.TransactionAnalytics
// Size: 0xf0 (Inherited: 0x68)
struct FTransactionAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString TransactionType; // 0x68(0x10)
	struct FString TransactionSource; // 0x78(0x10)
	struct FString SourceId; // 0x88(0x10)
	int32_t SourceTier; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct FString CurrencyType; // 0xa0(0x10)
	int32_t CurrencyAmount; // 0xb0(0x04)
	int32_t CurrencyBalance; // 0xb4(0x04)
	int32_t LevelAchieved; // 0xb8(0x04)
	int32_t Prestige; // 0xbc(0x04)
	struct FString ItemIDAcquired; // 0xc0(0x10)
	int32_t Rank; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FString SelectedCharacter; // 0xd8(0x10)
	bool TransactionTriggeredLevelUp; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
};

// ScriptStruct DBDAnalytics.WalesCypherAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FWalesCypherAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString EnteredSequence; // 0x68(0x10)
	struct FString ExpectedSequence; // 0x78(0x10)
	int32_t TimeoutThreshold; // 0x88(0x04)
	bool success; // 0x8c(0x01)
	bool TIMEOUT; // 0x8d(0x01)
	bool CharmGranted; // 0x8e(0x01)
	char pad_8F[0x1]; // 0x8f(0x01)
	int32_t ValidCharacterSelcted; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

