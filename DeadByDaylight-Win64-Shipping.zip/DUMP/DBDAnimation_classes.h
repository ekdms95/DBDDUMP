// Class DBDAnimation.PlayerAnimInstance
// Size: 0x4f0 (Inherited: 0x270)
struct UPlayerAnimInstance : UAnimInstance {
	char pad_270[0x20]; // 0x270(0x20)
	struct ADBDPlayer* _owningPlayer; // 0x290(0x08)
	struct UAnimEffectBlackBoard* _animEffectBlackBoard; // 0x298(0x08)
	struct UAnimEffectHandler* _animEffectHandlerForSFX; // 0x2a0(0x08)
	struct UAnimEffectHandler* _animEffectHandlerForVFX; // 0x2a8(0x08)
	struct UAnimEffectHandler* _animEffectHandlerClassForSFX; // 0x2b0(0x08)
	struct UAnimEffectHandler* _animEffectHandlerClassForVFX; // 0x2b8(0x08)
	struct TArray<struct FTaggedAnimCollection> _taggedAnimCollections; // 0x2c0(0x10)
	struct TMap<struct FGameplayTag, struct UAnimSequence*> _animations; // 0x2d0(0x50)
	struct TMap<struct FGameplayTag, struct UBlendSpace*> _blendspaces; // 0x320(0x50)
	struct TMap<struct FGameplayTag, struct UAimOffsetBlendSpace*> _aimoffsets; // 0x370(0x50)
	struct TMap<struct FGameplayTag, struct UBlendSpace1D*> _blendspaces1d; // 0x3c0(0x50)
	struct TMap<struct FGameplayTag, struct UAimOffsetBlendSpace1D*> _aimoffsets1d; // 0x410(0x50)
	struct TMap<struct FGameplayTag, struct FAnimSequenceSelector> _selectors; // 0x460(0x50)
	bool _isInParadise; // 0x4b0(0x01)
	bool _isIntroCompleted; // 0x4b1(0x01)
	bool _isLevelReadyToPlay; // 0x4b2(0x01)
	char pad_4B3[0x5]; // 0x4b3(0x05)
	struct FActivationDefinition _activationDefinition; // 0x4b8(0x28)
	char pad_4E0[0x10]; // 0x4e0(0x10)

	void OnLevelReadyToPlay(); // Function DBDAnimation.PlayerAnimInstance.OnLevelReadyToPlay // (Final|Native|Protected) // @ game+0x2bd0010
	void OnIntroCompleted(); // Function DBDAnimation.PlayerAnimInstance.OnIntroCompleted // (Native|Protected) // @ game+0x2bcff70
	bool HasBeenNotified(struct FName AnimNotify); // Function DBDAnimation.PlayerAnimInstance.HasBeenNotified // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcfcc0
	struct ADBDPlayer* GetOwningPlayer(); // Function DBDAnimation.PlayerAnimInstance.GetOwningPlayer // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcfc90
};

// Class DBDAnimation.BaseSurvivorAnimInstance
// Size: 0x4f0 (Inherited: 0x4f0)
struct UBaseSurvivorAnimInstance : UPlayerAnimInstance {
	struct ACamperPlayer* _owningSurvivor; // 0x4e8(0x08)

	struct ACamperPlayer* GetOwningSurvivor(); // Function DBDAnimation.BaseSurvivorAnimInstance.GetOwningSurvivor // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcd700
};

// Class DBDAnimation.AimOffsetSurvivorSubAnimInstance
// Size: 0x550 (Inherited: 0x4f0)
struct UAimOffsetSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	float _pitch; // 0x4f0(0x04)
	float _yaw; // 0x4f4(0x04)
	float _yawInterpolated; // 0x4f8(0x04)
	bool _allowLookAt; // 0x4fc(0x01)
	bool _isUsingAimItem; // 0x4fd(0x01)
	bool _isInjured; // 0x4fe(0x01)
	bool _isCrawling; // 0x4ff(0x01)
	bool _isIdle; // 0x500(0x01)
	bool _isDrasticYawChangeDetected; // 0x501(0x01)
	char pad_502[0x2]; // 0x502(0x02)
	float _yawInterpolationSpeed; // 0x504(0x04)
	float _yawDeadzoneStart; // 0x508(0x04)
	float _yawClampValue; // 0x50c(0x04)
	float _yawDrasticChangeUpperLimit; // 0x510(0x04)
	float _yawDrasticChangeLowerLimit; // 0x514(0x04)
	float _yawDrasticChangeInterpolationSpeed; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct UCurveFloat* _yawInterpolateEaseIn; // 0x520(0x08)
	struct UCurveFloat* _yawInterpolateEaseOut; // 0x528(0x08)
	float _yawInterpolationEaseInLength; // 0x530(0x04)
	float _yawInterpolationEaseOutDistance; // 0x534(0x04)
	bool _isYawInDeadZone; // 0x538(0x01)
	char pad_539[0x3]; // 0x539(0x03)
	float _currentTargetYaw; // 0x53c(0x04)
	float _yawAcceleration; // 0x540(0x04)
	float _yawAccelerationTime; // 0x544(0x04)
	char pad_548[0x8]; // 0x548(0x08)
};

// Class DBDAnimation.ArmIKSurvivorSubAnimInstance
// Size: 0x570 (Inherited: 0x4f0)
struct UArmIKSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	struct FRotator _rightWristUpRotation; // 0x4f0(0x0c)
	struct FRotator _leftWristUpRotation; // 0x4fc(0x0c)
	struct FFloatRange _localWristYawRange; // 0x508(0x10)
	struct FFloatRange _localWristPitchRange; // 0x518(0x10)
	float _armInterpolationSpeed; // 0x528(0x04)
	float _handInterpolationSpeed; // 0x52c(0x04)
	float _alphaLerpTime; // 0x530(0x04)
	float _reachPadding; // 0x534(0x04)
	float _rightArmIKAlpha; // 0x538(0x04)
	float _leftArmIKAlpha; // 0x53c(0x04)
	enum class EArmIkMode _armIkMode; // 0x540(0x01)
	char pad_541[0x7]; // 0x541(0x07)
	struct UArmDetectionFanComponent* _rightDetectionFan; // 0x548(0x08)
	struct UArmDetectionFanComponent* _leftDetectionFan; // 0x550(0x08)
	struct USkeletalMeshComponent* _meshComponent; // 0x558(0x08)
	char pad_560[0x10]; // 0x560(0x10)

	void ChangeMode(enum class EArmIkMode NewMode); // Function DBDAnimation.ArmIKSurvivorSubAnimInstance.ChangeMode // (Final|Native|Public|BlueprintCallable) // @ game+0x2bcd620
};

// Class DBDAnimation.BaseKillerAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UBaseKillerAnimInstance : UPlayerAnimInstance {
	struct ASlasherPlayer* _owningKiller; // 0x4e8(0x08)
	bool _firstPersonView; // 0x4f0(0x01)
	char pad_4F9[0x7]; // 0x4f9(0x07)

	struct ASlasherPlayer* GetOwningKiller(); // Function DBDAnimation.BaseKillerAnimInstance.GetOwningKiller // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcd6a0
	void DBD_ForceAnimPOV(int32_t animPOV); // Function DBDAnimation.BaseKillerAnimInstance.DBD_ForceAnimPOV // (Final|Exec|Native|Private) // @ game+0x2b49820
};

// Class DBDAnimation.BasePlayerAttackSubAnimInstance
// Size: 0x5b0 (Inherited: 0x4f0)
struct UBasePlayerAttackSubAnimInstance : UPlayerAnimInstance {
	enum class EAttackSubstate _attackState; // 0x4e8(0x01)
	float _direction; // 0x4ec(0x04)
	float _strafeAngle; // 0x4f0(0x04)
	bool _isStrafe; // 0x4f4(0x01)
	float _attackInPlayRate; // 0x4f8(0x04)
	char pad_4FE[0x2]; // 0x4fe(0x02)
	struct FAnimSequenceSelector _attackIn; // 0x500(0x18)
	float _attackSwingPlayRate; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct FAnimSequenceSelector _attackSwing; // 0x520(0x18)
	float _attackMissPlayRate; // 0x538(0x04)
	char pad_53C[0x4]; // 0x53c(0x04)
	struct FAnimSequenceSelector _attackMiss; // 0x540(0x18)
	float _attackHitPlayRate; // 0x558(0x04)
	char pad_55C[0x4]; // 0x55c(0x04)
	struct FAnimSequenceSelector _attackHit; // 0x560(0x18)
	float _attackBounceOfWallPlayRate; // 0x578(0x04)
	char pad_57C[0x4]; // 0x57c(0x04)
	struct FAnimSequenceSelector _attackBounceOfWall; // 0x580(0x18)
	char pad_598[0x14]; // 0x598(0x14)
	bool _firstPersonView; // 0x5ac(0x01)
	char pad_5AD[0x3]; // 0x5ad(0x03)
};

// Class DBDAnimation.BaseKillerAttackSubAnimInstance
// Size: 0x5c0 (Inherited: 0x5b0)
struct UBaseKillerAttackSubAnimInstance : UBasePlayerAttackSubAnimInstance {
	struct ASlasherPlayer* _owningKiller; // 0x5b0(0x08)
	char pad_5B8[0x8]; // 0x5b8(0x08)

	struct ASlasherPlayer* GetOwningKiller(); // Function DBDAnimation.BaseKillerAttackSubAnimInstance.GetOwningKiller // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcd6a0
};

// Class DBDAnimation.BaseKillerWeaponAnimInstance
// Size: 0x280 (Inherited: 0x270)
struct UBaseKillerWeaponAnimInstance : UAnimInstance {
	enum class EAttackSubstate _attackState; // 0x270(0x01)
	char pad_271[0xf]; // 0x271(0x0f)
};

// Class DBDAnimation.BaseMenuAnimInstance
// Size: 0x270 (Inherited: 0x270)
struct UBaseMenuAnimInstance : UAnimInstance {

	struct ADBDMenuPlayer* GetOwningMenuPlayer(); // Function DBDAnimation.BaseMenuAnimInstance.GetOwningMenuPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcd6d0
};

// Class DBDAnimation.BasePowerSubAnimInstance
// Size: 0x500 (Inherited: 0x500)
struct UBasePowerSubAnimInstance : UBaseKillerAnimInstance {
	bool _isUsingPower; // 0x4f8(0x01)
};

// Class DBDAnimation.BreathingSurvivorSubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UBreathingSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isDead; // 0x4f0(0x01)
	char pad_4F1[0x7]; // 0x4f1(0x07)
	struct UAnimSequence* _breathing; // 0x4f8(0x08)
};

// Class DBDAnimation.ChestAnimInstance
// Size: 0x290 (Inherited: 0x270)
struct UChestAnimInstance : UAnimInstance {
	struct ASearchable* _owningChest; // 0x270(0x08)
	bool _isOpen; // 0x278(0x01)
	bool _isBeingPriedOpen; // 0x279(0x01)
	char pad_27A[0xe]; // 0x27a(0x0e)
	struct UInteractionDefinition* _openChestInteraction; // 0x288(0x08)

	void OnSearchedChanged(bool searched); // Function DBDAnimation.ChestAnimInstance.OnSearchedChanged // (Final|Native|Private) // @ game+0x2bcd7f0
};

// Class DBDAnimation.CrowAnimInstance
// Size: 0x280 (Inherited: 0x270)
struct UCrowAnimInstance : UAnimInstance {
	bool _shouldTakeOff; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct UWorldRunawayMeshComponent* _crow; // 0x278(0x08)
};

// Class DBDAnimation.DynamicAccessoryAnimInstance
// Size: 0x280 (Inherited: 0x270)
struct UDynamicAccessoryAnimInstance : UAnimInstance {
	bool _isInMenu; // 0x270(0x01)
	bool _isInGame; // 0x271(0x01)
	char pad_272[0x2]; // 0x272(0x02)
	struct TWeakObjectPtr<struct USkeletalMeshComponent> _masterMesh; // 0x274(0x08)
	char pad_27C[0x4]; // 0x27c(0x04)
};

// Class DBDAnimation.FaceCorrectionSurvivorSubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UFaceCorrectionSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isIdle; // 0x4f0(0x01)
	bool _isFreddyMori; // 0x4f1(0x01)
	bool _isInCloset; // 0x4f2(0x01)
	bool _isEdgeCase; // 0x4f3(0x01)
	bool _isInjured; // 0x4f4(0x01)
	bool _isHealingOthers; // 0x4f5(0x01)
	bool _isCrouched; // 0x4f6(0x01)
	char pad_4F7[0x9]; // 0x4f7(0x09)
};

// Class DBDAnimation.GeneratorAnimInstance
// Size: 0x290 (Inherited: 0x280)
struct UGeneratorAnimInstance : USleepingAnimInstance {
	struct AGenerator* _owningGenerator; // 0x280(0x08)
	bool _rushFailed; // 0x288(0x01)
	bool _isActivated; // 0x289(0x01)
	char pad_28A[0x2]; // 0x28a(0x02)
	float _percentComplete; // 0x28c(0x04)

	void SetSkillCheckSuccess(bool success); // Function DBDAnimation.GeneratorAnimInstance.SetSkillCheckSuccess // (Final|Native|Public|BlueprintCallable) // @ game+0x2bcd8a0
};

// Class DBDAnimation.HagDynamicAccessoryAnimInstance
// Size: 0x280 (Inherited: 0x280)
struct UHagDynamicAccessoryAnimInstance : UDynamicAccessoryAnimInstance {
};

// Class DBDAnimation.HealSurvivorSubAnimInstance
// Size: 0x540 (Inherited: 0x4f0)
struct UHealSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	char pad_4F0[0x40]; // 0x4f0(0x40)
	bool _isHealingACrawlingTarget; // 0x530(0x01)
	bool _isHealingOtherNoMedkit; // 0x531(0x01)
	bool _isHealingOtherMedkit; // 0x532(0x01)
	bool _isHealingSelfNoMedkit; // 0x533(0x01)
	bool _isHealingSelfMedkit; // 0x534(0x01)
	bool _isWakingUpOther; // 0x535(0x01)
	bool _isBeingHealed; // 0x536(0x01)
	bool _isBeingMended; // 0x537(0x01)
	bool _isMendingOther; // 0x538(0x01)
	bool _hasSkillCheckFailed; // 0x539(0x01)
	bool _isCrawling; // 0x53a(0x01)
	bool _hasHealerSkillCheckFailed; // 0x53b(0x01)
	char pad_53C[0x4]; // 0x53c(0x04)

	void ResetHealerSkillCheckFailed(); // Function DBDAnimation.HealSurvivorSubAnimInstance.ResetHealerSkillCheckFailed // (Final|Native|Protected|BlueprintCallable) // @ game+0x2bcd880
	void OnHealerSkillCheckResponseAesthetic(bool success, struct ADBDPlayer* healer); // Function DBDAnimation.HealSurvivorSubAnimInstance.OnHealerSkillCheckResponseAesthetic // (Final|Native|Protected) // @ game+0x2bcd730
};

// Class DBDAnimation.InteractionSurvivorSubAnimInstance
// Size: 0x530 (Inherited: 0x4f0)
struct UInteractionSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isAgainstSmallKiller; // 0x4f0(0x01)
	bool _isInsideCloset; // 0x4f1(0x01)
	bool _isEnteringCloset; // 0x4f2(0x01)
	bool _isBeingCarried; // 0x4f3(0x01)
	bool _isHooked; // 0x4f4(0x01)
	bool _isSacrificeStruggling; // 0x4f5(0x01)
	char pad_4F6[0x2]; // 0x4f6(0x02)
	float _sacrificeStrugglePercent; // 0x4f8(0x04)
	bool _selfUnhookFailed; // 0x4fc(0x01)
	enum class EInteractionAnimation _interactionAnimation; // 0x4fd(0x01)
	char pad_4FE[0x2]; // 0x4fe(0x02)
	struct FVector _snapPosition; // 0x500(0x0c)
	bool _isInteractingWithEscapeDoor; // 0x50c(0x01)
	char pad_50D[0x23]; // 0x50d(0x23)
};

// Class DBDAnimation.KillerAnimInstance
// Size: 0x5b0 (Inherited: 0x500)
struct UKillerAnimInstance : UBaseKillerAnimInstance {
	struct FVector _leftHandIKLocationFPV; // 0x4f8(0x0c)
	struct FVector _rightHandIKLocationFPV; // 0x504(0x0c)
	bool _isAnyMontagePlaying; // 0x510(0x01)
	bool _isCarrying; // 0x511(0x01)
	struct FVector _firstPersonCarryOffset; // 0x514(0x0c)
	struct FVector _firstPersonCarryOffsetLookingDown; // 0x520(0x0c)
	bool _isInAir; // 0x52c(0x01)
	bool _isSpectator; // 0x52d(0x01)
	bool _isIdle; // 0x52e(0x01)
	float _animDirection; // 0x530(0x04)
	float _animSpeed; // 0x534(0x04)
	float _animPitch; // 0x538(0x04)
	float _animYaw; // 0x53c(0x04)
	float _pelvisHeight; // 0x540(0x04)
	float _idleTime; // 0x544(0x04)
	int32_t _directionSwitch; // 0x548(0x04)
	bool _isAttacking; // 0x54c(0x01)
	bool _isPlayingAnyMontage; // 0x54d(0x01)
	struct FVector _leftClearFrontSpaceVector; // 0x550(0x0c)
	struct FVector _rightClearFrontSpaceVector; // 0x55c(0x0c)
	struct FVector _velocity; // 0x568(0x0c)
	struct FVector _rightFootEffectorLocation; // 0x574(0x0c)
	struct FVector _leftFootEffectorLocation; // 0x580(0x0c)
	enum class EInteractionAnimation _interactionType; // 0x58c(0x01)
	struct UArmIKSensorComponent* _armIKSensorComponent; // 0x590(0x08)
	enum class EAttackSubstate _attackState; // 0x598(0x01)
	char pad_599[0x3]; // 0x599(0x03)
	float _forwardVelocity; // 0x59c(0x04)
	float _lateralVelocity; // 0x5a0(0x04)
	char pad_5A4[0xc]; // 0x5a4(0x0c)
};

// Class DBDAnimation.KillerAttackSubAnimInstance
// Size: 0x5c0 (Inherited: 0x5c0)
struct UKillerAttackSubAnimInstance : UBaseKillerAttackSubAnimInstance {
	bool _isCarrying; // 0x5b8(0x01)
	bool _isActive; // 0x5b9(0x01)
};

// Class DBDAnimation.KillerLocomotionSubAnimInstance
// Size: 0x5b0 (Inherited: 0x500)
struct UKillerLocomotionSubAnimInstance : UBaseKillerAnimInstance {
	struct UAnimSequence* _landLightTPV; // 0x4f8(0x08)
	struct UAnimSequence* _landLightFPV; // 0x500(0x08)
	struct UBlendSpace1D* _BSLandTPV; // 0x508(0x08)
	struct UBlendSpace1D* _BSLandFPV; // 0x510(0x08)
	struct UAnimSequence* _walkToFallTPV; // 0x518(0x08)
	struct UAnimSequence* _walkToFallFPV; // 0x520(0x08)
	struct UAnimSequence* _carryIdleTPV; // 0x528(0x08)
	struct UAnimSequence* _carryIdleFPV; // 0x530(0x08)
	struct UAnimSequence* _fallingTPV; // 0x538(0x08)
	struct UAnimSequence* _fallingFPV; // 0x540(0x08)
	bool _isFirstPersonView; // 0x548(0x01)
	struct UAnimSequence* _landLight; // 0x550(0x08)
	struct UBlendSpace1D* _BSLand; // 0x558(0x08)
	struct UAnimSequence* _walkToFall; // 0x560(0x08)
	struct UAnimSequence* _carryIdle; // 0x568(0x08)
	struct UAnimSequence* _falling; // 0x570(0x08)
	bool _isVaultingToFall; // 0x578(0x01)
	char pad_57A[0x6]; // 0x57a(0x06)
	struct FTagStateBool _isVaultingToFallState; // 0x580(0x30)
};

// Class DBDAnimation.LegIKSurvivorSubAnimInstance
// Size: 0x600 (Inherited: 0x4f0)
struct ULegIKSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	struct FVector _leftFootOffset; // 0x4f0(0x0c)
	struct FVector _rightFootOffset; // 0x4fc(0x0c)
	struct FVector _pelvisOffset; // 0x508(0x0c)
	bool _isIdle; // 0x514(0x01)
	bool _isCrouched; // 0x515(0x01)
	char pad_516[0x2]; // 0x516(0x02)
	struct FRotator _rightFootDeltaRotator; // 0x518(0x0c)
	struct FRotator _leftFootDeltaRotator; // 0x524(0x0c)
	struct UAnimCollection* AnimCollection; // 0x530(0x08)
	struct FName _floorJoint; // 0x538(0x0c)
	float _pelvisOffsetTreshold; // 0x544(0x04)
	struct FFloatRange _pelvisOffsetRange; // 0x548(0x10)
	struct FFloatRange _pelvisOffsetRangeCrouched; // 0x558(0x10)
	float _pelvisOffsetInterpolationSpeed; // 0x568(0x04)
	struct FFloatRange _footOffsetRange; // 0x56c(0x10)
	struct FFloatRange _footOffsetRangeCrouched; // 0x57c(0x10)
	float _footOffsetInterpolationSpeed; // 0x58c(0x04)
	struct FFloatRange _footPitchDeltaRange; // 0x590(0x10)
	struct UBaseGroundDetectorComponent* _leftFootGroundDetector; // 0x5a0(0x08)
	struct UBaseGroundDetectorComponent* _rightFootGroundDetector; // 0x5a8(0x08)
	float maxLocalHeightForPlanting; // 0x5b0(0x04)
	char pad_5B4[0x3c]; // 0x5b4(0x3c)
	struct ULocomotionPredictor* _locomotionPredictor; // 0x5f0(0x08)
	char pad_5F8[0x8]; // 0x5f8(0x08)
};

// Class DBDAnimation.LocomotionLookAtSurvivorSubAnimInstance
// Size: 0x550 (Inherited: 0x4f0)
struct ULocomotionLookAtSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isInjured; // 0x4f0(0x01)
	bool _isCrawling; // 0x4f1(0x01)
	bool _isDead; // 0x4f2(0x01)
	bool _isUsingAimItem; // 0x4f3(0x01)
	float _aimOffsetPitch; // 0x4f4(0x04)
	float _aimOffsetYaw; // 0x4f8(0x04)
	float _aimOffsetYawInterpolated; // 0x4fc(0x04)
	bool _allowLookAt; // 0x500(0x01)
	bool _isDrasticAimOffsetYawChangeDetected; // 0x501(0x01)
	char pad_502[0x2]; // 0x502(0x02)
	float _aimOffsetYawInterpolationSpeed; // 0x504(0x04)
	float _aimOffsetYawDeadzoneStart; // 0x508(0x04)
	float _aimOffsetYawClampValue; // 0x50c(0x04)
	float _aimOffsetYawDrasticChangeUpperLimit; // 0x510(0x04)
	float _aimOffsetYawDrasticChangeLowerLimit; // 0x514(0x04)
	float _aimOffsetYawDrasticChangeInterpolationSpeed; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct UCurveFloat* _aimOffsetYawInterpolateEaseIn; // 0x520(0x08)
	struct UCurveFloat* _aimOffsetYawInterpolateEaseOut; // 0x528(0x08)
	float _aimOffsetYawInterpolationEaseInLength; // 0x530(0x04)
	float _aimOffsetYawInterpolationEaseOutDistance; // 0x534(0x04)
	bool _isAimOffsetYawInDeadZone; // 0x538(0x01)
	char pad_539[0x3]; // 0x539(0x03)
	float _currentTargetAimOffsetYaw; // 0x53c(0x04)
	float _aimOffsetYawAcceleration; // 0x540(0x04)
	float _aimOffsetYawAccelerationTime; // 0x544(0x04)
	char pad_548[0x8]; // 0x548(0x08)
};

// Class DBDAnimation.LocomotionPredictor
// Size: 0x80 (Inherited: 0x30)
struct ULocomotionPredictor : UObject {
	struct TMap<struct UAnimSequence*, struct FFootBoneData> _animFootData; // 0x30(0x50)
};

// Class DBDAnimation.LocomotionSurvivorSubAnimInstance
// Size: 0x760 (Inherited: 0x4f0)
struct ULocomotionSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isRecoveringWhileCrawling; // 0x4f0(0x01)
	bool _isTenacityPerkActive; // 0x4f1(0x01)
	char pad_4F2[0x2]; // 0x4f2(0x02)
	float _wasStandingResetTime; // 0x4f4(0x04)
	float _wasRunningResetTime; // 0x4f8(0x04)
	float _wasCrouchingResetTime; // 0x4fc(0x04)
	float _wasMovingResetTime; // 0x500(0x04)
	bool _isIdle; // 0x504(0x01)
	char pad_505[0x3]; // 0x505(0x03)
	float _recentlyIdleCooldownTime; // 0x508(0x04)
	float _recentlyNotIdleCooldownTime; // 0x50c(0x04)
	bool _wasIdleRecently; // 0x510(0x01)
	bool _idleInterupt; // 0x511(0x01)
	bool _isAgainstSmallKiller; // 0x512(0x01)
	bool _isMoving; // 0x513(0x01)
	bool _wasRunning; // 0x514(0x01)
	bool _isRunning; // 0x515(0x01)
	bool _wasCrouching; // 0x516(0x01)
	bool _isCrouching; // 0x517(0x01)
	bool _wasStanding; // 0x518(0x01)
	bool _isStanding; // 0x519(0x01)
	bool _isCrawling; // 0x51a(0x01)
	bool _isDead; // 0x51b(0x01)
	float _walkAnimSpeed; // 0x51c(0x04)
	float _walkAnimStartOffset; // 0x520(0x04)
	float _walkAnimPlayRateMultiplier; // 0x524(0x04)
	bool _wasLastDamageSourceDeepWounds; // 0x528(0x01)
	bool _isStrafing; // 0x529(0x01)
	bool _isUsingDeadHard; // 0x52a(0x01)
	char pad_52B[0x1]; // 0x52b(0x01)
	float _direction; // 0x52c(0x04)
	bool _isUsingAimItem; // 0x530(0x01)
	bool _isBeingCarried; // 0x531(0x01)
	char pad_532[0x2]; // 0x532(0x02)
	float _aimOffsetPitch; // 0x534(0x04)
	bool _turn180Active; // 0x538(0x01)
	bool _turningRight; // 0x539(0x01)
	bool _start180Active; // 0x53a(0x01)
	char pad_53B[0x1]; // 0x53b(0x01)
	float _aimOffsetYawInterpolated; // 0x53c(0x04)
	bool _allowLookAt; // 0x540(0x01)
	bool _isDrasticAimOffsetYawChangeDetected; // 0x541(0x01)
	char pad_542[0x2]; // 0x542(0x02)
	float _aimOffsetYawClampValue; // 0x544(0x04)
	float _maxParadiseWalkCycleOffSet; // 0x548(0x04)
	char pad_54C[0x4]; // 0x54c(0x04)
	float _minParadiseWalkPlayRateMultiplier; // 0x550(0x04)
	char pad_554[0x4]; // 0x554(0x04)
	float _turn180DetectionPrecision; // 0x558(0x04)
	float _turn180DetectionDeadZone; // 0x55c(0x04)
	float _turn180PrevVelocitiesCacheDuration; // 0x560(0x04)
	float _minDurationBetweenTurn180Detection; // 0x564(0x04)
	float _start180DetectionPrecision; // 0x568(0x04)
	float _idleDurationFor180StartDetection; // 0x56c(0x04)
	float _durationBeforeStart180Reset; // 0x570(0x04)
	char pad_574[0x1ec]; // 0x574(0x1ec)
};

// Class DBDAnimation.LookAtTargetKillerSubAnimInstance
// Size: 0x6b0 (Inherited: 0x500)
struct ULookAtTargetKillerSubAnimInstance : UBaseKillerAnimInstance {
	float _maxDistanceForTargetDetection; // 0x4f8(0x04)
	struct FName _headSocket; // 0x4fc(0x0c)
	struct FName _rootSocket; // 0x508(0x0c)
	float _preferredMinLookAtTime; // 0x514(0x04)
	float _distanceScoreFactor; // 0x518(0x04)
	float _angleScoreFactor; // 0x51c(0x04)
	float _sameTargetScoreFactor; // 0x520(0x04)
	float _yawToTarget; // 0x524(0x04)
	float _pitchToTarget; // 0x528(0x04)
	bool _hasVisibleTarget; // 0x52c(0x01)
	char pad_535[0x17b]; // 0x535(0x17b)

	void OnChaseStarted(struct ADBDPlayer* Target); // Function DBDAnimation.LookAtTargetKillerSubAnimInstance.OnChaseStarted // (Final|Native|Private) // @ game+0x2bcfef0
	void OnChaseEnded(struct ADBDPlayer* Target, float chaseTime); // Function DBDAnimation.LookAtTargetKillerSubAnimInstance.OnChaseEnded // (Final|Native|Private) // @ game+0x2bcfe20
};

// Class DBDAnimation.LookAtThreatSurvivorSubAnimInstance
// Size: 0x650 (Inherited: 0x4f0)
struct ULookAtThreatSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	float _maxDistanceForThreatDetection; // 0x4f0(0x04)
	struct FName _headSocket; // 0x4f4(0x0c)
	struct FName _rootSocket; // 0x500(0x0c)
	float _yawToThreat; // 0x50c(0x04)
	float _pitchToThreat; // 0x510(0x04)
	bool _isVisibleThreat; // 0x514(0x01)
	char pad_515[0x13b]; // 0x515(0x13b)
};

// Class DBDAnimation.MeshRotationCorrectionSubAnimInstance
// Size: 0x510 (Inherited: 0x4f0)
struct UMeshRotationCorrectionSubAnimInstance : UBaseSurvivorAnimInstance {
	float _rotationInterpSpeed; // 0x4f0(0x04)
	bool _isCrawling; // 0x4f4(0x01)
	char pad_4F5[0x3]; // 0x4f5(0x03)
	struct FRotator _toSlopeRotation; // 0x4f8(0x0c)
	char pad_504[0x4]; // 0x504(0x04)
	struct UCharacterMovementComponent* _movementComponent; // 0x508(0x08)
};

// Class DBDAnimation.OpenChestSurvivorSubAnimInstance
// Size: 0x520 (Inherited: 0x4f0)
struct UOpenChestSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isInteractingWithChest; // 0x4f0(0x01)
	char pad_4F1[0x3]; // 0x4f1(0x03)
	struct FGameplayTag _interactionPhase; // 0x4f4(0x0c)
	bool _isInteractingWithOpenChest; // 0x500(0x01)
	char pad_501[0x3]; // 0x501(0x03)
	struct FVector _snapPosition; // 0x504(0x0c)
	bool _isVomiting; // 0x510(0x01)
	char pad_511[0xf]; // 0x511(0x0f)
};

// Class DBDAnimation.PalletAnimInstance
// Size: 0x2a0 (Inherited: 0x280)
struct UPalletAnimInstance : USleepingAnimInstance {
	bool _isPulledDown; // 0x280(0x01)
	bool _isBeingPulledUp; // 0x281(0x01)
	bool _isBeingDestroyed; // 0x282(0x01)
	char pad_283[0x1]; // 0x283(0x01)
	float _isBeingDestroyedPlayRate; // 0x284(0x04)
	struct FAnimSequenceSelector _destroyPalletAnim; // 0x288(0x18)

	void OnKillerSet(struct ASlasherPlayer* killer); // Function DBDAnimation.PalletAnimInstance.OnKillerSet // (Final|Native|Private) // @ game+0x2bcff90
};

// Class DBDAnimation.RBTSurvivorSubAnimInstance
// Size: 0x540 (Inherited: 0x4f0)
struct URBTSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	char pad_4F0[0x40]; // 0x4f0(0x40)
	bool _isRemovingRBT; // 0x530(0x01)
	bool _hasSkillCheckFailed; // 0x531(0x01)
	char pad_532[0xe]; // 0x532(0x0e)
};

// Class DBDAnimation.RepairGeneratorSubAnimInstance
// Size: 0x300 (Inherited: 0x270)
struct URepairGeneratorSubAnimInstance : UAnimInstance {
	struct AGenerator* _owningGenerator; // 0x270(0x08)
	bool _isBeingRepaired; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct ACamperPlayer* _repairingSurvivor; // 0x280(0x08)
	struct UAnimSequence* _animSequence; // 0x288(0x08)
	struct FGameplayTag _interactionTag; // 0x290(0x0c)
	struct FGameplayTag _currentAnimId; // 0x29c(0x0c)
	struct TMap<struct FGameplayTag, struct UAnimSequence*> _taggedAnimSequences; // 0x2a8(0x50)
	char pad_2F8[0x8]; // 0x2f8(0x08)
};

// Class DBDAnimation.RepairGeneratorSurvivorSubAnimInstance
// Size: 0x570 (Inherited: 0x4f0)
struct URepairGeneratorSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	char pad_4F0[0x48]; // 0x4f0(0x48)
	struct FVector _snapPosition; // 0x538(0x0c)
	int32_t _side; // 0x544(0x04)
	int32_t _repairAnimIndex; // 0x548(0x04)
	char pad_54C[0xc]; // 0x54c(0x0c)
	bool _isRepairingGenerator; // 0x558(0x01)
	bool _rightFootDown; // 0x559(0x01)
	char pad_55A[0x2]; // 0x55a(0x02)
	int32_t _animSequenceVariationCount; // 0x55c(0x04)
	bool _isVomiting; // 0x560(0x01)
	bool _hasSkillCheckFailed; // 0x561(0x01)
	char pad_562[0xe]; // 0x562(0x0e)
};

// Class DBDAnimation.SabotageSurvivorSubAnimInstance
// Size: 0x540 (Inherited: 0x4f0)
struct USabotageSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	char pad_4F0[0x40]; // 0x4f0(0x40)
	bool _isSabotaging; // 0x530(0x01)
	bool _hasSkillCheckFailed; // 0x531(0x01)
	char pad_532[0xe]; // 0x532(0x0e)
};

// Class DBDAnimation.ScreamSurvivorSubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UScreamSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _screamTrigger; // 0x4f0(0x01)
	char pad_4F1[0xf]; // 0x4f1(0x0f)

	void ResetScreamTrigger(); // Function DBDAnimation.ScreamSurvivorSubAnimInstance.ResetScreamTrigger // (Final|Native|Protected|BlueprintCallable) // @ game+0x2bd0140
};

// Class DBDAnimation.SkillCheckFailureTracker
// Size: 0x30 (Inherited: 0x30)
struct USkillCheckFailureTracker : UInterface {

	void ResetSkillCheckFailed(); // Function DBDAnimation.SkillCheckFailureTracker.ResetSkillCheckFailed // (Native|Public|BlueprintCallable) // @ game+0x26f2db0
	void OnSkillCheckFailed(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function DBDAnimation.SkillCheckFailureTracker.OnSkillCheckFailed // (Native|Protected|HasOutParms) // @ game+0x2bd0030
};

// Class DBDAnimation.SurvivorAimableArmSensor
// Size: 0x160 (Inherited: 0x128)
struct USurvivorAimableArmSensor : UArmIKSensorComponent {
	char pad_128[0x10]; // 0x128(0x10)
	struct ACollectable* _aimableCollectable; // 0x138(0x08)
	struct UAimableComponent* _aimable; // 0x140(0x08)
	char pad_148[0x18]; // 0x148(0x18)
};

// Class DBDAnimation.SurvivorAimableSubAnimInstance
// Size: 0x520 (Inherited: 0x4f0)
struct USurvivorAimableSubAnimInstance : UBaseSurvivorAnimInstance {
	float _pitch; // 0x4f0(0x04)
	bool _isHoldingAimItem; // 0x4f4(0x01)
	bool _isAiming; // 0x4f5(0x01)
	char pad_4F6[0x2]; // 0x4f6(0x02)
	float _isAimingAlpha; // 0x4f8(0x04)
	struct FVector _aimPoint; // 0x4fc(0x0c)
	float _shoulderToCollisionDistance; // 0x508(0x04)
	char pad_50C[0x14]; // 0x50c(0x14)
};

// Class DBDAnimation.SurvivorAnimInstance
// Size: 0x600 (Inherited: 0x4f0)
struct USurvivorAnimInstance : UBaseSurvivorAnimInstance {
	struct ACamperPlayer* CamperPlayer; // 0x4f0(0x08)
	bool IsHooked; // 0x4f8(0x01)
	bool IsSacrificeStruggling; // 0x4f9(0x01)
	char pad_4FA[0x6]; // 0x4fa(0x06)
	struct UAnimMontage* MontageMadnessTierUp; // 0x500(0x08)
	struct TArray<struct UAnimCompositeBase*> ArrayCarryAttackMontage; // 0x508(0x10)
	bool _isFrightScreaming; // 0x518(0x01)
	bool IsBeingCarried; // 0x519(0x01)
	bool IsBeingPutOnHook; // 0x51a(0x01)
	bool isCrouched; // 0x51b(0x01)
	enum class ECamperGuidedAction GuidedAction; // 0x51c(0x01)
	bool IsTrapped; // 0x51d(0x01)
	bool IsCrawling; // 0x51e(0x01)
	bool IsDead; // 0x51f(0x01)
	float MaxSpeed; // 0x520(0x04)
	bool IsInsideCloset; // 0x524(0x01)
	char pad_525[0x3]; // 0x525(0x03)
	float IsPlayingMadnessTierUpWeight; // 0x528(0x04)
	bool IsBeingKilled; // 0x52c(0x01)
	bool IsCarryAttackSucess; // 0x52d(0x01)
	bool IsUsingAimItem; // 0x52e(0x01)
	bool IsHoldingAimItem; // 0x52f(0x01)
	bool AllowLookAt; // 0x530(0x01)
	char pad_531[0x3]; // 0x531(0x03)
	float DropStaggerTimeLeft; // 0x534(0x04)
	float RightArmIKAlpha; // 0x538(0x04)
	char pad_53C[0x4]; // 0x53c(0x04)
	struct FTransform RightHandIKTransform; // 0x540(0x30)
	bool Strafe; // 0x570(0x01)
	bool IsInteracting; // 0x571(0x01)
	bool Injured; // 0x572(0x01)
	enum class EInteractionAnimation interactionType; // 0x573(0x01)
	enum class EInteractionAnimation PreviousInteractionType; // 0x574(0x01)
	bool IsSlasherInFPV; // 0x575(0x01)
	char pad_576[0x2]; // 0x576(0x02)
	float CarriedAlpha; // 0x578(0x04)
	bool IsHoldingHandleItem; // 0x57c(0x01)
	bool IsHoldingSmallItem; // 0x57d(0x01)
	bool IsHoldingFirecracker; // 0x57e(0x01)
	bool IsHoldingFlashbang; // 0x57f(0x01)
	bool IsHoldingVaccine; // 0x580(0x01)
	bool IsHoldingAnyItem; // 0x581(0x01)
	bool InAir; // 0x582(0x01)
	char pad_583[0x1]; // 0x583(0x01)
	float _walkAnimSpeed; // 0x584(0x04)
	float Direction; // 0x588(0x04)
	float Pitch; // 0x58c(0x04)
	float Yaw; // 0x590(0x04)
	struct FVector RightFootEffectorLocation; // 0x594(0x0c)
	struct FVector LeftFootEffectorLocation; // 0x5a0(0x0c)
	bool Idle; // 0x5ac(0x01)
	char pad_5AD[0x3]; // 0x5ad(0x03)
	float MyTime; // 0x5b0(0x04)
	bool HasAnyMontagePlaying; // 0x5b4(0x01)
	char pad_5B5[0x3]; // 0x5b5(0x03)
	struct FName CurrentlyPlayerMontageId; // 0x5b8(0x0c)
	bool IsBeingCarriedByTheSpirit; // 0x5c4(0x01)
	bool IsBeingCarriedByTheNightmare; // 0x5c5(0x01)
	bool IsBeingCarriedByThePig; // 0x5c6(0x01)
	bool IsBeingCarriedByTheHag; // 0x5c7(0x01)
	bool IsBeingCarriedByTheLegion; // 0x5c8(0x01)
	bool IsBeingCarriedByTheGhostFace; // 0x5c9(0x01)
	bool IsUsingDeadHard; // 0x5ca(0x01)
	bool IsPlayingWakeUpOther; // 0x5cb(0x01)
	bool IsPlayingFreddyMori; // 0x5cc(0x01)
	bool IsHealingKOCamper; // 0x5cd(0x01)
	bool HasLinkInput; // 0x5ce(0x01)
	char pad_5CF[0x31]; // 0x5cf(0x31)

	void SetAudioRummageAkEvent(struct FName Distance); // Function DBDAnimation.SurvivorAnimInstance.SetAudioRummageAkEvent // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnInfectiousFrightScream(); // Function DBDAnimation.SurvivorAnimInstance.OnInfectiousFrightScream // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	bool IsPlayingMontageByName(struct FName MontageID); // Function DBDAnimation.SurvivorAnimInstance.IsPlayingMontageByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bcfd70
	void AddAudioRepairRateRadius(int32_t Distance); // Function DBDAnimation.SurvivorAnimInstance.AddAudioRepairRateRadius // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDAnimation.Turn180Component
// Size: 0xe8 (Inherited: 0xb8)
struct UTurn180Component : UActorComponent {
	char pad_B8[0x28]; // 0xb8(0x28)
	struct FTurn180Settings _settings; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)

	void Server_SetSettings(float Timestamp, struct FTurn180Settings Settings); // Function DBDAnimation.Turn180Component.Server_SetSettings // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2bd0780
};

// Class DBDAnimation.WakerObjectAnimInstance
// Size: 0x2b0 (Inherited: 0x270)
struct UWakerObjectAnimInstance : UAnimInstance {
	float _reappearTimerCooldown; // 0x270(0x04)
	float _wakeUpCharge; // 0x274(0x04)
	bool _chargeStarted; // 0x278(0x01)
	bool _interactionComplete; // 0x279(0x01)
	bool _outEnd; // 0x27a(0x01)
	bool _reset; // 0x27b(0x01)
	bool _inEnd; // 0x27c(0x01)
	bool _wakerObjectStarted; // 0x27d(0x01)
	bool _respawnEnd; // 0x27e(0x01)
	bool _cancelEnd; // 0x27f(0x01)
	char pad_280[0x30]; // 0x280(0x30)

	void ResetReappearTimer(); // Function DBDAnimation.WakerObjectAnimInstance.ResetReappearTimer // (Final|Native|Private|BlueprintCallable) // @ game+0x2bd0760
	void OnReappear(); // Function DBDAnimation.WakerObjectAnimInstance.OnReappear // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool GetWakerObjectStarted(); // Function DBDAnimation.WakerObjectAnimInstance.GetWakerObjectStarted // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bd0730
	bool GetWakerObjectChargeComplete(); // Function DBDAnimation.WakerObjectAnimInstance.GetWakerObjectChargeComplete // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bd0700
	float GetWakerObjectCharge(); // Function DBDAnimation.WakerObjectAnimInstance.GetWakerObjectCharge // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bd06d0
	struct AWakerObject* GetWakerObject(); // Function DBDAnimation.WakerObjectAnimInstance.GetWakerObject // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2bd06a0
};

