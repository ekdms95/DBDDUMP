// Enum DBDAnimation.EArmIkMode
enum class EArmIkMode : uint8 {
	None,
	BothHand,
	OnlyRight,
	OnlyLeft,
	OneHandAtTime,
	BothAtSameTime,
	EArmIkMode_MAX,
};

// ScriptStruct DBDAnimation.FootBoneData
// Size: 0x30 (Inherited: 0x00)
struct FFootBoneData {
	struct UCurveVector* RightFootCurve; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
	struct UCurveVector* LeftFootCurve; // 0x18(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DBDAnimation.PerspectiveDependentAnimSequenceSelector
// Size: 0x18 (Inherited: 0x00)
struct FPerspectiveDependentAnimSequenceSelector {
	struct UAnimSequence* _current; // 0x00(0x08)
	struct UAnimSequence* _thirdPerson; // 0x08(0x08)
	struct UAnimSequence* _firstPerson; // 0x10(0x08)
};

