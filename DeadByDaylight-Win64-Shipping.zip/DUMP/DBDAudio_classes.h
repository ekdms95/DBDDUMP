// Class DBDAudio.AmbienceBoxComponent
// Size: 0x450 (Inherited: 0x450)
struct UAmbienceBoxComponent : UBoxComponent {
};

// Class DBDAudio.AnimNotify_PostInteractionSoundEvent
// Size: 0x78 (Inherited: 0x40)
struct UAnimNotify_PostInteractionSoundEvent : UAnimNotify {
	struct UAkAudioEvent* SoundEvent; // 0x40(0x08)
	SoftClassProperty InteractionAudioClass; // 0x48(0x30)
};

// Class DBDAudio.AudioUtilities
// Size: 0x30 (Inherited: 0x30)
struct UAudioUtilities : UBlueprintFunctionLibrary {

	void PostAkAudioEvent(struct UAkAudioEvent* audioEvent); // Function DBDAudio.AudioUtilities.PostAkAudioEvent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2bd5320
};

// Class DBDAudio.InteractionAudioComponent
// Size: 0x120 (Inherited: 0xb8)
struct UInteractionAudioComponent : UActorComponent {
	struct UAkComponent* _audioComponent; // 0xb8(0x08)
	struct FNonTunableStat _audioRadius; // 0xc0(0x60)

	bool PostAkEvent(struct UAkAudioEvent* AkEvent); // Function DBDAudio.InteractionAudioComponent.PostAkEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x2bd5530
};

// Class DBDAudio.LoadAsyncBankData
// Size: 0x40 (Inherited: 0x30)
struct ULoadAsyncBankData : UObject {
	struct UAkAudioBank* Bank; // 0x30(0x08)
	struct USoundBankLoader* SoundBankLoader; // 0x38(0x08)
};

// Class DBDAudio.SoundBankLoader
// Size: 0x80 (Inherited: 0x38)
struct USoundBankLoader : UGameInstanceSubsystem {
	char pad_38[0x28]; // 0x38(0x28)
	struct TArray<struct UAkAudioBank*> _audioBanks; // 0x60(0x10)
	struct TArray<struct ULoadAsyncBankData*> _asyncAudioBanksPendingLoadData; // 0x70(0x10)
};

