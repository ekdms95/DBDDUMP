// ScriptStruct DBDAudio.AkSoundLoop
// Size: 0x28 (Inherited: 0x00)
struct FAkSoundLoop {
	char pad_0[0x8]; // 0x00(0x08)
	struct UAkAudioEvent* _startEvent; // 0x08(0x08)
	struct UAkAudioEvent* _endEvent; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct UAkComponent* _akComponent; // 0x20(0x08)
};

