// Class DBDBots.AIDisplayDebugInterface
// Size: 0x30 (Inherited: 0x30)
struct UAIDisplayDebugInterface : UInterface {
};

// Class DBDBots.AIGoalGeneratorInterface
// Size: 0x30 (Inherited: 0x30)
struct UAIGoalGeneratorInterface : UInterface {
};

// Class DBDBots.AIIntentionValidatorInterface
// Size: 0x30 (Inherited: 0x30)
struct UAIIntentionValidatorInterface : UInterface {
};

// Class DBDBots.AIPathValidatorInterface
// Size: 0x30 (Inherited: 0x30)
struct UAIPathValidatorInterface : UInterface {
};

// Class DBDBots.AISkill
// Size: 0xc0 (Inherited: 0x30)
struct UAISkill : UObject {
	struct FGameplayTagContainer RunContexts; // 0x30(0x20)
	bool StopIfPausedByNavLinkProxy; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float RunTimeLimit; // 0x54(0x04)
	float RunCooldownTime; // 0x58(0x04)
	float RunCooldownTimeDeviation; // 0x5c(0x04)
	struct UNavigationQueryFilter* SkillNavigationFilterClass; // 0x60(0x08)
	struct TArray<struct UAISenseConfig*> SkillSenseConfigs; // 0x68(0x10)
	struct UBehaviorTree* DynamicSubtree; // 0x78(0x08)
	char pad_80[0x18]; // 0x80(0x18)
	struct TArray<struct UObject*> _pausedByObjects; // 0x98(0x10)
	char pad_A8[0x10]; // 0xa8(0x10)
	struct ADBDAIBTController* _aiControllerOwner; // 0xb8(0x08)
};

// Class DBDBots.AISkill_Diversion
// Size: 0x110 (Inherited: 0xc0)
struct UAISkill_Diversion : UAISkill {
	struct FName PerkId; // 0xc0(0x0c)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TArray<struct AActor*> DiversionFromGoalClasses; // 0xd0(0x10)
	enum class EAIDifficultyLevel ThrowOnInteractablesAtDifficultyLevel; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	float MaxThrowOnInteractableHalfAngle; // 0xe4(0x04)
	float MaxMoveToTargetDistance; // 0xe8(0x04)
	struct FVector NavMeshFindLocationExtents; // 0xec(0x0c)
	float PlanInterval; // 0xf8(0x04)
	char pad_FC[0x14]; // 0xfc(0x14)
};

// Class DBDBots.AISkill_Find
// Size: 0x100 (Inherited: 0xc0)
struct UAISkill_Find : UAISkill {
	struct AActor* FindClass; // 0xc0(0x08)
	struct FGameplayTag BlackboardWishListTag; // 0xc8(0x0c)
	float SearchInterval; // 0xd4(0x04)
	bool MustBeSeen; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct TArray<struct UObject*> _currentWishedObjects; // 0xe0(0x10)
	char pad_F0[0x10]; // 0xf0(0x10)
};

// Class DBDBots.AISkill_FindInteractable
// Size: 0x118 (Inherited: 0x100)
struct UAISkill_FindInteractable : UAISkill_Find {
	struct FString RequiredInteractionId; // 0x100(0x10)
	enum class EInputInteractionType RequiredInteractionInputType; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
};

// Class DBDBots.AISkill_FindCollectable
// Size: 0x120 (Inherited: 0x118)
struct UAISkill_FindCollectable : UAISkill_FindInteractable {
	int32_t CollectUnderItemCount; // 0x118(0x04)
	float CollectOverItemChargeRatio; // 0x11c(0x04)
};

// Class DBDBots.AISkill_FindCollectable_Camper
// Size: 0x120 (Inherited: 0x120)
struct UAISkill_FindCollectable_Camper : UAISkill_FindCollectable {
};

// Class DBDBots.AISkill_FindCollectable_Hatchet
// Size: 0x120 (Inherited: 0x120)
struct UAISkill_FindCollectable_Hatchet : UAISkill_FindCollectable {
};

// Class DBDBots.AISkill_FindCollectable_Searchable
// Size: 0x138 (Inherited: 0x120)
struct UAISkill_FindCollectable_Searchable : UAISkill_FindCollectable {
	float SearchIntervalAfterOpenSearchable; // 0x120(0x04)
	float OpenSearchableRelevancyDuration; // 0x124(0x04)
	char pad_128[0x8]; // 0x128(0x08)
	struct ASearchable* _relevantSearchable; // 0x130(0x08)
};

// Class DBDBots.AISkill_FindCollectable_Trap
// Size: 0x120 (Inherited: 0x120)
struct UAISkill_FindCollectable_Trap : UAISkill_FindCollectable {
};

// Class DBDBots.AISkill_FindInteractable_SolveRBT
// Size: 0x128 (Inherited: 0x118)
struct UAISkill_FindInteractable_SolveRBT : UAISkill_FindInteractable {
	struct FAITunableParameter UrgencyGoalWeight; // 0x118(0x10)
};

// Class DBDBots.AISkill_FindInteractable_SolveSickness
// Size: 0x128 (Inherited: 0x118)
struct UAISkill_FindInteractable_SolveSickness : UAISkill_FindInteractable {
	struct FAITunableParameter UrgencyGoalWeight; // 0x118(0x10)
};

// Class DBDBots.AISkill_FindInteractable_StatusEffect
// Size: 0x128 (Inherited: 0x118)
struct UAISkill_FindInteractable_StatusEffect : UAISkill_FindInteractable {
	struct FGameplayTag RequiredPerkFlag; // 0x118(0x0c)
	bool InvertCondition; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
};

// Class DBDBots.AISkill_FindInteractable_StatusEffect_Plague
// Size: 0x128 (Inherited: 0x128)
struct UAISkill_FindInteractable_StatusEffect_Plague : UAISkill_FindInteractable_StatusEffect {
};

// Class DBDBots.AISkill_FindInteractable_Waker
// Size: 0x118 (Inherited: 0x118)
struct UAISkill_FindInteractable_Waker : UAISkill_FindInteractable {
};

// Class DBDBots.AISkill_FindOrb
// Size: 0x108 (Inherited: 0x100)
struct UAISkill_FindOrb : UAISkill_Find {
	char pad_100[0x8]; // 0x100(0x08)
};

// Class DBDBots.AISkill_Interaction
// Size: 0x170 (Inherited: 0xc0)
struct UAISkill_Interaction : UAISkill {
	enum class EPawnInputPressTypes inputType; // 0xc0(0x01)
	enum class EInteractionSkillInputModes InputMode; // 0xc1(0x01)
	enum class EPawnInputPressTypes CancelInputType; // 0xc2(0x01)
	enum class EInteractionCancelInputModes CancelInputMode; // 0xc3(0x01)
	bool AutoLockInput; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	struct FAIRoll StartRoll; // 0xc8(0x24)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FString StartInteractionID; // 0xf0(0x10)
	struct FString StopInteractionID; // 0x100(0x10)
	float MinHoldInputTime; // 0x110(0x04)
	bool AutoReleaseHoldInputWhenCharged; // 0x114(0x01)
	char pad_115[0x5b]; // 0x115(0x5b)
};

// Class DBDBots.AISkill_Interaction_AttachRBT
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_AttachRBT : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_ForThePeople
// Size: 0x188 (Inherited: 0x170)
struct UAISkill_Interaction_ForThePeople : UAISkill_Interaction {
	char pad_170[0x8]; // 0x170(0x08)
	struct FString BlockInteractionId; // 0x178(0x10)
};

// Class DBDBots.AISkill_Interaction_Kill
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_Kill : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_OrbAbsorb
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_OrbAbsorb : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_Reel
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_Reel : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_ReloadClown
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_ReloadClown : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_SendToDeathBed
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_SendToDeathBed : UAISkill_Interaction {
};

// Class DBDBots.AISkill_Interaction_StaticBlast
// Size: 0x170 (Inherited: 0x170)
struct UAISkill_Interaction_StaticBlast : UAISkill_Interaction {
};

// Class DBDBots.AISkill_InteractionSetTrap
// Size: 0x180 (Inherited: 0x170)
struct UAISkill_InteractionSetTrap : UAISkill_Interaction {
	struct AActor* TrapClass; // 0x170(0x08)
	float MaxDistanceFromPointOfInterest; // 0x178(0x04)
	float MaxDistanceFromAnotherSetTrap; // 0x17c(0x04)
};

// Class DBDBots.AISkill_InteractionSetTrap_Demogorgon
// Size: 0x180 (Inherited: 0x180)
struct UAISkill_InteractionSetTrap_Demogorgon : UAISkill_InteractionSetTrap {
};

// Class DBDBots.AISkill_InteractionSetTrap_DreamPallet
// Size: 0x180 (Inherited: 0x180)
struct UAISkill_InteractionSetTrap_DreamPallet : UAISkill_InteractionSetTrap {
};

// Class DBDBots.AISkill_InteractionSetTrap_DreamSnare
// Size: 0x180 (Inherited: 0x180)
struct UAISkill_InteractionSetTrap_DreamSnare : UAISkill_InteractionSetTrap {
};

// Class DBDBots.AISkill_InteractionSetTrap_Phantom
// Size: 0x180 (Inherited: 0x180)
struct UAISkill_InteractionSetTrap_Phantom : UAISkill_InteractionSetTrap {
};

// Class DBDBots.AISkill_InteractionTarget
// Size: 0x220 (Inherited: 0x170)
struct UAISkill_InteractionTarget : UAISkill_Interaction {
	enum class EInteractionTargetRequirements TargetRequirement; // 0x170(0x01)
	bool AutoSwapBestStimulusWithBestTarget; // 0x171(0x01)
	char pad_172[0x2]; // 0x172(0x02)
	float StartMinRange; // 0x174(0x04)
	float StartMaxRange; // 0x178(0x04)
	float StopMinRange; // 0x17c(0x04)
	float StopMaxRange; // 0x180(0x04)
	float StartMaxHalfAngle; // 0x184(0x04)
	float StopMaxHalfAngle; // 0x188(0x04)
	bool IsMaxHalfAngle2D; // 0x18c(0x01)
	bool TestMaxHalfAngleOnPath; // 0x18d(0x01)
	char pad_18E[0x2]; // 0x18e(0x02)
	struct UNavigationQueryFilter* MaxAngleFilterClass; // 0x190(0x08)
	enum class EInteractionTargetInSightModes InSightMode; // 0x198(0x01)
	char pad_199[0x3]; // 0x199(0x03)
	float OutOfSightModeDelay; // 0x19c(0x04)
	float TargetMoveAwayTooFastStopDelay; // 0x1a0(0x04)
	float TargetMoveAwayTooFastCooldown; // 0x1a4(0x04)
	bool AlwaysStrafeAroundTarget; // 0x1a8(0x01)
	char pad_1A9[0x7]; // 0x1a9(0x07)
	struct TArray<struct FAIDetectedStimulus> _unfilteredTargets; // 0x1b0(0x10)
	struct TArray<struct FAIDetectedStimulus> _filteredTargets; // 0x1c0(0x10)
	struct TMap<struct AActor*, struct FTargetMoveAwayToFastInfo> _targetsMoveAwayTooFastInfo; // 0x1d0(0x50)
};

// Class DBDBots.AISkill_InteractionTarget_Aim
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Aim : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_AmbushAttack
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_AmbushAttack : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_AmbushMode
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_AmbushMode : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_Cloak
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Cloak : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_Dash
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Dash : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_DashAttack
// Size: 0x230 (Inherited: 0x220)
struct UAISkill_InteractionTarget_DashAttack : UAISkill_InteractionTarget_Dash {
	float DashAttackUnderMaxRange; // 0x220(0x04)
	float DashAttackUnderMaxHalfAngle; // 0x224(0x04)
	enum class EAttackType ExpectedAttackType; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
};

// Class DBDBots.AISkill_InteractionTarget_DashAttack_Cannibal
// Size: 0x230 (Inherited: 0x230)
struct UAISkill_InteractionTarget_DashAttack_Cannibal : UAISkill_InteractionTarget_DashAttack {
};

// Class DBDBots.AISkill_InteractionTarget_DashAttack_Chainsaw
// Size: 0x230 (Inherited: 0x230)
struct UAISkill_InteractionTarget_DashAttack_Chainsaw : UAISkill_InteractionTarget_DashAttack {
};

// Class DBDBots.AISkill_InteractionTarget_DashAttack_Demogorgon
// Size: 0x230 (Inherited: 0x230)
struct UAISkill_InteractionTarget_DashAttack_Demogorgon : UAISkill_InteractionTarget_DashAttack {
};

// Class DBDBots.AISkill_InteractionTarget_DashHillbilly
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_DashHillbilly : UAISkill_InteractionTarget_Dash {
};

// Class DBDBots.AISkill_InteractionTarget_DashOni
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_DashOni : UAISkill_InteractionTarget_Dash {
};

// Class DBDBots.AISkill_InteractionTarget_DeadHard
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_DeadHard : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_DemonMode
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_DemonMode : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_Fire
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Fire : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_Frenzy
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Frenzy : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_LungeAttack
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_LungeAttack : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_PhaseWalk
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_PhaseWalk : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_ReloadDeathSlinger
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_ReloadDeathSlinger : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_ShockTherapy
// Size: 0x228 (Inherited: 0x220)
struct UAISkill_InteractionTarget_ShockTherapy : UAISkill_InteractionTarget {
	float TargetToEvadePointMaxDistance; // 0x220(0x04)
	float CastShockTimeBuffer; // 0x224(0x04)
};

// Class DBDBots.AISkill_InteractionTarget_Stalk
// Size: 0x220 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Stalk : UAISkill_InteractionTarget {
};

// Class DBDBots.AISkill_InteractionTarget_StalkGhost
// Size: 0x230 (Inherited: 0x220)
struct UAISkill_InteractionTarget_StalkGhost : UAISkill_InteractionTarget_Stalk {
	float CautiousModeUnderTargetRange; // 0x220(0x04)
	float CautiousModeSpeedFactor; // 0x224(0x04)
	float BackFromCautiousDelay; // 0x228(0x04)
	char pad_22C[0x4]; // 0x22c(0x04)
};

// Class DBDBots.AISkill_InteractionTarget_StalkShape
// Size: 0x228 (Inherited: 0x220)
struct UAISkill_InteractionTarget_StalkShape : UAISkill_InteractionTarget_Stalk {
	int32_t StalkRangeLimitedAtEvilTier; // 0x220(0x04)
	float MaxStalkRangeWhenLimitedByEvilTier; // 0x224(0x04)
};

// Class DBDBots.AISkill_InteractionTarget_StealthGhost
// Size: 0x228 (Inherited: 0x220)
struct UAISkill_InteractionTarget_StealthGhost : UAISkill_InteractionTarget {
	float CrouchSwapDelay; // 0x220(0x04)
	char pad_224[0x4]; // 0x224(0x04)
};

// Class DBDBots.AISkill_InteractionTarget_Throw
// Size: 0x298 (Inherited: 0x220)
struct UAISkill_InteractionTarget_Throw : UAISkill_InteractionTarget {
	enum class EAIThrowPredictionModes ThrowPredictionMode; // 0x220(0x01)
	char pad_221[0x3]; // 0x221(0x03)
	int32_t MaxAddPitchAngle; // 0x224(0x04)
	enum class EAIThrowProjectileModes ThrowProjectileMode; // 0x228(0x01)
	char pad_229[0x3]; // 0x229(0x03)
	struct FAITunableParameter HoldInputTimeRandDeviation; // 0x22c(0x10)
	struct FAITunableParameter PitchAngleRandDeviation; // 0x23c(0x10)
	char pad_24C[0x4c]; // 0x24c(0x4c)
};

// Class DBDBots.AISkill_InteractionTarget_ThrowClown
// Size: 0x298 (Inherited: 0x298)
struct UAISkill_InteractionTarget_ThrowClown : UAISkill_InteractionTarget_Throw {
};

// Class DBDBots.AISkill_InteractionTarget_ThrowHatchet
// Size: 0x298 (Inherited: 0x298)
struct UAISkill_InteractionTarget_ThrowHatchet : UAISkill_InteractionTarget_Throw {
};

// Class DBDBots.AISkill_InteractionTarget_ThrowPlague
// Size: 0x2a8 (Inherited: 0x298)
struct UAISkill_InteractionTarget_ThrowPlague : UAISkill_InteractionTarget_Throw {
	struct FGameplayTag ProjectileDamageSickTargetTag; // 0x298(0x0c)
	char pad_2A4[0x4]; // 0x2a4(0x04)
};

// Class DBDBots.AISkill_InteractionTarget_TormentAttack
// Size: 0x250 (Inherited: 0x220)
struct UAISkill_InteractionTarget_TormentAttack : UAISkill_InteractionTarget {
	int32_t AdvancedAtNbDetectedTargets; // 0x220(0x04)
	struct FAIRoll AdvancedStartRoll; // 0x224(0x24)
	char pad_248[0x8]; // 0x248(0x08)
};

// Class DBDBots.AISkill_InteractionTarget_TormentMode
// Size: 0x230 (Inherited: 0x220)
struct UAISkill_InteractionTarget_TormentMode : UAISkill_InteractionTarget {
	float ChasedTargetToEvadePointMaxDistance; // 0x220(0x04)
	float StartTormentInPatrolAboveChargeRatio; // 0x224(0x04)
	float StartTormentInChaseAboveChargeRatio; // 0x228(0x04)
	char pad_22C[0x4]; // 0x22c(0x04)
};

// Class DBDBots.AISkill_InteractionTeleport
// Size: 0x178 (Inherited: 0x170)
struct UAISkill_InteractionTeleport : UAISkill_Interaction {
	float BlockTeleportWhenPathGoalUnderRange; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
};

// Class DBDBots.AISkill_InteractionTeleportEthereal
// Size: 0x1c8 (Inherited: 0x178)
struct UAISkill_InteractionTeleportEthereal : UAISkill_InteractionTeleport {
	float TeleportPlanInterval; // 0x178(0x04)
	float MaxTeleportAlignHalfAngle; // 0x17c(0x04)
	float AbortNotWorkingTeleportDelay; // 0x180(0x04)
	float AbortAddRunCooldownPenaltyTime; // 0x184(0x04)
	char pad_188[0x18]; // 0x188(0x18)
	struct AActor* _onStimulusInstigator; // 0x1a0(0x08)
	char pad_1A8[0x20]; // 0x1a8(0x20)
};

// Class DBDBots.AISkill_InteractionTeleportEthereal_Blink
// Size: 0x1d8 (Inherited: 0x1c8)
struct UAISkill_InteractionTeleportEthereal_Blink : UAISkill_InteractionTeleportEthereal {
	float StartBlinkAtWarpLocationRange; // 0x1c8(0x04)
	float ValidateBlinkWarpRange; // 0x1cc(0x04)
	float BlinkAboveSavedPathLength; // 0x1d0(0x04)
	float BlinkIfTargetWillBeInRange; // 0x1d4(0x04)
};

// Class DBDBots.AISkill_InteractionTeleportEthereal_Demogorgon
// Size: 0x1e0 (Inherited: 0x1c8)
struct UAISkill_InteractionTeleportEthereal_Demogorgon : UAISkill_InteractionTeleportEthereal {
	float MaxRangeFromFirstPortal; // 0x1c8(0x04)
	char pad_1CC[0x4]; // 0x1cc(0x04)
	struct ADemogorgonPortal* _firstPortal; // 0x1d0(0x08)
	struct ADemogorgonPortal* _secondPortal; // 0x1d8(0x08)
};

// Class DBDBots.AISkill_InteractionTeleportEthereal_Nightmare
// Size: 0x1d8 (Inherited: 0x1c8)
struct UAISkill_InteractionTeleportEthereal_Nightmare : UAISkill_InteractionTeleportEthereal {
	float TeleportIfPathLengthSavedAboveRange; // 0x1c8(0x04)
	char pad_1CC[0x4]; // 0x1cc(0x04)
	struct AGenerator* _toGenerator; // 0x1d0(0x08)
};

// Class DBDBots.AISkill_InteractionUseItem
// Size: 0x178 (Inherited: 0x170)
struct UAISkill_InteractionUseItem : UAISkill_Interaction {
	enum class ELoadoutItemType ItemType; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
};

// Class DBDBots.AISkill_InteractionUseItem_Firecracker
// Size: 0x190 (Inherited: 0x178)
struct UAISkill_InteractionUseItem_Firecracker : UAISkill_InteractionUseItem {
	struct FAITunableParameter StartMaxRange; // 0x178(0x10)
	float TargetFaceMeMaxAngle; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
};

// Class DBDBots.AISkill_InteractionUseItem_Flashlight
// Size: 0x1e0 (Inherited: 0x178)
struct UAISkill_InteractionUseItem_Flashlight : UAISkill_InteractionUseItem {
	struct FAIRoll VulnerableTargetStartRoll; // 0x178(0x24)
	float TargetFaceMeMaxAngle; // 0x19c(0x04)
	struct AActor* _targetActor; // 0x1a0(0x08)
	char pad_1A8[0x38]; // 0x1a8(0x38)
};

// Class DBDBots.AISkill_InteractionUseItem_Map
// Size: 0x178 (Inherited: 0x178)
struct UAISkill_InteractionUseItem_Map : UAISkill_InteractionUseItem {
};

// Class DBDBots.AISkill_SkillCheck
// Size: 0x110 (Inherited: 0xc0)
struct UAISkill_SkillCheck : UAISkill {
	struct FAIRoll RegularZoneRoll; // 0xc0(0x24)
	struct FAIRoll BonusZoneRoll; // 0xe4(0x24)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class DBDBots.AISkill_Strafe
// Size: 0x128 (Inherited: 0xc0)
struct UAISkill_Strafe : UAISkill {
	float StartMaxRange; // 0xc0(0x04)
	float StopMaxRange; // 0xc4(0x04)
	float IgnoreUnderNavLinkStartRange; // 0xc8(0x04)
	bool PauseStrafeOnAnimation; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	struct FAITunableParameter StrafeHoldInterval; // 0xd0(0x10)
	struct FAITunableParameter StrafeHoldDeviation; // 0xe0(0x10)
	struct FAITunableParameter StrafePauseInterval; // 0xf0(0x10)
	struct FAITunableParameter StrafePauseDeviation; // 0x100(0x10)
	char pad_110[0x18]; // 0x110(0x18)
};

// Class DBDBots.AISkill_StrafeChained
// Size: 0x128 (Inherited: 0x128)
struct UAISkill_StrafeChained : UAISkill_Strafe {
};

// Class DBDBots.AISkill_StrafeDodge
// Size: 0x150 (Inherited: 0x128)
struct UAISkill_StrafeDodge : UAISkill_Strafe {
	struct FAIRoll StartRoll; // 0x128(0x24)
	char pad_14C[0x4]; // 0x14c(0x04)
};

// Class DBDBots.AISkill_ThroughTorment
// Size: 0xc8 (Inherited: 0xc0)
struct UAISkill_ThroughTorment : UAISkill {
	enum class EAITerrorLevel ToleratedTerrorPressure; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class DBDBots.AISkill_Wiggle
// Size: 0x110 (Inherited: 0x110)
struct UAISkill_Wiggle : UAISkill_SkillCheck {
};

// Class DBDBots.BTDecorator_TickableBase
// Size: 0x70 (Inherited: 0x70)
struct UBTDecorator_TickableBase : UBTDecorator {
};

// Class DBDBots.BTDecorator_CanRunSkill
// Size: 0x80 (Inherited: 0x70)
struct UBTDecorator_CanRunSkill : UBTDecorator_TickableBase {
	struct FGameplayTag Context; // 0x70(0x0c)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class DBDBots.BTDecorator_ExtCompareBBEntries
// Size: 0xe0 (Inherited: 0xd8)
struct UBTDecorator_ExtCompareBBEntries : UBTDecorator_CompareBBEntries {
	float Tolerance; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class DBDBots.BTDecorator_ExtConeCheck
// Size: 0x110 (Inherited: 0x70)
struct UBTDecorator_ExtConeCheck : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBConeOrigin; // 0x70(0x30)
	struct FBlackboardKeySelector BBConeDirection; // 0xa0(0x30)
	struct FBlackboardKeySelector BBWith; // 0xd0(0x30)
	struct FAITunableParameter ConeHalfAngle; // 0x100(0x10)
};

// Class DBDBots.BTDecorator_ExtIsAtLocation
// Size: 0xb0 (Inherited: 0x70)
struct UBTDecorator_ExtIsAtLocation : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBLoc; // 0x70(0x30)
	struct FAITunableParameter AcceptableRadius; // 0xa0(0x10)
};

// Class DBDBots.BTDecorator_ExtIsBBEntryOfClass
// Size: 0xb0 (Inherited: 0xa8)
struct UBTDecorator_ExtIsBBEntryOfClass : UBTDecorator_IsBBEntryOfClass {
	bool InvertConditition; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// Class DBDBots.BTDecorator_ExtTimeLimit
// Size: 0xc8 (Inherited: 0x78)
struct UBTDecorator_ExtTimeLimit : UBTDecorator_TimeLimit {
	char pad_78[0x8]; // 0x78(0x08)
	struct FAITunableParameter MaxTimeLimit; // 0x80(0x10)
	struct FBlackboardKeySelector BBFilterKey; // 0x90(0x30)
	enum class EBasicKeyOperation FilterOperation; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class DBDBots.BTDecorator_HasDynamicSubtree
// Size: 0x80 (Inherited: 0x70)
struct UBTDecorator_HasDynamicSubtree : UBTDecorator_TickableBase {
	struct FGameplayTag InjectTag; // 0x70(0x0c)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class DBDBots.BTDecorator_IsCamperState
// Size: 0xb0 (Inherited: 0x70)
struct UBTDecorator_IsCamperState : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBCamper; // 0x70(0x30)
	enum class ECamperDamageState damageState; // 0xa0(0x01)
	enum class EArithmeticKeyOperation DamageOp; // 0xa1(0x01)
	enum class ECamperImmobilizeState ImmobilizeState; // 0xa2(0x01)
	enum class EArithmeticKeyOperation ImmobilizeOp; // 0xa3(0x01)
	enum class EIsCamperStateOnFilter OnFilter; // 0xa4(0x01)
	enum class EArithmeticKeyOperation OnOthersFilterOp; // 0xa5(0x01)
	char pad_A6[0x2]; // 0xa6(0x02)
	int32_t NbOnOthersCampers; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class DBDBots.BTDecorator_IsExitOpened
// Size: 0xa0 (Inherited: 0x70)
struct UBTDecorator_IsExitOpened : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBExitObj; // 0x70(0x30)
};

// Class DBDBots.BTDecorator_IsGameState
// Size: 0x80 (Inherited: 0x70)
struct UBTDecorator_IsGameState : UBTDecorator_TickableBase {
	enum class EArithmeticKeyOperation RemainingObjectiveOp; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t NbRemainingObjectives; // 0x74(0x04)
	enum class EArithmeticKeyOperation SurvivorsLeftOp; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	int32_t NbSurvivorsLeft; // 0x7c(0x04)
};

// Class DBDBots.BTDecorator_IsInteractionAvailable
// Size: 0x88 (Inherited: 0x70)
struct UBTDecorator_IsInteractionAvailable : UBTDecorator_TickableBase {
	struct TArray<struct FString> InteractionIds; // 0x70(0x10)
	enum class EIsInteractionAvailableOnFilter OnFilter; // 0x80(0x01)
	bool FailIfAnotherOngoingInteraction; // 0x81(0x01)
	bool FailIfNotPerformingInteraction; // 0x82(0x01)
	char pad_83[0x5]; // 0x83(0x05)
};

// Class DBDBots.BTDecorator_IsInteractorAvailable
// Size: 0xa0 (Inherited: 0x70)
struct UBTDecorator_IsInteractorAvailable : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBInteractorObj; // 0x70(0x30)
};

// Class DBDBots.BTDecorator_IsLocationInPressureZone
// Size: 0xa0 (Inherited: 0x70)
struct UBTDecorator_IsLocationInPressureZone : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBAtLocation; // 0x70(0x30)
};

// Class DBDBots.BTDecorator_IsNearestThan
// Size: 0xd8 (Inherited: 0x70)
struct UBTDecorator_IsNearestThan : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBFrom; // 0x70(0x30)
	struct FBlackboardKeySelector BBThan; // 0xa0(0x30)
	float AddDistanceBuffer; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// Class DBDBots.BTDecorator_IsObjectFocused
// Size: 0xa8 (Inherited: 0x70)
struct UBTDecorator_IsObjectFocused : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBObj; // 0x70(0x30)
	enum class EDecoratorIsObjFocusedFilter Filter; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
};

// Class DBDBots.BTDecorator_IsTunable
// Size: 0x88 (Inherited: 0x70)
struct UBTDecorator_IsTunable : UBTDecorator_TickableBase {
	enum class ETunableComparison Operator; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	struct FAITunableParameter TunableValue; // 0x74(0x10)
	float CompareToValue; // 0x84(0x04)
};

// Class DBDBots.BTDecorator_Random
// Size: 0x80 (Inherited: 0x70)
struct UBTDecorator_Random : UBTDecorator_TickableBase {
	struct FAITunableParameter PercentageRatio; // 0x70(0x10)
};

// Class DBDBots.BTDecorator_RandomByDistance
// Size: 0x150 (Inherited: 0x70)
struct UBTDecorator_RandomByDistance : UBTDecorator_TickableBase {
	struct FBlackboardKeySelector BBAroundLoc; // 0x70(0x30)
	struct FBlackboardKeySelector BBRelativeFromTime; // 0xa0(0x30)
	struct FBlackboardKeySelector BBRelativeToTime; // 0xd0(0x30)
	struct FAITunableParameter StartDistance; // 0x100(0x10)
	struct FAITunableParameter EndDistance; // 0x110(0x10)
	struct FAITunableParameter PercentageAtStartDistance; // 0x120(0x10)
	struct FAITunableParameter PercentageAtEndDistance; // 0x130(0x10)
	struct TArray<struct FAIRandomByDistancePercentagesAtTime> PercentagesAtTimes; // 0x140(0x10)
};

// Class DBDBots.BTService_AroundEQS
// Size: 0x178 (Inherited: 0x108)
struct UBTService_AroundEQS : UBTService_RunEQS {
	struct FBlackboardKeySelector BBAroundObj; // 0x108(0x30)
	struct FBlackboardKeySelector BBAroundLocation; // 0x138(0x30)
	float ValidLocationRefreshInterval; // 0x168(0x04)
	float InvalidLocationRefreshInterval; // 0x16c(0x04)
	float InvalidateLocationUnderTargetDistance; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
};

// Class DBDBots.BTService_OnRelevantBase
// Size: 0x80 (Inherited: 0x78)
struct UBTService_OnRelevantBase : UBTService {
	enum class EAINodeRelevancyOptions When; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class DBDBots.BTService_ClearBBEntry
// Size: 0xb0 (Inherited: 0x80)
struct UBTService_ClearBBEntry : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBToResetKey; // 0x80(0x30)
};

// Class DBDBots.BTService_CopyBBEntry
// Size: 0xe8 (Inherited: 0x80)
struct UBTService_CopyBBEntry : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBFrom; // 0x80(0x30)
	struct FBlackboardKeySelector BBTo; // 0xb0(0x30)
	bool CopyOnlyValidKeyValue; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
};

// Class DBDBots.BTService_FindInteractor
// Size: 0x218 (Inherited: 0x78)
struct UBTService_FindInteractor : UBTService {
	char pad_78[0x10]; // 0x78(0x10)
	struct FBlackboardKeySelector BBSearchAround; // 0x88(0x30)
	float SearchInterval; // 0xb8(0x04)
	float SearchHeightAmplifierActivationHeight; // 0xbc(0x04)
	float SearchHeightAmplifier; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xc8(0x08)
	bool RegisterAsDiscoveredWhenFound; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)
	struct FBlackboardKeySelector BBOnlyFromActor; // 0xd8(0x30)
	struct TArray<struct FString> OnlyWithInteractorIDs; // 0x108(0x10)
	float RejectIfTerrorIsCloserThanSelfMargin; // 0x118(0x04)
	float RejectIfInTerrorRadius; // 0x11c(0x04)
	bool RejectIfInPressureZone; // 0x120(0x01)
	bool UseLastKnownPositionForTerrorRejects; // 0x121(0x01)
	bool RejectIfWasInCooldownAndFocusedOnAnotherObject; // 0x122(0x01)
	char pad_123[0x1]; // 0x123(0x01)
	struct FName RejectCooldownContextName; // 0x124(0x0c)
	bool AbandonIfInChase; // 0x130(0x01)
	bool RejectIfFocusedByOther; // 0x131(0x01)
	bool RejectIfNotFocusedBySelf; // 0x132(0x01)
	bool IgnoreFocusFilterInEndgameCollapse; // 0x133(0x01)
	bool RejectIfNotInSight; // 0x134(0x01)
	bool IgnoreSightFilterIfDiscovered; // 0x135(0x01)
	bool IgnoreSightFilterIfInRange; // 0x136(0x01)
	char pad_137[0x1]; // 0x137(0x01)
	float RejectAboveRange; // 0x138(0x04)
	bool IgnoreRangeFilterIfDiscovered; // 0x13c(0x01)
	bool IgnoreRangeFilterIfInSight; // 0x13d(0x01)
	char pad_13E[0x2]; // 0x13e(0x02)
	struct FBlackboardKeySelector BBInteractLocation; // 0x140(0x30)
	struct FBlackboardKeySelector BBInteractorObj; // 0x170(0x30)
	struct FAITunableParameter CantInterruptGoalInteractionUnderRemainingTime; // 0x1a0(0x10)
	struct FAITunableParameter GoalBasicWeight; // 0x1b0(0x10)
	struct FAITunableParameter GoalWeightMaxDistance; // 0x1c0(0x10)
	struct FAITunableParameter GoalWeightAtMinDistance; // 0x1d0(0x10)
	struct FAITunableParameter GoalWeightAtEndgameStart; // 0x1e0(0x10)
	struct FAITunableParameter GoalWeightAtEndgameEnd; // 0x1f0(0x10)
	struct UInteractor* _goalInteractor; // 0x200(0x08)
	struct ADBDAIBTController* _aiOwner; // 0x208(0x08)
	char pad_210[0x8]; // 0x210(0x08)
};

// Class DBDBots.BTService_FindInteractor_Camper
// Size: 0x240 (Inherited: 0x218)
struct UBTService_FindInteractor_Camper : UBTService_FindInteractor {
	enum class EFindInteractableCamperFilter StatusFilter; // 0x218(0x01)
	char pad_219[0x3]; // 0x219(0x03)
	struct FAITunableParameter AllyDangerStateGoalWeight; // 0x21c(0x10)
	struct FAITunableParameter IncapacitatedAlliesGoalWeight; // 0x22c(0x10)
	char pad_23C[0x4]; // 0x23c(0x04)
};

// Class DBDBots.BTService_FindInteractor_Exit
// Size: 0x268 (Inherited: 0x218)
struct UBTService_FindInteractor_Exit : UBTService_FindInteractor {
	enum class EFindInteractorExitOptions Filter; // 0x218(0x01)
	enum class EFindInteractorOpenConditions OpenCondition; // 0x219(0x01)
	char pad_21A[0x6]; // 0x21a(0x06)
	struct FBlackboardKeySelector BBFinalExitLocation; // 0x220(0x30)
	float ClosedDoorOffset; // 0x250(0x04)
	float OpenDoorOffset; // 0x254(0x04)
	struct FAITunableParameter OpenedExitGoalWeight; // 0x258(0x10)
};

// Class DBDBots.BTService_FindInteractor_Generator
// Size: 0x270 (Inherited: 0x218)
struct UBTService_FindInteractor_Generator : UBTService_FindInteractor {
	enum class EFindInteractableGeneratorStatusFilter StatusFilter; // 0x218(0x01)
	char pad_219[0x3]; // 0x219(0x03)
	struct FAITunableParameter MinRepairRatioFilter; // 0x21c(0x10)
	bool UsePerceptionToGetRepairRatio; // 0x22c(0x01)
	char pad_22D[0x3]; // 0x22d(0x03)
	struct FAITunableParameter MaxRepairGoalWeight; // 0x230(0x10)
	struct FAITunableParameter InfectedStateGoalWeight; // 0x240(0x10)
	struct FAITunableParameter HexRuinGoalWeight; // 0x250(0x10)
	struct FName HexRuinPerkId; // 0x260(0x0c)
	char pad_26C[0x4]; // 0x26c(0x04)
};

// Class DBDBots.BTService_FindInteractor_Locker
// Size: 0x220 (Inherited: 0x218)
struct UBTService_FindInteractor_Locker : UBTService_FindInteractor {
	enum class EFindInteractableLockerStatusFilter StatusFilter; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
};

// Class DBDBots.BTService_FindInteractor_MeatHook
// Size: 0x280 (Inherited: 0x218)
struct UBTService_FindInteractor_MeatHook : UBTService_FindInteractor {
	enum class EFindInteractableMeatHookStatus StatusFilter; // 0x218(0x01)
	char pad_219[0x3]; // 0x219(0x03)
	struct FAITunableParameter AllyDangerStateGoalWeight; // 0x21c(0x10)
	struct FAITunableParameter BotDangerStateGoalWeight; // 0x22c(0x10)
	struct FAITunableParameter BotInjuredStateGoalWeight; // 0x23c(0x10)
	struct FAITunableParameter HumanAllyHookedGoalWeight; // 0x24c(0x10)
	struct FAITunableParameter MaxHookTimeGoalWeight; // 0x25c(0x10)
	struct FAITunableParameter IncapacitatedAlliesGoalWeight; // 0x26c(0x10)
	char pad_27C[0x4]; // 0x27c(0x04)
};

// Class DBDBots.BTService_FindInteractor_Pallet
// Size: 0x278 (Inherited: 0x218)
struct UBTService_FindInteractor_Pallet : UBTService_FindInteractor {
	struct FBlackboardKeySelector BBPickSideRelativelyFrom; // 0x218(0x30)
	enum class EFindInteractablePalletIntentions IntentionFilter; // 0x248(0x01)
	char pad_249[0x3]; // 0x249(0x03)
	struct FName RaisePalletPerkId; // 0x24c(0x0c)
	struct FAITunableParameter BrokenGeneratorGoalMaxDistance; // 0x258(0x10)
	struct FAITunableParameter BrokenGeneratorGoalMaxDistanceWeight; // 0x268(0x10)
};

// Class DBDBots.BTService_FindInteractor_Searchable
// Size: 0x218 (Inherited: 0x218)
struct UBTService_FindInteractor_Searchable : UBTService_FindInteractor {
};

// Class DBDBots.BTService_FindInteractor_Totem
// Size: 0x238 (Inherited: 0x218)
struct UBTService_FindInteractor_Totem : UBTService_FindInteractor {
	struct FAITunableParameter InactiveGoalWeightMaxDistance; // 0x218(0x10)
	struct FAITunableParameter InactiveGoalWeightAtMinDistance; // 0x228(0x10)
};

// Class DBDBots.BTService_FindInteractor_Trap
// Size: 0x250 (Inherited: 0x218)
struct UBTService_FindInteractor_Trap : UBTService_FindInteractor {
	struct FAITunableParameter HelpDestroyDemoPortal; // 0x218(0x10)
	struct FAIRoll SeeStandardTrapRoll; // 0x228(0x24)
	float TrapGroundLocationOffset; // 0x24c(0x04)
};

// Class DBDBots.BTService_FindInteractor_WishList
// Size: 0x228 (Inherited: 0x218)
struct UBTService_FindInteractor_WishList : UBTService_FindInteractor {
	struct FGameplayTag WishListTag; // 0x218(0x0c)
	char pad_224[0x4]; // 0x224(0x04)
};

// Class DBDBots.BTService_Flee
// Size: 0x138 (Inherited: 0x78)
struct UBTService_Flee : UBTService {
	char pad_78[0x8]; // 0x78(0x08)
	struct FBlackboardKeySelector BBFleePath; // 0x80(0x30)
	struct FBlackboardKeySelector BBShouldFallPallet; // 0xb0(0x30)
	struct UPathStrategySelector* PathStrategySelectorClass; // 0xe0(0x08)
	float OnEndObjectInFocusCooldown; // 0xe8(0x04)
	struct FAITunableParameter ShouldFallPalletUnderHostileRange; // 0xec(0x10)
	float ClearFleePathBBKeyDelay; // 0xfc(0x04)
	char pad_100[0x10]; // 0x100(0x10)
	struct UNavMovePath* _activePath; // 0x110(0x08)
	struct TArray<struct UObject*> _lostFocusedObjects; // 0x118(0x10)
	struct UPathStrategySelector* _strategySelector; // 0x128(0x08)
	char pad_130[0x8]; // 0x130(0x08)
};

// Class DBDBots.BTService_GetPinLocation
// Size: 0xc0 (Inherited: 0x80)
struct UBTService_GetPinLocation : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBToSetKey; // 0x80(0x30)
	struct FGameplayTag PinTag; // 0xb0(0x0c)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// Class DBDBots.BTService_GetPinObject
// Size: 0xc0 (Inherited: 0x80)
struct UBTService_GetPinObject : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBToSetKey; // 0x80(0x30)
	struct FGameplayTag PinTag; // 0xb0(0x0c)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// Class DBDBots.BTService_GoalCoordinator
// Size: 0xd0 (Inherited: 0x78)
struct UBTService_GoalCoordinator : UBTService {
	char pad_78[0x8]; // 0x78(0x08)
	struct TMap<struct UObject*, struct FAIGoalWeightContainer> _managedGoals; // 0x80(0x50)
};

// Class DBDBots.BTService_Patrol
// Size: 0x158 (Inherited: 0x78)
struct UBTService_Patrol : UBTService {
	struct FBlackboardKeySelector BBFilterKey; // 0x78(0x30)
	enum class EBasicKeyOperation FilterOperation; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	struct FVector NavMeshFindLocationExtents; // 0xac(0x0c)
	float MinPatrolInvestigationDistance; // 0xb8(0x04)
	float PatrolPointsValidityCheckInterval; // 0xbc(0x04)
	struct FBlackboardKeySelector BBPatrolPointOwner; // 0xc0(0x30)
	struct FBlackboardKeySelector BBPatrolLocation; // 0xf0(0x30)
	struct FBlackboardKeySelector BBGoToNextPatrolLocation; // 0x120(0x30)
	char pad_150[0x8]; // 0x150(0x08)
};

// Class DBDBots.BTService_Patrol_Discovery
// Size: 0x168 (Inherited: 0x158)
struct UBTService_Patrol_Discovery : UBTService_Patrol {
	bool RejectPatrolPointIfInPressureZone; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	int32_t MaxFindRandomLocationOnTileAttempts; // 0x15c(0x04)
	int32_t FirstFindOnNbNeighborTiles; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
};

// Class DBDBots.BTService_Patrol_PointOfInterest
// Size: 0x198 (Inherited: 0x158)
struct UBTService_Patrol_PointOfInterest : UBTService_Patrol {
	float OnEnterPatrolRefreshPointsDelay; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	struct FBlackboardKeySelector BBMoveAroundPatrolLocation; // 0x160(0x30)
	float MoveAroundPatrolPointAboveStimulusStrength; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
};

// Class DBDBots.BTService_PushObjectFocus
// Size: 0xa8 (Inherited: 0x78)
struct UBTService_PushObjectFocus : UBTService {
	struct FBlackboardKeySelector BBFocusObj; // 0x78(0x30)
};

// Class DBDBots.BTService_RunSkills
// Size: 0xc0 (Inherited: 0x78)
struct UBTService_RunSkills : UBTService {
	struct FGameplayTag Context; // 0x78(0x0c)
	char pad_84[0x4]; // 0x84(0x04)
	struct FBlackboardKeySelector BBFilterKey; // 0x88(0x30)
	enum class EBasicKeyOperation FilterOperation; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

// Class DBDBots.BTService_SetBBEntry
// Size: 0xd0 (Inherited: 0x80)
struct UBTService_SetBBEntry : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBToSetKey; // 0x80(0x30)
	struct FString ToSetValue; // 0xb0(0x10)
	struct FAITunableParameter RandomSetChance; // 0xc0(0x10)
};

// Class DBDBots.BTService_SetBBEntryTime
// Size: 0xb0 (Inherited: 0x80)
struct UBTService_SetBBEntryTime : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBToSetKey; // 0x80(0x30)
};

// Class DBDBots.BTService_SetFocusCooldown
// Size: 0xc8 (Inherited: 0x80)
struct UBTService_SetFocusCooldown : UBTService_OnRelevantBase {
	struct FBlackboardKeySelector BBOnObject; // 0x80(0x30)
	struct FName ContextName; // 0xb0(0x0c)
	bool InfiniteDuration; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	float Duration; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// Class DBDBots.BTService_SetMovementMode
// Size: 0x80 (Inherited: 0x78)
struct UBTService_SetMovementMode : UBTService {
	enum class ECharacterMovementTypes OnEnterMovementMode; // 0x78(0x01)
	enum class ECharacterMovementTypes OnExitMovementMode; // 0x79(0x01)
	char pad_7A[0x6]; // 0x7a(0x06)
};

// Class DBDBots.BTService_SetPathSpeedFactor
// Size: 0x80 (Inherited: 0x78)
struct UBTService_SetPathSpeedFactor : UBTService {
	float SpeedFactor; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class DBDBots.BTService_StateMonitor
// Size: 0xd8 (Inherited: 0x78)
struct UBTService_StateMonitor : UBTService {
	struct FBlackboardKeySelector BBIsIntroCompleted; // 0x78(0x30)
	struct FBlackboardKeySelector BBDifficultyLevel; // 0xa8(0x30)
};

// Class DBDBots.BTService_StateMonitor_Camper
// Size: 0x2b8 (Inherited: 0xd8)
struct UBTService_StateMonitor_Camper : UBTService_StateMonitor {
	struct FBlackboardKeySelector BBDamageState; // 0xd8(0x30)
	struct FBlackboardKeySelector BBImmoblizedState; // 0x108(0x30)
	struct FBlackboardKeySelector BBGuidedState; // 0x138(0x30)
	struct FBlackboardKeySelector BBEscapedState; // 0x168(0x30)
	struct FBlackboardKeySelector BBIsInInjuredBleedout; // 0x198(0x30)
	struct FBlackboardKeySelector BBDyingTimerPercentLeft; // 0x1c8(0x30)
	struct FBlackboardKeySelector BBItemCharge; // 0x1f8(0x30)
	struct FBlackboardKeySelector BBIsChased; // 0x228(0x30)
	struct FBlackboardKeySelector BBIsChained; // 0x258(0x30)
	struct FBlackboardKeySelector BBIsInPressureZone; // 0x288(0x30)
};

// Class DBDBots.BTService_StateMonitor_Slasher
// Size: 0x108 (Inherited: 0xd8)
struct UBTService_StateMonitor_Slasher : UBTService_StateMonitor {
	struct FBlackboardKeySelector BBIsCarrying; // 0xd8(0x30)
};

// Class DBDBots.BTService_StimuliMonitor
// Size: 0x158 (Inherited: 0x78)
struct UBTService_StimuliMonitor : UBTService {
	struct FBlackboardKeySelector BBStimulusOriginLocation; // 0x78(0x30)
	struct FBlackboardKeySelector BBStimulusNavLocation; // 0xa8(0x30)
	struct FBlackboardKeySelector BBStimulusActor; // 0xd8(0x30)
	struct FBlackboardKeySelector BBStimulusInSight; // 0x108(0x30)
	struct FAITunableParameter StimuliRefreshInterval; // 0x138(0x10)
	float ExtrapolateLoseSightDuration; // 0x148(0x04)
	struct FVector NavMeshFindLocationExtents; // 0x14c(0x0c)
};

// Class DBDBots.BTService_StimuliMonitor_Camper
// Size: 0x1c0 (Inherited: 0x158)
struct UBTService_StimuliMonitor_Camper : UBTService_StimuliMonitor {
	struct FBlackboardKeySelector BBTerrorPressure; // 0x158(0x30)
	struct FBlackboardKeySelector BBIsFleeing; // 0x188(0x30)
	float LastValidTerrorRadiusStimulusMemoryLifeTime; // 0x1b8(0x04)
	char pad_1BC[0x4]; // 0x1bc(0x04)
};

// Class DBDBots.BTService_StimuliMonitor_Slasher
// Size: 0x278 (Inherited: 0x158)
struct UBTService_StimuliMonitor_Slasher : UBTService_StimuliMonitor {
	struct FBlackboardKeySelector BBInvestigateStimulusLocation; // 0x158(0x30)
	struct FBlackboardKeySelector BBInvestigateStimulusActor; // 0x188(0x30)
	struct FBlackboardKeySelector BBInBehaviorInvestigationStep; // 0x1b8(0x30)
	struct FBlackboardKeySelector BBIsBlind; // 0x1e8(0x30)
	struct FBlackboardKeySelector BBChasedActor; // 0x218(0x30)
	struct FAITunableParameter UseNextStimulusInvestigationAfterChaseDelay; // 0x248(0x10)
	float IgnorePreviousChasedStimulusActorDelay; // 0x258(0x04)
	float DefaultStimulusToInvestigateMaxAge; // 0x25c(0x04)
	float KOStimulusToInvestigateMaxAge; // 0x260(0x04)
	float NextStimulusInvestigationMinRange; // 0x264(0x04)
	float CantSeeOverBlindRatio; // 0x268(0x04)
	float FavorizeStandingTargetInRange; // 0x26c(0x04)
	float FavorizeStandingTargetOutRange; // 0x270(0x04)
	char pad_274[0x4]; // 0x274(0x04)
};

// Class DBDBots.BTTask_ClearBBEntry
// Size: 0xa8 (Inherited: 0x78)
struct UBTTask_ClearBBEntry : UBTTaskNode {
	struct FBlackboardKeySelector BBToResetKey; // 0x78(0x30)
};

// Class DBDBots.BTTask_CopyBBEntry
// Size: 0xe0 (Inherited: 0x78)
struct UBTTask_CopyBBEntry : UBTTaskNode {
	struct FBlackboardKeySelector BBFrom; // 0x78(0x30)
	struct FBlackboardKeySelector BBTo; // 0xa8(0x30)
	bool CopyOnlyValidKeyValue; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class DBDBots.BTTask_ExtMoveDirecltyToward
// Size: 0xd0 (Inherited: 0xc8)
struct UBTTask_ExtMoveDirecltyToward : UBTTask_MoveDirectlyToward {
	enum class ECharacterMovementTypes MovementMode; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class DBDBots.BTTask_ExtMoveTo
// Size: 0x160 (Inherited: 0xc0)
struct UBTTask_ExtMoveTo : UBTTask_MoveTo {
	struct FBlackboardKeySelector BBStrafeFocus; // 0xc0(0x30)
	enum class EExtMoveToStrafeFocusOptions StrafeFocus; // 0xf0(0x01)
	bool StrafeFocusPitch; // 0xf1(0x01)
	char pad_F2[0x2]; // 0xf2(0x02)
	float StrafeNearFocusModeUnderDistance; // 0xf4(0x04)
	float IntermittentOnStrafeFocusInterval; // 0xf8(0x04)
	float IntermittentOnStrafeFocusDeviation; // 0xfc(0x04)
	float IntermittentOffStrafeFocusInterval; // 0x100(0x04)
	float IntermittentOffStrafeFocusDeviation; // 0x104(0x04)
	float EndMoveStrafeFocusPrecisionAngle; // 0x108(0x04)
	bool StrafeFocusOwnerOnComponentBBKey; // 0x10c(0x01)
	enum class ECharacterMovementTypes ToGoalMovementMode; // 0x10d(0x01)
	enum class ECharacterMovementTypes NearGoalMovementMode; // 0x10e(0x01)
	char pad_10F[0x1]; // 0x10f(0x01)
	float NearGoalModeUnderDistance; // 0x110(0x04)
	float NormalMoveUnderNavLinkDistance; // 0x114(0x04)
	struct FBlackboardKeySelector BBIgnoreGroupAvoidance; // 0x118(0x30)
	float RepathInterval; // 0x148(0x04)
	bool UseAccelerationForPaths; // 0x14c(0x01)
	char pad_14D[0x3]; // 0x14d(0x03)
	float PathReachedPointRadius; // 0x150(0x04)
	struct FName UseContextualAcceptableRadius; // 0x154(0x0c)
};

// Class DBDBots.BTTask_ExtWait
// Size: 0xa0 (Inherited: 0x80)
struct UBTTask_ExtWait : UBTTask_Wait {
	struct FAITunableParameter WaitTimeInterval; // 0x80(0x10)
	struct FAITunableParameter WaitRandomDeviation; // 0x90(0x10)
};

// Class DBDBots.BTTask_FleeMoveTo
// Size: 0x178 (Inherited: 0x160)
struct UBTTask_FleeMoveTo : UBTTask_ExtMoveTo {
	float InScrambleMovementMinDistance; // 0x160(0x04)
	float OutScrambleMovementMinDistance; // 0x164(0x04)
	float InScrambleMovementInterval; // 0x168(0x04)
	float LoopScrambleMovementInterval; // 0x16c(0x04)
	float LoopScrambleMovementRandomDeviation; // 0x170(0x04)
	float CrouchWithinLastEvadeLoopPointRadius; // 0x174(0x04)
};

// Class DBDBots.BTTask_InputPress
// Size: 0x90 (Inherited: 0x78)
struct UBTTask_InputPress : UBTTaskNode {
	enum class EPawnInputPressTypes Input; // 0x78(0x01)
	enum class ETaskInputPressModes InputMode; // 0x79(0x01)
	char pad_7A[0x2]; // 0x7a(0x02)
	struct FAITunableParameter InputPressLoopInterval; // 0x7c(0x10)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class DBDBots.BTTask_Interact
// Size: 0xb8 (Inherited: 0x78)
struct UBTTask_Interact : UBTTaskNode {
	struct FBlackboardKeySelector BBInteractorObj; // 0x78(0x30)
	enum class EPawnInputPressTypes Input; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	float OnFailFocusCooldownDuration; // 0xac(0x04)
	bool PropagateCooldownOnInteractable; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	float FailStartInteractTimeLimit; // 0xb4(0x04)
};

// Class DBDBots.BTTask_RunSkills
// Size: 0x88 (Inherited: 0x78)
struct UBTTask_RunSkills : UBTTaskNode {
	struct FGameplayTag Context; // 0x78(0x0c)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class DBDBots.BTTask_SetBBEntry
// Size: 0xb8 (Inherited: 0x78)
struct UBTTask_SetBBEntry : UBTTaskNode {
	struct FBlackboardKeySelector BBToSetKey; // 0x78(0x30)
	struct FString ToSetValue; // 0xa8(0x10)
};

// Class DBDBots.BTTask_SetBBEntryTime
// Size: 0xa8 (Inherited: 0x78)
struct UBTTask_SetBBEntryTime : UBTTaskNode {
	struct FBlackboardKeySelector BBToSetKey; // 0x78(0x30)
};

// Class DBDBots.BTTask_SetFocusCooldown
// Size: 0xc0 (Inherited: 0x78)
struct UBTTask_SetFocusCooldown : UBTTaskNode {
	struct FBlackboardKeySelector BBOnObject; // 0x78(0x30)
	struct FName ContextName; // 0xa8(0x0c)
	bool InfiniteDuration; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	float Duration; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// Class DBDBots.BTTask_SetMovementMode
// Size: 0x80 (Inherited: 0x78)
struct UBTTask_SetMovementMode : UBTTaskNode {
	enum class ECharacterMovementTypes MovementMode; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class DBDBots.BTTask_SetRandomNavPoint
// Size: 0xf0 (Inherited: 0x78)
struct UBTTask_SetRandomNavPoint : UBTTaskNode {
	struct FBlackboardKeySelector BBFromLocation; // 0x78(0x30)
	struct FBlackboardKeySelector BBToLocation; // 0xa8(0x30)
	float MinAroundRadius; // 0xd8(0x04)
	float MaxAroundRadius; // 0xdc(0x04)
	int32_t MaxNbAttempts; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xe8(0x08)
};

// Class DBDBots.BTTask_StealthMoveTo
// Size: 0x160 (Inherited: 0x160)
struct UBTTask_StealthMoveTo : UBTTask_ExtMoveTo {
};

// Class DBDBots.DBDAIBTController
// Size: 0x5d8 (Inherited: 0x4f8)
struct ADBDAIBTController : ADBDAIController {
	struct UBehaviorTree* BehaviorTree; // 0x4f8(0x08)
	struct TArray<struct UAISkill*> BaseSkills; // 0x500(0x10)
	struct TArray<struct UAISkill*> RoleSkills; // 0x510(0x10)
	struct TArray<struct FAISkillPerk> PerkSkills; // 0x520(0x10)
	struct UDBDAIPerceptionComponent* _dbdPerception; // 0x530(0x08)
	struct UDBDBlackboardComponent* _dbdBlackboard; // 0x538(0x08)
	struct UDBDPathFollowingComponent* _dbdPathFollowing; // 0x540(0x08)
	struct UDBDBehaviorTreeComponent* _dbdBehaviorTree; // 0x548(0x08)
	struct UDBDNavMeshExplorerComponent* _navMeshExplorer; // 0x550(0x08)
	struct UDBDAIStateComponent* _aiState; // 0x558(0x08)
	struct UDBDAIGoalComponent* _aiGoal; // 0x560(0x08)
	char pad_568[0x10]; // 0x568(0x10)
	struct TMap<struct FGameplayTag, struct UBehaviorTree*> _setDynamicSubtrees; // 0x578(0x50)
	struct TArray<struct UAISkill*> _aiSkills; // 0x5c8(0x10)

	void OnPawnBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult Hit); // Function DBDBots.DBDAIBTController.OnPawnBump // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x2c575a0
	void Authority_FinishedPlaying(); // Function DBDBots.DBDAIBTController.Authority_FinishedPlaying // (Final|Native|Private) // @ game+0x2c57560
};

// Class DBDBots.DBDAIBTUtilities
// Size: 0x30 (Inherited: 0x30)
struct UDBDAIBTUtilities : UDBDAIUtilities {
};

// Class DBDBots.DBDAIGoalComponent
// Size: 0x160 (Inherited: 0xb8)
struct UDBDAIGoalComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TMap<struct UObject*, struct FAIGoal> _activeGoals; // 0xc0(0x50)
	struct TMap<struct UObject*, struct FAIGoalWeightContainer> _foundWeightedGoals; // 0x110(0x50)
};

// Class DBDBots.DBDAIPerceptionComponent
// Size: 0x330 (Inherited: 0x188)
struct UDBDAIPerceptionComponent : UAIPerceptionComponent {
	char pad_188[0x20]; // 0x188(0x20)
	struct TMap<struct UObject*, struct UObject*> _objOverridingSenses; // 0x1a8(0x50)
	struct TArray<struct UAISenseConfig*> _originalSenseConfigs; // 0x1f8(0x10)
	struct TArray<struct FAIDetectedStimulus> _detectedHostileStimuli; // 0x208(0x10)
	struct FAIDetectedStimulus _bestDetectedHostileStimulus; // 0x218(0x5c)
	struct FAIDetectedStimulus _lastBestDetectedHostileStimulusInMemory; // 0x274(0x5c)
	char pad_2D0[0x60]; // 0x2d0(0x60)
};

// Class DBDBots.DBDAIStateComponent
// Size: 0x1d0 (Inherited: 0xb8)
struct UDBDAIStateComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	int32_t UnsafeStateAtHookedCount; // 0xc0(0x04)
	int32_t DireStateAtHookedCount; // 0xc4(0x04)
	float MidObjectiveStateProgressionRatio; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TMap<enum class EAIObjectiveState, struct FDangerStateGameStateMapContainer> GameStateTable; // 0xd0(0x50)
	struct TMap<enum class EAIDifficultyLevel, struct FGameStatePressureZoneLevelMapContainer> PressureZoneLevelTable; // 0x120(0x50)
	struct TMap<enum class EAIPressureZoneLevel, float> PressureZoneHighToMedRangeLerpRatios; // 0x170(0x50)
	float DefaultChasedPhaseOutDuration; // 0x1c0(0x04)
	float InjuredChasedPhaseOutDuration; // 0x1c4(0x04)
	char pad_1C8[0x8]; // 0x1c8(0x08)
};

// Class DBDBots.DBDBehaviorTreeComponent
// Size: 0x2e0 (Inherited: 0x278)
struct UDBDBehaviorTreeComponent : UBehaviorTreeComponent {
	char pad_278[0x8]; // 0x278(0x08)
	struct TMap<struct UObject*, struct FRelevantNodeMemory> _lastRelevantNodeMemories; // 0x280(0x50)
	struct TArray<struct UObject*> _createdObjects; // 0x2d0(0x10)
};

// Class DBDBots.DBDBlackboardComponent
// Size: 0x3f0 (Inherited: 0x1b8)
struct UDBDBlackboardComponent : UBlackboardComponent {
	char pad_1B8[0x8]; // 0x1b8(0x08)
	struct TMap<struct UObject*, struct FMindFocusObjectEntry> _mindFocusEntries; // 0x1c0(0x50)
	struct TMap<struct FGameplayTag, struct FVector> _pinLocations; // 0x210(0x50)
	struct TMap<struct FGameplayTag, struct UObject*> _pinObjects; // 0x260(0x50)
	struct TMap<struct UObject*, float> _lostMindFocusEntries; // 0x2b0(0x50)
	struct TMap<struct FGameplayTag, struct FWeightedWishedObjectMapContainer> _objectWishListMap; // 0x300(0x50)
	struct TSet<struct UObject*> _discoveredObjects; // 0x350(0x50)
	struct TSet<struct UObject*> _intentionValidators; // 0x3a0(0x50)
};

// Class DBDBots.DBDNavLinkCustomComponent
// Size: 0x208 (Inherited: 0x198)
struct UDBDNavLinkCustomComponent : UNavLinkCustomComponent {
	struct FVector BaseLinkRelativeStart; // 0x198(0x0c)
	struct FVector BaseLinkRelativeEnd; // 0x1a4(0x0c)
	enum class ENavLinkDirection BaseLinkDirection; // 0x1b0(0x01)
	char pad_1B1[0x3]; // 0x1b1(0x03)
	float AutoSnapSmartLinkPointsUpHeight; // 0x1b4(0x04)
	float AutoSnapSmartLinkPointsDownHeight; // 0x1b8(0x04)
	enum class ECollisionChannel AutoSnapCollisionChannel; // 0x1bc(0x01)
	char pad_1BD[0x3]; // 0x1bd(0x03)
	float AutoSmartLinkDirectionMaxHeight; // 0x1c0(0x04)
	bool DisableSmartLinkOnPathObstruction; // 0x1c4(0x01)
	char pad_1C5[0x3]; // 0x1c5(0x03)
	float PathObstructionTestDistance; // 0x1c8(0x04)
	float PathObstructionTestShapeRadius; // 0x1cc(0x04)
	float PathObstructionTestHeightOffset; // 0x1d0(0x04)
	enum class ECollisionChannel PathObstructionCollisionChannel; // 0x1d4(0x01)
	bool DisableOtherSmartLinkInProximityOnEnable; // 0x1d5(0x01)
	bool EnableOtherSmartLinkInProximityOnDisable; // 0x1d6(0x01)
	char pad_1D7[0x1]; // 0x1d7(0x01)
	float OtherSmartLinkInProximitySearchDistance; // 0x1d8(0x04)
	bool ShowDebugInfo; // 0x1dc(0x01)
	char pad_1DD[0x1b]; // 0x1dd(0x1b)
	struct TArray<struct ANavLinkProxy*> _navLinkProxyInProximity; // 0x1f8(0x10)

	void OnLevelReadyToPlay(); // Function DBDBots.DBDNavLinkCustomComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x2c57580
};

// Class DBDBots.DBDNavMeshExplorerComponent
// Size: 0x140 (Inherited: 0xb8)
struct UDBDNavMeshExplorerComponent : UActorComponent {
	float ExploreAtAgentMoveDistance; // 0xb8(0x04)
	float ExploreAtInterval; // 0xbc(0x04)
	struct FAITunableParameter ExplorationBoxHalfExtent; // 0xc0(0x10)
	int32_t FullyAutoExploredAtGameTime; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct UDBDPathFollowingComponent* _pathFollowingComponent; // 0xd8(0x08)
	char pad_E0[0x60]; // 0xe0(0x60)
};

// Class DBDBots.DBDPathFollowingComponent
// Size: 0x478 (Inherited: 0x260)
struct UDBDPathFollowingComponent : UPathFollowingComponent {
	float UnblockPathDeviationRadius; // 0x260(0x04)
	float UnblockPathTimeLimit; // 0x264(0x04)
	char pad_268[0x120]; // 0x268(0x120)
	struct TSet<struct ANavLinkProxy*> _onNavLinkProxies; // 0x388(0x50)
	char pad_3D8[0xa0]; // 0x3d8(0xa0)
};

// Class DBDBots.EnvQueryContext_CenterOfMap
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_CenterOfMap : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_EscapeDoors
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_EscapeDoors : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_Generators
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_Generators : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_Hooks
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_Hooks : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_Lockers
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_Lockers : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_PinActor
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_PinActor : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_PinLocation
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_PinLocation : UEnvQueryContext {
};

// Class DBDBots.EnvQueryContext_TerrorRadius
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_TerrorRadius : UEnvQueryContext {
};

// Class DBDBots.EnvQueryTest_LineOfSight
// Size: 0x320 (Inherited: 0x238)
struct UEnvQueryTest_LineOfSight : UEnvQueryTest {
	struct UEnvQueryContext* QuerierContext; // 0x238(0x08)
	struct UEnvQueryContext* ToContext; // 0x240(0x08)
	struct FAIDataProviderFloatValue ItemHeightOffset; // 0x248(0x40)
	struct FAIDataProviderBoolValue Invert; // 0x288(0x40)
	char pad_2C8[0x58]; // 0x2c8(0x58)
};

// Class DBDBots.NavArea_Blink
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Blink : UNavArea {
};

// Class DBDBots.NavArea_Breakable
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Breakable : UNavArea {
};

// Class DBDBots.NavArea_Vault
// Size: 0x50 (Inherited: 0x50)
struct UNavArea_Vault : UNavArea {
};

// Class DBDBots.NavigationQueryFilter_Player
// Size: 0x70 (Inherited: 0x50)
struct UNavigationQueryFilter_Player : UNavigationQueryFilter {
	int32_t MaxSearchNodes; // 0x50(0x04)
	char pad_54[0x1c]; // 0x54(0x1c)
};

// Class DBDBots.NavigationQueryFilter_Camper
// Size: 0x88 (Inherited: 0x70)
struct UNavigationQueryFilter_Camper : UNavigationQueryFilter_Player {
	float SlasherAreaBoundsLimit; // 0x70(0x04)
	float SlasherAreaPenetrationCost; // 0x74(0x04)
	float SlasherInSightCost; // 0x78(0x04)
	float SlasherInSightTestFrequency; // 0x7c(0x04)
	float SlasherAreaExcludeUnderRange; // 0x80(0x04)
	float SlasherInExcludeAreaCost; // 0x84(0x04)
};

// Class DBDBots.NavigationQueryFilter_Camper_Cheap
// Size: 0x88 (Inherited: 0x88)
struct UNavigationQueryFilter_Camper_Cheap : UNavigationQueryFilter_Camper {
};

// Class DBDBots.NavigationQueryFilter_CamperStealth
// Size: 0x88 (Inherited: 0x88)
struct UNavigationQueryFilter_CamperStealth : UNavigationQueryFilter_Camper {
};

// Class DBDBots.NavigationQueryFilter_Slasher
// Size: 0x110 (Inherited: 0x70)
struct UNavigationQueryFilter_Slasher : UNavigationQueryFilter_Player {
	struct TMap<struct FString, float> DefaultInteractionsTimeCost; // 0x70(0x50)
	struct TMap<struct FString, float> FrenzyInteractionsTimeCost; // 0xc0(0x50)
};

// Class DBDBots.NavigationQueryFilter_Slasher_Limited
// Size: 0x70 (Inherited: 0x70)
struct UNavigationQueryFilter_Slasher_Limited : UNavigationQueryFilter_Player {
};

// Class DBDBots.NavLinkProxy_Base
// Size: 0x2f0 (Inherited: 0x280)
struct ANavLinkProxy_Base : ANavLinkProxy {
	float WaitLinkOffset; // 0x280(0x04)
	float MoveOnEndPointTimeLimit; // 0x284(0x04)
	int32_t NbMaxLinkUsers; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct TMap<struct ADBDPlayer*, struct FMoveLinkPlayerInfo> _players; // 0x290(0x50)
	struct TArray<struct ADBDPlayer*> _linkUsedByPlayers; // 0x2e0(0x10)

	void OnSmartLinkReachedCallback(struct AActor* MovingActor, struct FVector DestinationPoint); // Function DBDBots.NavLinkProxy_Base.OnSmartLinkReachedCallback // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x2c598e0
	void AutoAdjustSmartLinkPoints(); // Function DBDBots.NavLinkProxy_Base.AutoAdjustSmartLinkPoints // (Final|Native|Public|BlueprintCallable) // @ game+0x2c598a0
};

// Class DBDBots.NavLinkProxy_DirectMove
// Size: 0x358 (Inherited: 0x2f0)
struct ANavLinkProxy_DirectMove : ANavLinkProxy_Base {
	struct TArray<struct FVector> CustomPathPoints; // 0x2f0(0x10)
	float MoveToPathPointTimeLimit; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	struct TMap<struct ADBDPlayer*, struct UNavMovePath*> _playersOnPath; // 0x308(0x50)

	void OnDisplayDebugInfo(); // Function DBDBots.NavLinkProxy_DirectMove.OnDisplayDebugInfo // (Final|Native|Private) // @ game+0x2c598c0
};

// Class DBDBots.NavLinkProxy_Interaction
// Size: 0x398 (Inherited: 0x2f0)
struct ANavLinkProxy_Interaction : ANavLinkProxy_Base {
	struct TMap<enum class EPlayerRole, struct FNavLinkInteractPlayerSetup> PlayerSetups; // 0x2f0(0x50)
	float InteractionStartTimeLimit; // 0x340(0x04)
	char pad_344[0x4]; // 0x344(0x04)
	struct TMap<struct ADBDPlayer*, float> _playersInteractionInputAtTime; // 0x348(0x50)
};

// Class DBDBots.NavMovePath
// Size: 0x60 (Inherited: 0x30)
struct UNavMovePath : UObject {
	char pad_30[0x30]; // 0x30(0x30)
};

// Class DBDBots.PathBuilder
// Size: 0x50 (Inherited: 0x30)
struct UPathBuilder : UObject {
	char pad_30[0x8]; // 0x30(0x08)
	float PathReachedPointRadius; // 0x38(0x04)
	enum class EAITerrorLevel ToleratedTerrorPressure; // 0x3c(0x01)
	bool OverridePreviousPathStrategy; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	struct UNavMovePath* _path; // 0x40(0x08)
	struct ADBDAIBTController* _aiOwner; // 0x48(0x08)
};

// Class DBDBots.PathBuilder_EQS
// Size: 0xd0 (Inherited: 0x50)
struct UPathBuilder_EQS : UPathBuilder {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x50(0x50)
	int32_t NbMaxEQSRequests; // 0xa0(0x04)
	bool MergeToSinglePathPoint; // 0xa4(0x01)
	char pad_A5[0x23]; // 0xa5(0x23)
	struct UPathBuilder_EQS* _pendingEQSRequestBuilder; // 0xc8(0x08)
};

// Class DBDBots.PathBuilder_EvadeLoop
// Size: 0xc0 (Inherited: 0x50)
struct UPathBuilder_EvadeLoop : UPathBuilder {
	float AddDistanceToRequiredEvadeGap; // 0x50(0x04)
	float ForceEvadePointUnderDistance; // 0x54(0x04)
	float ChaserCrossingEvadeTimePenalty; // 0x58(0x04)
	float SwapPathReachTimeBuffer; // 0x5c(0x04)
	struct FString BreakPalletInteractionId; // 0x60(0x10)
	float OnPathRadius; // 0x70(0x04)
	float MaxEvadeInteractableWeightDistance; // 0x74(0x04)
	float WeightAtMaxDistance; // 0x78(0x04)
	bool MaxWeightAtNearestDistanceIfHostileHasRangedAbility; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
	float WeightAtMaxSafety; // 0x80(0x04)
	float MaxNearAllyPenaltyPathPointDistance; // 0x84(0x04)
	float WeightWhenNearAlly; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct UNavMovePath* _originalEvadeLoopWorkPath; // 0x90(0x08)
	struct UNavMovePath* _querierWorkPathA; // 0x98(0x08)
	struct UNavMovePath* _querierWorkPathB; // 0xa0(0x08)
	struct UNavMovePath* _chaserWorkPath; // 0xa8(0x08)
	struct UDBDNavEvadeLoopComponent* _pickedEvadeLoopComponent; // 0xb0(0x08)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class DBDBots.PathBuilder_LastGoal
// Size: 0x50 (Inherited: 0x50)
struct UPathBuilder_LastGoal : UPathBuilder {
};

// Class DBDBots.PathStrategy
// Size: 0xb8 (Inherited: 0x30)
struct UPathStrategy : UObject {
	char pad_30[0x10]; // 0x30(0x10)
	struct TArray<struct UPathBuilder*> DefaultPathBuilders; // 0x40(0x10)
	float RefreshPartialPathDelay; // 0x50(0x04)
	float StartNextBranchBuildDelay; // 0x54(0x04)
	struct ADBDAIBTController* _aiOwner; // 0x58(0x08)
	struct TArray<struct UPathBuilder*> _pathBuilders; // 0x60(0x10)
	char pad_70[0x48]; // 0x70(0x48)
};

// Class DBDBots.PathStrategy_Flee
// Size: 0xb8 (Inherited: 0xb8)
struct UPathStrategy_Flee : UPathStrategy {
};

// Class DBDBots.PathStrategy_FleeLoop
// Size: 0x210 (Inherited: 0xb8)
struct UPathStrategy_FleeLoop : UPathStrategy_Flee {
	struct TMap<enum class EAIDifficultyLevel, struct FGameStateEvadeLoopStrategyMapContainer> GameStateFleeLoopStrategyTable; // 0xb8(0x50)
	struct TMap<enum class EAIFleeLoopStrategy, struct UPathBuilder_EvadeLoop*> FleeLoopStrategyPathBuilders; // 0x108(0x50)
	float CanBranchUnderEndPathDistance; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	struct TMap<enum class EAIFleeLoopStrategy, struct FAIRoll> BranchRolls; // 0x160(0x50)
	float RejectLoopBranchUnderEndPointsDistance; // 0x1b0(0x04)
	float RejectBranchPointNearerHostileSourceDistance; // 0x1b4(0x04)
	float RejectBranchUnderNavLinkDistance; // 0x1b8(0x04)
	float AddDistanceToRequiredBranchEvadeGap; // 0x1bc(0x04)
	char pad_1C0[0x50]; // 0x1c0(0x50)
};

// Class DBDBots.PathStrategy_FleeLOS
// Size: 0xb8 (Inherited: 0xb8)
struct UPathStrategy_FleeLOS : UPathStrategy_Flee {
};

// Class DBDBots.PathStrategySelector
// Size: 0x68 (Inherited: 0x30)
struct UPathStrategySelector : UObject {
	char pad_30[0x8]; // 0x30(0x08)
	struct ADBDAIBTController* _aiOwner; // 0x38(0x08)
	struct TArray<struct UPathStrategy*> _activePathStrategies; // 0x40(0x10)
	struct TArray<struct UPathStrategy*> _nextPathStrategies; // 0x50(0x10)
	char pad_60[0x8]; // 0x60(0x08)
};

// Class DBDBots.PathStrategySelector_Flee
// Size: 0x110 (Inherited: 0x68)
struct UPathStrategySelector_Flee : UPathStrategySelector {
	struct TMap<enum class EAIFleePathStrategy, struct UPathStrategy*> FleePathStrategies; // 0x68(0x50)
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TMap<enum class EAIFleePathStrategy, struct UPathStrategy*> _activeFleePathStrategiesMap; // 0xc0(0x50)
};

