// Enum DBDBots.EInteractionCancelInputModes
enum class EInteractionCancelInputModes : uint8 {
	PressCancelInput,
	InvertWithStopInputFlow,
	EInteractionCancelInputModes_MAX,
};

// Enum DBDBots.EInteractionSkillInputModes
enum class EInteractionSkillInputModes : uint8 {
	Once,
	Hold,
	Toggle,
	ToggleHold,
	OneClickHold,
	EInteractionSkillInputModes_MAX,
};

// Enum DBDBots.EInteractionTargetInSightModes
enum class EInteractionTargetInSightModes : uint8 {
	None,
	MustBeInSight,
	MustBeInSight_NoObstruction,
	ActivateIfOutOfSight,
	EInteractionTargetInSightModes_MAX,
};

// Enum DBDBots.EInteractionTargetRequirements
enum class EInteractionTargetRequirements : uint8 {
	BestTargetMustBeValid,
	AnyValidTarget,
	NoTarget,
	None,
	EInteractionTargetRequirements_MAX,
};

// Enum DBDBots.EAIThrowProjectileModes
enum class EAIThrowProjectileModes : uint8 {
	OneShot,
	Continuous,
	EAIThrowProjectileModes_MAX,
};

// Enum DBDBots.EAIThrowPredictionModes
enum class EAIThrowPredictionModes : uint8 {
	FindBestThrowPowerRatio,
	FullThrowPowerRatio,
	EAIThrowPredictionModes_MAX,
};

// Enum DBDBots.EIsCamperStateOnFilter
enum class EIsCamperStateOnFilter : uint8 {
	OnBlackboardKey,
	OnOthersThanSelf,
	EIsCamperStateOnFilter_MAX,
};

// Enum DBDBots.EIsInteractionAvailableOnFilter
enum class EIsInteractionAvailableOnFilter : uint8 {
	Self,
	AnyFriend,
	EIsInteractionAvailableOnFilter_MAX,
};

// Enum DBDBots.EDecoratorIsObjFocusedFilter
enum class EDecoratorIsObjFocusedFilter : uint8 {
	Self,
	SelfNearest,
	EDecoratorIsObjFocusedFilter_MAX,
};

// Enum DBDBots.ETunableComparison
enum class ETunableComparison : uint8 {
	Equal,
	NotEqual,
	Less,
	LessOrEqual,
	Greater,
	GreaterOrEqual,
	ETunableComparison_MAX,
};

// Enum DBDBots.EFindInteractableCamperFilter
enum class EFindInteractableCamperFilter : uint8 {
	Crawling,
	Standing,
	GiveHelp,
	RequestHelp,
	RescuableBeingCarried,
	EFindInteractableCamperFilter_MAX,
};

// Enum DBDBots.EFindInteractorOpenConditions
enum class EFindInteractorOpenConditions : uint8 {
	AllGate_OpenedHatch,
	All,
	ClosedOnly,
	OpenedOnly,
	EFindInteractorOpenConditions_MAX,
};

// Enum DBDBots.EFindInteractorExitOptions
enum class EFindInteractorExitOptions : uint8 {
	All,
	HatchOnly,
	GateOnly,
	EFindInteractorExitOptions_MAX,
};

// Enum DBDBots.EFindInteractableGeneratorStatusFilter
enum class EFindInteractableGeneratorStatusFilter : uint8 {
	NeedRepair,
	CanBeDamaged,
	EFindInteractableGeneratorStatusFilter_MAX,
};

// Enum DBDBots.EFindInteractableLockerStatusFilter
enum class EFindInteractableLockerStatusFilter : uint8 {
	Empty,
	Occupied,
	Both,
	EFindInteractableLockerStatusFilter_MAX,
};

// Enum DBDBots.EFindInteractableMeatHookStatus
enum class EFindInteractableMeatHookStatus : uint8 {
	HookedSurvivor,
	Available,
	EFindInteractableMeatHookStatus_MAX,
};

// Enum DBDBots.EFindInteractablePalletIntentions
enum class EFindInteractablePalletIntentions : uint8 {
	Fall,
	Raise,
	EFindInteractablePalletIntentions_MAX,
};

// Enum DBDBots.EAINodeRelevancyOptions
enum class EAINodeRelevancyOptions : uint8 {
	OnEnter,
	OnExit,
	OnEnterAndExit,
	OnTick,
	EAINodeRelevancyOptions_MAX,
};

// Enum DBDBots.EAIInvestigateSteps
enum class EAIInvestigateSteps : uint8 {
	None,
	ToInvestigation,
	Investigating,
	EAIInvestigateSteps_MAX,
};

// Enum DBDBots.EExtMoveToStrafeFocusOptions
enum class EExtMoveToStrafeFocusOptions : uint8 {
	Never,
	NearFocus,
	NearGoal,
	Always,
	Intermittent,
	EExtMoveToStrafeFocusOptions_MAX,
};

// Enum DBDBots.ETaskInputPressModes
enum class ETaskInputPressModes : uint8 {
	Once,
	Loop,
	Hold,
	ETaskInputPressModes_MAX,
};

// Enum DBDBots.EAIPressureZoneLevel
enum class EAIPressureZoneLevel : uint8 {
	LMin,
	L01,
	L02,
	LMax,
	EAIPressureZoneLevel_MAX,
};

// Enum DBDBots.EAIGameState
enum class EAIGameState : uint8 {
	VeryEarly,
	Early,
	Mid,
	Late,
	VeryLate,
	Max,
	EAIGameState_MAX,
};

// Enum DBDBots.EAIObjectiveState
enum class EAIObjectiveState : uint8 {
	Early,
	Mid,
	Last,
	Completed,
	EAIObjectiveState_MAX,
};

// Enum DBDBots.EAIDangerState
enum class EAIDangerState : uint8 {
	Safe,
	Unsafe,
	Dire,
	EAIDangerState_MAX,
};

// Enum DBDBots.ENavLinkPlayerStates
enum class ENavLinkPlayerStates : uint8 {
	RequestStart,
	MoveStart,
	Using,
	MoveEnd,
	Release,
	ENavLinkPlayerStates_MAX,
};

// Enum DBDBots.EPathBuildResult
enum class EPathBuildResult : uint8 {
	None,
	Failed,
	Succeeded,
	Partial,
	InProgress,
	EPathBuildResult_MAX,
};

// Enum DBDBots.EAIFleeLoopStrategy
enum class EAIFleeLoopStrategy : uint8 {
	LoseKiller,
	WasteTime,
	EAIFleeLoopStrategy_MAX,
};

// Enum DBDBots.EAIFleePathStrategy
enum class EAIFleePathStrategy : uint8 {
	None,
	KeepGoal,
	Away,
	Loop,
	AwayLOS,
	EAIFleePathStrategy_MAX,
};

// ScriptStruct DBDBots.TargetMoveAwayToFastInfo
// Size: 0x64 (Inherited: 0x00)
struct FTargetMoveAwayToFastInfo {
	float AccumulatedTime; // 0x00(0x04)
	float CooldownUntilTime; // 0x04(0x04)
	struct FAIDetectedStimulus Stimulus; // 0x08(0x5c)
};

// ScriptStruct DBDBots.AIRandomByDistancePercentagesAtTime
// Size: 0x30 (Inherited: 0x00)
struct FAIRandomByDistancePercentagesAtTime {
	struct FAITunableParameter PercentageAtStartDistance; // 0x00(0x10)
	struct FAITunableParameter PercentageAtEndDistance; // 0x10(0x10)
	struct FAITunableParameter AtRelativeTime; // 0x20(0x10)
};

// ScriptStruct DBDBots.AISkillPerk
// Size: 0x38 (Inherited: 0x00)
struct FAISkillPerk {
	struct FDataTableDropdown PerkId; // 0x00(0x30)
	struct UAISkill* Skill; // 0x30(0x08)
};

// ScriptStruct DBDBots.AIGoalWeightContainer
// Size: 0x10 (Inherited: 0x00)
struct FAIGoalWeightContainer {
	struct TArray<struct FAIGoalWeight> WeightedGoals; // 0x00(0x10)
};

// ScriptStruct DBDBots.AIGoalWeight
// Size: 0x30 (Inherited: 0x00)
struct FAIGoalWeight {
	struct FAIGoal GoalInfo; // 0x00(0x18)
	float Weight; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString WeightDebug; // 0x20(0x10)
};

// ScriptStruct DBDBots.AIGoal
// Size: 0x18 (Inherited: 0x00)
struct FAIGoal {
	struct UObject* Source; // 0x00(0x08)
	struct UObject* MetaGoal; // 0x08(0x08)
	struct UObject* Goal; // 0x10(0x08)
};

// ScriptStruct DBDBots.GameStatePressureZoneLevelMapContainer
// Size: 0x50 (Inherited: 0x00)
struct FGameStatePressureZoneLevelMapContainer {
	struct TMap<enum class EAIGameState, enum class EAIPressureZoneLevel> Map; // 0x00(0x50)
};

// ScriptStruct DBDBots.DangerStateGameStateMapContainer
// Size: 0x50 (Inherited: 0x00)
struct FDangerStateGameStateMapContainer {
	struct TMap<enum class EAIDangerState, enum class EAIGameState> Map; // 0x00(0x50)
};

// ScriptStruct DBDBots.RelevantNodeMemory
// Size: 0x18 (Inherited: 0x00)
struct FRelevantNodeMemory {
	struct UBTNode* Node; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct DBDBots.MindFocusObjectEntry
// Size: 0x78 (Inherited: 0x00)
struct FMindFocusObjectEntry {
	struct TArray<struct UObject*> FocusedBy; // 0x00(0x10)
	float FocusedStartTime; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TMap<struct FName, float> CooldownMap; // 0x18(0x50)
	char pad_68[0x10]; // 0x68(0x10)
};

// ScriptStruct DBDBots.WeightedWishedObjectMapContainer
// Size: 0x50 (Inherited: 0x00)
struct FWeightedWishedObjectMapContainer {
	struct TMap<struct UObject*, float> WeightedWishedObjectMap; // 0x00(0x50)
};

// ScriptStruct DBDBots.ExplorableTileInfo
// Size: 0x2c (Inherited: 0x00)
struct FExplorableTileInfo {
	struct FGuid ID; // 0x00(0x10)
	struct FBox Bounds; // 0x10(0x1c)
};

// ScriptStruct DBDBots.MoveLinkPlayerInfo
// Size: 0x28 (Inherited: 0x00)
struct FMoveLinkPlayerInfo {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct DBDBots.NavLinkInteractPlayerSetup
// Size: 0x28 (Inherited: 0x00)
struct FNavLinkInteractPlayerSetup {
	enum class EPawnInputPressTypes Input; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FString> InteractionIds; // 0x08(0x10)
	struct FAITunableParameter InputTimeDeviationInChase; // 0x18(0x10)
};

// ScriptStruct DBDBots.NavMovePathPoint
// Size: 0x14 (Inherited: 0x00)
struct FNavMovePathPoint {
	char pad_0[0x14]; // 0x00(0x14)
};

// ScriptStruct DBDBots.GameStateEvadeLoopStrategyMapContainer
// Size: 0x50 (Inherited: 0x00)
struct FGameStateEvadeLoopStrategyMapContainer {
	struct TMap<enum class EAIGameState, enum class EAIFleeLoopStrategy> Map; // 0x00(0x50)
};

