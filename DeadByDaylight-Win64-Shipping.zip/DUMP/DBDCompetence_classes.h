// Class DBDCompetence.TimedStatusEffect
// Size: 0x320 (Inherited: 0x320)
struct UTimedStatusEffect : UStatusEffect {
};

// Class DBDCompetence.AbilityStealthUndetectableEffect
// Size: 0x320 (Inherited: 0x320)
struct UAbilityStealthUndetectableEffect : UTimedStatusEffect {
};

// Class DBDCompetence.AdjustableCooldownStatusEffect
// Size: 0x330 (Inherited: 0x320)
struct UAdjustableCooldownStatusEffect : UStatusEffect {
	struct FGameplayTag CooldownModifierType; // 0x320(0x0c)
	char pad_32C[0x4]; // 0x32c(0x04)
};

// Class DBDCompetence.ExhaustedEffect
// Size: 0x338 (Inherited: 0x330)
struct UExhaustedEffect : UAdjustableCooldownStatusEffect {
	float CooldownModifier; // 0x330(0x04)
	char pad_334[0x4]; // 0x334(0x04)
};

// Class DBDCompetence.ActivatableExhaustedEffect
// Size: 0x338 (Inherited: 0x338)
struct UActivatableExhaustedEffect : UExhaustedEffect {

	void Authority_Start(float Duration); // Function DBDCompetence.ActivatableExhaustedEffect.Authority_Start // (Final|Native|Public|BlueprintCallable) // @ game+0x2c8c060
	void Authority_OnHookCamper(struct FGameplayTag GameEvent, struct FGameEventData GameEventData); // Function DBDCompetence.ActivatableExhaustedEffect.Authority_OnHookCamper // (Final|Native|Private|HasOutParms) // @ game+0x2c8bae0
};

// Class DBDCompetence.ActivateOnEventTimedStatusEffect
// Size: 0x340 (Inherited: 0x320)
struct UActivateOnEventTimedStatusEffect : UStatusEffect {
	struct FGameplayTagContainer _eventsToActivateOn; // 0x320(0x20)
};

// Class DBDCompetence.AllHexTotemsAreActive
// Size: 0x100 (Inherited: 0xe8)
struct UAllHexTotemsAreActive : UEventDrivenModifierCondition {
	char pad_E8[0x18]; // 0xe8(0x18)
};

// Class DBDCompetence.AnyActorPairQueryRangeIsTrue
// Size: 0x100 (Inherited: 0xf0)
struct UAnyActorPairQueryRangeIsTrue : URangeBasedCondition {
	char pad_F0[0x10]; // 0xf0(0x10)

	void OnInRangeChanged(bool InRange); // Function DBDCompetence.AnyActorPairQueryRangeIsTrue.OnInRangeChanged // (Final|Native|Private) // @ game+0x2c8c400
};

// Class DBDCompetence.AnyMeansNecessary
// Size: 0x3c8 (Inherited: 0x3a8)
struct UAnyMeansNecessary : UPerk {
	bool RevealSurvivorOnPalletPullUpStarted; // 0x3a8(0x01)
	bool RevealSurvivorOnPalletPulledUp; // 0x3a9(0x01)
	char pad_3AA[0x2]; // 0x3aa(0x02)
	float RevealSurvivorDuration; // 0x3ac(0x04)
	struct TWeakObjectPtr<struct UStatusEffect> _effect; // 0x3b0(0x08)
	float _cooldownDuration[0x3]; // 0x3b8(0x0c)
	char pad_3C4[0x4]; // 0x3c4(0x04)

	void Authority_OnPalletPullUpStarted(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function DBDCompetence.AnyMeansNecessary.Authority_OnPalletPullUpStarted // (Final|Native|Private|HasOutParms) // @ game+0x2c8bd30
	void Authority_OnPalletPulledUp(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function DBDCompetence.AnyMeansNecessary.Authority_OnPalletPulledUp // (Final|Native|Private|HasOutParms) // @ game+0x2c8be40
};

// Class DBDCompetence.AnySurvivorHasObjectState
// Size: 0x158 (Inherited: 0xe8)
struct UAnySurvivorHasObjectState : UEventDrivenModifierCondition {
	char pad_E8[0x50]; // 0xe8(0x50)
	struct FGameplayTag _stateTag; // 0x138(0x0c)
	char pad_144[0x14]; // 0x144(0x14)

	void OnSurvivorRemoved(struct ACamperPlayer* survivor); // Function DBDCompetence.AnySurvivorHasObjectState.OnSurvivorRemoved // (Final|Native|Protected) // @ game+0x2c8ca80
	void OnSurvivorAdded(struct ACamperPlayer* survivor); // Function DBDCompetence.AnySurvivorHasObjectState.OnSurvivorAdded // (Final|Native|Protected) // @ game+0x2c8ca00
};

// Class DBDCompetence.Babysitter
// Size: 0x3d0 (Inherited: 0x3a8)
struct UBabysitter : UPerk {
	float _scratchMarkHidingTime[0x3]; // 0x3a8(0x0c)
	float _showAuraTime[0x3]; // 0x3b4(0x0c)
	float _cooldownTime[0x3]; // 0x3c0(0x0c)
	char pad_3CC[0x4]; // 0x3cc(0x04)
};

// Class DBDCompetence.BabysitterEffect
// Size: 0x320 (Inherited: 0x320)
struct UBabysitterEffect : UStatusEffect {
};

// Class DBDCompetence.BaseIsPerkUsableCondition
// Size: 0xf0 (Inherited: 0xe8)
struct UBaseIsPerkUsableCondition : UEventDrivenModifierCondition {
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class DBDCompetence.BaseIsPlayerPerformingInteraction
// Size: 0x118 (Inherited: 0xe8)
struct UBaseIsPlayerPerformingInteraction : UEventDrivenModifierCondition {
	struct FGameplayTagContainer _interactionSemantics; // 0xe8(0x20)
	char pad_108[0x10]; // 0x108(0x10)

	void UpdateIsTrue(struct UInteractionDefinition* InteractionDefinition); // Function DBDCompetence.BaseIsPlayerPerformingInteraction.UpdateIsTrue // (Final|Native|Protected) // @ game+0x2c8cd30
	void SetInteractionSemantics(struct FGameplayTagContainer interactionSemantics); // Function DBDCompetence.BaseIsPlayerPerformingInteraction.SetInteractionSemantics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2c8cb70
};

// Class DBDCompetence.BaseLingeringStatusEffect
// Size: 0x328 (Inherited: 0x320)
struct UBaseLingeringStatusEffect : UStatusEffect {
	float _lingerDuration; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)

	void SetLingerDuration(float lingerDuration); // Function DBDCompetence.BaseLingeringStatusEffect.SetLingerDuration // (Final|Native|Protected|BlueprintCallable) // @ game+0x2c8cc30
};

// Class DBDCompetence.BetterTogether
// Size: 0x400 (Inherited: 0x3a8)
struct UBetterTogether : UPerk {
	bool ShouldRevealKiller; // 0x3a8(0x01)
	bool ShouldRevealSurvivors; // 0x3a9(0x01)
	char pad_3AA[0x2]; // 0x3aa(0x02)
	float RevealDistance; // 0x3ac(0x04)
	struct TArray<struct ADBDPlayer*> _affectedCampers; // 0x3b0(0x10)
	char pad_3C0[0x8]; // 0x3c0(0x08)
	struct AActor* _genToReveal; // 0x3c8(0x08)
	float _durationByLevel[0x3]; // 0x3d0(0x0c)
	char pad_3DC[0x24]; // 0x3dc(0x24)

	void OnStartedGeneratorRepair(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function DBDCompetence.BetterTogether.OnStartedGeneratorRepair // (Final|Native|Private|HasOutParms) // @ game+0x2c8c8f0
};

// Class DBDCompetence.BloodEcho
// Size: 0x3c0 (Inherited: 0x3a8)
struct UBloodEcho : UPerk {
	struct FGameplayTag _statusEffectDurationTag; // 0x3a8(0x0c)
	float _cooldownDuration[0x3]; // 0x3b4(0x0c)
};

// Class DBDCompetence.Breakout
// Size: 0x420 (Inherited: 0x3a8)
struct UBreakout : UPerk {
	struct ASlasherPlayer* _slasher; // 0x3a8(0x08)
	struct ADBDPlayer* _playerOwner; // 0x3b0(0x08)
	float _hasteEffect[0x3]; // 0x3b8(0x0c)
	float _wiggleEffect; // 0x3c4(0x04)
	float _survivorDistanceMax; // 0x3c8(0x04)
	bool _isPerkActive; // 0x3cc(0x01)
	char pad_3CD[0x53]; // 0x3cd(0x53)

	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function DBDCompetence.Breakout.OnSlasherSet // (Final|Native|Private) // @ game+0x2c8c870
	void OnRep_IsPerkActive(); // Function DBDCompetence.Breakout.OnRep_IsPerkActive // (Final|Native|Private) // @ game+0x2c8c6b0
	void Authority_OnRangeChanged(bool InRange); // Function DBDCompetence.Breakout.Authority_OnRangeChanged // (Final|Native|Private) // @ game+0x2c8bfd0
	void Authority_ImposeWiggleStatusEffect(struct ACamperPlayer* survivor); // Function DBDCompetence.Breakout.Authority_ImposeWiggleStatusEffect // (Final|Native|Private) // @ game+0x2c8ba40
};

// Class DBDCompetence.BuckleUp
// Size: 0x3d8 (Inherited: 0x3a8)
struct UBuckleUp : UPerk {
	struct FLinearColor _noRecoveryColor; // 0x3a8(0x10)
	struct FLinearColor _fullRecoveryColor; // 0x3b8(0x10)
	float _revealDuration[0x3]; // 0x3c8(0x0c)
	char pad_3D4[0x4]; // 0x3d4(0x04)
};

// Class DBDCompetence.Camaraderie
// Size: 0x3d0 (Inherited: 0x3a8)
struct UCamaraderie : UPerk {
	char pad_3A8[0xc]; // 0x3a8(0x0c)
	float _percentUseItem[0x3]; // 0x3b4(0x0c)
	float _pauseTimer[0x3]; // 0x3c0(0x0c)
	bool _needItemToTrigger; // 0x3cc(0x01)
	char pad_3CD[0x3]; // 0x3cd(0x03)

	void Authority_EnablePerk(); // Function DBDCompetence.Camaraderie.Authority_EnablePerk // (Final|Native|Private) // @ game+0x2c8ba20
};

// Class DBDCompetence.CollectableOwnerSubjectProvider
// Size: 0x60 (Inherited: 0x48)
struct UCollectableOwnerSubjectProvider : UModifierSubjectProvider {
	char pad_48[0x18]; // 0x48(0x18)
};

// Class DBDCompetence.CorruptIntervention
// Size: 0x3e0 (Inherited: 0x3a8)
struct UCorruptIntervention : UPerk {
	char _blockedGeneratorCount[0x3]; // 0x3a8(0x03)
	char pad_3AB[0x1]; // 0x3ab(0x01)
	float _generatorBlockDuration[0x3]; // 0x3ac(0x0c)
	struct FLinearColor _generatorAuraColorForKiller; // 0x3b8(0x10)
	struct TArray<struct AGenerator*> _blockedGenerators; // 0x3c8(0x10)
	char pad_3D8[0x8]; // 0x3d8(0x08)

	void Server_ActivatePerk(); // Function DBDCompetence.CorruptIntervention.Server_ActivatePerk // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2c8cb20
	void OnRep_BlockedGenerators(); // Function DBDCompetence.CorruptIntervention.OnRep_BlockedGenerators // (Final|Native|Private) // @ game+0x2c8c670
	void Local_OnIntroCompleted(); // Function DBDCompetence.CorruptIntervention.Local_OnIntroCompleted // (Final|Native|Private) // @ game+0x2c8c3e0
};

// Class DBDCompetence.CruelConfinement
// Size: 0x448 (Inherited: 0x3a8)
struct UCruelConfinement : UPerk {
	float _effectiveRadius[0x3]; // 0x3a8(0x0c)
	float _blockDuration[0x3]; // 0x3b4(0x0c)
	struct FLinearColor _windowAuraColor; // 0x3c0(0x10)
	struct TMap<struct AGenerator*, struct FWindowBlockableList> _blockableLists; // 0x3d0(0x50)
	char pad_420[0x28]; // 0x420(0x28)
};

// Class DBDCompetence.DarkDevotion
// Size: 0x3c0 (Inherited: 0x3a8)
struct UDarkDevotion : UPerk {
	struct UTerrorRadiusEmitterComponent* _obsessionTerrorRadiusEmitter; // 0x3a8(0x08)
	float _obsessionTerrorRadius; // 0x3b0(0x04)
	float _simulatedFixedDistance; // 0x3b4(0x04)
	char pad_3B8[0x8]; // 0x3b8(0x08)
};

// Class DBDCompetence.DarkSense
// Size: 0x3c0 (Inherited: 0x3a8)
struct UDarkSense : UPerk {
	float _effectDurationOnGeneratorComplete; // 0x3a8(0x04)
	float _effectDurationOnFinalGeneratorComplete[0x3]; // 0x3ac(0x0c)
	char pad_3B8[0x8]; // 0x3b8(0x08)
};

// Class DBDCompetence.DBDConditionFactory
// Size: 0x30 (Inherited: 0x30)
struct UDBDConditionFactory : UBlueprintFunctionLibrary {

	struct UIsPlayerPerformingInteraction* IsPlayerPerformingInteraction(struct TScriptInterface<None> ConditionReceiver, struct FGameplayTagContainer interactionSemantics); // Function DBDCompetence.DBDConditionFactory.IsPlayerPerformingInteraction // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2c8c2c0
	struct UDoesPerkHaveToken* DoesPerkHaveToken(struct TScriptInterface<None> ConditionReceiver, struct UPerk* Perk); // Function DBDCompetence.DBDConditionFactory.DoesPerkHaveToken // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2c8c110
};

// Class DBDCompetence.DeadMansSwitchEffect
// Size: 0x320 (Inherited: 0x320)
struct UDeadMansSwitchEffect : UStatusEffect {
};

// Class DBDCompetence.DeceptionEffect
// Size: 0x328 (Inherited: 0x320)
struct UDeceptionEffect : UStatusEffect {
	bool _hideBloodTrailsWhenCamperFakeEnterLocker; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)
};

// Class DBDCompetence.DecisiveStrike
// Size: 0x448 (Inherited: 0x3a8)
struct UDecisiveStrike : UPerk {
	float _timeAfterUnhook[0x3]; // 0x3a8(0x0c)
	float _skillCheckDelay; // 0x3b4(0x04)
	float _skillCheckBuffer; // 0x3b8(0x04)
	bool _killerHearsSkillCheckCue; // 0x3bc(0x01)
	char pad_3BD[0x73]; // 0x3bd(0x73)
	struct TArray<struct FGameplayTag> _deactivationEvents; // 0x430(0x10)
	bool _hasBeenAttempted; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)

	void OnUnhookedTimerEnded(); // Function DBDCompetence.DecisiveStrike.OnUnhookedTimerEnded // (Final|Native|Private) // @ game+0x2c8cb00
	void OnSkillCheck(bool hadInput, bool success, bool Bonus, enum class ESkillCheckCustomType Type); // Function DBDCompetence.DecisiveStrike.OnSkillCheck // (Final|Native|Private) // @ game+0x2c8c710
	void OnRep_HasBeenAttempted(); // Function DBDCompetence.DecisiveStrike.OnRep_HasBeenAttempted // (Final|Native|Private) // @ game+0x2c8c690
	void OnPickUpEnded(struct ADBDPlayer* picker); // Function DBDCompetence.DecisiveStrike.OnPickUpEnded // (Final|Native|Private) // @ game+0x2c8c5d0
	void OnOwnerPickedUp(struct ADBDPlayer* picker); // Function DBDCompetence.DecisiveStrike.OnOwnerPickedUp // (Final|Native|Private) // @ game+0x2c8c550
};

// Class DBDCompetence.DelayedHealEffect
// Size: 0x328 (Inherited: 0x320)
struct UDelayedHealEffect : UStatusEffect {
	char pad_320[0x8]; // 0x320(0x08)

	void Authority_OnOwningCamperPickedUp(struct ADBDPlayer* picker); // Function DBDCompetence.DelayedHealEffect.Authority_OnOwningCamperPickedUp // (Final|Native|Private) // @ game+0x2c8bcb0
	void Authority_OnOwningCamperHealthChanged(enum class ECamperDamageState before, enum class ECamperDamageState after); // Function DBDCompetence.DelayedHealEffect.Authority_OnOwningCamperHealthChanged // (Final|Native|Private) // @ game+0x2c8bbf0
	void Authority_OnActivationTimerComplete(); // Function DBDCompetence.DelayedHealEffect.Authority_OnActivationTimerComplete // (Final|Native|Private) // @ game+0x2c8bac0
};

// Class DBDCompetence.DidGameEventOccurred
// Size: 0x120 (Inherited: 0xe8)
struct UDidGameEventOccurred : UEventDrivenModifierCondition {
	struct FGameplayTag EventTag; // 0xe8(0x0c)
	char pad_F4[0x2c]; // 0xf4(0x2c)
};

// Class DBDCompetence.Distortion
// Size: 0x3c8 (Inherited: 0x3a8)
struct UDistortion : UPerk {
	float _activationDurations[0x3]; // 0x3a8(0x0c)
	bool _auraBlockIsActive; // 0x3b4(0x01)
	char pad_3B5[0x13]; // 0x3b5(0x13)

	void OnRep_AuraBlockIsActive(); // Function DBDCompetence.Distortion.OnRep_AuraBlockIsActive // (Final|Native|Private) // @ game+0x2c8c650
	bool AuraBlockCanBeActive(); // Function DBDCompetence.Distortion.AuraBlockCanBeActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c8b9f0
};

// Class DBDCompetence.Diversion
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDiversion : UPerk {

	bool IsOwnerDisabled(struct ACamperPlayer* OwningPlayer); // Function DBDCompetence.Diversion.IsOwnerDisabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c8c230
	float GetThrowDistance(); // Function DBDCompetence.Diversion.GetThrowDistance // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2c8c1f0
	bool CanThrow(); // Function DBDCompetence.Diversion.CanThrow // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2c8c0e0
};

// Class DBDCompetence.DoesPerkHaveToken
// Size: 0xf8 (Inherited: 0xe8)
struct UDoesPerkHaveToken : UEventDrivenModifierCondition {
	struct TWeakObjectPtr<struct UPerk> _perk; // 0xe8(0x08)
	char pad_F0[0x8]; // 0xf0(0x08)

	void SetPerk(struct UPerk* Perk); // Function DBDCompetence.DoesPerkHaveToken.SetPerk // (Final|Native|Public|BlueprintCallable) // @ game+0x2c8ccb0
	void OnRep_Perk(); // Function DBDCompetence.DoesPerkHaveToken.OnRep_Perk // (Final|Native|Private) // @ game+0x2c8c6d0
};

// Class DBDCompetence.DownedByBasicAttack
// Size: 0x140 (Inherited: 0xe8)
struct UDownedByBasicAttack : UEventDrivenModifierCondition {
	bool _replicatedIsTrue; // 0xe8(0x01)
	char pad_E9[0x57]; // 0xe9(0x57)

	void OnRep_ReplicatedIsTrue(); // Function DBDCompetence.DownedByBasicAttack.OnRep_ReplicatedIsTrue // (Final|Native|Private) // @ game+0x2c8c6f0
};

// Class DBDCompetence.DyingLight
// Size: 0x3e8 (Inherited: 0x3a8)
struct UDyingLight : UPerk {
	struct TArray<float> _actionSpeedPenaltyPerToken; // 0x3a8(0x10)
	float _obsessionActionSpeedBonus; // 0x3b8(0x04)
	struct FName _obsessionStatusEffectID; // 0x3bc(0x0c)
	struct FName _nonObsessionStatusEffectID; // 0x3c8(0x0c)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct TArray<struct UStatusEffect*> _survivorDebuffs; // 0x3d8(0x10)

	void OnObsessionChanged(struct ACamperPlayer* newObsession, struct ACamperPlayer* previousObsession); // Function DBDCompetence.DyingLight.OnObsessionChanged // (Final|Native|Private) // @ game+0x2c8c490
};

// Class DBDCompetence.EnduranceHighlightEffect
// Size: 0x320 (Inherited: 0x320)
struct UEnduranceHighlightEffect : UStatusEffect {
};

// Class DBDCompetence.ExposedEffect
// Size: 0x320 (Inherited: 0x320)
struct UExposedEffect : UStatusEffect {
};

// Class DBDCompetence.Fixated
// Size: 0x3a8 (Inherited: 0x3a8)
struct UFixated : UPerk {
};

// Class DBDCompetence.FlipFlop
// Size: 0x3c0 (Inherited: 0x3a8)
struct UFlipFlop : UPerk {
	float _recoveryProgressionConversionRatio[0x3]; // 0x3a8(0x0c)
	float _maxWiggleProgression[0x3]; // 0x3b4(0x0c)

	void Authority_OnPickedUp(struct ADBDPlayer* picker); // Function DBDCompetence.FlipFlop.Authority_OnPickedUp // (Final|Native|Private) // @ game+0x2c8bf50
};

// Class DBDCompetence.FurtiveChase
// Size: 0x3b8 (Inherited: 0x3a8)
struct UFurtiveChase : UPerk {
	int32_t _maxTokensByLevel[0x3]; // 0x3a8(0x0c)
	float _terrorRadiusSuppressionPerToken; // 0x3b4(0x04)
};

// Class DBDCompetence.GateBlockerEffect
// Size: 0x320 (Inherited: 0x320)
struct UGateBlockerEffect : UStatusEffect {
};

// Class DBDCompetence.HasPlayerReachedWiggleFillPercentCondition
// Size: 0xf0 (Inherited: 0xe8)
struct UHasPlayerReachedWiggleFillPercentCondition : UEventDrivenModifierCondition {
	char pad_E8[0x4]; // 0xe8(0x04)
	bool _isWigglePercentReached; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)

	void OnRep_IsWigglePercentReached(); // Function DBDCompetence.HasPlayerReachedWiggleFillPercentCondition.OnRep_IsWigglePercentReached // (Final|Native|Private) // @ game+0x2c92c40
	void Authority_OnOwnerWiggleChargePercentChanged(struct UChargeableComponent* ChargeableComponent, float PercentCompletionChange, float TotalPercentComplete); // Function DBDCompetence.HasPlayerReachedWiggleFillPercentCondition.Authority_OnOwnerWiggleChargePercentChanged // (Final|Native|Private) // @ game+0x2c91c90
};

// Class DBDCompetence.HeadOn
// Size: 0x420 (Inherited: 0x3a8)
struct UHeadOn : UPerk {
	bool IsPerformingHeadOn; // 0x3a8(0x01)
	bool ExhaustOnlyOnSuccessfulStun; // 0x3a9(0x01)
	bool StunKillersEnteringStunZone; // 0x3aa(0x01)
	char pad_3AB[0x1]; // 0x3ab(0x01)
	float _hideDuration[0x3]; // 0x3ac(0x0c)
	struct ALocker* _locker; // 0x3b8(0x08)
	char pad_3C0[0x60]; // 0x3c0(0x60)

	void OnPawnOverlapExit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function DBDCompetence.HeadOn.OnPawnOverlapExit // (Final|Native|Private) // @ game+0x2c92a40
	void OnPawnOverlapEnter(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function DBDCompetence.HeadOn.OnPawnOverlapEnter // (Final|Native|Private|HasOutParms) // @ game+0x2c92830
	void OnHeadOnAnimationComplete(); // Function DBDCompetence.HeadOn.OnHeadOnAnimationComplete // (Final|Native|Public|BlueprintCallable) // @ game+0x2c92610
	void Multicast_StunPlayer(struct UStunnableComponent* StunnableComponent, struct ADBDPlayer* stunner); // Function DBDCompetence.HeadOn.Multicast_StunPlayer // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2c92350
	bool CanApplyHeadOnInteraction(); // Function DBDCompetence.HeadOn.CanApplyHeadOnInteraction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c91f50
	void Authority_ActivatePerk(); // Function DBDCompetence.HeadOn.Authority_ActivatePerk // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x2c91c20
};

// Class DBDCompetence.HexPerk
// Size: 0x408 (Inherited: 0x3a8)
struct UHexPerk : UPerk {
	int32_t NumTotemsToBind; // 0x3a8(0x04)
	bool _doNotBindToTotemOnInit; // 0x3ac(0x01)
	char pad_3AD[0x3]; // 0x3ad(0x03)
	struct TArray<struct ATotem*> _totemActors; // 0x3b0(0x10)
	struct TArray<struct ATotem*> _authorityPrevTotemActors; // 0x3c0(0x10)
	struct TArray<struct ADBDPlayer*> _playersWhoKnowCurse; // 0x3d0(0x10)
	char pad_3E0[0x28]; // 0x3e0(0x28)

	void ReceiveGameplayEvent(enum class EDBDScoreTypes gameplayEventType, float amount, struct AActor* Instigator, struct AActor* Target); // Function DBDCompetence.HexPerk.ReceiveGameplayEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x2c92e70
	void OnRep_TotemActors(); // Function DBDCompetence.HexPerk.OnRep_TotemActors // (Final|Native|Private) // @ game+0x2c92d80
	void OnRep_PlayersWhoKnowCurse(struct TArray<struct ADBDPlayer*> oldPlayersWhoKnowCurse); // Function DBDCompetence.HexPerk.OnRep_PlayersWhoKnowCurse // (Final|Native|Private) // @ game+0x2c92ca0
	void OnHexPerkGameplayEvent(enum class EDBDScoreTypes gameplayEventType, float amount, struct AActor* Instigator, struct AActor* Target); // Function DBDCompetence.HexPerk.OnHexPerkGameplayEvent // (Final|Native|Public) // @ game+0x2c92630
	bool IsCurseRevealedToPlayer(struct ADBDPlayer* Player); // Function DBDCompetence.HexPerk.IsCurseRevealedToPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c922c0
	struct TArray<struct ATotem*> GetTotems(); // Function DBDCompetence.HexPerk.GetTotems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c920f0
	float GetDistanceToOwner(struct AActor* OtherActor); // Function DBDCompetence.HexPerk.GetDistanceToOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c92020
	struct TArray<struct ATotem*> GetBoundTotems(); // Function DBDCompetence.HexPerk.GetBoundTotems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c91fa0
	void FireCursedStatusOnLocalPlayer(); // Function DBDCompetence.HexPerk.FireCursedStatusOnLocalPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2c91f80
	void Authority_UnbindFromTotem(struct ATotem* aTotemActor, bool isCleansedTotem); // Function DBDCompetence.HexPerk.Authority_UnbindFromTotem // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x2c91e80
	void Authority_SetCurseRevealedToPlayer(struct ADBDPlayer* Player, bool revealed); // Function DBDCompetence.HexPerk.Authority_SetCurseRevealedToPlayer // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x2c91db0
	void Authority_RevealCurseToAllSurvivors(); // Function DBDCompetence.HexPerk.Authority_RevealCurseToAllSurvivors // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x2c91d90
	void Authority_Reactivate_BP(); // Function DBDCompetence.HexPerk.Authority_Reactivate_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool Authority_BindToDullTotems(); // Function DBDCompetence.HexPerk.Authority_BindToDullTotems // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x2c91c40
};

// Class DBDCompetence.HexHauntedGround
// Size: 0x408 (Inherited: 0x408)
struct UHexHauntedGround : UHexPerk {
};

// Class DBDCompetence.HexRuin
// Size: 0x470 (Inherited: 0x408)
struct UHexRuin : UHexPerk {
	char pad_408[0x18]; // 0x408(0x18)
	struct TMap<struct AGenerator*, struct FFastTimer> _curseActivationTimers; // 0x420(0x50)

	void Authority_ConstructActivationTimersMap(); // Function DBDCompetence.HexRuin.Authority_ConstructActivationTimersMap // (Final|Native|Private) // @ game+0x2c91c70
};

// Class DBDCompetence.HighestLevelAndClosestEffectCondition
// Size: 0x108 (Inherited: 0xd0)
struct UHighestLevelAndClosestEffectCondition : UGameplayModifierCondition {
	char pad_D0[0x8]; // 0xd0(0x08)
	struct TArray<struct UStatusEffect*> _effectsLevel1; // 0xd8(0x10)
	struct TArray<struct UStatusEffect*> _effectsLevel2; // 0xe8(0x10)
	struct TArray<struct UStatusEffect*> _effectsLevel3; // 0xf8(0x10)

	void SetCurrentEffectLevel(int32_t Level); // Function DBDCompetence.HighestLevelAndClosestEffectCondition.SetCurrentEffectLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x2c93180
	void InitEffectArrays(struct FName effectIDLevel1, struct FName effectIDLevel2, struct FName effectIDLevel3); // Function DBDCompetence.HighestLevelAndClosestEffectCondition.InitEffectArrays // (Final|Native|Public|BlueprintCallable) // @ game+0x2c92180
};

// Class DBDCompetence.ImAllEars
// Size: 0x400 (Inherited: 0x3a8)
struct UImAllEars : UPerk {
	int32_t _cooldownByLevel[0x3]; // 0x3a8(0x0c)
	float _durationByLevel[0x3]; // 0x3b4(0x0c)
	bool _useTerrorRadius; // 0x3c0(0x01)
	char pad_3C1[0x3]; // 0x3c1(0x03)
	float _triggerOutsideRadius; // 0x3c4(0x04)
	char pad_3C8[0x38]; // 0x3c8(0x38)

	void Server_OnCamperLoudNoise(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function DBDCompetence.ImAllEars.Server_OnCamperLoudNoise // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2c93030
};

// Class DBDCompetence.ImmediateUndetectableEffect
// Size: 0x320 (Inherited: 0x320)
struct UImmediateUndetectableEffect : UStatusEffect {
};

// Class DBDCompetence.OnEventBaseAddon
// Size: 0x288 (Inherited: 0x278)
struct UOnEventBaseAddon : UItemAddon {
	struct FGameplayTag _eventToListenTo; // 0x278(0x0c)
	char pad_284[0x4]; // 0x284(0x04)

	void OnEventFired(struct FGameEventData GameEventData); // Function DBDCompetence.OnEventBaseAddon.OnEventFired // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x3873200
};

// Class DBDCompetence.ImposeStatusEffectOnEventAddon
// Size: 0x2a0 (Inherited: 0x288)
struct UImposeStatusEffectOnEventAddon : UOnEventBaseAddon {
	float _statusEffectTime; // 0x288(0x04)
	struct FName _statusEffectName; // 0x28c(0x0c)
	enum class EImposeEffectTo _imposeEffectTo; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
};

// Class DBDCompetence.InfectiousFright
// Size: 0x3f0 (Inherited: 0x3a8)
struct UInfectiousFright : UPerk {
	bool _revealPlayerInTerrorRadius; // 0x3a8(0x01)
	char _perkActivationCount; // 0x3a9(0x01)
	char pad_3AA[0x6]; // 0x3aa(0x06)
	struct TArray<struct ACamperPlayer*> _revealedSurvivors; // 0x3b0(0x10)
	struct ACamperPlayer* _targetSurvivor; // 0x3c0(0x08)
	char pad_3C8[0x28]; // 0x3c8(0x28)

	void RevealSurvivorLocation(struct ACamperPlayer* Target); // Function DBDCompetence.InfectiousFright.RevealSurvivorLocation // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRep_PerkActivationCount(); // Function DBDCompetence.InfectiousFright.OnRep_PerkActivationCount // (Final|Native|Private) // @ game+0x2c92c60
};

// Class DBDCompetence.InnerStrength
// Size: 0x3e0 (Inherited: 0x3a8)
struct UInnerStrength : UPerk {
	float _hideDuration[0x3]; // 0x3a8(0x0c)
	bool _perkEnabled; // 0x3b4(0x01)
	char pad_3B5[0x2b]; // 0x3b5(0x2b)

	void OnRep_PerkEnabled(); // Function DBDCompetence.InnerStrength.OnRep_PerkEnabled // (Final|Native|Private) // @ game+0x2c92c80
	void OnPlayerImmobilizeStateChanged(enum class ECamperImmobilizeState oldImmobilizeState, enum class ECamperImmobilizeState newImmobilizeState); // Function DBDCompetence.InnerStrength.OnPlayerImmobilizeStateChanged // (Final|Native|Private) // @ game+0x2c92b80
};

// Class DBDCompetence.Insidious
// Size: 0x3a8 (Inherited: 0x3a8)
struct UInsidious : UPerk {
};

// Class DBDCompetence.InsidiousEffect
// Size: 0x320 (Inherited: 0x320)
struct UInsidiousEffect : UAbilityStealthUndetectableEffect {
};

// Class DBDCompetence.IsActivationTimerActive
// Size: 0x100 (Inherited: 0xe8)
struct UIsActivationTimerActive : UEventDrivenModifierCondition {
	char pad_E8[0x18]; // 0xe8(0x18)
};

// Class DBDCompetence.IsActivationTimerActiveAndNotPaused
// Size: 0x108 (Inherited: 0xe8)
struct UIsActivationTimerActiveAndNotPaused : UEventDrivenModifierCondition {
	char pad_E8[0x20]; // 0xe8(0x20)
};

// Class DBDCompetence.IsClosestEffectCondition
// Size: 0xd0 (Inherited: 0xd0)
struct UIsClosestEffectCondition : UGameplayModifierCondition {
};

// Class DBDCompetence.IsCooldownTimerActive
// Size: 0x100 (Inherited: 0xe8)
struct UIsCooldownTimerActive : UEventDrivenModifierCondition {
	char pad_E8[0x18]; // 0xe8(0x18)
};

// Class DBDCompetence.IsHexCursed
// Size: 0x100 (Inherited: 0xe8)
struct UIsHexCursed : UEventDrivenModifierCondition {
	char pad_E8[0x18]; // 0xe8(0x18)
};

// Class DBDCompetence.IsHighestLevelAndClosestOriginatingEffect
// Size: 0xf8 (Inherited: 0xd0)
struct UIsHighestLevelAndClosestOriginatingEffect : UGameplayModifierCondition {
	struct TArray<struct UStatusEffect*> _applicableEffects; // 0xd0(0x10)
	char pad_E0[0x18]; // 0xe0(0x18)

	void OnStatusEffectAddedOrRemoved(struct UStatusEffect* effect, bool Valid); // Function DBDCompetence.IsHighestLevelAndClosestOriginatingEffect.OnStatusEffectAddedOrRemoved // (Final|Native|Private) // @ game+0x2c92da0
};

// Class DBDCompetence.IsInAnyHookedSurvivorOriginatorAuraReadingRange
// Size: 0x1a0 (Inherited: 0xf0)
struct UIsInAnyHookedSurvivorOriginatorAuraReadingRange : URangeBasedCondition {
	char pad_F0[0xb0]; // 0xf0(0xb0)
};

// Class DBDCompetence.IsLifetimeActive
// Size: 0xf8 (Inherited: 0xe8)
struct UIsLifetimeActive : UEventDrivenModifierCondition {
	char pad_E8[0x10]; // 0xe8(0x10)
};

// Class DBDCompetence.IsOnHitSprintEffectActive
// Size: 0xe8 (Inherited: 0xe8)
struct UIsOnHitSprintEffectActive : UEventDrivenModifierCondition {
};

// Class DBDCompetence.IsOriginatingPerkUsableCondition
// Size: 0xf0 (Inherited: 0xf0)
struct UIsOriginatingPerkUsableCondition : UBaseIsPerkUsableCondition {
};

// Class DBDCompetence.IsOutRangeOfOriginatingPlayer
// Size: 0x118 (Inherited: 0xf0)
struct UIsOutRangeOfOriginatingPlayer : URangeBasedCondition {
	char pad_F0[0x28]; // 0xf0(0x28)

	void OnInRangeChanged(bool InRange); // Function DBDCompetence.IsOutRangeOfOriginatingPlayer.OnInRangeChanged // (Final|Native|Private) // @ game+0x2c92780
};

// Class DBDCompetence.IsOwningPlayerInRangeFromHook
// Size: 0x108 (Inherited: 0x100)
struct UIsOwningPlayerInRangeFromHook : UAnyActorPairQueryRangeIsTrue {
	char pad_100[0x8]; // 0x100(0x08)

	void OnLevelReadyToPlay(); // Function DBDCompetence.IsOwningPlayerInRangeFromHook.OnLevelReadyToPlay // (Final|Native|Protected) // @ game+0x2c92810
};

// Class DBDCompetence.IsOwningPlayerInHookRangeWhenKillerCarry
// Size: 0x120 (Inherited: 0x108)
struct UIsOwningPlayerInHookRangeWhenKillerCarry : UIsOwningPlayerInRangeFromHook {
	char pad_108[0x18]; // 0x108(0x18)
};

// Class DBDCompetence.IsOwningPlayerLastSurvivor
// Size: 0xf0 (Inherited: 0xe8)
struct UIsOwningPlayerLastSurvivor : UEventDrivenModifierCondition {
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class DBDCompetence.IsOwningSurvivorAuraRevealedToKiller
// Size: 0xd0 (Inherited: 0xd0)
struct UIsOwningSurvivorAuraRevealedToKiller : UGameplayModifierCondition {
};

// Class DBDCompetence.IsPerkUsableCondition
// Size: 0xf0 (Inherited: 0xf0)
struct UIsPerkUsableCondition : UBaseIsPerkUsableCondition {
};

// Class DBDCompetence.IsPlayerPerformingItemInteraction
// Size: 0x138 (Inherited: 0x118)
struct UIsPlayerPerformingItemInteraction : UBaseIsPlayerPerformingInteraction {
	char pad_118[0x20]; // 0x118(0x20)

	void OnCollectablePickedUp(struct ADBDPlayer* Player); // Function DBDCompetence.IsPlayerPerformingItemInteraction.OnCollectablePickedUp // (Final|Native|Private) // @ game+0x2c924d0
	void OnCollectableDropped(); // Function DBDCompetence.IsPlayerPerformingItemInteraction.OnCollectableDropped // (Final|Native|Private) // @ game+0x2c924b0
	void OnCollectableChargeStateChange(bool Empty); // Function DBDCompetence.IsPlayerPerformingItemInteraction.OnCollectableChargeStateChange // (Final|Native|Private) // @ game+0x2c92420
};

// Class DBDCompetence.IsPlayerPerformingInteraction
// Size: 0x128 (Inherited: 0xe8)
struct UIsPlayerPerformingInteraction : UEventDrivenModifierCondition {
	struct FGameplayTagContainer _interactionSemantics; // 0xe8(0x20)
	char pad_108[0x20]; // 0x108(0x20)

	void UpdateIsTrue(struct UInteractionDefinition* InteractionDefinition); // Function DBDCompetence.IsPlayerPerformingInteraction.UpdateIsTrue // (Final|Native|Private) // @ game+0x2c93200
	void SetInteractionSemantics(struct FGameplayTagContainer interactionSemantics); // Function DBDCompetence.IsPlayerPerformingInteraction.SetInteractionSemantics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2c8cb70
};

// Class DBDCompetence.KillerIsLowOnAmmo
// Size: 0x100 (Inherited: 0xe8)
struct UKillerIsLowOnAmmo : UEventDrivenModifierCondition {
	int32_t _ammoThreshold; // 0xe8(0x04)
	char pad_EC[0x14]; // 0xec(0x14)
};

// Class DBDCompetence.KillerSubjectProvider
// Size: 0x50 (Inherited: 0x48)
struct UKillerSubjectProvider : UModifierSubjectProvider {
	char pad_48[0x8]; // 0x48(0x08)

	void RegisterWhenKillerSet(struct ASlasherPlayer* killer); // Function DBDCompetence.KillerSubjectProvider.RegisterWhenKillerSet // (Final|Native|Private) // @ game+0x2c92fb0
};

// Class DBDCompetence.KindredPerk
// Size: 0x3d0 (Inherited: 0x3a8)
struct UKindredPerk : UPerk {
	char pad_3A8[0x10]; // 0x3a8(0x10)
	struct TArray<float> _killerAuraRevealRange; // 0x3b8(0x10)
	char pad_3C8[0x8]; // 0x3c8(0x08)
};

// Class DBDCompetence.LingeringStateTagStatusEffect
// Size: 0x360 (Inherited: 0x328)
struct ULingeringStateTagStatusEffect : UBaseLingeringStatusEffect {
	struct FGameplayTag _ownerStateTag; // 0x328(0x0c)
	char pad_334[0x2c]; // 0x334(0x2c)
};

// Class DBDCompetence.LuckyBreak
// Size: 0x3b8 (Inherited: 0x3a8)
struct ULuckyBreak : UPerk {
	float _activationTime[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)

	void OnDamageStateChanged(enum class ECamperDamageState oldDamageState, enum class ECamperDamageState CurrentDamageState); // Function DBDCompetence.LuckyBreak.OnDamageStateChanged // (Final|Native|Private) // @ game+0x2c92550
	void ActivationTimerEnded(); // Function DBDCompetence.LuckyBreak.ActivationTimerEnded // (Final|Native|Private) // @ game+0x2c91c00
};

// Class DBDCompetence.MindBreaker
// Size: 0x3e8 (Inherited: 0x3a8)
struct UMindBreaker : UPerk {
	float _effectDurationAfterRepair[0x3]; // 0x3a8(0x0c)
	float _generatorRepairThreshold[0x3]; // 0x3b4(0x0c)
	char pad_3C0[0x28]; // 0x3c0(0x28)
};

// Class DBDCompetence.Nemesis
// Size: 0x3c8 (Inherited: 0x3a8)
struct UNemesis : UPerk {
	char pad_3A8[0x8]; // 0x3a8(0x08)
	float _revealToKillerTime[0x3]; // 0x3b0(0x0c)
	float _obliviousTime[0x3]; // 0x3bc(0x0c)
};

// Class DBDCompetence.NoOneLeftBehind
// Size: 0x3b8 (Inherited: 0x3a8)
struct UNoOneLeftBehind : UPerk {
	struct TArray<float> _speedBoostEffect; // 0x3a8(0x10)

	float GetSpeedBoostEffect(); // Function DBDCompetence.NoOneLeftBehind.GetSpeedBoostEffect // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c920c0
};

// Class DBDCompetence.ObliviousEffect
// Size: 0x320 (Inherited: 0x320)
struct UObliviousEffect : UStatusEffect {
};

// Class DBDCompetence.ObsessionTargetSubjectProvider
// Size: 0x58 (Inherited: 0x48)
struct UObsessionTargetSubjectProvider : UModifierSubjectProvider {
	char pad_48[0x10]; // 0x48(0x10)
};

// Class DBDCompetence.OwningPlayerInTotemRange
// Size: 0x118 (Inherited: 0x100)
struct UOwningPlayerInTotemRange : UAnyActorPairQueryRangeIsTrue {
	char pad_100[0x18]; // 0x100(0x18)

	void OnLevelReadyToPlay(); // Function DBDCompetence.OwningPlayerInTotemRange.OnLevelReadyToPlay // (Final|Native|Protected) // @ game+0x2c98490
};

// Class DBDCompetence.OwningPlayerInDullTotemRange
// Size: 0x118 (Inherited: 0x118)
struct UOwningPlayerInDullTotemRange : UOwningPlayerInTotemRange {
};

// Class DBDCompetence.OwningSlasherHasBeenStill
// Size: 0xd8 (Inherited: 0xd0)
struct UOwningSlasherHasBeenStill : UGameplayModifierCondition {
	float _secondsOfStillnessRequired; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)

	void Authority_SetSecondsOfStillnessRequired(float secondsRequired); // Function DBDCompetence.OwningSlasherHasBeenStill.Authority_SetSecondsOfStillnessRequired // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x2c98010
};

// Class DBDCompetence.PharmacyPerk
// Size: 0x3b8 (Inherited: 0x3a8)
struct UPharmacyPerk : UPerk {
	struct TArray<float> _searchSpeeds; // 0x3a8(0x10)
};

// Class DBDCompetence.PlayerIsInExitArea
// Size: 0xd8 (Inherited: 0xd0)
struct UPlayerIsInExitArea : UGameplayModifierCondition {
	char pad_D0[0x8]; // 0xd0(0x08)

	void PlayerExitExitArea(); // Function DBDCompetence.PlayerIsInExitArea.PlayerExitExitArea // (Final|Native|Private) // @ game+0x2c98530
	void PlayerEnterExitArea(); // Function DBDCompetence.PlayerIsInExitArea.PlayerEnterExitArea // (Final|Native|Private) // @ game+0x2c98510
};

// Class DBDCompetence.Poised
// Size: 0x3d0 (Inherited: 0x3a8)
struct UPoised : UPerk {
	float _activationTime[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x1c]; // 0x3b4(0x1c)
};

// Class DBDCompetence.PreventKOEffect
// Size: 0x328 (Inherited: 0x320)
struct UPreventKOEffect : UStatusEffect {
	char pad_320[0x8]; // 0x320(0x08)
};

// Class DBDCompetence.QKPerk3ExhaustedEffect
// Size: 0x360 (Inherited: 0x338)
struct UQKPerk3ExhaustedEffect : UExhaustedEffect {
	char pad_338[0x28]; // 0x338(0x28)
};

// Class DBDCompetence.ResiliencePerk
// Size: 0x3b8 (Inherited: 0x3a8)
struct UResiliencePerk : UPerk {
	float _actionSpeed[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class DBDCompetence.Saboteur
// Size: 0x3d0 (Inherited: 0x3a8)
struct USaboteur : UPerk {
	float _cooldownDuration[0x3]; // 0x3a8(0x0c)
	float _revealHookDistance[0x3]; // 0x3b4(0x0c)
	struct TArray<struct UMeatHookOutlineUpdateStrategy*> _revealedMeatHooksOultineStrategy; // 0x3c0(0x10)
};

// Class DBDCompetence.SecondsToRateModifierBaseAddon
// Size: 0x388 (Inherited: 0x278)
struct USecondsToRateModifierBaseAddon : UItemAddon {
	struct FTunableStat _chargeRate; // 0x278(0x80)
	struct FTunableStat _maxCharge; // 0x2f8(0x80)
	float _secondsToAdd; // 0x378(0x04)
	struct FGameplayTag _rateModifierTagToCompute; // 0x37c(0x0c)
};

// Class DBDCompetence.SecondWind
// Size: 0x3e0 (Inherited: 0x3a8)
struct USecondWind : UPerk {
	char pad_3A8[0x8]; // 0x3a8(0x08)
	enum class ESecondWindState _currentState; // 0x3b0(0x01)
	char pad_3B1[0x3]; // 0x3b1(0x03)
	float _amountHealed; // 0x3b4(0x04)
	char pad_3B8[0x4]; // 0x3b8(0x04)
	float _numberOfHealStateToHealToActivate[0x3]; // 0x3bc(0x0c)
	float _durationOfHeal[0x3]; // 0x3c8(0x0c)
	bool _applyBrokenEffect; // 0x3d4(0x01)
	char pad_3D5[0xb]; // 0x3d5(0x0b)
};

// Class DBDCompetence.SpawnEffectsOnAllSurvivorsBaseAddon
// Size: 0x280 (Inherited: 0x278)
struct USpawnEffectsOnAllSurvivorsBaseAddon : UItemAddon {
	char pad_278[0x8]; // 0x278(0x08)
};

// Class DBDCompetence.SimpleSpawnEffectsOnAllSurvivorsAddon
// Size: 0x290 (Inherited: 0x280)
struct USimpleSpawnEffectsOnAllSurvivorsAddon : USpawnEffectsOnAllSurvivorsBaseAddon {
	struct TArray<struct FSimpleSpawnEffectsOnAllSurvivorsAddonParams> _statusEffectsSpawnParams; // 0x280(0x10)
};

// Class DBDCompetence.SingleGateBlockerEffect
// Size: 0x370 (Inherited: 0x320)
struct USingleGateBlockerEffect : UGateBlockerEffect {
	float _distanceThreshold; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
	struct AEscapeDoor* _gate; // 0x328(0x08)
	bool _isInRange; // 0x330(0x01)
	char pad_331[0x3f]; // 0x331(0x3f)
};

// Class DBDCompetence.SmallGame
// Size: 0x3d0 (Inherited: 0x3a8)
struct USmallGame : UPerk {
	float _detectionConeAngle[0x3]; // 0x3a8(0x0c)
	float _detectionConeAngleReductionRate[0x3]; // 0x3b4(0x0c)
	bool _totemDetected; // 0x3c0(0x01)
	char pad_3C1[0xf]; // 0x3c1(0x0f)

	void VFXTotemFound(); // Function DBDCompetence.SmallGame.VFXTotemFound // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void SearchForTotems(); // Function DBDCompetence.SmallGame.SearchForTotems // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_TotemFound(); // Function DBDCompetence.SmallGame.Multicast_TotemFound // (Net|NetReliableNative|Event|NetMulticast|Protected) // @ game+0x2c98470
	float GetDetectionConeAngle(); // Function DBDCompetence.SmallGame.GetDetectionConeAngle // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c981c0
	void Authority_SetTotemDetected(bool value); // Function DBDCompetence.SmallGame.Authority_SetTotemDetected // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x2c98090
};

// Class DBDCompetence.SoleSurvivor
// Size: 0x3d8 (Inherited: 0x3a8)
struct USoleSurvivor : UPerk {
	float _auraHideDistancePerDeadOrDisconnectedSurvivor[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct TArray<struct ACamperPlayer*> _otherSurvivors; // 0x3b8(0x10)
	char pad_3C8[0x10]; // 0x3c8(0x10)

	void Authority_OnSurvivorAdded(struct ACamperPlayer* survivor); // Function DBDCompetence.SoleSurvivor.Authority_OnSurvivorAdded // (Final|Native|Private) // @ game+0x2c97f90
};

// Class DBDCompetence.Solidarity
// Size: 0x3d8 (Inherited: 0x3a8)
struct USolidarity : UPerk {
	bool _allowMedkit; // 0x3a8(0x01)
	char pad_3A9[0x7]; // 0x3a9(0x07)
	struct UChargeableComponent* _healerHPSlot; // 0x3b0(0x08)
	struct UChargeableComponent* _targetHPSlot; // 0x3b8(0x08)
	struct UChargeableInteractionDefinition* _healOtherInteraction; // 0x3c0(0x08)
	char pad_3C8[0x10]; // 0x3c8(0x10)

	void Authority_OnSkillCheckResponse(bool success, bool Bonus, struct ADBDPlayer* Player, bool TriggerLoudNoise, bool hadInput, enum class ESkillCheckCustomType Type, float ChargeChange); // Function DBDCompetence.Solidarity.Authority_OnSkillCheckResponse // (Final|Native|Private) // @ game+0x2c97d70
	void Authority_OnHealthChargeApplied(float individualChargeAmount, float totalChargeAmount, struct AActor* chargeInstigator, bool wasCoop, float DeltaTime); // Function DBDCompetence.Solidarity.Authority_OnHealthChargeApplied // (Final|Native|Private) // @ game+0x2c97b50
};

// Class DBDCompetence.SpiesFromTheShadows
// Size: 0x3b0 (Inherited: 0x3a8)
struct USpiesFromTheShadows : UPerk {
	float _cooldownDurationSecs; // 0x3a8(0x04)
	char pad_3AC[0x4]; // 0x3ac(0x04)

	void StartCooldownIfInRange(struct FVector loudNoiseLocation); // Function DBDCompetence.SpiesFromTheShadows.StartCooldownIfInRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2c985a0
	void Server_TriggerCooldown(); // Function DBDCompetence.SpiesFromTheShadows.Server_TriggerCooldown // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2c98550
};

// Class DBDCompetence.SpineChillPerk
// Size: 0x3b8 (Inherited: 0x3a8)
struct USpineChillPerk : UPerk {
	float _actionSpeed[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class DBDCompetence.SprintBurst
// Size: 0x3c8 (Inherited: 0x3a8)
struct USprintBurst : UPerk {
	float _exhaustionDuration[0x3]; // 0x3a8(0x0c)
	float _sprintDuration; // 0x3b4(0x04)
	struct UActivatableExhaustedEffect* _exhaustedEffect; // 0x3b8(0x08)
	char pad_3C0[0x8]; // 0x3c0(0x08)

	void Authority_OnIsRunningAndMovingChanged(bool IsRunningAndMoving); // Function DBDCompetence.SprintBurst.Authority_OnIsRunningAndMovingChanged // (Final|Native|Private) // @ game+0x2c97ce0
};

// Class DBDCompetence.StatsSystemUtilities
// Size: 0x30 (Inherited: 0x30)
struct UStatsSystemUtilities : UBlueprintFunctionLibrary {

	void InitStatBP(struct FTunableStat theStat, struct TScriptInterface<None> ModifierProvider); // Function DBDCompetence.StatsSystemUtilities.InitStatBP // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2c98300
	float GetStatValueBP(struct FTunableStat theStat); // Function DBDCompetence.StatsSystemUtilities.GetStatValueBP // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2c981f0
};

// Class DBDCompetence.StatusEffectOriginatorSubjectProvider
// Size: 0x48 (Inherited: 0x48)
struct UStatusEffectOriginatorSubjectProvider : UModifierSubjectProvider {
};

// Class DBDCompetence.Surge
// Size: 0x3e8 (Inherited: 0x3a8)
struct USurge : UPerk {
	float _zoneRadius[0x3]; // 0x3a8(0x0c)
	float _instantRegression[0x3]; // 0x3b4(0x0c)
	float _cooldownDuration[0x3]; // 0x3c0(0x0c)
	bool _hasCooldown; // 0x3cc(0x01)
	bool _useTerrorRadiusInsteadOfFixedDistance; // 0x3cd(0x01)
	char pad_3CE[0x1a]; // 0x3ce(0x1a)

	void Client_TriggerEffects(struct TArray<struct AGenerator*> generators); // Function DBDCompetence.Surge.Client_TriggerEffects // (Final|Net|Native|Event|Private|NetClient) // @ game+0x2c98120
};

// Class DBDCompetence.TestAnyActorPairQueryRangeIsTrue
// Size: 0x108 (Inherited: 0x100)
struct UTestAnyActorPairQueryRangeIsTrue : UAnyActorPairQueryRangeIsTrue {
	struct UActorPairQueryEvaluatorComponent* _actorPairQueryEvaluatorComponent; // 0x100(0x08)
};

// Class DBDCompetence.TestCollectable
// Size: 0x498 (Inherited: 0x498)
struct ATestCollectable : ACollectable {
};

// Class DBDCompetence.TestDBDGameState
// Size: 0x788 (Inherited: 0x788)
struct ATestDBDGameState : ADBDGameState {
};

// Class DBDCompetence.TestStatusEffect
// Size: 0x320 (Inherited: 0x320)
struct UTestStatusEffect : UStatusEffect {
};

// Class DBDCompetence.TheMettleOfMan
// Size: 0x3f0 (Inherited: 0x3a8)
struct UTheMettleOfMan : UPerk {
	int32_t _tokenNeededToActivate[0x3]; // 0x3a8(0x0c)
	float _revealOutsideRange[0x3]; // 0x3b4(0x0c)
	bool _mustBeInjured; // 0x3c0(0x01)
	char pad_3C1[0x3]; // 0x3c1(0x03)
	int32_t _numTokenSoFar; // 0x3c4(0x04)
	enum class ETheMettleOfManPhase _currentPhase; // 0x3c8(0x01)
	char pad_3C9[0xf]; // 0x3c9(0x0f)
	struct UStatusEffect* _revealToKillerEffect; // 0x3d8(0x08)
	char pad_3E0[0x10]; // 0x3e0(0x10)

	void OnRep_CurrentPhase(); // Function DBDCompetence.TheMettleOfMan.OnRep_CurrentPhase // (Final|Native|Private) // @ game+0x2c984f0
};

// Class DBDCompetence.ThrillingTremors
// Size: 0x408 (Inherited: 0x3a8)
struct UThrillingTremors : UPerk {
	int32_t _cooldownByLevel[0x3]; // 0x3a8(0x0c)
	float _durationByLevel[0x3]; // 0x3b4(0x0c)
	bool _disableWhenSurvivorPutDownOrUnhooked; // 0x3c0(0x01)
	char pad_3C1[0x3]; // 0x3c1(0x03)
	struct FLinearColor _generatorAuraColorForKiller; // 0x3c4(0x10)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct TArray<struct AGenerator*> _blockedGenerators; // 0x3d8(0x10)
	struct TArray<struct AGenerator*> _revealedGenerators; // 0x3e8(0x10)
	char pad_3F8[0x10]; // 0x3f8(0x10)

	void OnRep_BlockedGenerators(); // Function DBDCompetence.ThrillingTremors.OnRep_BlockedGenerators // (Final|Native|Private) // @ game+0x2c984d0
};

// Class DBDCompetence.TimedObliviousEffect
// Size: 0x320 (Inherited: 0x320)
struct UTimedObliviousEffect : UObliviousEffect {
};

// Class DBDCompetence.WeddingRing
// Size: 0x280 (Inherited: 0x278)
struct UWeddingRing : UItemAddon {
	char pad_278[0x8]; // 0x278(0x08)
};

// Class DBDCompetence.YamaokaFamilyCrest
// Size: 0x2b0 (Inherited: 0x278)
struct UYamaokaFamilyCrest : UItemAddon {
	float _revealDuration; // 0x278(0x04)
	float _revealRange; // 0x27c(0x04)
	struct TArray<struct ACamperPlayer*> _survivorsToReveal; // 0x280(0x10)
	char _addonActivationCount; // 0x290(0x01)
	char pad_291[0x1f]; // 0x291(0x1f)

	void RevealSurvivor(struct ACamperPlayer* survivorToReveal); // Function DBDCompetence.YamaokaFamilyCrest.RevealSurvivor // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRep_AddonActivationCount(); // Function DBDCompetence.YamaokaFamilyCrest.OnRep_AddonActivationCount // (Final|Native|Private) // @ game+0x2c984b0
};

// Class DBDCompetence.ZanshinTactics
// Size: 0x3b8 (Inherited: 0x3a8)
struct UZanshinTactics : UPerk {
	float _cooldownDuration[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

