// Enum DBDCompetence.EImposeEffectTo
enum class EImposeEffectTo : uint8 {
	EventInstigator,
	EventTarget,
	AddonOwner,
	AllSurvivors,
	EImposeEffectTo_MAX,
};

// Enum DBDCompetence.ESecondWindState
enum class ESecondWindState : uint8 {
	Loading,
	Locked,
	Available,
	InUse,
	ESecondWindState_MAX,
};

// Enum DBDCompetence.ETheMettleOfManPhase
enum class ETheMettleOfManPhase : uint8 {
	Uninitialized,
	GainingTokens,
	CancelNextAttack,
	RevealWhenHealthy,
	RevealedToKiller,
	ETheMettleOfManPhase_MAX,
};

// ScriptStruct DBDCompetence.WindowBlockableList
// Size: 0x10 (Inherited: 0x00)
struct FWindowBlockableList {
	struct TArray<struct UBlockableComponent*> Blockables; // 0x00(0x10)
};

// ScriptStruct DBDCompetence.SimpleSpawnEffectsOnAllSurvivorsAddonParams
// Size: 0x10 (Inherited: 0x00)
struct FSimpleSpawnEffectsOnAllSurvivorsAddonParams {
	struct FName _statusEffectId; // 0x00(0x0c)
	float _customParam; // 0x0c(0x04)
};

