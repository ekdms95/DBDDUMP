// Class DBDGameplayPresenter.SurvivorStatusComponent
// Size: 0xf0 (Inherited: 0xb8)
struct USurvivorStatusComponent : UActorComponent {
	struct ACamperPlayer* _survivor; // 0xb8(0x08)
	char pad_C0[0x30]; // 0xc0(0x30)

	void OnValidatedInteractionStarted(); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnValidatedInteractionStarted // (Final|Native|Private) // @ game+0x2cc8260
	void OnValidatedInteractionEnded(); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnValidatedInteractionEnded // (Final|Native|Private) // @ game+0x2cc8260
	void OnSuvivorDamaged(enum class ECamperDamageState oldDamageState, enum class ECamperDamageState newDamageState); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnSuvivorDamaged // (Final|Native|Private) // @ game+0x2cc8280
	void OnSurivorStatusChange(); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnSurivorStatusChange // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnRunningAndMovementChanged(bool IsRunningAndMoving); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnRunningAndMovementChanged // (Final|Native|Private) // @ game+0x2cc81d0
	void OnPlayerImmobilizeStateChanged(enum class ECamperImmobilizeState oldImmobilizeState, enum class ECamperImmobilizeState newImmobilizeState); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnPlayerImmobilizeStateChanged // (Final|Native|Private) // @ game+0x2cc8280
	void OnHookedStateChanged(); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnHookedStateChanged // (Final|Native|Private) // @ game+0x2cc8260
	void OnGuidedStateChanged(); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnGuidedStateChanged // (Final|Native|Private) // @ game+0x2cc8260
	void OnCrouchChanged(bool isCrouched); // Function DBDGameplayPresenter.SurvivorStatusComponent.OnCrouchChanged // (Final|Native|Private) // @ game+0x2cc81d0
	bool IsSleeping(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsSleeping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc81a0
	bool IsRunning(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsRunning // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8170
	bool IsInjured(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsInjured // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8140
	bool IsHooked(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsHooked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8110
	bool IsHiding(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsHiding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc80e0
	bool IsHealing(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsHealing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc80b0
	bool IsHarpooned(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsHarpooned // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8080
	bool IsGettingStrangled(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsGettingStrangled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8050
	bool IsGettingSacrificed(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsGettingSacrificed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc8020
	bool IsDying(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsDying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc7ff0
	bool IsDead(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsDead // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc7fc0
	bool IsCrouching(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsCrouching // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc7f90
	bool IsCaptured(); // Function DBDGameplayPresenter.SurvivorStatusComponent.IsCaptured // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc7f60
	void GetMovementSpeed(float currentMovementSpeed, float percentMovementSpeed, float maximumMovementSpeed); // Function DBDGameplayPresenter.SurvivorStatusComponent.GetMovementSpeed // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc7e20
};

