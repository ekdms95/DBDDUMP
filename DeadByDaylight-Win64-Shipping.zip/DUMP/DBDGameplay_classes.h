// Class DBDGameplay.ActorPairQueryEvaluatorUtilities
// Size: 0x30 (Inherited: 0x30)
struct UActorPairQueryEvaluatorUtilities : UBlueprintFunctionLibrary {
};

// Class DBDGameplay.AimableComponent
// Size: 0x110 (Inherited: 0xb8)
struct UAimableComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TArray<struct AActor*> _occlusionIgnoredActors; // 0xc0(0x10)
	float _maxAimDistance; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct UAimDirectionProvider* _aimDirectionProvider; // 0xd8(0x08)
	bool _useOcclusion; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	float _aimPointLerpFactor; // 0xe4(0x04)
	struct TArray<struct UAimPointProcessor*> _preOcclusionAimPointProcessors; // 0xe8(0x10)
	char pad_F8[0x18]; // 0xf8(0x18)

	void SetProcessors(struct TArray<struct UAimPointProcessor*> processors); // Function DBDGameplay.AimableComponent.SetProcessors // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf7d0
	void SetOcclusionIgnoredActors(struct TArray<struct AActor*> ignoredActors); // Function DBDGameplay.AimableComponent.SetOcclusionIgnoredActors // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2cbf720
	void SetMaxAimDistance(float maxAimDistance); // Function DBDGameplay.AimableComponent.SetMaxAimDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf620
};

// Class DBDGameplay.AimDirectionProvider
// Size: 0x30 (Inherited: 0x30)
struct UAimDirectionProvider : UObject {
};

// Class DBDGameplay.AimPointProcessor
// Size: 0xb8 (Inherited: 0xb8)
struct UAimPointProcessor : UActorComponent {
};

// Class DBDGameplay.AimPointPerlinNoise
// Size: 0xe8 (Inherited: 0xb8)
struct UAimPointPerlinNoise : UAimPointProcessor {
	char pad_B8[0x4]; // 0xb8(0x04)
	float _baseInaccuracyNoisePersistence; // 0xbc(0x04)
	int32_t _baseInaccuracyNoiseOctaveCount; // 0xc0(0x04)
	float _baseInaccuracyNoiseAmplitude; // 0xc4(0x04)
	char pad_C8[0x4]; // 0xc8(0x04)
	float _baseInaccuracyNoiseFrequency; // 0xcc(0x04)
	char pad_D0[0x4]; // 0xd0(0x04)
	float _timeOffset; // 0xd4(0x04)
	char pad_D8[0x10]; // 0xd8(0x10)

	void SetNoiseFrequencyMultiplier(float Multiplier); // Function DBDGameplay.AimPointPerlinNoise.SetNoiseFrequencyMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x2c98010
	void SetNoiseAmplitudeMultiplier(float Multiplier); // Function DBDGameplay.AimPointPerlinNoise.SetNoiseAmplitudeMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf6a0
	void SetBaseInaccuracyNoisePersistence(float noisePersistence); // Function DBDGameplay.AimPointPerlinNoise.SetBaseInaccuracyNoisePersistence // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf520
	void SetBaseInaccuracyNoiseOctaveCount(int32_t octaveCount); // Function DBDGameplay.AimPointPerlinNoise.SetBaseInaccuracyNoiseOctaveCount // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf4a0
	void SetBaseInaccuracyNoiseFrequency(float Frequency); // Function DBDGameplay.AimPointPerlinNoise.SetBaseInaccuracyNoiseFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf420
	void SetBaseInaccuracyNoiseAmplitude(float Amplitude); // Function DBDGameplay.AimPointPerlinNoise.SetBaseInaccuracyNoiseAmplitude // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf3a0
};

// Class DBDGameplay.AuraOverriderComponent
// Size: 0x108 (Inherited: 0xb8)
struct UAuraOverriderComponent : UActorComponent {
	char pad_B8[0x50]; // 0xb8(0x50)

	void ResetAura(struct AActor* Actor); // Function DBDGameplay.AuraOverriderComponent.ResetAura // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf160
	void ForceShowAura(struct AActor* Actor, struct FLinearColor Color, bool isAlwaysVisible, float minimumOutlineDistance); // Function DBDGameplay.AuraOverriderComponent.ForceShowAura // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2cbeb10
};

// Class DBDGameplay.BaseCamperCollectable
// Size: 0x4e0 (Inherited: 0x498)
struct ABaseCamperCollectable : ACollectable {
	struct USpherePlayerOverlapComponent* _interactable; // 0x498(0x08)
	struct UInteractor* _collectableInteractor; // 0x4a0(0x08)
	struct UDropItemInteraction* _dropInteraction; // 0x4a8(0x08)
	struct UCollectItemInteraction* _collectInteraction; // 0x4b0(0x08)
	struct USphereComponent* _infectablePrimitive; // 0x4b8(0x08)
	struct UDBDOutlineComponent* _outlineComponent; // 0x4c0(0x08)
	struct UMaterialHelper* _materialHelper; // 0x4c8(0x08)
	struct USurvivorCollectableOutlineUpdateStrategy* _survivorCollectableOutlineUpdateStrategy; // 0x4d0(0x08)
	char pad_4D8[0x8]; // 0x4d8(0x08)
};

// Class DBDGameplay.FlashlightableLightingStrategy
// Size: 0x30 (Inherited: 0x30)
struct UFlashlightableLightingStrategy : UObject {
};

// Class DBDGameplay.FlashlightablePointsLightingStrategy
// Size: 0x40 (Inherited: 0x30)
struct UFlashlightablePointsLightingStrategy : UFlashlightableLightingStrategy {
	struct UPointsProvider* _pointsProvider; // 0x30(0x08)
	float _impactPointDistanceError; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class DBDGameplay.BlindFlashlightableLightingStrategy
// Size: 0x40 (Inherited: 0x40)
struct UBlindFlashlightableLightingStrategy : UFlashlightablePointsLightingStrategy {
};

// Class DBDGameplay.FlashlightTargetFXComponent
// Size: 0x100 (Inherited: 0xb8)
struct UFlashlightTargetFXComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
	bool _modifiesBeamAngle; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct UFlashlightableComponent* _flashlightable; // 0xf0(0x08)
	char pad_F8[0x8]; // 0xf8(0x08)

	void OnIsLitChanged(bool IsLit); // Function DBDGameplay.FlashlightTargetFXComponent.OnIsLitChanged // (Final|Native|Private) // @ game+0x2cbeff0
};

// Class DBDGameplay.BlindFlashlightTargetFXComponent
// Size: 0x128 (Inherited: 0x100)
struct UBlindFlashlightTargetFXComponent : UFlashlightTargetFXComponent {
	char pad_100[0x28]; // 0x100(0x28)
};

// Class DBDGameplay.CollectableComponentUtilities
// Size: 0x30 (Inherited: 0x30)
struct UCollectableComponentUtilities : UBlueprintFunctionLibrary {

	struct ADBDPlayer* GetCollector(struct UActorComponent* Component); // Function DBDGameplay.CollectableComponentUtilities.GetCollector // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2cbecb0
};

// Class DBDGameplay.DBDCharacterPusherComponent
// Size: 0x180 (Inherited: 0x170)
struct UDBDCharacterPusherComponent : UCharacterPusherComponent {
	char pad_170[0x10]; // 0x170(0x10)
};

// Class DBDGameplay.DebugIndicator
// Size: 0x250 (Inherited: 0x230)
struct ADebugIndicator : AActor {
	struct UStaticMeshComponent* _staticMeshComponent; // 0x230(0x08)
	struct UDBDOutlineComponent* _outlineComponent; // 0x238(0x08)
	char pad_240[0x10]; // 0x240(0x10)

	void SetVisible(bool visible); // Function DBDGameplay.DebugIndicator.SetVisible // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf8b0
	void SetColor(struct FLinearColor Color); // Function DBDGameplay.DebugIndicator.SetColor // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2cbf5a0
};

// Class DBDGameplay.EtherealComponent
// Size: 0xe8 (Inherited: 0xb8)
struct UEtherealComponent : UActorComponent {
	char pad_B8[0x28]; // 0xb8(0x28)
	bool _isEthereal; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)

	void Server_SetIsEthereal(float Timestamp, bool Ethereal); // Function DBDGameplay.EtherealComponent.Server_SetIsEthereal // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2cbf2a0
	void OnRep_OnIsEtherealChanged(); // Function DBDGameplay.EtherealComponent.OnRep_OnIsEtherealChanged // (Final|Native|Private) // @ game+0x2cbf0c0
};

// Class DBDGameplay.RangeToActorsTrackerStrategy
// Size: 0x70 (Inherited: 0x30)
struct URangeToActorsTrackerStrategy : UObject {
	struct FDBDTunableRowHandle _range; // 0x30(0x28)
	char pad_58[0x18]; // 0x58(0x18)

	void OnInRangeToTrackedActorsChanged(bool InRange); // Function DBDGameplay.RangeToActorsTrackerStrategy.OnInRangeToTrackedActorsChanged // (Final|Native|Private) // @ game+0x2cc3ee0
};

// Class DBDGameplay.ExitGateSwitchesRangeTrackerStrategy
// Size: 0x70 (Inherited: 0x70)
struct UExitGateSwitchesRangeTrackerStrategy : URangeToActorsTrackerStrategy {
};

// Class DBDGameplay.FadeComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UFadeComponent : UActorComponent {
	struct FMulticastInlineDelegate OnFadePercentChanged; // 0xb8(0x10)
	float _fadeDuration; // 0xc8(0x04)
	char pad_CC[0xc]; // 0xcc(0x0c)

	float GetFadePercent(); // Function DBDGameplay.FadeComponent.GetFadePercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbedf0
};

// Class DBDGameplay.FlashlightableComponent
// Size: 0x140 (Inherited: 0xb8)
struct UFlashlightableComponent : UActorComponent {
	struct FMulticastInlineDelegate OnFlashlightAddedEvent; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnFlashlightRemovedEvent; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnFlashlightLitChangedEvent; // 0xd8(0x10)
	struct UFlashlightableLightingStrategy* _lightingStrategy; // 0xe8(0x08)
	struct TSet<struct UFlashlightComponent*> _flashlights; // 0xf0(0x50)

	void OnFlashlightLitChangedEvent__DelegateSignature(bool IsLit); // DelegateFunction DBDGameplay.FlashlightableComponent.OnFlashlightLitChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnFlashlightAddedRemovedEvent__DelegateSignature(struct UFlashlightComponent* Flashlight); // DelegateFunction DBDGameplay.FlashlightableComponent.OnFlashlightAddedRemovedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	bool IsLit(); // Function DBDGameplay.FlashlightableComponent.IsLit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbee50
};

// Class DBDGameplay.FlashlightComponent
// Size: 0x200 (Inherited: 0xb8)
struct UFlashlightComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct FMulticastInlineDelegate OnFlashlightTurnedOn; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnFlashlightTurnedOff; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnFlashlightablesUpdated; // 0xe0(0x10)
	struct FDBDTunableRowHandle _baseBlindnessDuration; // 0xf0(0x28)
	float _baseAccuracy; // 0x118(0x04)
	float _lagDuration; // 0x11c(0x04)
	struct TSet<struct UFlashlightableComponent*> _flashlightables; // 0x120(0x50)
	struct TSet<struct UFlashlightableComponent*> _autonomousLitFlashlightables; // 0x170(0x50)
	struct TArray<struct UFlashlightableComponent*> _replicatedLitFlashlightables; // 0x1c0(0x10)
	bool _isOwnerLagging; // 0x1d0(0x01)
	char pad_1D1[0x2f]; // 0x1d1(0x2f)

	void TurnOn(); // Function DBDGameplay.FlashlightComponent.TurnOn // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf960
	void TurnOff(); // Function DBDGameplay.FlashlightComponent.TurnOff // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf940
	void Server_SetAndUpdateAutonomousLitFlashlightables(struct TArray<struct UFlashlightableComponent*> newLitFlashlightables); // Function DBDGameplay.FlashlightComponent.Server_SetAndUpdateAutonomousLitFlashlightables // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x2cbf1e0
	void OnRep_ReplicatedLitFlashlightables(); // Function DBDGameplay.FlashlightComponent.OnRep_ReplicatedLitFlashlightables // (Final|Native|Private) // @ game+0x2cbf0e0
	void OnRep_IsOwnerLagging(); // Function DBDGameplay.FlashlightComponent.OnRep_IsOwnerLagging // (Final|Native|Private) // @ game+0x2cbf0a0
	void OnFlashlightEvent__DelegateSignature(); // DelegateFunction DBDGameplay.FlashlightComponent.OnFlashlightEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	bool IsOn(); // Function DBDGameplay.FlashlightComponent.IsOn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbee80
	float GetEffectiveTimeToBlindModifier(); // Function DBDGameplay.FlashlightComponent.GetEffectiveTimeToBlindModifier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbedc0
	float GetEffectiveBlindnessDuration(); // Function DBDGameplay.FlashlightComponent.GetEffectiveBlindnessDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbed30
};

// Class DBDGameplay.FlashlightConeComponent
// Size: 0x148 (Inherited: 0xb8)
struct UFlashlightConeComponent : UActorComponent {
	struct FVector AIAimBeamLocationOffset; // 0xb8(0x0c)
	struct FRotator AIAimBeamRotationOffset; // 0xc4(0x0c)
	struct USceneComponent* _flashlightBottom; // 0xd0(0x08)
	struct FDBDTunableRowHandle _baseBeamAngle; // 0xd8(0x28)
	struct FDBDTunableRowHandle _baseBeamLength; // 0x100(0x28)
	struct TWeakObjectPtr<struct AActor> _cacheCollidingActor; // 0x128(0x08)
	char pad_130[0x18]; // 0x130(0x18)

	float GetOcclusionDistance(); // Function DBDGameplay.FlashlightConeComponent.GetOcclusionDistance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbee20
	float GetEffectiveConeLength(); // Function DBDGameplay.FlashlightConeComponent.GetEffectiveConeLength // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbed90
	float GetEffectiveConeHalfAngle(); // Function DBDGameplay.FlashlightConeComponent.GetEffectiveConeHalfAngle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbed60
};

// Class DBDGameplay.FlashlightFXComponent
// Size: 0x258 (Inherited: 0xb8)
struct UFlashlightFXComponent : UActorComponent {
	struct FMulticastInlineDelegate OnFlashEvent; // 0xb8(0x10)
	struct USceneComponent* _tip; // 0xc8(0x08)
	struct UStaticMeshComponent* _centerGlowMesh; // 0xd0(0x08)
	struct USplineMeshComponent* _beamMesh; // 0xd8(0x08)
	float _minimumOcclusionDistanceForSpotlight; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct UCurveFloat* _flashEffectIntensityCurve; // 0xe8(0x08)
	float _flashEffectDuration; // 0xf0(0x04)
	float _spotLightHalfAngle; // 0xf4(0x04)
	float _spotLightIntensity; // 0xf8(0x04)
	float _visualReworkSpotLightIntensity; // 0xfc(0x04)
	float _beamBlindingHalfAngle; // 0x100(0x04)
	float _beamFlashHalfAngle; // 0x104(0x04)
	float _beamBlindingRatioInterpSpeedWithTarget; // 0x108(0x04)
	float _beamBlindingRatioInterpSpeedWithoutTarget; // 0x10c(0x04)
	bool _resizeConeLength; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float _centerGlowWidthScaleWithoutBlindTarget; // 0x114(0x04)
	float _centerGlowWidthScaleWithBlindTarget; // 0x118(0x04)
	float _centerGlowWidthScaleDuringFlash; // 0x11c(0x04)
	float _centerGlowShrinkDistance; // 0x120(0x04)
	float _centerGlowLengthMaxScale; // 0x124(0x04)
	struct FAkObservedPlayerSoundLoop _aimedAtSoundLoop; // 0x128(0x40)
	struct UFlashlightTargetFXComponent* _currentBeamModifyingTarget; // 0x168(0x08)
	struct TSet<struct UFlashlightTargetFXComponent*> _targets; // 0x170(0x50)
	char pad_1C0[0x98]; // 0x1c0(0x98)

	void UpdateFXTargets(); // Function DBDGameplay.FlashlightFXComponent.UpdateFXTargets // (Final|Native|Private) // @ game+0x2cbf980
	void UpdateConeEvent(float Length, float halfAngle); // Function DBDGameplay.FlashlightFXComponent.UpdateConeEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void PostUpdateEvent(); // Function DBDGameplay.FlashlightFXComponent.PostUpdateEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTurnedOn(); // Function DBDGameplay.FlashlightFXComponent.OnTurnedOn // (Final|Native|Private) // @ game+0x2cbf140
	void OnTurnedOff(); // Function DBDGameplay.FlashlightFXComponent.OnTurnedOff // (Final|Native|Private) // @ game+0x2cbf120
	void OnStopEvent(); // Function DBDGameplay.FlashlightFXComponent.OnStopEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnStartEvent(); // Function DBDGameplay.FlashlightFXComponent.OnStartEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnFlashEvent__DelegateSignature(); // DelegateFunction DBDGameplay.FlashlightFXComponent.OnFlashEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnDroppedEvent(); // Function DBDGameplay.FlashlightFXComponent.OnDroppedEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnCollectorLocallyObservedChangedEvent(bool IsLocallyObserved); // Function DBDGameplay.FlashlightFXComponent.OnCollectorLocallyObservedChangedEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnCollectedEvent(struct ADBDPlayer* collector); // Function DBDGameplay.FlashlightFXComponent.OnCollectedEvent // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	float GetBlindingSuccessRatio(); // Function DBDGameplay.FlashlightFXComponent.GetBlindingSuccessRatio // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cbec80
};

// Class DBDGameplay.FlashlightUtilities
// Size: 0x30 (Inherited: 0x30)
struct UFlashlightUtilities : UObject {
};

// Class DBDGameplay.HooksWithSurvivorRangeTrackerStrategy
// Size: 0xd8 (Inherited: 0x70)
struct UHooksWithSurvivorRangeTrackerStrategy : URangeToActorsTrackerStrategy {
	char pad_70[0x68]; // 0x70(0x68)
};

// Class DBDGameplay.InteractionStarterComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UInteractionStarterComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct UInteractionDefinition* _interaction; // 0xc0(0x08)
	bool _shouldStartInteraction; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)

	void OnRep_ShouldStartInteraction(); // Function DBDGameplay.InteractionStarterComponent.OnRep_ShouldStartInteraction // (Final|Native|Private) // @ game+0x2cbf100
	void OnInteractionStarted(); // Function DBDGameplay.InteractionStarterComponent.OnInteractionStarted // (Final|Native|Private) // @ game+0x2cbefd0
};

// Class DBDGameplay.KillerFlashlightSFXComponent
// Size: 0x158 (Inherited: 0xb8)
struct UKillerFlashlightSFXComponent : UActorComponent {
	struct FAkObservedPlayerSoundLoop _targetSoundLoop; // 0xb8(0x40)
	struct TArray<struct UFlashlightTargetFXComponent*> _flashlightTargets; // 0xf8(0x10)
	char pad_108[0x50]; // 0x108(0x50)
};

// Class DBDGameplay.LightBurnable
// Size: 0x100 (Inherited: 0xb8)
struct ULightBurnable : UActorComponent {
	struct FMulticastInlineDelegate OnBurnChargeCompleteEvent; // 0xb8(0x10)
	char pad_C8[0x18]; // 0xc8(0x18)
	struct UChargeableComponent* _chargeable; // 0xe0(0x08)
	struct UFlashlightableComponent* _flashlightable; // 0xe8(0x08)
	struct UFirecrackerEffectHandlerComponent* _firecrackerEffectHandler; // 0xf0(0x08)
	bool _isBurning; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)

	void OnRep_IsBurning(); // Function DBDGameplay.LightBurnable.OnRep_IsBurning // (Final|Native|Private) // @ game+0x2cbf080
	void OnChargeableCompleteEvent(bool COMPLETED, struct TArray<struct AActor*> instigatorsForCompletion); // Function DBDGameplay.LightBurnable.OnChargeableCompleteEvent // (Final|Native|Protected|HasOutParms) // @ game+0x2cbeed0
	void OnBurnChargeEmpty(); // Function DBDGameplay.LightBurnable.OnBurnChargeEmpty // (Native|Protected) // @ game+0x2cbeeb0
	void OnBurnChargeCompleteEvent__DelegateSignature(struct TArray<struct AActor*> instigatorsForCompletion); // DelegateFunction DBDGameplay.LightBurnable.OnBurnChargeCompleteEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	void Authority_OnFlashlightAddedRemoved(struct UFlashlightComponent* Flashlight); // Function DBDGameplay.LightBurnable.Authority_OnFlashlightAddedRemoved // (Final|Native|Protected) // @ game+0x2cbea90
	void Authority_OnFirecrackerInRangeBegin(struct FFirecrackerEffectData effectData); // Function DBDGameplay.LightBurnable.Authority_OnFirecrackerInRangeBegin // (Native|Protected|HasOutParms) // @ game+0x2cbe9f0
};

// Class DBDGameplay.LightBurnableFlashlightTargetFXComponent
// Size: 0x110 (Inherited: 0x100)
struct ULightBurnableFlashlightTargetFXComponent : UFlashlightTargetFXComponent {
	struct ULightBurnable* _burnable; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class DBDGameplay.Medkit
// Size: 0x520 (Inherited: 0x4e0)
struct AMedkit : ABaseCamperCollectable {
	struct UAkComponent* _akComponent; // 0x4e0(0x08)
	struct UChargerComponent* _charger; // 0x4e8(0x08)
	struct UParticleSystem* _dustRingTemplate; // 0x4f0(0x08)
	struct UAkAudioEvent* _medkitGetAkEvent; // 0x4f8(0x08)
	struct UAkAudioEvent* _medkitDropAkEvent; // 0x500(0x08)
	struct UAkAudioBank* _medkitBank; // 0x508(0x08)
	float _healOtherChargeMultiplier; // 0x510(0x04)
	char pad_514[0xc]; // 0x514(0x0c)

	void UseCharge(float Seconds); // Function DBDGameplay.Medkit.UseCharge // (Final|Native|Public|BlueprintCallable) // @ game+0x2cc4b40
	void OnMedkitHealedCamper(struct ADBDPlayer* healedPlayer); // Function DBDGameplay.Medkit.OnMedkitHealedCamper // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2cc3fb0
	bool HasCharge(); // Function DBDGameplay.Medkit.HasCharge // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc2fb0
	float GetChargeMultiplier(); // Function DBDGameplay.Medkit.GetChargeMultiplier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc2f50
	void Authority_OnChargeStateChange(bool Empty); // Function DBDGameplay.Medkit.Authority_OnChargeStateChange // (Final|Native|Protected) // @ game+0x2cc2ec0
	void Authority_OnAnyOngoingInteractionChanged(bool IsInteracting); // Function DBDGameplay.Medkit.Authority_OnAnyOngoingInteractionChanged // (Final|Native|Protected) // @ game+0x2cc2e30
	void Authority_ConsumeIfNotInteracting(); // Function DBDGameplay.Medkit.Authority_ConsumeIfNotInteracting // (Final|Native|Protected) // @ game+0x2cc2e10
};

// Class DBDGameplay.PointsProvider
// Size: 0x30 (Inherited: 0x30)
struct UPointsProvider : UObject {
};

// Class DBDGameplay.MeshSocketPointsProvider
// Size: 0x78 (Inherited: 0x30)
struct UMeshSocketPointsProvider : UPointsProvider {
	struct FComponentReference _meshReference; // 0x30(0x30)
	struct UMeshComponent* _mesh; // 0x60(0x08)
	struct TArray<struct FName> _sockets; // 0x68(0x10)
};

// Class DBDGameplay.PlayerCameraAimDirectionProvider
// Size: 0x30 (Inherited: 0x30)
struct UPlayerCameraAimDirectionProvider : UAimDirectionProvider {
};

// Class DBDGameplay.PlayerInteractionListenerComponent
// Size: 0x108 (Inherited: 0xb8)
struct UPlayerInteractionListenerComponent : UActorComponent {
	char pad_B8[0x50]; // 0xb8(0x50)

	void UnlistenToInteractionStart(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic); // Function DBDGameplay.PlayerInteractionListenerComponent.UnlistenToInteractionStart // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2cc4a60
	void UnlistenToInteractionEnd(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic); // Function DBDGameplay.PlayerInteractionListenerComponent.UnlistenToInteractionEnd // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2cc4980
	void OnActorDestroyed(struct AActor* DestroyedActor); // Function DBDGameplay.PlayerInteractionListenerComponent.OnActorDestroyed // (Final|Native|Private) // @ game+0x2cc3be0
	void ListenToInteractionStart(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic, struct FDelegate interactionDelegate); // Function DBDGameplay.PlayerInteractionListenerComponent.ListenToInteractionStart // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2cc3140
	void ListenToInteractionEnd(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic, struct FDelegate interactionDelegate); // Function DBDGameplay.PlayerInteractionListenerComponent.ListenToInteractionEnd // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2cc2fe0
	void InteractionMulticastDelegate__DelegateSignature(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic); // DelegateFunction DBDGameplay.PlayerInteractionListenerComponent.InteractionMulticastDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void InteractionDelegate__DelegateSignature(struct ADBDPlayer* Player, struct FGameplayTag interactionSemantic); // DelegateFunction DBDGameplay.PlayerInteractionListenerComponent.InteractionDelegate__DelegateSignature // (Public|Delegate) // @ game+0x3873200
};

// Class DBDGameplay.PlayerLightBurnable
// Size: 0x100 (Inherited: 0x100)
struct UPlayerLightBurnable : ULightBurnable {
};

// Class DBDGameplay.PlayerMovementUtilities
// Size: 0x30 (Inherited: 0x30)
struct UPlayerMovementUtilities : UBlueprintFunctionLibrary {

	void Local_SetGamepadYawCurve(struct ADBDPlayer* Player, struct UCurveFloat* Curve); // Function DBDGameplay.PlayerMovementUtilities.Local_SetGamepadYawCurve // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3b10
	void Local_SetGamepadPitchCurve(struct ADBDPlayer* Player, struct UCurveFloat* Curve); // Function DBDGameplay.PlayerMovementUtilities.Local_SetGamepadPitchCurve // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3a60
	void Local_ResetRotationScale(struct ADBDPlayer* Player, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ResetRotationScale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc39a0
	void Local_ResetGamepadLookCurves(struct ADBDPlayer* Player); // Function DBDGameplay.PlayerMovementUtilities.Local_ResetGamepadLookCurves // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3930
	void Local_ApplyYawScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyYawScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3840
	void Local_ApplyRotationScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyRotationScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3750
	void Local_ApplyPitchScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyPitchScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3660
	void Local_ApplyMouseYawScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyMouseYawScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3570
	void Local_ApplyMousePitchScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyMousePitchScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3480
	void Local_ApplyGamepadYawScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyGamepadYawScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc3390
	void Local_ApplyGamepadPitchScaleMultiplier(struct ADBDPlayer* Player, float Multiplier, float adjustmentTime); // Function DBDGameplay.PlayerMovementUtilities.Local_ApplyGamepadPitchScaleMultiplier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2cc32a0
};

// Class DBDGameplay.PositionLagCompensationComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UPositionLagCompensationComponent : UActorComponent {
	float _maxExtrapolationDurationInSeconds; // 0xb8(0x04)
	float _maxInterpolationToServerMoveInSeconds; // 0xbc(0x04)
};

// Class DBDGameplay.PowerChargeComponent
// Size: 0x160 (Inherited: 0xb8)
struct UPowerChargeComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPowerChargeChanged; // 0xb8(0x10)
	char pad_C8[0x58]; // 0xc8(0x58)
	struct FSpeedBasedNetSyncedValue _currentCharge; // 0x120(0x38)
	char pad_158[0x4]; // 0x158(0x04)
	bool _forceFullCharge; // 0x15c(0x01)
	char pad_15D[0x3]; // 0x15d(0x03)

	void OnRep_CurrentCharge(); // Function DBDGameplay.PowerChargeComponent.OnRep_CurrentCharge // (Final|Native|Private) // @ game+0x2cc42a0
	void OnCurrentChargeChanged(float value); // Function DBDGameplay.PowerChargeComponent.OnCurrentChargeChanged // (Final|Native|Private) // @ game+0x2cc3d60
};

// Class DBDGameplay.PowerChargePresentationItemProgressComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UPowerChargePresentationItemProgressComponent : UPresentationItemProgressComponent {
	struct UPowerChargeComponent* _powerChargeComponent; // 0xb8(0x08)
	struct UPowerToggleComponent* _powerToggleComponent; // 0xc0(0x08)
	float _chargeReadyThreshold; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class DBDGameplay.PowerToggleComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UPowerToggleComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	bool _isInPower; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	void OnRep_IsInPower(); // Function DBDGameplay.PowerToggleComponent.OnRep_IsInPower // (Final|Native|Private|Const) // @ game+0x2cc42c0
};

// Class DBDGameplay.RangeToActorsTrackerComponent
// Size: 0xc8 (Inherited: 0xb8)
struct URangeToActorsTrackerComponent : UActorComponent {
	struct TArray<struct URangeToActorsTrackerStrategy*> _rangeTrackers; // 0xb8(0x10)

	void OnLevelReadyToPlay(); // Function DBDGameplay.RangeToActorsTrackerComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x2cc3f90
};

// Class DBDGameplay.RangeToActorsTrackerDefaultStrategy
// Size: 0x78 (Inherited: 0x70)
struct URangeToActorsTrackerDefaultStrategy : URangeToActorsTrackerStrategy {
	struct AActor* _actorClass; // 0x70(0x08)
};

// Class DBDGameplay.SceneComponentPointProvider
// Size: 0x68 (Inherited: 0x30)
struct USceneComponentPointProvider : UPointsProvider {
	struct FComponentReference _sceneReference; // 0x30(0x30)
	struct USceneComponent* _sceneComponent; // 0x60(0x08)
};

// Class DBDGameplay.StruggleComponent
// Size: 0x180 (Inherited: 0xb8)
struct UStruggleComponent : UActorComponent {
	char pad_B8[0x58]; // 0xb8(0x58)
	int32_t _skillCheckCount; // 0x110(0x04)
	char pad_114[0x6c]; // 0x114(0x6c)

	void OnSkillCheckEnd(bool hadInput, bool success, bool Bonus, enum class ESkillCheckCustomType Type); // Function DBDGameplay.StruggleComponent.OnSkillCheckEnd // (Final|Native|Private) // @ game+0x2cc42e0
	void Local_TryActivateSkillCheck(); // Function DBDGameplay.StruggleComponent.Local_TryActivateSkillCheck // (Final|Native|Private) // @ game+0x2cc3bc0
};

// Class DBDGameplay.SurvivorAimStanceCameraDirectionProvider
// Size: 0x30 (Inherited: 0x30)
struct USurvivorAimStanceCameraDirectionProvider : UAimDirectionProvider {
};

// Class DBDGameplay.SurvivorAimStateComponent
// Size: 0x118 (Inherited: 0xb8)
struct USurvivorAimStateComponent : UActorComponent {
	char pad_B8[0x10]; // 0xb8(0x10)
	struct ACollectable* _aimableCollectable; // 0xc8(0x08)
	char pad_D0[0x48]; // 0xd0(0x48)
};

// Class DBDGameplay.TracingConeFlashlightableLightingStrategy
// Size: 0x38 (Inherited: 0x30)
struct UTracingConeFlashlightableLightingStrategy : UFlashlightableLightingStrategy {
	int32_t _aroundConeCircleTraceCount; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class DBDGameplay.UnhookedSurvivorTrackerComponent
// Size: 0xe8 (Inherited: 0xb8)
struct UUnhookedSurvivorTrackerComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
};

// Class DBDGameplay.VisibleHatchRangeTrackerStrategy
// Size: 0x98 (Inherited: 0x70)
struct UVisibleHatchRangeTrackerStrategy : URangeToActorsTrackerStrategy {
	char pad_70[0x28]; // 0x70(0x28)
};

// Class DBDGameplay.WiggleComponent
// Size: 0x190 (Inherited: 0xb8)
struct UWiggleComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct UChargeableComponent* _wiggleProgress; // 0xc0(0x08)
	struct ASlasherPlayer* _killerWigglingFrom; // 0xc8(0x08)
	struct UInputComponent* _inputComponent; // 0xd0(0x08)
	char pad_D8[0xb8]; // 0xd8(0xb8)

	void Server_OnWiggleEnd(); // Function DBDGameplay.WiggleComponent.Server_OnWiggleEnd // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2cc4840
	void OnWiggleSkillCheckEnd(bool hadInput, bool success, bool Bonus, enum class ESkillCheckCustomType Type); // Function DBDGameplay.WiggleComponent.OnWiggleSkillCheckEnd // (Final|Native|Private) // @ game+0x2cc4580
	void OnWiggleInput(); // Function DBDGameplay.WiggleComponent.OnWiggleInput // (Final|Native|Private) // @ game+0x2cc4560
	void OnWiggleEnd(); // Function DBDGameplay.WiggleComponent.OnWiggleEnd // (Final|Native|Private) // @ game+0x2cc4540
	void OnPlayerPickedUpStart(struct ADBDPlayer* picker); // Function DBDGameplay.WiggleComponent.OnPlayerPickedUpStart // (Final|Native|Private) // @ game+0x2cc4220
	void OnPlayerPickedUpEnd(struct ADBDPlayer* picker); // Function DBDGameplay.WiggleComponent.OnPlayerPickedUpEnd // (Final|Native|Private) // @ game+0x2cc41a0
	void OnPickedUpSkillCheckEnd(bool hadInput, bool success, bool Bonus, enum class ESkillCheckCustomType Type); // Function DBDGameplay.WiggleComponent.OnPickedUpSkillCheckEnd // (Final|Native|Private) // @ game+0x2cc4040
	void OnKeyBindingsChanged(); // Function DBDGameplay.WiggleComponent.OnKeyBindingsChanged // (Final|Native|Private) // @ game+0x2cc3f70
	void OnHideWiggleSkillCheck(enum class ESkillCheckCustomType Type); // Function DBDGameplay.WiggleComponent.OnHideWiggleSkillCheck // (Final|Native|Private) // @ game+0x2cc3de0
	void OnChargeableCompleteEvent(bool COMPLETED, struct TArray<struct AActor*> instigatorsForCompletion); // Function DBDGameplay.WiggleComponent.OnChargeableCompleteEvent // (Final|Native|Private|HasOutParms) // @ game+0x2cc3c60
	struct UChargeableComponent* GetWiggleChargeable(); // Function DBDGameplay.WiggleComponent.GetWiggleChargeable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cc2f80
	void Authority_AddWiggleCharge(float ChargeAmount); // Function DBDGameplay.WiggleComponent.Authority_AddWiggleCharge // (Final|Native|Public|BlueprintCallable) // @ game+0x2cc2d90
};

// Class DBDGameplay.WiggleMotionComponent
// Size: 0x110 (Inherited: 0xb8)
struct UWiggleMotionComponent : UActorComponent {
	struct ADBDPlayer* _carriedPlayer; // 0xb8(0x08)
	struct UDBDCharacterMovementComponent* _ownerMovementComponent; // 0xc0(0x08)
	char pad_C8[0x48]; // 0xc8(0x48)

	void SetIsBeingWiggled(bool isBeingWiggled); // Function DBDGameplay.WiggleMotionComponent.SetIsBeingWiggled // (Final|Native|Public|BlueprintCallable) // @ game+0x2cc48f0
	void Server_SetIsBeingWiggled(bool isBeingWiggled); // Function DBDGameplay.WiggleMotionComponent.Server_SetIsBeingWiggled // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2cc4860
	void OnWiggleSkillCheckEnd(bool hadInput, bool success, bool Bonus, enum class ESkillCheckCustomType Type); // Function DBDGameplay.WiggleMotionComponent.OnWiggleSkillCheckEnd // (Final|Native|Private) // @ game+0x2cc46e0
	void OnSurvivorRemoved(struct ADBDPlayer* Target); // Function DBDGameplay.WiggleMotionComponent.OnSurvivorRemoved // (Final|Native|Private) // @ game+0x2cc44c0
	void OnSurvivorPickedUp(struct ADBDPlayer* Target); // Function DBDGameplay.WiggleMotionComponent.OnSurvivorPickedUp // (Final|Native|Private) // @ game+0x2cc4440
	void OnHideWiggleSkillCheck(enum class ESkillCheckCustomType Type); // Function DBDGameplay.WiggleMotionComponent.OnHideWiggleSkillCheck // (Final|Native|Private) // @ game+0x2cc3e60
};

