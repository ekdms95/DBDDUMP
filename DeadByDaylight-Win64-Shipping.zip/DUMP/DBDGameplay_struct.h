// ScriptStruct DBDGameplay.AimDirection
// Size: 0x24 (Inherited: 0x00)
struct FAimDirection {
	char pad_0[0x24]; // 0x00(0x24)
};

// ScriptStruct DBDGameplay.BlindTargetViewData
// Size: 0x40 (Inherited: 0x00)
struct FBlindTargetViewData {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct DBDGameplay.TestableStat
// Size: 0x88 (Inherited: 0x80)
struct FTestableStat : FTunableStat {
	char pad_80[0x8]; // 0x80(0x08)
};

