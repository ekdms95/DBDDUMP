// Enum DBDInput.EAnalogCursorDataType
enum class EAnalogCursorDataType : uint8 {
	MaxSpeedDefault,
	MaxSpeedDefaultSlow,
	MaxSpeedStickyDefault,
	MaxSpeedStickySlow,
	MaxSpeedStickyButtonMedium,
	MaxSpeedStickyButtonLarge,
	MaxSpeedDefaultBloodweb,
	MaxSpeedStickyBloodweb,
	CustomAcceleration,
	DeadZone,
	HandheldSpeedBoostFactor,
	EAnalogCursorDataType_MAX,
};

// Enum DBDInput.EDBDInputMode
enum class EDBDInputMode : uint8 {
	None,
	Scaleform,
	UMG,
	Game,
	EDBDInputMode_MAX,
};

// Enum DBDInput.EUIActionType
enum class EUIActionType : uint8 {
	Accept,
	Cancel,
	Previous,
	Next,
	EUIActionType_MAX,
};

// ScriptStruct DBDInput.AnalogCursorData
// Size: 0x18 (Inherited: 0x08)
struct FAnalogCursorData : FDBDTableRowBase {
	enum class EAnalogCursorDataType Type; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float value; // 0x0c(0x04)
	bool ScalesWithDPI; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

