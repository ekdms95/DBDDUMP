// Class DBDInteraction.ActivePhaseWalkInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct UActivePhaseWalkInteraction : UChargeableInteractionDefinition {
	char pad_680[0x8]; // 0x680(0x08)
	struct UCurveFloat* _chargingSpeedCurve; // 0x688(0x08)
	char pad_690[0x10]; // 0x690(0x10)

	void ResetMovementSpeedMultipliers(); // Function DBDInteraction.ActivePhaseWalkInteraction.ResetMovementSpeedMultipliers // (Final|Native|Protected|BlueprintCallable) // @ game+0x2cd4680
	void ResetChargeVFX(struct ADBDPlayer* Player); // Function DBDInteraction.ActivePhaseWalkInteraction.ResetChargeVFX // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Local_SendPhaseWalkInfo(bool startActivePhaseWalk, bool TeleportToHusk, struct ADBDPlayer* Player); // Function DBDInteraction.ActivePhaseWalkInteraction.Local_SendPhaseWalkInfo // (Final|Native|Protected|BlueprintCallable) // @ game+0x2cd4570
};

// Class DBDInteraction.BaseLockerInteraction
// Size: 0x560 (Inherited: 0x560)
struct UBaseLockerInteraction : UInteractionDefinition {
	struct ALocker* _owningLocker; // 0x558(0x08)
};

// Class DBDInteraction.BaseStalkModeInteraction
// Size: 0x560 (Inherited: 0x560)
struct UBaseStalkModeInteraction : UInteractionDefinition {

	struct UStalkerComponent* GetStalkerComponent(); // Function DBDInteraction.BaseStalkModeInteraction.GetStalkerComponent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd49e0
	bool CanStalk(); // Function DBDInteraction.BaseStalkModeInteraction.CanStalk // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd49b0
};

// Class DBDInteraction.CollectItemInteraction
// Size: 0x580 (Inherited: 0x560)
struct UCollectItemInteraction : UInteractionDefinition {
	struct FMulticastInlineDelegate OnCollectUpdateStart; // 0x558(0x10)
	struct FMulticastInlineDelegate OnCollectUpdateEnd; // 0x568(0x10)

	struct ACollectable* GetItem(); // Function DBDInteraction.CollectItemInteraction.GetItem // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd4e00
};

// Class DBDInteraction.CollectItemFromSearchableInteraction
// Size: 0x590 (Inherited: 0x580)
struct UCollectItemFromSearchableInteraction : UCollectItemInteraction {
	char pad_580[0x10]; // 0x580(0x10)
};

// Class DBDInteraction.DeadHardDashInteraction
// Size: 0x560 (Inherited: 0x560)
struct UDeadHardDashInteraction : UInteractionDefinition {
};

// Class DBDInteraction.DestroyDemogorgonPortalInteraction
// Size: 0x690 (Inherited: 0x680)
struct UDestroyDemogorgonPortalInteraction : UChargeableInteractionDefinition {
	struct ADemogorgonPortal* _owningPortal; // 0x680(0x08)
	char pad_688[0x8]; // 0x688(0x08)

	void Authority_OnChargeApplied(float individualChargeAmount, float totalChargeAmount, struct AActor* chargeInstigator, bool wasCoop, float DeltaTime); // Function DBDInteraction.DestroyDemogorgonPortalInteraction.Authority_OnChargeApplied // (Final|Native|Private) // @ game+0x2cd5120
};

// Class DBDInteraction.DropItemInteraction
// Size: 0x560 (Inherited: 0x560)
struct UDropItemInteraction : UInteractionDefinition {

	struct ACollectable* GetItem(); // Function DBDInteraction.DropItemInteraction.GetItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd5420
};

// Class DBDInteraction.EscapeMapInteraction
// Size: 0x560 (Inherited: 0x560)
struct UEscapeMapInteraction : UInteractionDefinition {
};

// Class DBDInteraction.GeneratorDamageInteraction
// Size: 0x680 (Inherited: 0x680)
struct UGeneratorDamageInteraction : UChargeableInteractionDefinition {

	void Authority_DamageGenerator(struct ADBDPlayer* damageBy, struct AGenerator* Generator); // Function DBDInteraction.GeneratorDamageInteraction.Authority_DamageGenerator // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|Const) // @ game+0x2cd57c0
};

// Class DBDInteraction.GeneratorRepairInteraction
// Size: 0x700 (Inherited: 0x680)
struct UGeneratorRepairInteraction : UChargeableInteractionDefinition {
	struct FDBDTunableRowHandle _penaltyPerRepairPlayerCount[0x3]; // 0x680(0x78)
	char pad_6F8[0x8]; // 0x6f8(0x08)

	void SetIsObstructed(bool obstructed); // Function DBDInteraction.GeneratorRepairInteraction.SetIsObstructed // (Final|Native|Public|BlueprintCallable) // @ game+0x2cd5a50
	struct AGenerator* GetOwningGenerator(); // Function DBDInteraction.GeneratorRepairInteraction.GetOwningGenerator // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd5a20
};

// Class DBDInteraction.GeneratorToolboxRepairInteraction
// Size: 0x770 (Inherited: 0x700)
struct UGeneratorToolboxRepairInteraction : UGeneratorRepairInteraction {
	struct FText _interactionTextWhenEmpty; // 0x700(0x18)
	struct FDBDTunableRowHandle _repairSkillCheckDurationWhenEmpty; // 0x718(0x28)
	struct FDBDTunableRowHandle _repairSkillCheckChanceWhenEmpty; // 0x740(0x28)
	char pad_768[0x8]; // 0x768(0x08)

	bool HasChargedToolBox(struct ADBDPlayer* Player); // Function DBDInteraction.GeneratorToolboxRepairInteraction.HasChargedToolBox // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd5fc0
	struct FString GetInteractionTextWhenEmpty(); // Function DBDInteraction.GeneratorToolboxRepairInteraction.GetInteractionTextWhenEmpty // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd5f40
};

// Class DBDInteraction.GhostChargeStalkModeInteraction
// Size: 0x570 (Inherited: 0x560)
struct UGhostChargeStalkModeInteraction : UBaseStalkModeInteraction {
	char pad_560[0x10]; // 0x560(0x10)

	struct UGhostStealthComponent* GetStealthComponent(); // Function DBDInteraction.GhostChargeStalkModeInteraction.GetStealthComponent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd6220
};

// Class DBDInteraction.HookSurvivorDefinition
// Size: 0x690 (Inherited: 0x680)
struct UHookSurvivorDefinition : UChargeableInteractionDefinition {
	struct ACamperPlayer* _survivorBeingHooked; // 0x680(0x08)
	char pad_688[0x8]; // 0x688(0x08)

	struct AMeatHook* GetMeatHook(); // Function DBDInteraction.HookSurvivorDefinition.GetMeatHook // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd63c0
};

// Class DBDInteraction.ItemCraftInteraction
// Size: 0x570 (Inherited: 0x560)
struct UItemCraftInteraction : UInteractionDefinition {
	struct FName _attachToSocketName; // 0x558(0x0c)
	struct ACollectable* _collectableClass; // 0x568(0x08)
};

// Class DBDInteraction.InClosetFlashbangItemCraftInteraction
// Size: 0x570 (Inherited: 0x570)
struct UInClosetFlashbangItemCraftInteraction : UItemCraftInteraction {
};

// Class DBDInteraction.LinkedVomitInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct ULinkedVomitInteraction : UChargeableInteractionDefinition {
	char pad_680[0x1c]; // 0x680(0x1c)
	bool _chargeComplete; // 0x69c(0x01)
	char pad_69D[0x3]; // 0x69d(0x03)

	bool IsVomiting(); // Function DBDInteraction.LinkedVomitInteraction.IsVomiting // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd68a0
	bool IsChargeComplete(); // Function DBDInteraction.LinkedVomitInteraction.IsChargeComplete // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd6870
	struct UVomitStateComponent* GetVomitStateComponent(); // Function DBDInteraction.LinkedVomitInteraction.GetVomitStateComponent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd6840
};

// Class DBDInteraction.LockerFakeEnterInteraction
// Size: 0x590 (Inherited: 0x560)
struct ULockerFakeEnterInteraction : UInteractionDefinition {
	float _lockerInteractionBlockTime; // 0x558(0x04)
	struct ALocker* _owningLocker; // 0x560(0x08)
	struct FDBDTunableRowHandle _fakeEnterLoudNoiseRange; // 0x568(0x28)
};

// Class DBDInteraction.SearchChestInteractionBase
// Size: 0x6b0 (Inherited: 0x680)
struct USearchChestInteractionBase : UChargeableInteractionDefinition {
	bool _handleCompletionScoreEvents; // 0x680(0x01)
	char pad_681[0x3]; // 0x681(0x03)
	struct FGameplayTag _searchableCompleteContributionPercentTag; // 0x684(0x0c)
	bool _scoreEventFired; // 0x690(0x01)
	char pad_691[0x7]; // 0x691(0x07)
	struct ASearchable* _owningChest; // 0x698(0x08)
	bool _onLastInteractionWasComplete; // 0x6a0(0x01)
	char pad_6A1[0xf]; // 0x6a1(0x0f)

	void FireChestScoreEvent(struct ADBDPlayer* Player); // Function DBDInteraction.SearchChestInteractionBase.FireChestScoreEvent // (Final|Native|Private|BlueprintCallable) // @ game+0x2cd7030
};

// Class DBDInteraction.OpenChestInteraction
// Size: 0x6d0 (Inherited: 0x6b0)
struct UOpenChestInteraction : USearchChestInteractionBase {
	struct FGameplayTag _camperSearchablePercentTag; // 0x6a8(0x0c)
	struct UAnimSequence* _successExitTimeAnimSequenceReference; // 0x6b8(0x08)
	float _startTime; // 0x6c0(0x04)
	char pad_6C8[0x8]; // 0x6c8(0x08)

	void CollectItemIfEmptyHanded(struct ACollectable* Collectable, struct ADBDPlayer* Player); // Function DBDInteraction.OpenChestInteraction.CollectItemIfEmptyHanded // (Final|Native|Private|BlueprintCallable) // @ game+0x2cd6c50
};

// Class DBDInteraction.PalletPullUpInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct UPalletPullUpInteraction : UChargeableInteractionDefinition {
	enum class EPalletSide _side; // 0x680(0x01)
	char pad_681[0x7]; // 0x681(0x07)
	struct APallet* _owningPallet; // 0x688(0x08)
	char pad_690[0x10]; // 0x690(0x10)
};

// Class DBDInteraction.SearchOpenedChestInteraction
// Size: 0x6b0 (Inherited: 0x6b0)
struct USearchOpenedChestInteraction : USearchChestInteractionBase {
};

// Class DBDInteraction.SetGroundPortalInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct USetGroundPortalInteraction : UChargeableInteractionDefinition {
	struct UPortalPlacerStateComponent* _portalPlacerState; // 0x680(0x08)
	struct UObjectPlacerComponent* _trapPlacerComponent; // 0x688(0x08)
	struct ADemogorgonPortal* _portalClassToSpawn; // 0x690(0x08)
	char pad_698[0x8]; // 0x698(0x08)
};

// Class DBDInteraction.SetTrapInteraction
// Size: 0x6e0 (Inherited: 0x680)
struct USetTrapInteraction : UChargeableInteractionDefinition {
	struct FSocketOrBoneCache _dropSocket; // 0x680(0x60)
};

// Class DBDInteraction.TeleportToDemogorgonPortalInteraction
// Size: 0x730 (Inherited: 0x680)
struct UTeleportToDemogorgonPortalInteraction : UChargeableInteractionDefinition {
	float _enterPortalPhaseDuration; // 0x680(0x04)
	float _cancelTeleportingPhaseDuration; // 0x684(0x04)
	struct UPortalTargetingComponent* _portalTargetingComponent; // 0x688(0x08)
	struct UPortalPlacerStateComponent* _portalPlacerState; // 0x690(0x08)
	struct ADemogorgonPortal* _startingPortal; // 0x698(0x08)
	struct ADemogorgonPortal* _targetedPortal; // 0x6a0(0x08)
	struct ADBDPlayer* _interactingPlayer; // 0x6a8(0x08)
	char pad_6B0[0x60]; // 0x6b0(0x60)
	struct AActor* _huskRef; // 0x710(0x08)
	struct AActor* ClassToSpawnForHusk; // 0x718(0x08)
	char pad_720[0x10]; // 0x720(0x10)

	void OnTeleportInteractionCanceledVFX(); // Function DBDInteraction.TeleportToDemogorgonPortalInteraction.OnTeleportInteractionCanceledVFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function DBDInteraction.TeleportToDemogorgonPortalInteraction.OnSlasherSet // (Final|Native|Private) // @ game+0x2cd7760
};

// Class DBDInteraction.ThrowInteraction
// Size: 0x690 (Inherited: 0x680)
struct UThrowInteraction : UChargeableInteractionDefinition {
	struct UCurveFloat* _throwCancelledSpeedCurve; // 0x680(0x08)
	float _throwCancellationExitTime; // 0x688(0x04)
	char pad_68C[0x4]; // 0x68c(0x04)

	void InitThrowCancellationExitTime(float value); // Function DBDInteraction.ThrowInteraction.InitThrowCancellationExitTime // (Final|Native|Protected|BlueprintCallable) // @ game+0x2cd7a00
	bool HasCancelledThrow(); // Function DBDInteraction.ThrowInteraction.HasCancelledThrow // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd79d0
};

// Class DBDInteraction.ThrowRockInteraction
// Size: 0x560 (Inherited: 0x560)
struct UThrowRockInteraction : UInteractionDefinition {
};

