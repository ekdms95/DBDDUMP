// Enum DBDSharedTypes.ELeanState
enum class ELeanState : uint8 {
	NotLeaning,
	LeanLeft,
	LeanRight,
	ELeanState_MAX,
};

// Enum DBDSharedTypes.ECharacterDifficulty
enum class ECharacterDifficulty : uint8 {
	VE_Easy,
	VE_Intermediate,
	VE_Hard,
	VE_MAX,
};

// Enum DBDSharedTypes.ESkillCheckCustomType
enum class ESkillCheckCustomType : uint8 {
	VE_None,
	VE_OnPickedUp,
	VE_OnAttacked,
	VE_DecisiveStrikeWhileWiggling,
	VE_GeneratorOvercharge1,
	VE_GeneratorOvercharge2,
	VE_GeneratorOvercharge3,
	VE_BrandNewPart,
	VE_Struggle,
	VE_OppressionPerkGeneratorKicked,
	VE_SoulChemical,
	VE_Wiggle,
	VE_MAX,
};

// Enum DBDSharedTypes.EGender
enum class EGender : uint8 {
	VE_Male,
	VE_Female,
	VE_Multiple,
	VE_NotHuman,
	VE_Undefined,
	VE_MAX,
};

// Enum DBDSharedTypes.EAttackSubstate
enum class EAttackSubstate : uint8 {
	VE_None,
	VE_Open,
	VE_Hitting,
	VE_HitSucceed,
	VE_HitMiss,
	VE_HitObstructed,
	VE_Done,
	VE_MAX,
};

// Enum DBDSharedTypes.EDetectionZone
enum class EDetectionZone : uint8 {
	VE_None,
	VE_Slash,
	VE_Pounce,
	VE_Chainsaw,
	VE_Obstructed,
	VE_Interruption,
	VE_ChainsawLockExtended,
	VE_Damage,
	VE_ChainsawObstruction,
	VE_Blink,
	VE_ChainsawDamageExtended,
	VE_Stalker,
	VE_Lunge,
	VE_PowerAttack,
	VE_Max,
	VE_Max,
};

// Enum DBDSharedTypes.EAttackSuccess
enum class EAttackSuccess : uint8 {
	VE_None,
	VE_Success,
	VE_Failure,
	VE_Obstructed,
	VE_MAX,
};

// Enum DBDSharedTypes.EBlindType
enum class EBlindType : uint8 {
	VE_None,
	VE_Flashlight,
	VE_SacrificeSuspended,
	VE_Firecracker,
	VE_MAX,
};

// Enum DBDSharedTypes.EStunType
enum class EStunType : uint8 {
	VE_None,
	VE_Bookshelf,
	VE_BearTrap,
	VE_Flashlight,
	VE_WiggleFree,
	VE_EvilWithin,
	VE_Kicked,
	VE_Closet,
	VE_HarpoonRifle,
	VE_GeneratorTrap,
	VE_MAX,
};

// Enum DBDSharedTypes.EAttackType
enum class EAttackType : uint8 {
	VE_None,
	VE_Slash,
	VE_Pounce,
	VE_Chainsaw,
	VE_Blink,
	VE_LFChainsaw,
	VE_Ambush,
	VE_Frenzy,
	VE_GhostCrouch,
	VE_QatarDash,
	VE_OniBasicAttack,
	VE_OniDemonBasicAttack,
	VE_OniDemonPowerAttack,
	VE_OniDemonDashAttack,
	VE_ExecutionerTormentAttack,
	VE_BlightDash,
	VE_TwinJump,
	VE_K24WhipAttack,
	VE_MAX,
};

// Enum DBDSharedTypes.EInteractionAnimation
enum class EInteractionAnimation : uint8 {
	VE_None,
	VE_Generator,
	VE_PullDownLeft,
	VE_PullDownRight,
	VE_Hiding,
	VE_SearchCloset,
	VE_HealingOther,
	VE_OpenEscape,
	VE_StruggleFree,
	VE_HealOther,
	VE_HealSelf,
	VE_PickedUp,
	VE_Unused01,
	VE_Dropped,
	VE_Unused02,
	VE_BeingHooked,
	VE_Sabotage,
	VE_ChargeBlink,
	VE_ThrowFirecracker,
	VE_WakeUpOther,
	VE_RemoveReverseBearTrap,
	VE_DeadHard,
	VE_DestroyPortal,
	VE_OniDash,
	VE_PickUpAnniversaryCrown,
	VE_InteractWithGlyph,
	VE_OpenChest,
	VE_MAX,
};

// Enum DBDSharedTypes.ECamperState
enum class ECamperState : uint8 {
	VE_None,
	VE_Navigate,
	VE_Interact,
	VE_MAX,
};

// Enum DBDSharedTypes.EAnimNotifyType
enum class EAnimNotifyType : uint8 {
	VE_None,
	VE_Pickup,
	VE_Release,
	VE_MAX,
};

// Enum DBDSharedTypes.EKillerMoodInfluence
enum class EKillerMoodInfluence : uint8 {
	VE_None,
	VE_Chuckles,
	VE_Banshee,
	VE_Hillbilly,
	VE_Nurse,
	VE_Shape,
	VE_MAX,
};

// Enum DBDSharedTypes.EKillerAbilities
enum class EKillerAbilities : uint8 {
	VE_None,
	VE_SpawnTraps,
	VE_Cloak,
	VE_Chainsaw,
	VE_Blink,
	VE_PhantomTrap,
	VE_Stalker,
	VE_Killer07Ability,
	VE_Killer08Ability,
	VE_LFChainsaw,
	VE_InduceDreams,
	VE_ReverseBearTrap,
	VE_GasBomb,
	VE_PhaseWalk,
	VE_Frenzy,
	VE_Vomit,
	VE_GhostStalker,
	VE_GroundPortals,
	VE_DemonMode,
	VE_HarpoonRifle,
	VE_TormentMode,
	VE_K21Power,
	VE_K22Power,
	VE_ThrowingKnives,
	VE_K24Power,
	VE_MAX,
};

// Enum DBDSharedTypes.EGameState
enum class EGameState : uint8 {
	VE_Active,
	VE_Dead,
	VE_Escaped,
	VE_EscapedInjured,
	VE_Sacrificed,
	VE_None,
	VE_Disconnected,
	VE_ManuallyLeftMatch,
	VE_MAX,
};

// Enum DBDSharedTypes.EPlayerTeam
enum class EPlayerTeam : uint8 {
	VE_None,
	VE_Killer,
	VE_Survivor,
	VE_MAX,
};

// Enum DBDSharedTypes.EPawnType
enum class EPawnType : uint8 {
	VE_None,
	VE_Killer,
	VE_Survivor,
	VE_Sidekick,
	VE_MAX,
};

// Enum DBDSharedTypes.EPlayerRole
enum class EPlayerRole : uint8 {
	VE_None,
	VE_Slasher,
	VE_Camper,
	VE_Observer,
	Max,
	EPlayerRole_MAX,
};

// Enum DBDSharedTypes.EDBDScoreCategory
enum class EDBDScoreCategory : uint8 {
	DBD_CamperScoreCat_Objectives,
	DBD_CamperScoreCat_Survival,
	DBD_CamperScoreCat_Altruism,
	DBD_CamperScoreCat_Boldness,
	DBD_SlasherScoreCat_Brutality,
	DBD_SlasherScoreCat_Deviousness,
	DBD_SlasherScoreCat_Hunter,
	DBD_SlasherScoreCat_Sacrifice,
	DBD_CamperScoreCat_Untracked,
	DBD_CamperScoreCat_Streak,
	DBD_ScoreCat_SpecialEvents,
	Count,
	EDBDScoreCategory_MAX,
};

// Enum DBDSharedTypes.EFriendshipStatus
enum class EFriendshipStatus : uint8 {
	None,
	RequestSent,
	RequestReceived,
	Friend,
	EFriendshipStatus_MAX,
};

// Enum DBDSharedTypes.EFriendSuggestionType
enum class EFriendSuggestionType : uint8 {
	None,
	Facebook,
	Google,
	EFriendSuggestionType_MAX,
};

// Enum DBDSharedTypes.EStatusEffectType
enum class EStatusEffectType : uint8 {
	None,
	Buff,
	Debuff,
	EStatusEffectType_MAX,
};

// Enum DBDSharedTypes.EHelpType
enum class EHelpType : uint8 {
	General,
	Survivor,
	Killer,
	EHelpType_MAX,
};

// Enum DBDSharedTypes.EBarColor
enum class EBarColor : uint8 {
	Default,
	Yellow,
	Red,
	EBarColor_MAX,
};

// Enum DBDSharedTypes.EHudScreenIndicatorType
enum class EHudScreenIndicatorType : uint8 {
	None,
	LoudNoise,
	StealthBroken,
	Objective,
	EHudScreenIndicatorType_MAX,
};

// Enum DBDSharedTypes.EHudParentContainerType
enum class EHudParentContainerType : uint8 {
	Widget,
	Outer,
	Spectate,
	EHudParentContainerType_MAX,
};

// Enum DBDSharedTypes.EItemAvailability
enum class EItemAvailability : uint8 {
	Available,
	Disabled,
	Retired,
	EItemAvailability_MAX,
};

// Enum DBDSharedTypes.ELoadoutItemType
enum class ELoadoutItemType : uint8 {
	None,
	Medkit,
	Toolbox,
	Flashlight,
	Key,
	Map,
	Firecracker,
	Flashbang,
	Count,
	ELoadoutItemType_MAX,
};

// Enum DBDSharedTypes.EItemRarity
enum class EItemRarity : uint8 {
	Common,
	Uncommon,
	Rare,
	VeryRare,
	UltraRare,
	Artifact,
	Spectral,
	Teachable,
	SpecialEvent,
	Legendary,
	Count,
	None,
	EItemRarity_MAX,
};

// Enum DBDSharedTypes.EOnboardingTutorialType
enum class EOnboardingTutorialType : uint8 {
	TutorialLevel,
	BotMatchLevel,
	FinalReward,
	EOnboardingTutorialType_MAX,
};

// Enum DBDSharedTypes.EOnboardingTutorialButtonStyle
enum class EOnboardingTutorialButtonStyle : uint8 {
	Default,
	Survivor,
	Killer,
	Reward,
	EOnboardingTutorialButtonStyle_MAX,
};

// Enum DBDSharedTypes.EOnboardingStepStatus
enum class EOnboardingStepStatus : uint8 {
	Unavailable,
	Open,
	Completed,
	EOnboardingStepStatus_MAX,
};

// Enum DBDSharedTypes.EPingQuality
enum class EPingQuality : uint8 {
	Good,
	Bad,
	Awful,
	EPingQuality_MAX,
};

// Enum DBDSharedTypes.EPlayerStateChangeType
enum class EPlayerStateChangeType : uint8 {
	None,
	Negative,
	Neutral,
	Positive,
	EPlayerStateChangeType_MAX,
};

// Enum DBDSharedTypes.ESicknessLevel
enum class ESicknessLevel : uint8 {
	Off,
	InProgress,
	Full,
	ESicknessLevel_MAX,
};

// Enum DBDSharedTypes.EAfflictionLevel
enum class EAfflictionLevel : uint8 {
	Off,
	Level1,
	Level2,
	Level3,
	EAfflictionLevel_MAX,
};

// Enum DBDSharedTypes.EBloodDisplayType
enum class EBloodDisplayType : uint8 {
	Hidden,
	Bottom,
	Top,
	EBloodDisplayType_MAX,
};

// Enum DBDSharedTypes.EPlayerStatus
enum class EPlayerStatus : uint8 {
	Default,
	Hook,
	Trap,
	Dead,
	Escaped,
	Injured,
	Crawling,
	Sacrificed,
	Disconnected,
	InDeathBed,
	EPlayerStatus_MAX,
};

// Enum DBDSharedTypes.EReverseBearTrapUIState
enum class EReverseBearTrapUIState : uint8 {
	Off,
	Stage1,
	Stage2,
	EReverseBearTrapUIState_MAX,
};

// Enum DBDSharedTypes.ESleepingUIState
enum class ESleepingUIState : uint8 {
	Off,
	FallingAsleep,
	Asleep,
	ESleepingUIState_MAX,
};

// Enum DBDSharedTypes.EObsessionUIState
enum class EObsessionUIState : uint8 {
	Off,
	Target,
	Chased,
	Dead,
	EObsessionUIState_MAX,
};

// Enum DBDSharedTypes.EThemeColorId
enum class EThemeColorId : uint8 {
	Invalid,
	Blue,
	Green,
	Yellow,
	EThemeColorId_MAX,
};

// Enum DBDSharedTypes.EProgressionType
enum class EProgressionType : uint8 {
	None,
	Stars,
	EProgressionType_MAX,
};

// Enum DBDSharedTypes.ECurrencyType
enum class ECurrencyType : uint8 {
	None,
	BloodPoints,
	FearTokens,
	Cells,
	HalloweenCoins,
	LunarNewYearCoins,
	HalloweenEventCurrency,
	ECurrencyType_MAX,
};

// Enum DBDSharedTypes.ERewardType
enum class ERewardType : uint8 {
	None,
	Character,
	Currency,
	Customization,
	Progression,
	ERewardType_MAX,
};

// Enum DBDSharedTypes.ETutorialObjectivePlayerActionMapping
enum class ETutorialObjectivePlayerActionMapping : uint8 {
	None,
	Action_Camper,
	Interact_Camper,
	Interact_Slasher,
	Run_Camper,
	Attack_Slasher,
	SecondaryAction_Camper,
	ItemUse_Camper,
	Crouch,
	ItemDrop_Camper,
	ItemUse_Slasher,
	ItemDrop_Slasher,
	Mash_Camper,
	FastInteract_Camper,
	SecondaryAction_Slasher,
	Action_Slasher,
	Struggle,
	MoveAxes,
	LookAxes,
	Count,
	ETutorialObjectivePlayerActionMapping_MAX,
};

// Enum DBDSharedTypes.EHudComponent
enum class EHudComponent : uint8 {
	ACTION_PROMPT,
	ACTION_PROGRESS_BAR,
	GENERATOR_ICON,
	HATCH_ICON,
	LOCAL_PLAYER_STATUS,
	OTHER_PLAYER_STATUSES,
	CROUCH_BUTTON,
	CENTER_INTERACT_BUTTON,
	DIRECTIONAL_STICK,
	WIGGLE_BUTTONS,
	STRUGGLE_BUTTONS,
	POWER_BUTTON,
	ATTACK_BUTTON,
	OBJECTIVES,
	LOUD_NOISE_INDICATOR,
	EHudComponent_MAX,
};

// Enum DBDSharedTypes.ETestBuildType
enum class ETestBuildType : uint8 {
	None,
	PublicTestBuild,
	PaxBuild,
	ConsolePreAlphaBuild,
	ETestBuildType_MAX,
};

// Enum DBDSharedTypes.EControlMode
enum class EControlMode : uint8 {
	MOUSE_KB,
	XBOX,
	PS,
	VITA,
	SWITCH,
	STADIA,
	SWITCH_PRO,
	UNDEFINED,
	EControlMode_MAX,
};

// ScriptStruct DBDSharedTypes.FriendData
// Size: 0x60 (Inherited: 0x00)
struct FFriendData {
	char pad_0[0x60]; // 0x00(0x60)
};

// ScriptStruct DBDSharedTypes.HelpCategoryData
// Size: 0x50 (Inherited: 0x08)
struct FHelpCategoryData : FDBDTableRowBase {
	enum class EHelpType Type; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FText Title; // 0x10(0x18)
	struct FText Description; // 0x28(0x18)
	struct TArray<struct FName> TopicIds; // 0x40(0x10)
};

// ScriptStruct DBDSharedTypes.HelpContextMappingData
// Size: 0x28 (Inherited: 0x08)
struct FHelpContextMappingData : FDBDTableRowBase {
	struct FString ContextName; // 0x08(0x10)
	struct TArray<struct FName> TopicIds; // 0x18(0x10)
};

// ScriptStruct DBDSharedTypes.HelpTopicData
// Size: 0x98 (Inherited: 0x08)
struct FHelpTopicData : FDBDTableRowBase {
	struct FText Title; // 0x08(0x18)
	struct FText Description; // 0x20(0x18)
	struct FString ImagePath; // 0x38(0x10)
	struct FString IconPath; // 0x48(0x10)
	struct FString VideoId; // 0x58(0x10)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x68(0x30)
};

// ScriptStruct DBDSharedTypes.RarityMaterialData
// Size: 0x18 (Inherited: 0x08)
struct FRarityMaterialData : FDBDTableRowBase {
	enum class EItemRarity Rarity; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UMaterialInterface* Material; // 0x10(0x08)
};

