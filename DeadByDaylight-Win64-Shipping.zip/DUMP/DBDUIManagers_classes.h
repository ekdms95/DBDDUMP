// Class DBDUIManagers.UIScaleManager
// Size: 0xe0 (Inherited: 0x38)
struct UUIScaleManager : UGameInstanceSubsystem {
	struct UDataTable* _dpiScaleCurveDB; // 0x38(0x08)
	struct UCurveFloat* _dpiScaleCurve; // 0x40(0x08)
	char pad_48[0x98]; // 0x48(0x98)

	float GetSkillCheckScaleFactor(); // Function DBDUIManagers.UIScaleManager.GetSkillCheckScaleFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26d6890
	float GetScaleFactor(enum class EScaleType Type); // Function DBDUIManagers.UIScaleManager.GetScaleFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26d6800
	float GetMenuScaleFactor(); // Function DBDUIManagers.UIScaleManager.GetMenuScaleFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26d67d0
	float GetHudScaleFactor(); // Function DBDUIManagers.UIScaleManager.GetHudScaleFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26d67a0
	enum class EDPIScaleCurveRatio GetDPIScaleCurveRatio(); // Function DBDUIManagers.UIScaleManager.GetDPIScaleCurveRatio // (Final|Native|Public|BlueprintCallable) // @ game+0x26d6770
};

