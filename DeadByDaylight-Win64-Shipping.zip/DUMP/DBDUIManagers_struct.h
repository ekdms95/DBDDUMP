// Enum DBDUIManagers.EDPIScaleCurveRatio
enum class EDPIScaleCurveRatio : uint8 {
	Default,
	SmallerEqual4_4,
	EDPIScaleCurveRatio_MAX,
};

// Enum DBDUIManagers.EScaleType
enum class EScaleType : uint8 {
	None,
	Menu,
	Hud,
	SkillCheck,
	EScaleType_MAX,
};

// ScriptStruct DBDUIManagers.DPIScaleCurveForRatio
// Size: 0x40 (Inherited: 0x08)
struct FDPIScaleCurveForRatio : FDBDTableRowBase {
	enum class EDPIScaleCurveRatio Ratio; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftObjectPtr<struct UCurveFloat> DPIScaleCurve; // 0x10(0x30)
};

