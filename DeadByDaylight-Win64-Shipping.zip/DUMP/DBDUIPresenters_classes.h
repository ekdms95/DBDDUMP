// Class DBDUIPresenters.UIComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UUIComponent : UActorComponent {
};

// Class DBDUIPresenters.ContextObserver
// Size: 0xe0 (Inherited: 0xb8)
struct UContextObserver : UUIComponent {
	enum class EContextSection ObservedContextSection; // 0xb8(0x01)
	char pad_B9[0x27]; // 0xb9(0x27)
};

// Class DBDUIPresenters.Presenter
// Size: 0xe0 (Inherited: 0xb8)
struct UPresenter : UUIComponent {
	bool RequestPresentationAtBeginPlay; // 0xb8(0x01)
	enum class ESlateVisibility InitialVisibility; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
	struct UUserWidget* _widget; // 0xc0(0x08)
	char pad_C8[0x18]; // 0xc8(0x18)
};

// Class DBDUIPresenters.HudPresenter
// Size: 0x108 (Inherited: 0xe0)
struct UHudPresenter : UPresenter {
	struct ADBDPlayer* _presentedCharacter; // 0xe0(0x08)
	struct ADBDPlayer* _pendingCharacter; // 0xe8(0x08)
	struct ADBDSpectator* _spectatorPawn; // 0xf0(0x08)
	char pad_F8[0x10]; // 0xf8(0x10)

	void OnPawnUnpossessed(struct APawn* Pawn); // Function DBDUIPresenters.HudPresenter.OnPawnUnpossessed // (Final|Native|Private) // @ game+0x26e6d20
	void OnPawnPossessed(struct APawn* Pawn); // Function DBDUIPresenters.HudPresenter.OnPawnPossessed // (Final|Native|Private) // @ game+0x26e6ca0
};

// Class DBDUIPresenters.ExamplePresenter
// Size: 0x148 (Inherited: 0x108)
struct UExamplePresenter : UHudPresenter {
	struct UUserWidget* ExampleWidgetClass; // 0x108(0x08)
	char pad_110[0x38]; // 0x110(0x38)

	void OnButtonClick(); // Function DBDUIPresenters.ExamplePresenter.OnButtonClick // (Final|Native|Private) // @ game+0x26e6c80
};

// Class DBDUIPresenters.FocusHandler
// Size: 0xc8 (Inherited: 0xb8)
struct UFocusHandler : UUIComponent {
	char pad_B8[0x10]; // 0xb8(0x10)
};

// Class DBDUIPresenters.SubPresenter
// Size: 0xb8 (Inherited: 0xb8)
struct USubPresenter : UUIComponent {
};

// Class DBDUIPresenters.GameManualSubPresenter
// Size: 0xc8 (Inherited: 0xb8)
struct UGameManualSubPresenter : USubPresenter {
	struct TScriptInterface<None> _gameManualWidget; // 0xb8(0x10)
};

// Class DBDUIPresenters.HookCountPresenter
// Size: 0x150 (Inherited: 0x108)
struct UHookCountPresenter : UHudPresenter {
	struct UUserWidget* HookCountWidgetClass; // 0x108(0x08)
	char pad_110[0x40]; // 0x110(0x40)
};

// Class DBDUIPresenters.HudRootContainer
// Size: 0xb8 (Inherited: 0xb8)
struct UHudRootContainer : UUIComponent {
};

// Class DBDUIPresenters.OnboardingMenuPresenter
// Size: 0x118 (Inherited: 0xe0)
struct UOnboardingMenuPresenter : UPresenter {
	struct UUserWidget* OnboardingMenuWidgetClass; // 0xe0(0x08)
	struct UOnboardingTutorialSubPresenter* _onboardingTutorialSubPresenter; // 0xe8(0x08)
	struct UGameManualSubPresenter* _gameManualSubPresenter; // 0xf0(0x08)
	struct USubPresenter* _activeSubPresenter; // 0xf8(0x08)
	char pad_100[0x18]; // 0x100(0x18)

	void OnSetUIEnabled(bool Enabled); // Function DBDUIPresenters.OnboardingMenuPresenter.OnSetUIEnabled // (Final|Native|Private) // @ game+0x26e6f10
	void OnSelectedTabChanged(int32_t selectedTabIndex); // Function DBDUIPresenters.OnboardingMenuPresenter.OnSelectedTabChanged // (Final|Native|Private) // @ game+0x26e6e90
	void OnBackAction(); // Function DBDUIPresenters.OnboardingMenuPresenter.OnBackAction // (Final|Native|Private) // @ game+0x26e6c60
};

// Class DBDUIPresenters.OnboardingTutorialSubPresenter
// Size: 0x118 (Inherited: 0xb8)
struct UOnboardingTutorialSubPresenter : USubPresenter {
	struct TScriptInterface<None> _onboardingTutorialWidget; // 0xb8(0x10)
	char pad_C8[0x50]; // 0xc8(0x50)

	void OnSelectTutorial(struct FString stepId, struct FString tutorialId); // Function DBDUIPresenters.OnboardingTutorialSubPresenter.OnSelectTutorial // (Final|Native|Private) // @ game+0x26e6da0
};

// Class DBDUIPresenters.PawnObserver
// Size: 0xe0 (Inherited: 0xb8)
struct UPawnObserver : UUIComponent {
	char pad_B8[0x20]; // 0xb8(0x20)
	struct APawn* _pawn; // 0xd8(0x08)
};

// Class DBDUIPresenters.PresenterGroup
// Size: 0x258 (Inherited: 0x230)
struct APresenterGroup : AActor {
	struct UContextObserver* ContextObserver; // 0x230(0x08)
	struct UFocusHandler* FocusHandler; // 0x238(0x08)
	struct UPawnObserver* PawnObserver; // 0x240(0x08)
	struct URootContainer* RootContainer; // 0x248(0x08)
	struct UTweenHandler* TweenHandler; // 0x250(0x08)
};

// Class DBDUIPresenters.PresenterGroupHandler
// Size: 0xc8 (Inherited: 0xb8)
struct UPresenterGroupHandler : UUIComponent {
	struct APresenterGroup* PresenterGroupClass; // 0xb8(0x08)
	struct APresenterGroup* _presenterGroup; // 0xc0(0x08)
};

// Class DBDUIPresenters.RootContainer
// Size: 0xd0 (Inherited: 0xb8)
struct URootContainer : UUIComponent {
	struct UUserWidget* RootWidgetClass; // 0xb8(0x08)
	float UnfocusedOpacity; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct UUserWidget* _rootWidget; // 0xc8(0x08)
};

// Class DBDUIPresenters.SkillCheckPresenter
// Size: 0x140 (Inherited: 0x108)
struct USkillCheckPresenter : UHudPresenter {
	struct UUserWidget* SkillCheckWidgetClass; // 0x108(0x08)
	char pad_110[0x30]; // 0x110(0x30)

	void OnUpdateSkillCheckVisual(bool IsActive); // Function DBDUIPresenters.SkillCheckPresenter.OnUpdateSkillCheckVisual // (Final|Native|Private) // @ game+0x26e7070
	void OnShowSkillCheckSuccess(bool IsBonus); // Function DBDUIPresenters.SkillCheckPresenter.OnShowSkillCheckSuccess // (Final|Native|Private) // @ game+0x26e6fe0
	void OnShowSkillCheckFail(); // Function DBDUIPresenters.SkillCheckPresenter.OnShowSkillCheckFail // (Final|Native|Private) // @ game+0x26e6fc0
	void OnShowSkillCheck(); // Function DBDUIPresenters.SkillCheckPresenter.OnShowSkillCheck // (Final|Native|Private) // @ game+0x26e6fa0
};

// Class DBDUIPresenters.TemplatePresenter
// Size: 0x128 (Inherited: 0x108)
struct UTemplatePresenter : UHudPresenter {
	struct UUserWidget* TemplateWidgetClass; // 0x108(0x08)
	char pad_110[0x18]; // 0x110(0x18)
};

// Class DBDUIPresenters.TestPresenter
// Size: 0xf0 (Inherited: 0xe0)
struct UTestPresenter : UPresenter {
	struct UUserWidget* TestWidgetClass; // 0xe0(0x08)
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class DBDUIPresenters.TweenHandler
// Size: 0xc0 (Inherited: 0xb8)
struct UTweenHandler : UUIComponent {
	bool DoUpdate; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

// Class DBDUIPresenters.UIConsoleCommands
// Size: 0x30 (Inherited: 0x30)
struct UUIConsoleCommands : UObject {

	void DBD_ToggleTestWidget(); // Function DBDUIPresenters.UIConsoleCommands.DBD_ToggleTestWidget // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_ToggleDPICurve(); // Function DBDUIPresenters.UIConsoleCommands.DBD_ToggleDPICurve // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_SetMenuScaleFactor(float ScaleFactor); // Function DBDUIPresenters.UIConsoleCommands.DBD_SetMenuScaleFactor // (Final|Exec|Native|Public) // @ game+0x26e6b50
	void DBD_SetHudVisible(bool IsVisible); // Function DBDUIPresenters.UIConsoleCommands.DBD_SetHudVisible // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_SetHudScaleFactor(float ScaleFactor); // Function DBDUIPresenters.UIConsoleCommands.DBD_SetHudScaleFactor // (Final|Exec|Native|Public) // @ game+0x26e6b50
	void DBD_SetApplicationScale(float ApplicationScale); // Function DBDUIPresenters.UIConsoleCommands.DBD_SetApplicationScale // (Final|Exec|Native|Public) // @ game+0x26e6b50
};

