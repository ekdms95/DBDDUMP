// Enum DBDUIPresenters.EContextSection
enum class EContextSection : uint8 {
	None,
	Hud,
	MainMenu,
	Lobby,
	Store,
	Tally,
	Archive,
	Credits,
	Onboarding,
	EContextSection_MAX,
};

