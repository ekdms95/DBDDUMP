// Class DBDUIViewInterfaces.AddonViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UAddonViewInterface : UInterface {

	void SetData(struct FAddonViewData BaseLoadoutPartViewData); // Function DBDUIViewInterfaces.AddonViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed240
	void ClearData(); // Function DBDUIViewInterfaces.AddonViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.CoreBaseViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UCoreBaseViewInterface : UInterface {
};

// Class DBDUIViewInterfaces.EndGameCollapseBarViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UEndGameCollapseBarViewInterface : UInterface {

	void StartEndGameScenario(); // Function DBDUIViewInterfaces.EndGameCollapseBarViewInterface.StartEndGameScenario // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
	void SetEndGameScenarioProgressionValue(float amount); // Function DBDUIViewInterfaces.EndGameCollapseBarViewInterface.SetEndGameScenarioProgressionValue // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed740
	void SetEndGameScenarioProgressionMode(bool isSlowMode); // Function DBDUIViewInterfaces.EndGameCollapseBarViewInterface.SetEndGameScenarioProgressionMode // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed6b0
	void InitEndGameScenario(); // Function DBDUIViewInterfaces.EndGameCollapseBarViewInterface.InitEndGameScenario // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecce0
};

// Class DBDUIViewInterfaces.EquippedItemViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UEquippedItemViewInterface : UInterface {

	void SetData(struct FItemBundleViewData itemBundleData); // Function DBDUIViewInterfaces.EquippedItemViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed300
	void SetActiveState(bool IsActive); // Function DBDUIViewInterfaces.EquippedItemViewInterface.SetActiveState // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecda0
	void ClearData(); // Function DBDUIViewInterfaces.EquippedItemViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbf0
};

// Class DBDUIViewInterfaces.EquippedPowerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UEquippedPowerViewInterface : UInterface {

	void SetData(struct FPowerBundleViewData powerBundleData); // Function DBDUIViewInterfaces.EquippedPowerViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed460
	void SetCarryingMode(bool IsCarrying); // Function DBDUIViewInterfaces.EquippedPowerViewInterface.SetCarryingMode // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ece30
	void SetActiveState(bool IsActive); // Function DBDUIViewInterfaces.EquippedPowerViewInterface.SetActiveState // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecda0
	void ClearData(); // Function DBDUIViewInterfaces.EquippedPowerViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc10
};

// Class DBDUIViewInterfaces.ExampleViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UExampleViewInterface : UInterface {

	void SetExampleText(struct FString Text); // Function DBDUIViewInterfaces.ExampleViewInterface.SetExampleText // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed7c0
	void SetExampleProgressRatio(float Ratio); // Function DBDUIViewInterfaces.ExampleViewInterface.SetExampleProgressRatio // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc30
};

// Class DBDUIViewInterfaces.ExternalEffectsViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UExternalEffectsViewInterface : UInterface {

	void ShowExternalPerk(struct FPerkViewData PerkViewData); // Function DBDUIViewInterfaces.ExternalEffectsViewInterface.ShowExternalPerk // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26edaa0
	void ShowExternalAddon(struct FAddonViewData AddonViewData); // Function DBDUIViewInterfaces.ExternalEffectsViewInterface.ShowExternalAddon // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed9e0
};

// Class DBDUIViewInterfaces.GameManualViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UGameManualViewInterface : UInterface {

	void SetCurrentManualMenuState(enum class EGameManualMenuState menuState); // Function DBDUIViewInterfaces.GameManualViewInterface.SetCurrentManualMenuState // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed1c0
	void SetCategoryData(struct FHelpCategoryData categoryData, struct TArray<struct FHelpTopicData> topicsData); // Function DBDUIViewInterfaces.GameManualViewInterface.SetCategoryData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ecec0
	enum class EGameManualMenuState GetCurrentManualMenuState(); // Function DBDUIViewInterfaces.GameManualViewInterface.GetCurrentManualMenuState // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x26eccb0
};

// Class DBDUIViewInterfaces.HookCountViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UHookCountViewInterface : UInterface {

	void SetData(int32_t currentHookCount, int32_t maxHookCount, int32_t initialMaxHookCount); // Function DBDUIViewInterfaces.HookCountViewInterface.SetData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed5c0
	void InitWidget(); // Function DBDUIViewInterfaces.HookCountViewInterface.InitWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc10
	void ClearData(); // Function DBDUIViewInterfaces.HookCountViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.HudAlertViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UHudAlertViewInterface : UInterface {

	void ShowStatusEffectAlert(struct FStatusEffectAlertViewData Data); // Function DBDUIViewInterfaces.HudAlertViewInterface.ShowStatusEffectAlert // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26edc20
	void ShowScoreAlert(struct FScoreAlertViewData Data); // Function DBDUIViewInterfaces.HudAlertViewInterface.ShowScoreAlert // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26edb70
	void FadeOut(float Delay); // Function DBDUIViewInterfaces.HudAlertViewInterface.FadeOut // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc30
	void FadeIn(); // Function DBDUIViewInterfaces.HudAlertViewInterface.FadeIn // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbf0
};

// Class DBDUIViewInterfaces.HudObjectiveViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UHudObjectiveViewInterface : UInterface {

	void SetHudObjectivePosition(bool isHookCountDisplayed); // Function DBDUIViewInterfaces.HudObjectiveViewInterface.SetHudObjectivePosition // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecda0
	void SetHudObjectiveData(struct FHudObjectiveViewData HudObjectiveViewData); // Function DBDUIViewInterfaces.HudObjectiveViewInterface.SetHudObjectiveData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed860
	void SetCurrentHudObjectiveHighlight(bool Highlight); // Function DBDUIViewInterfaces.HudObjectiveViewInterface.SetCurrentHudObjectiveHighlight // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ece30
	void ClearData(); // Function DBDUIViewInterfaces.HudObjectiveViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc10
};

// Class DBDUIViewInterfaces.InteractionProgressViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UInteractionProgressViewInterface : UInterface {

	void UpdateInputProgress(float Progress, float itemCharge); // Function DBDUIViewInterfaces.InteractionProgressViewInterface.UpdateInputProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26eddb0
	void SetInputProgressPrompt(struct FInteractionProgressViewData Data); // Function DBDUIViewInterfaces.InteractionProgressViewInterface.SetInputProgressPrompt // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26ed900
	void HideInputProgressPrompt(); // Function DBDUIViewInterfaces.InteractionProgressViewInterface.HideInputProgressPrompt // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.InteractionPromptsContainerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UInteractionPromptsContainerViewInterface : UInterface {

	void RemovePrompt(struct FName ID); // Function DBDUIViewInterfaces.InteractionPromptsContainerViewInterface.RemovePrompt // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecd00
	void RemoveAllPrompts(); // Function DBDUIViewInterfaces.InteractionPromptsContainerViewInterface.RemoveAllPrompts // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
	void AddPrompt(struct FInteractionPromptViewData Data); // Function DBDUIViewInterfaces.InteractionPromptsContainerViewInterface.AddPrompt // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26eca20
};

// Class DBDUIViewInterfaces.ItemBundleViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UItemBundleViewInterface : UInterface {

	void SetData(struct FItemBundleViewData ItemBundleViewData); // Function DBDUIViewInterfaces.ItemBundleViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f2f00
	void ClearData(); // Function DBDUIViewInterfaces.ItemBundleViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.ItemInteractionViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UItemInteractionViewInterface : UInterface {

	void SetData(struct FItemBundleViewData itemBundleData); // Function DBDUIViewInterfaces.ItemInteractionViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f2f00
	void ClearData(); // Function DBDUIViewInterfaces.ItemInteractionViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.ItemViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UItemViewInterface : UInterface {

	void SetData(struct FItemViewData ItemViewData); // Function DBDUIViewInterfaces.ItemViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3060
	void ClearData(); // Function DBDUIViewInterfaces.ItemViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.LeaningArrowsViewInterface
// Size: 0x30 (Inherited: 0x30)
struct ULeaningArrowsViewInterface : UInterface {

	void SetData(enum class ELeanState leanState); // Function DBDUIViewInterfaces.LeaningArrowsViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3160
};

// Class DBDUIViewInterfaces.MatchResultViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UMatchResultViewInterface : UInterface {

	void UpdateWidget(struct FMatchResultViewData Data); // Function DBDUIViewInterfaces.MatchResultViewInterface.UpdateWidget // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3960
	void PlayAnimationSequence(); // Function DBDUIViewInterfaces.MatchResultViewInterface.PlayAnimationSequence // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.OfferingInteractionViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UOfferingInteractionViewInterface : UInterface {

	void SetData(struct FOfferingViewData OfferingData); // Function DBDUIViewInterfaces.OfferingInteractionViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f31f0
	void ClearData(); // Function DBDUIViewInterfaces.OfferingInteractionViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.OfferingViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UOfferingViewInterface : UInterface {

	void SetData(struct FOfferingViewData OfferingViewData); // Function DBDUIViewInterfaces.OfferingViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f31f0
	void ClearData(); // Function DBDUIViewInterfaces.OfferingViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.OnboardingMenuViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UOnboardingMenuViewInterface : UInterface {

	void SetUIEnabled(bool Enabled); // Function DBDUIViewInterfaces.OnboardingMenuViewInterface.SetUIEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecda0
	void SetOnboardingMenuState(enum class EOnboardingMenuState State); // Function DBDUIViewInterfaces.OnboardingMenuViewInterface.SetOnboardingMenuState // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f3480
	void SetFirstTimeUserExperience(bool ftue); // Function DBDUIViewInterfaces.OnboardingMenuViewInterface.SetFirstTimeUserExperience // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ece30
	struct TScriptInterface<None> GetOnboardingTutorialInterface(); // Function DBDUIViewInterfaces.OnboardingMenuViewInterface.GetOnboardingTutorialInterface // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x26f2e10
	struct TScriptInterface<None> GetGameManualInterface(); // Function DBDUIViewInterfaces.OnboardingMenuViewInterface.GetGameManualInterface // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x26f2dd0
};

// Class DBDUIViewInterfaces.OnboardingTutorialViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UOnboardingTutorialViewInterface : UInterface {

	void UpdateProgress(struct TArray<struct FOnboardingStepViewData> before, struct TArray<struct FOnboardingStepViewData> after, struct TArray<struct FRewardWrapperViewData> Rewards); // Function DBDUIViewInterfaces.OnboardingTutorialViewInterface.UpdateProgress // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3750
	void StopLoadingSpinner(); // Function DBDUIViewInterfaces.OnboardingTutorialViewInterface.StopLoadingSpinner // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbf0
	void SetUIEnabled(bool Enabled); // Function DBDUIViewInterfaces.OnboardingTutorialViewInterface.SetUIEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecda0
	void SetTutorialDescription(struct FString completedStepId); // Function DBDUIViewInterfaces.OnboardingTutorialViewInterface.SetTutorialDescription // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f36b0
	void SetProgress(struct TArray<struct FOnboardingStepViewData> Progress); // Function DBDUIViewInterfaces.OnboardingTutorialViewInterface.SetProgress // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3500
};

// Class DBDUIViewInterfaces.PerksContainerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPerksContainerViewInterface : UInterface {

	struct TScriptInterface<None> GetPerkInterface(int32_t Index); // Function DBDUIViewInterfaces.PerksContainerViewInterface.GetPerkInterface // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f2e50
};

// Class DBDUIViewInterfaces.PerkViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPerkViewInterface : UInterface {

	void UpdatePerkCooldown(float cooldownValue); // Function DBDUIViewInterfaces.PerkViewInterface.UpdatePerkCooldown // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed740
	void SetData(struct FPerkViewData PerkViewData); // Function DBDUIViewInterfaces.PerkViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f32b0
	void ClearData(); // Function DBDUIViewInterfaces.PerkViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.PingStatusViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPingStatusViewInterface : UInterface {

	void SetData(enum class EPingQuality pingQuality); // Function DBDUIViewInterfaces.PingStatusViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3160
};

// Class DBDUIViewInterfaces.PlayerStatusesContainerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPlayerStatusesContainerViewInterface : UInterface {

	struct TScriptInterface<None> GetPlayerStatusInterface(int32_t Index); // Function DBDUIViewInterfaces.PlayerStatusesContainerViewInterface.GetPlayerStatusInterface // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f2e50
};

// Class DBDUIViewInterfaces.PlayerStatusViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPlayerStatusViewInterface : UInterface {

	void TriggerAfflictionHit(); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.TriggerAfflictionHit // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
	void SetTimerProgress(float value, bool IsDeepWound); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.SetTimerProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f35e0
	void SetData(struct FPlayerStatusViewData Data); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f3380
	void PlayTimerAnimation(); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.PlayTimerAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc10
	void PlayHookEscapeFailedAnimation(); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.PlayHookEscapeFailedAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbf0
	void ClearData(); // Function DBDUIViewInterfaces.PlayerStatusViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f2db0
};

// Class DBDUIViewInterfaces.PowerBundleViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPowerBundleViewInterface : UInterface {

	void SetData(struct FPowerBundleViewData PowerBundleViewData); // Function DBDUIViewInterfaces.PowerBundleViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7a20
	void ClearData(); // Function DBDUIViewInterfaces.PowerBundleViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.PowerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UPowerViewInterface : UInterface {

	void SetData(struct FPowerViewData PowerViewData); // Function DBDUIViewInterfaces.PowerViewInterface.SetData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7b80
	void ClearData(); // Function DBDUIViewInterfaces.PowerViewInterface.ClearData // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.ScreenIndicatorsContainerViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UScreenIndicatorsContainerViewInterface : UInterface {

	void ShowDirectionIndicator(struct FScreenIndicatorViewData Data); // Function DBDUIViewInterfaces.ScreenIndicatorsContainerViewInterface.ShowDirectionIndicator // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7e00
	void RemoveDirectionIndicator(struct FString ID); // Function DBDUIViewInterfaces.ScreenIndicatorsContainerViewInterface.RemoveDirectionIndicator // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f7840
};

// Class DBDUIViewInterfaces.SkillCheckViewInterface
// Size: 0x30 (Inherited: 0x30)
struct USkillCheckViewInterface : UInterface {

	void UpdateProgress(float value); // Function DBDUIViewInterfaces.SkillCheckViewInterface.UpdateProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f8270
	void UpdatePositionOffset(int32_t X, int32_t Y); // Function DBDUIViewInterfaces.SkillCheckViewInterface.UpdatePositionOffset // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f81b0
	void ShowSkillCheckSuccess(bool IsBonus); // Function DBDUIViewInterfaces.SkillCheckViewInterface.ShowSkillCheckSuccess // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ece30
	void ShowSkillCheckFail(); // Function DBDUIViewInterfaces.SkillCheckViewInterface.ShowSkillCheckFail // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc10
	void ShowSkillCheck(struct FSkillCheckViewData skillCheckData); // Function DBDUIViewInterfaces.SkillCheckViewInterface.ShowSkillCheck // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7f80
	void HideSkillCheck(); // Function DBDUIViewInterfaces.SkillCheckViewInterface.HideSkillCheck // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f7820
	void ApplyScaleFactor(float Scale); // Function DBDUIViewInterfaces.SkillCheckViewInterface.ApplyScaleFactor // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecc30
};

// Class DBDUIViewInterfaces.SpectateBarViewInterface
// Size: 0x30 (Inherited: 0x30)
struct USpectateBarViewInterface : UInterface {

	void SetSpectatedName(struct FString PlayerName); // Function DBDUIViewInterfaces.SpectateBarViewInterface.SetSpectatedName // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26f7840
	void SetSpectateBarVisibility(bool IsVisible); // Function DBDUIViewInterfaces.SpectateBarViewInterface.SetSpectateBarVisibility // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed6b0
	void SetArrowsVisibility(bool IsVisible); // Function DBDUIViewInterfaces.SpectateBarViewInterface.SetArrowsVisibility // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ece30
};

// Class DBDUIViewInterfaces.StartSequenceViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UStartSequenceViewInterface : UInterface {

	void ShowStartSequence(struct FStartSequenceViewData Data); // Function DBDUIViewInterfaces.StartSequenceViewInterface.ShowStartSequence // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f8060
	void HideStartSequence(); // Function DBDUIViewInterfaces.StartSequenceViewInterface.HideStartSequence // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
	bool GetIsStartSequenceVisible(); // Function DBDUIViewInterfaces.StartSequenceViewInterface.GetIsStartSequenceVisible // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x26f77f0
};

// Class DBDUIViewInterfaces.StatusEffectViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UStatusEffectViewInterface : UInterface {

	void ShowActiveStatusEffect(struct FStatusEffectViewData statusEffectData); // Function DBDUIViewInterfaces.StatusEffectViewInterface.ShowActiveStatusEffect // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7d50
	void RemoveExistingStatusEffect(struct FName statusEffectId); // Function DBDUIViewInterfaces.StatusEffectViewInterface.RemoveExistingStatusEffect // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f78e0
};

// Class DBDUIViewInterfaces.TemplateViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTemplateViewInterface : UInterface {

	void TemplateExampleFunction(struct FTemplateViewData TemplateData); // Function DBDUIViewInterfaces.TemplateViewInterface.TemplateExampleFunction // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f8120
};

// Class DBDUIViewInterfaces.TestBuildFlagViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTestBuildFlagViewInterface : UInterface {

	void UpdateWidget(enum class ETestBuildType testBuildType); // Function DBDUIViewInterfaces.TestBuildFlagViewInterface.UpdateWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ed1c0
};

// Class DBDUIViewInterfaces.TutorialHighlightViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTutorialHighlightViewInterface : UInterface {

	void SetTutorialHighlight(bool show, enum class EHudComponent componentId); // Function DBDUIViewInterfaces.TutorialHighlightViewInterface.SetTutorialHighlight // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7c80
};

// Class DBDUIViewInterfaces.TutorialMysteryNoteViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTutorialMysteryNoteViewInterface : UInterface {

	void ShowMysteryNote(struct FNotifTutorialPopupViewData notifData); // Function DBDUIViewInterfaces.TutorialMysteryNoteViewInterface.ShowMysteryNote // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7ec0
	void HideMysteryNote(); // Function DBDUIViewInterfaces.TutorialMysteryNoteViewInterface.HideMysteryNote // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

// Class DBDUIViewInterfaces.TutorialObjectivesViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTutorialObjectivesViewInterface : UInterface {

	void RemoveTutorialObjective(struct FName ID); // Function DBDUIViewInterfaces.TutorialObjectivesViewInterface.RemoveTutorialObjective // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7980
	void RemoveAllTutorialObjectives(); // Function DBDUIViewInterfaces.TutorialObjectivesViewInterface.RemoveAllTutorialObjectives // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbf0
	void CompleteTutorialObjective(struct FName ID, bool removeAfterCompletion); // Function DBDUIViewInterfaces.TutorialObjectivesViewInterface.CompleteTutorialObjective // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7700
	void AddTutorialObjective(struct FName ID, struct FTutorialObjectivesViewData InteractionPromptViewData); // Function DBDUIViewInterfaces.TutorialObjectivesViewInterface.AddTutorialObjective // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f75d0
};

// Class DBDUIViewInterfaces.TutorialPopupViewInterface
// Size: 0x30 (Inherited: 0x30)
struct UTutorialPopupViewInterface : UInterface {

	void ShowNotifTutorialPopup(struct FNotifTutorialPopupViewData notifTutoData); // Function DBDUIViewInterfaces.TutorialPopupViewInterface.ShowNotifTutorialPopup // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x26f7ec0
	void HideTutorialPopup(); // Function DBDUIViewInterfaces.TutorialPopupViewInterface.HideTutorialPopup // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x26ecbd0
};

