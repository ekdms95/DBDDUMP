// Enum DBDUIViewInterfaces.EGameManualMenuState
enum class EGameManualMenuState : uint8 {
	Categories,
	Topics,
	EGameManualMenuState_MAX,
};

// Enum DBDUIViewInterfaces.ESingleHookState
enum class ESingleHookState : uint8 {
	EMPTY,
	UNHOOKED,
	HOOKED,
	DISCONNECTED,
	ESingleHookState_MAX,
};

// Enum DBDUIViewInterfaces.EHudStatusEffectAlertViewType
enum class EHudStatusEffectAlertViewType : uint8 {
	Unhandled,
	Perk,
	Item,
	Addon,
	EHudStatusEffectAlertViewType_MAX,
};

// Enum DBDUIViewInterfaces.EInteractionPromptType
enum class EInteractionPromptType : uint8 {
	PressButton,
	MashButton,
	HoldButton,
	AlternateTwoButtons,
	WiggleThumbstick,
	MovementAxes,
	MovementKeys,
	EInteractionPromptType_MAX,
};

// Enum DBDUIViewInterfaces.EKillerResult
enum class EKillerResult : uint8 {
	DisgracefulDefeat,
	EntityDispleased,
	BrutalKiller,
	RuthlessKiller,
	MercilessKiller,
	EKillerResult_MAX,
};

// Enum DBDUIViewInterfaces.EOnboardingMenuState
enum class EOnboardingMenuState : uint8 {
	Tutorial,
	GameManual,
	EOnboardingMenuState_MAX,
};

// ScriptStruct DBDUIViewInterfaces.BaseLoadoutPartViewData
// Size: 0x30 (Inherited: 0x00)
struct FBaseLoadoutPartViewData {
	struct FName ItemId; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UTexture2D* IconTexture; // 0x10(0x08)
	struct FString DisplayName; // 0x18(0x10)
	enum class EItemRarity Rarity; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct DBDUIViewInterfaces.AddonViewData
// Size: 0x38 (Inherited: 0x30)
struct FAddonViewData : FBaseLoadoutPartViewData {
	float Cooldown; // 0x30(0x04)
	enum class EStatusEffectType StatusEffectType; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct DBDUIViewInterfaces.RewardViewData
// Size: 0x02 (Inherited: 0x00)
struct FRewardViewData {
	bool IsLocked; // 0x00(0x01)
	bool IsHighlighted; // 0x01(0x01)
};

// ScriptStruct DBDUIViewInterfaces.CharacterRewardViewData
// Size: 0x78 (Inherited: 0x02)
struct FCharacterRewardViewData : FRewardViewData {
	char pad_2[0x6]; // 0x02(0x06)
	struct UTexture2D* IconTexture; // 0x08(0x08)
	bool IsOwned; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t Level; // 0x14(0x04)
	int32_t Prestige; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FCharacterTooltipViewData TooltipData; // 0x20(0x58)
};

// ScriptStruct DBDUIViewInterfaces.CharacterTooltipViewData
// Size: 0x58 (Inherited: 0x00)
struct FCharacterTooltipViewData {
	struct FText DisplayName; // 0x00(0x18)
	struct FText Biography; // 0x18(0x18)
	struct FText DLCTitle; // 0x30(0x18)
	int32_t Level; // 0x48(0x04)
	int32_t Prestige; // 0x4c(0x04)
	bool IsUnlocked; // 0x50(0x01)
	bool IsNewInStore; // 0x51(0x01)
	bool IsOwned; // 0x52(0x01)
	bool IsAvailableInStore; // 0x53(0x01)
	bool IsDLCPurchasable; // 0x54(0x01)
	enum class ECharacterDifficulty Difficulty; // 0x55(0x01)
	char pad_56[0x2]; // 0x56(0x02)
};

// ScriptStruct DBDUIViewInterfaces.CurrencyRewardViewData
// Size: 0x48 (Inherited: 0x02)
struct FCurrencyRewardViewData : FRewardViewData {
	char pad_2[0x2]; // 0x02(0x02)
	int32_t CurrencyAmount; // 0x04(0x04)
	enum class ECurrencyType CurrencyType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FCurrencyTooltipViewData TooltipData; // 0x10(0x38)
};

// ScriptStruct DBDUIViewInterfaces.CurrencyTooltipViewData
// Size: 0x38 (Inherited: 0x00)
struct FCurrencyTooltipViewData {
	enum class ECurrencyType CurrencyType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t amount; // 0x04(0x04)
	struct FText CurrencyDescription; // 0x08(0x18)
	struct FText EndTiming; // 0x20(0x18)
};

// ScriptStruct DBDUIViewInterfaces.CustomizationRewardViewData
// Size: 0xc0 (Inherited: 0x02)
struct FCustomizationRewardViewData : FRewardViewData {
	char pad_2[0x6]; // 0x02(0x06)
	struct UTexture2D* IconTexture; // 0x08(0x08)
	enum class EItemRarity Rarity; // 0x10(0x01)
	bool IsOwned; // 0x11(0x01)
	bool IsEquipped; // 0x12(0x01)
	bool IsUnbreakable; // 0x13(0x01)
	char pad_14[0x4]; // 0x14(0x04)
	struct FCustomizationTooltipViewData TooltipData; // 0x18(0xa8)
};

// ScriptStruct DBDUIViewInterfaces.CustomizationTooltipViewData
// Size: 0xa8 (Inherited: 0x00)
struct FCustomizationTooltipViewData {
	struct FText DisplayName; // 0x00(0x18)
	struct FText ParentName; // 0x18(0x18)
	struct FText RarityPartInfo; // 0x30(0x18)
	struct FText CollectionDisplayName; // 0x48(0x18)
	struct FText Description; // 0x60(0x18)
	struct FText RoleCategoryInfo; // 0x78(0x18)
	bool IsLocked; // 0x90(0x01)
	bool IsUnbreakable; // 0x91(0x01)
	bool IsEquipped; // 0x92(0x01)
	bool IsOwned; // 0x93(0x01)
	enum class EPlayerRole AssociatedRole; // 0x94(0x01)
	enum class EItemRarity Rarity; // 0x95(0x01)
	char pad_96[0x2]; // 0x96(0x02)
	struct TArray<struct FPriceViewData> Prices; // 0x98(0x10)
};

// ScriptStruct DBDUIViewInterfaces.PriceViewData
// Size: 0x10 (Inherited: 0x00)
struct FPriceViewData {
	enum class ECurrencyType CurrencyType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Price; // 0x04(0x04)
	float Discount; // 0x08(0x04)
	bool IsAffordable; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct DBDUIViewInterfaces.StatusEffectAlertViewData
// Size: 0x100 (Inherited: 0x00)
struct FStatusEffectAlertViewData {
	struct FString StatusEffectName; // 0x00(0x10)
	struct UTexture2D* StatusEffectIcon; // 0x10(0x08)
	enum class EStatusEffectType StatusEffectType; // 0x18(0x01)
	enum class EHudStatusEffectAlertViewType SourceViewType; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct FPerkViewData PerkViewData; // 0x20(0x40)
	struct FItemViewData ItemViewData; // 0x60(0x68)
	struct FAddonViewData AddonViewData; // 0xc8(0x38)
};

// ScriptStruct DBDUIViewInterfaces.ItemViewData
// Size: 0x68 (Inherited: 0x30)
struct FItemViewData : FBaseLoadoutPartViewData {
	bool IsEnergyTypeValid; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float EnergyLevel; // 0x34(0x04)
	int32_t count; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FKey InputKey; // 0x40(0x20)
	bool ShowKeyPrompt; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct DBDUIViewInterfaces.PerkViewData
// Size: 0x40 (Inherited: 0x30)
struct FPerkViewData : FBaseLoadoutPartViewData {
	int32_t Level; // 0x30(0x04)
	float Cooldown; // 0x34(0x04)
	enum class EStatusEffectType StatusEffectType; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t StackCount; // 0x3c(0x04)
};

// ScriptStruct DBDUIViewInterfaces.ScoreAlertViewData
// Size: 0x20 (Inherited: 0x00)
struct FScoreAlertViewData {
	enum class EDBDScoreCategory scoreType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Title; // 0x08(0x10)
	int32_t ScoreValue; // 0x18(0x04)
	float Progress; // 0x1c(0x04)
};

// ScriptStruct DBDUIViewInterfaces.HudObjectiveViewData
// Size: 0x08 (Inherited: 0x00)
struct FHudObjectiveViewData {
	enum class EPlayerTeam playerTeam; // 0x00(0x01)
	bool isHatchOpen; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t nbGeneratorsLeft; // 0x04(0x04)
};

// ScriptStruct DBDUIViewInterfaces.InteractionProgressViewData
// Size: 0x40 (Inherited: 0x00)
struct FInteractionProgressViewData {
	struct FString Message; // 0x00(0x10)
	struct FString SecondaryMessage; // 0x10(0x10)
	enum class EBarColor BarColor; // 0x20(0x01)
	enum class EBarColor ChargeBarColor; // 0x21(0x01)
	bool ShowIcon; // 0x22(0x01)
	bool ShowIconCharge; // 0x23(0x01)
	char pad_24[0x4]; // 0x24(0x04)
	struct UTexture2D* ItemIcon; // 0x28(0x08)
	struct TArray<struct FStatusEffectViewData> Proficiencies; // 0x30(0x10)
};

// ScriptStruct DBDUIViewInterfaces.StatusEffectViewData
// Size: 0x28 (Inherited: 0x00)
struct FStatusEffectViewData {
	struct FName ID; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UTexture2D* IconTexture; // 0x10(0x08)
	enum class EStatusEffectType StatusEffectType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t Level; // 0x1c(0x04)
	float Percentage; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DBDUIViewInterfaces.InteractionPromptViewData
// Size: 0xb0 (Inherited: 0x00)
struct FInteractionPromptViewData {
	struct FName ID; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Message; // 0x10(0x10)
	enum class EInteractionPromptType Type; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FKey InputKey1; // 0x28(0x20)
	struct FKey InputKey2; // 0x48(0x20)
	struct FKey InputKey3; // 0x68(0x20)
	struct FKey InputKey4; // 0x88(0x20)
	bool PlaceInCenter; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// ScriptStruct DBDUIViewInterfaces.ItemBundleViewData
// Size: 0xd8 (Inherited: 0x00)
struct FItemBundleViewData {
	struct FItemViewData item; // 0x00(0x68)
	struct FAddonViewData Addon1; // 0x68(0x38)
	struct FAddonViewData Addon2; // 0xa0(0x38)
};

// ScriptStruct DBDUIViewInterfaces.MatchResultViewData
// Size: 0x08 (Inherited: 0x00)
struct FMatchResultViewData {
	bool IsSlasher; // 0x00(0x01)
	enum class EGameState SurvivorResult; // 0x01(0x01)
	enum class EKillerResult KillerResult; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	float Duration; // 0x04(0x04)
};

// ScriptStruct DBDUIViewInterfaces.NotifTutorialPopupViewData
// Size: 0x30 (Inherited: 0x00)
struct FNotifTutorialPopupViewData {
	struct FString Title; // 0x00(0x10)
	struct FString Description; // 0x10(0x10)
	struct UTexture2D* Icon; // 0x20(0x08)
	struct UTexture2D* Image; // 0x28(0x08)
};

// ScriptStruct DBDUIViewInterfaces.OfferingViewData
// Size: 0x38 (Inherited: 0x30)
struct FOfferingViewData : FBaseLoadoutPartViewData {
	int32_t StackCount; // 0x30(0x04)
	enum class EItemAvailability Availability; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct DBDUIViewInterfaces.OnboardingStepViewData
// Size: 0x28 (Inherited: 0x00)
struct FOnboardingStepViewData {
	struct FString stepId; // 0x00(0x10)
	enum class EOnboardingStepStatus status; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FOnboardingTutorialViewData> Tutorials; // 0x18(0x10)
};

// ScriptStruct DBDUIViewInterfaces.OnboardingTutorialViewData
// Size: 0x78 (Inherited: 0x00)
struct FOnboardingTutorialViewData {
	struct FString tutorialId; // 0x00(0x10)
	bool COMPLETED; // 0x10(0x01)
	bool MainRewardClaimed; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
	struct TArray<struct FRewardWrapperViewData> MainRewards; // 0x18(0x10)
	struct TArray<struct FRewardWrapperViewData> AlternativeRewards; // 0x28(0x10)
	enum class EOnboardingTutorialType TutorialType; // 0x38(0x01)
	enum class EOnboardingTutorialButtonStyle ButtonStyle; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
	struct FText DisplayName; // 0x40(0x18)
	struct FText Description; // 0x58(0x18)
	struct UTexture2D* Icon; // 0x70(0x08)
};

// ScriptStruct DBDUIViewInterfaces.RewardWrapperViewData
// Size: 0x198 (Inherited: 0x00)
struct FRewardWrapperViewData {
	enum class ERewardType RewardType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FCharacterRewardViewData CharacterRewardViewData; // 0x08(0x78)
	struct FCurrencyRewardViewData CurrencyRewardViewData; // 0x80(0x48)
	struct FCustomizationRewardViewData CustomizationRewardViewData; // 0xc8(0xc0)
	struct FProgressionRewardViewData ProgressionRewardViewData; // 0x188(0x0c)
	char pad_194[0x4]; // 0x194(0x04)
};

// ScriptStruct DBDUIViewInterfaces.ProgressionRewardViewData
// Size: 0x0c (Inherited: 0x02)
struct FProgressionRewardViewData : FRewardViewData {
	char pad_2[0x2]; // 0x02(0x02)
	int32_t ProgressionAmount; // 0x04(0x04)
	enum class EProgressionType CurrencyType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct DBDUIViewInterfaces.PlayerStatusViewData
// Size: 0x78 (Inherited: 0x00)
struct FPlayerStatusViewData {
	struct FString PlayerName; // 0x00(0x10)
	enum class EGender Gender; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct UTexture2D* PlayerPortraitIcon; // 0x18(0x08)
	struct UTexture2D* PlayerPortraitIconOverride; // 0x20(0x08)
	enum class EPlayerStatus PlayerStatusState; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float TimerProgress; // 0x2c(0x04)
	bool IsDeepWound; // 0x30(0x01)
	bool IsBroken; // 0x31(0x01)
	bool IsLocalPlayerAKiller; // 0x32(0x01)
	enum class EObsessionUIState ObsessionState; // 0x33(0x01)
	int32_t DrainStage; // 0x34(0x04)
	struct FDoctorStatusData DoctorStatusData; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	struct FExecutionerStatusData ExecutionerStatusData; // 0x3c(0x04)
	struct FGhostStatusData GhostStatusData; // 0x40(0x08)
	struct FNightmareStatusData NightmareStatusData; // 0x48(0x0c)
	struct FPigStatusData PigStatusData; // 0x54(0x08)
	struct FPlagueStatusData PlagueStatusData; // 0x5c(0x08)
	struct FTwinsStatusData TwinsStatusData; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	struct FTricksterStatusData TricksterStatusData; // 0x68(0x0c)
	struct FK24StatusData K24StatusData; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
};

// ScriptStruct DBDUIViewInterfaces.K24StatusData
// Size: 0x01 (Inherited: 0x00)
struct FK24StatusData {
	bool IsContaminated; // 0x00(0x01)
};

// ScriptStruct DBDUIViewInterfaces.TricksterStatusData
// Size: 0x0c (Inherited: 0x00)
struct FTricksterStatusData {
	float CurrentLacerationLevel; // 0x00(0x04)
	float MaximumLacerationLevel; // 0x04(0x04)
	bool IsDangerousLacerationLevel; // 0x08(0x01)
	bool WasRecentlyDamagedByLaceration; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct DBDUIViewInterfaces.TwinsStatusData
// Size: 0x01 (Inherited: 0x00)
struct FTwinsStatusData {
	bool TwinsActive; // 0x00(0x01)
};

// ScriptStruct DBDUIViewInterfaces.PlagueStatusData
// Size: 0x08 (Inherited: 0x00)
struct FPlagueStatusData {
	enum class ESicknessLevel SicknessLevel; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float SicknessProgress; // 0x04(0x04)
};

// ScriptStruct DBDUIViewInterfaces.PigStatusData
// Size: 0x08 (Inherited: 0x00)
struct FPigStatusData {
	enum class EReverseBearTrapUIState ReverseBearTrapState; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float TimerProgress; // 0x04(0x04)
};

// ScriptStruct DBDUIViewInterfaces.NightmareStatusData
// Size: 0x0c (Inherited: 0x00)
struct FNightmareStatusData {
	enum class ESleepingUIState SleepingState; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float SleepingProgress; // 0x04(0x04)
	float SleepProtectionRemainingDuration; // 0x08(0x04)
};

// ScriptStruct DBDUIViewInterfaces.GhostStatusData
// Size: 0x08 (Inherited: 0x00)
struct FGhostStatusData {
	bool IsExposed; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float StalkingProgress; // 0x04(0x04)
};

// ScriptStruct DBDUIViewInterfaces.ExecutionerStatusData
// Size: 0x04 (Inherited: 0x00)
struct FExecutionerStatusData {
	float AgonyProgress; // 0x00(0x04)
};

// ScriptStruct DBDUIViewInterfaces.DoctorStatusData
// Size: 0x01 (Inherited: 0x00)
struct FDoctorStatusData {
	enum class EAfflictionLevel AfflictionLevel; // 0x00(0x01)
};

// ScriptStruct DBDUIViewInterfaces.PowerBundleViewData
// Size: 0xd0 (Inherited: 0x00)
struct FPowerBundleViewData {
	struct FPowerViewData Power; // 0x00(0x60)
	struct FAddonViewData Addon1; // 0x60(0x38)
	struct FAddonViewData Addon2; // 0x98(0x38)
};

// ScriptStruct DBDUIViewInterfaces.PowerViewData
// Size: 0x60 (Inherited: 0x30)
struct FPowerViewData : FBaseLoadoutPartViewData {
	struct FKey InputKey; // 0x30(0x20)
	bool IsRechargeable; // 0x50(0x01)
	bool IsActivated; // 0x51(0x01)
	char pad_52[0x2]; // 0x52(0x02)
	int32_t count; // 0x54(0x04)
	float ProgressValue; // 0x58(0x04)
	bool ShowKeyPrompt; // 0x5c(0x01)
	bool IsCountDisplayForced; // 0x5d(0x01)
	char pad_5E[0x2]; // 0x5e(0x02)
};

// ScriptStruct DBDUIViewInterfaces.ScreenIndicatorViewData
// Size: 0x30 (Inherited: 0x00)
struct FScreenIndicatorViewData {
	struct FString ID; // 0x00(0x10)
	bool IsInFront; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FVector2D ScreenPosition; // 0x14(0x08)
	float Distance; // 0x1c(0x04)
	struct UTexture2D* IndicatorIcon; // 0x20(0x08)
	enum class EHudScreenIndicatorType IndicatorType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct DBDUIViewInterfaces.SkillCheckViewData
// Size: 0x38 (Inherited: 0x00)
struct FSkillCheckViewData {
	struct FKey InputKey; // 0x00(0x20)
	float HitAreaStart; // 0x20(0x04)
	float HitAreaLength; // 0x24(0x04)
	float BonusAreaStart; // 0x28(0x04)
	float BonusAreaLength; // 0x2c(0x04)
	bool IsHexed; // 0x30(0x01)
	bool IsSpectating; // 0x31(0x01)
	bool IsReversed; // 0x32(0x01)
	bool IsMirrored; // 0x33(0x01)
	bool IsInsane; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct DBDUIViewInterfaces.StartSequenceViewData
// Size: 0x28 (Inherited: 0x00)
struct FStartSequenceViewData {
	struct FString ThemeName; // 0x00(0x10)
	struct FString MapName; // 0x10(0x10)
	enum class EThemeColorId ThemeColorId; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DBDUIViewInterfaces.TemplateViewData
// Size: 0x01 (Inherited: 0x00)
struct FTemplateViewData {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DBDUIViewInterfaces.TutorialObjectivesViewData
// Size: 0x170 (Inherited: 0x00)
struct FTutorialObjectivesViewData {
	struct FString Description; // 0x00(0x10)
	struct FInteractionPromptViewData PrimaryInteractionPromptViewData; // 0x10(0xb0)
	struct FInteractionPromptViewData SecondaryInteractionPromptViewData; // 0xc0(0xb0)
};

