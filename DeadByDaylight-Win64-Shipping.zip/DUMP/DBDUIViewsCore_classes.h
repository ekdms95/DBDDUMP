// Class DBDUIViewsCore.CoreBaseUserWidget
// Size: 0x2d8 (Inherited: 0x260)
struct UCoreBaseUserWidget : UUserWidget {
	char pad_260[0x10]; // 0x260(0x10)
	struct UScaleBox* ScaleContainer; // 0x270(0x08)
	bool IsInteractive; // 0x278(0x01)
	enum class EControlMode _controlMode; // 0x279(0x01)
	enum class EScaleType ScaleType; // 0x27a(0x01)
	char pad_27B[0x5]; // 0x27b(0x05)
	struct UDBDInputManager* _inputManager; // 0x280(0x08)
	char pad_288[0x50]; // 0x288(0x50)

	void UpdateScale(float Scale); // Function DBDUIViewsCore.CoreBaseUserWidget.UpdateScale // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x27140c0
	void RegisterForInput(); // Function DBDUIViewsCore.CoreBaseUserWidget.RegisterForInput // (Final|Native|Protected|BlueprintCallable) // @ game+0x27135f0
	void OnControlModeChangedBP(enum class EControlMode controlMode); // Function DBDUIViewsCore.CoreBaseUserWidget.OnControlModeChangedBP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void DeregisterFromInput(); // Function DBDUIViewsCore.CoreBaseUserWidget.DeregisterFromInput // (Final|Native|Protected|BlueprintCallable) // @ game+0x2712cc0
};

// Class DBDUIViewsCore.CharacterTooltipWidget
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCharacterTooltipWidget : UCoreBaseUserWidget {

	void SetTooltipData(struct FCharacterTooltipViewData characterViewData); // Function DBDUIViewsCore.CharacterTooltipWidget.SetTooltipData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreBaseLoadoutPartWidget
// Size: 0x280 (Inherited: 0x260)
struct UCoreBaseLoadoutPartWidget : UUserWidget {
	char pad_260[0x8]; // 0x260(0x08)
	struct UDBDImage* ImageRarity; // 0x268(0x08)
	struct UDBDImage* ImageIcon; // 0x270(0x08)
	struct UTextBlock* TextStackCount; // 0x278(0x08)

	void SetLoadoutStackCount(int32_t StackCount); // Function DBDUIViewsCore.CoreBaseLoadoutPartWidget.SetLoadoutStackCount // (Final|Native|Protected|BlueprintCallable) // @ game+0x2713c40
	void SetLoadoutPartRarity(enum class EItemRarity Rarity); // Function DBDUIViewsCore.CoreBaseLoadoutPartWidget.SetLoadoutPartRarity // (Final|Native|Protected|BlueprintCallable) // @ game+0x2713bc0
	void SetLoadoutPartIcon(struct UTexture2D* Icon); // Function DBDUIViewsCore.CoreBaseLoadoutPartWidget.SetLoadoutPartIcon // (Final|Native|Protected|BlueprintCallable) // @ game+0x2713b40
};

// Class DBDUIViewsCore.CoreAddonWidget
// Size: 0x288 (Inherited: 0x280)
struct UCoreAddonWidget : UCoreBaseLoadoutPartWidget {
	char pad_280[0x8]; // 0x280(0x08)
};

// Class DBDUIViewsCore.CoreBaseHudWidget
// Size: 0x2f0 (Inherited: 0x2d8)
struct UCoreBaseHudWidget : UCoreBaseUserWidget {
	float FocusAnimationDuration; // 0x2d8(0x04)
	float FocusAnimationDelay; // 0x2dc(0x04)
	enum class EEasingType FocusAnimationEasing; // 0x2e0(0x01)
	char pad_2E1[0x3]; // 0x2e1(0x03)
	float FocusAnimationMaxOpacity; // 0x2e4(0x04)
	float FocusAnimationMinOpacity; // 0x2e8(0x04)
	char pad_2EC[0x4]; // 0x2ec(0x04)

	bool ShouldPlayFocusAnimation(); // Function DBDUIViewsCore.CoreBaseHudWidget.ShouldPlayFocusAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2713ff0
	void PlayFocusAnimation(); // Function DBDUIViewsCore.CoreBaseHudWidget.PlayFocusAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2713590
};

// Class DBDUIViewsCore.CoreButtonPromptWidget
// Size: 0x310 (Inherited: 0x2d8)
struct UCoreButtonPromptWidget : UCoreBaseUserWidget {
	struct UAkAudioEvent* CursorOverSfx; // 0x2d8(0x08)
	struct UAkAudioEvent* CursorPressSfx; // 0x2e0(0x08)
	struct UAkAudioEvent* CursorReleaseSfx; // 0x2e8(0x08)
	struct UCoreInputPromptTextWidget* _inputPromptText; // 0x2f0(0x08)
	struct UTextBlock* _buttonTextField; // 0x2f8(0x08)
	struct FMulticastInlineDelegate _buttonPromptTriggeredDelegate; // 0x300(0x10)

	void SetText(struct FText Text); // Function DBDUIViewsCore.CoreButtonPromptWidget.SetText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2713cc0
	void SetInputKey(struct FKey Key); // Function DBDUIViewsCore.CoreButtonPromptWidget.SetInputKey // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x27138d0
	void SetAction(enum class EUIActionType actionType); // Function DBDUIViewsCore.CoreButtonPromptWidget.SetAction // (Final|Native|Public|BlueprintCallable) // @ game+0x2713610
	void EnablePrompts(); // Function DBDUIViewsCore.CoreButtonPromptWidget.EnablePrompts // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void DisablePrompts(); // Function DBDUIViewsCore.CoreButtonPromptWidget.DisablePrompts // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreButtonWidget
// Size: 0x2e8 (Inherited: 0x2d8)
struct UCoreButtonWidget : UCoreBaseUserWidget {
	struct UDBDButton* HitzoneButton; // 0x2d8(0x08)
	enum class EAnalogCursorStickiness AnalogCursorStickiness; // 0x2e0(0x01)
	char pad_2E1[0x7]; // 0x2e1(0x07)

	void OnHitzoneUnhovered(); // Function DBDUIViewsCore.CoreButtonWidget.OnHitzoneUnhovered // (Final|Native|Private) // @ game+0x2713330
	void OnHitzoneHovered(); // Function DBDUIViewsCore.CoreButtonWidget.OnHitzoneHovered // (Final|Native|Private) // @ game+0x2713310
};

// Class DBDUIViewsCore.CoreRewardWidget
// Size: 0x270 (Inherited: 0x260)
struct UCoreRewardWidget : UUserWidget {
	struct UDBDImage* RewardIcon; // 0x260(0x08)
	struct UDBDButton* HitZone; // 0x268(0x08)

	struct UDBDButton* GetHitZone(); // Function DBDUIViewsCore.CoreRewardWidget.GetHitZone // (Final|Native|Public|BlueprintCallable) // @ game+0x2719310
	void ClearData(); // Function DBDUIViewsCore.CoreRewardWidget.ClearData // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreCharacterRewardWidget
// Size: 0x270 (Inherited: 0x270)
struct UCoreCharacterRewardWidget : UCoreRewardWidget {

	void SetData(struct FCharacterRewardViewData CharacterRewardViewData); // Function DBDUIViewsCore.CoreCharacterRewardWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreCurrencyRewardWidget
// Size: 0x270 (Inherited: 0x270)
struct UCoreCurrencyRewardWidget : UCoreRewardWidget {

	void SetData(struct FCurrencyRewardViewData CurrencyRewardViewData); // Function DBDUIViewsCore.CoreCurrencyRewardWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreCustomizationRewardWidget
// Size: 0x270 (Inherited: 0x270)
struct UCoreCustomizationRewardWidget : UCoreRewardWidget {

	void SetData(struct FCustomizationRewardViewData CustomizationRewardViewData); // Function DBDUIViewsCore.CoreCustomizationRewardWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreEndGameCollapseBarWidget
// Size: 0x368 (Inherited: 0x2f0)
struct UCoreEndGameCollapseBarWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	float _progressBarInterpSpeed; // 0x2f8(0x04)
	char pad_2FC[0x6c]; // 0x2fc(0x6c)

	void UpdateBarProgression(float Progress); // Function DBDUIViewsCore.CoreEndGameCollapseBarWidget.UpdateBarProgression // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void PlayToZeroAnimation(); // Function DBDUIViewsCore.CoreEndGameCollapseBarWidget.PlayToZeroAnimation // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreEndGameCollapseProgressWidget
// Size: 0x320 (Inherited: 0x2d8)
struct UCoreEndGameCollapseProgressWidget : UCoreBaseUserWidget {
	struct UProgressBar* ProgressBar; // 0x2d8(0x08)
	struct UCanvasPanel* MarkerLeftCanvas; // 0x2e0(0x08)
	struct UCanvasPanel* MarkerRightCanvas; // 0x2e8(0x08)
	struct UHorizontalBoxSlot* _markerLeftBox; // 0x2f0(0x08)
	struct UHorizontalBoxSlot* _markerRightBox; // 0x2f8(0x08)
	char pad_300[0x20]; // 0x300(0x20)
};

// Class DBDUIViewsCore.CoreEquippedItemWidget
// Size: 0x300 (Inherited: 0x2f0)
struct UCoreEquippedItemWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UAkAudioEvent* ItemDisappearSfx; // 0x2f8(0x08)
};

// Class DBDUIViewsCore.CoreEquippedPowerWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreEquippedPowerWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreExampleWidget
// Size: 0x388 (Inherited: 0x2f0)
struct UCoreExampleWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FString EditAnywhere; // 0x2f8(0x10)
	struct FString EditDefaultsOnly; // 0x308(0x10)
	struct FString EditInstanceOnly; // 0x318(0x10)
	struct FString EditNoBlueprint; // 0x328(0x10)
	struct FString EditDefaultsOnlyBlueprintReadOnly; // 0x338(0x10)
	struct FString VisibleAnywhere; // 0x348(0x10)
	struct FString VisibleDefaultsOnly; // 0x358(0x10)
	struct FString VisibleInstanceOnly; // 0x368(0x10)
	struct FMulticastInlineDelegate ExampleButtonClickDelegate; // 0x378(0x10)
};

// Class DBDUIViewsCore.CoreExternalEffectsWidget
// Size: 0x4a0 (Inherited: 0x2f0)
struct UCoreExternalEffectsWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct TArray<struct UCorePerkWidget*> PerkWidgets; // 0x2f8(0x10)
	struct TArray<struct UCoreAddonWidget*> AddonWidgets; // 0x308(0x10)
	char pad_318[0x8]; // 0x318(0x08)
	struct TArray<struct TScriptInterface<None>> _perkViewInterfaces; // 0x320(0x10)
	struct TArray<struct TScriptInterface<None>> _addonViewInterfaces; // 0x330(0x10)
	char pad_340[0x160]; // 0x340(0x160)

	void HideExternalPerk(struct FName PerkId); // Function DBDUIViewsCore.CoreExternalEffectsWidget.HideExternalPerk // (Final|Native|Private|HasOutParms) // @ game+0x27130b0
	void HideExternalAddon(struct FName AddonID); // Function DBDUIViewsCore.CoreExternalEffectsWidget.HideExternalAddon // (Final|Native|Private|HasOutParms) // @ game+0x2713010
};

// Class DBDUIViewsCore.CoreGameManualCategoryButton
// Size: 0x318 (Inherited: 0x2e8)
struct UCoreGameManualCategoryButton : UCoreButtonWidget {
	struct UDBDTextBlock* Title; // 0x2e8(0x08)
	struct UDBDTextBlock* Description; // 0x2f0(0x08)
	struct UDBDImage* Icon; // 0x2f8(0x08)
	struct UDBDImage* Background; // 0x300(0x08)
	struct UTexture2D* IconTexture; // 0x308(0x08)
	struct UTexture2D* BackgroundTexture; // 0x310(0x08)

	void SetText(struct FText Title, struct FText Description); // Function DBDUIViewsCore.CoreGameManualCategoryButton.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0x2713d90
};

// Class DBDUIViewsCore.CoreGameManualPanelWidget
// Size: 0x3a0 (Inherited: 0x2d8)
struct UCoreGameManualPanelWidget : UCoreBaseUserWidget {
	char pad_2D8[0x8]; // 0x2d8(0x08)
	enum class EGameManualMenuState _currentSelectedManualMenu; // 0x2e0(0x01)
	enum class EHelpType _currentGameManualTopic; // 0x2e1(0x01)
	char pad_2E2[0x6]; // 0x2e2(0x06)
	struct UPanelWidget* CategoryPanel; // 0x2e8(0x08)
	struct UCoreGameManualCategoryButton* GameCategoryButton; // 0x2f0(0x08)
	struct UCoreGameManualCategoryButton* SurvivorCategoryButton; // 0x2f8(0x08)
	struct UCoreGameManualCategoryButton* KillerCategoryButton; // 0x300(0x08)
	struct UPanelWidget* TopicsPanel; // 0x308(0x08)
	struct UCoreTabContainerWidget* GameManualTopicsTabs; // 0x310(0x08)
	struct UDBDTextBlock* GameManualContentTitle; // 0x318(0x08)
	struct UDBDTextBlock* GameManualContentSubtitle; // 0x320(0x08)
	struct UDBDRichTextBlock* GameManualContentText; // 0x328(0x08)
	char pad_330[0x50]; // 0x330(0x50)
	struct FMulticastInlineDelegate _onSetOnboardingMenuSubtitleDelegate; // 0x380(0x10)
	struct FMulticastInlineDelegate _onResetOnboardingMenuSubtitleDelegate; // 0x390(0x10)

	void ToggleGameManualMenuState(); // Function DBDUIViewsCore.CoreGameManualPanelWidget.ToggleGameManualMenuState // (Final|Native|Protected|BlueprintCallable) // @ game+0x27140a0
	void ShowHelpTopics(enum class EHelpType categoryType); // Function DBDUIViewsCore.CoreGameManualPanelWidget.ShowHelpTopics // (Final|Native|Protected|BlueprintCallable) // @ game+0x2714020
	void SetGameManualMenuState(enum class EGameManualMenuState menuState); // Function DBDUIViewsCore.CoreGameManualPanelWidget.SetGameManualMenuState // (Final|Native|Protected|BlueprintCallable) // @ game+0x27136b0
	void SetCurrentOnbardingMenuSubtitle(); // Function DBDUIViewsCore.CoreGameManualPanelWidget.SetCurrentOnbardingMenuSubtitle // (Final|Native|Protected|BlueprintCallable) // @ game+0x2713690
	void OnTopicTabChanged(int32_t tabIndex); // Function DBDUIViewsCore.CoreGameManualPanelWidget.OnTopicTabChanged // (Final|Native|Protected) // @ game+0x2713510
};

// Class DBDUIViewsCore.CoreHookCountWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreHookCountWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreHudAlertWidget
// Size: 0x380 (Inherited: 0x2f0)
struct UCoreHudAlertWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	int32_t MaxDisplayedItems; // 0x2f8(0x04)
	float SecondaryAlpha; // 0x2fc(0x04)
	float FullAlertDuration; // 0x300(0x04)
	float PendingAlertDuration; // 0x304(0x04)
	float AnimationDuration; // 0x308(0x04)
	enum class EEasingType AnimationEasing; // 0x30c(0x01)
	char pad_30D[0x3]; // 0x30d(0x03)
	float AnimationTranslationY; // 0x310(0x04)
	char pad_314[0x4]; // 0x314(0x04)
	struct UCoreHudScoreAlertItem* CoreHudScoreAlertItemClass; // 0x318(0x08)
	struct UCoreHudStatusEffectAlertItem* CoreHudStatusEffectAlertItemClass; // 0x320(0x08)
	struct UGridPanel* AlertContainer; // 0x328(0x08)
	struct TArray<struct UCoreBaseUserWidget*> _alerts; // 0x330(0x10)
	struct TArray<struct UCoreBaseUserWidget*> _pendingAlerts; // 0x340(0x10)
	struct TArray<struct UCoreHudScoreAlertItem*> _scoreAlertPool; // 0x350(0x10)
	struct TArray<struct UCoreHudStatusEffectAlertItem*> _statusEffectAlertPool; // 0x360(0x10)
	char pad_370[0x10]; // 0x370(0x10)

	void PopAlert(); // Function DBDUIViewsCore.CoreHudAlertWidget.PopAlert // (Final|Native|Private) // @ game+0x27135b0
	void OnPopAlertComplete(struct FUITweenInstance tween); // Function DBDUIViewsCore.CoreHudAlertWidget.OnPopAlertComplete // (Final|Native|Private|HasOutParms) // @ game+0x2713350
	void OnClearAlertsComplete(struct FUITweenInstance tween); // Function DBDUIViewsCore.CoreHudAlertWidget.OnClearAlertsComplete // (Final|Native|Private|HasOutParms) // @ game+0x2713150
	float GetRemainingTime(); // Function DBDUIViewsCore.CoreHudAlertWidget.GetRemainingTime // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712f00
	struct TArray<struct UCoreBaseUserWidget*> GetPendingAlerts(); // Function DBDUIViewsCore.CoreHudAlertWidget.GetPendingAlerts // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712e40
	struct TArray<struct UCoreBaseUserWidget*> GetAlerts(); // Function DBDUIViewsCore.CoreHudAlertWidget.GetAlerts // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712ce0
	void ClearAlerts(); // Function DBDUIViewsCore.CoreHudAlertWidget.ClearAlerts // (Final|Native|Private) // @ game+0x2712ca0
};

// Class DBDUIViewsCore.CoreHudObjectiveWidget
// Size: 0x300 (Inherited: 0x2f0)
struct UCoreHudObjectiveWidget : UCoreBaseHudWidget {
	char pad_2F0[0x10]; // 0x2f0(0x10)
};

// Class DBDUIViewsCore.CoreHudScoreAlertItem
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCoreHudScoreAlertItem : UCoreBaseUserWidget {

	void SetData(struct FScoreAlertViewData Data); // Function DBDUIViewsCore.CoreHudScoreAlertItem.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreHudStatusEffectAlertItem
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCoreHudStatusEffectAlertItem : UCoreBaseUserWidget {

	void SetData(struct FStatusEffectAlertViewData Data); // Function DBDUIViewsCore.CoreHudStatusEffectAlertItem.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreInputPromptTextWidget
// Size: 0x320 (Inherited: 0x2d8)
struct UCoreInputPromptTextWidget : UCoreBaseUserWidget {
	struct UCoreInputPromptWidget* InputPrompt; // 0x2d8(0x08)
	struct UTextBlock* TextField; // 0x2e0(0x08)
	struct FKey InputKey; // 0x2e8(0x20)
	struct FText Text; // 0x308(0x18)

	void SetText(struct FText Text); // Function DBDUIViewsCore.CoreInputPromptTextWidget.SetText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2713f20
	void SetInputKey(struct FKey InputKey); // Function DBDUIViewsCore.CoreInputPromptTextWidget.SetInputKey // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x27139a0
};

// Class DBDUIViewsCore.CoreInputPromptWidget
// Size: 0x310 (Inherited: 0x2d8)
struct UCoreInputPromptWidget : UCoreBaseUserWidget {
	struct FText UnfoundInputKeyText; // 0x2d8(0x18)
	struct FKey InputKey; // 0x2f0(0x20)

	void SetInputKey(struct FKey InputKey); // Function DBDUIViewsCore.CoreInputPromptWidget.SetInputKey // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2713a70
	void PromptNotFound(); // Function DBDUIViewsCore.CoreInputPromptWidget.PromptNotFound // (Final|Native|Protected|BlueprintCallable) // @ game+0x27135d0
	struct FText GetInputShortDisplayName(); // Function DBDUIViewsCore.CoreInputPromptWidget.GetInputShortDisplayName // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712da0
	void DisplayPrompt(); // Function DBDUIViewsCore.CoreInputPromptWidget.DisplayPrompt // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreInteractionProgressWidget
// Size: 0x310 (Inherited: 0x2f0)
struct UCoreInteractionProgressWidget : UCoreBaseHudWidget {
	char pad_2F0[0x10]; // 0x2f0(0x10)
	struct TArray<struct UCoreStatusEffectIcon*> Proficiencies; // 0x300(0x10)
};

// Class DBDUIViewsCore.CoreInteractionPromptActionWidget
// Size: 0x360 (Inherited: 0x320)
struct UCoreInteractionPromptActionWidget : UCoreInputPromptTextWidget {
	struct UCoreInputPromptWidget* InputPrompt2; // 0x320(0x08)
	struct FName IdleAnimationName; // 0x328(0x0c)
	char pad_334[0x4]; // 0x334(0x04)
	struct FKey InputKey2; // 0x338(0x20)
	char pad_358[0x8]; // 0x358(0x08)

	void StopIdleAnimation(); // Function DBDUIViewsCore.CoreInteractionPromptActionWidget.StopIdleAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x2719f50
	void SetInputKey2(struct FKey InputKey2); // Function DBDUIViewsCore.CoreInteractionPromptActionWidget.SetInputKey2 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2719d10
	void PlayIdleAnimation(); // Function DBDUIViewsCore.CoreInteractionPromptActionWidget.PlayIdleAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x2719ad0
	bool HasSecondPrompt(); // Function DBDUIViewsCore.CoreInteractionPromptActionWidget.HasSecondPrompt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719910
};

// Class DBDUIViewsCore.CoreInteractionPromptActionMovementWidget
// Size: 0x3b0 (Inherited: 0x360)
struct UCoreInteractionPromptActionMovementWidget : UCoreInteractionPromptActionWidget {
	struct UCoreInputPromptWidget* InputPrompt3; // 0x360(0x08)
	struct UCoreInputPromptWidget* InputPrompt4; // 0x368(0x08)
	struct FKey InputKey3; // 0x370(0x20)
	struct FKey InputKey4; // 0x390(0x20)

	void SetInputKey4(struct FKey InputKey4); // Function DBDUIViewsCore.CoreInteractionPromptActionMovementWidget.SetInputKey4 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2713800
	void SetInputKey3(struct FKey InputKey3); // Function DBDUIViewsCore.CoreInteractionPromptActionMovementWidget.SetInputKey3 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2713730
	bool HasThirdPrompt(); // Function DBDUIViewsCore.CoreInteractionPromptActionMovementWidget.HasThirdPrompt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712fa0
	bool HasFourthPrompt(); // Function DBDUIViewsCore.CoreInteractionPromptActionMovementWidget.HasFourthPrompt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2712f30
};

// Class DBDUIViewsCore.CoreInteractionPromptsContainerWidget
// Size: 0x390 (Inherited: 0x2f0)
struct UCoreInteractionPromptsContainerWidget : UCoreBaseHudWidget {
	char pad_2F0[0x10]; // 0x2f0(0x10)
	struct UDBDWrapBox* CenterContainerBox; // 0x300(0x08)
	struct UDBDWrapBox* ContainerBox; // 0x308(0x08)
	struct UCoreInteractionPromptWidget* InteractionPromptWidgetClass; // 0x310(0x08)
	int32_t MaxDisplayedPrompts; // 0x318(0x04)
	struct FMargin SlotMargin; // 0x31c(0x10)
	char pad_32C[0x4]; // 0x32c(0x04)
	struct TArray<struct UCoreInteractionPromptWidget*> _promptWidgetPool; // 0x330(0x10)
	struct TMap<struct FName, struct UCoreInteractionPromptWidget*> _displayedPromptsMap; // 0x340(0x50)
};

// Class DBDUIViewsCore.CoreInteractionPromptWidget
// Size: 0x260 (Inherited: 0x260)
struct UCoreInteractionPromptWidget : UUserWidget {

	void SetData(struct FInteractionPromptViewData Data); // Function DBDUIViewsCore.CoreInteractionPromptWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ClearData(); // Function DBDUIViewsCore.CoreInteractionPromptWidget.ClearData // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreItemBundleWidget
// Size: 0x2e0 (Inherited: 0x2d8)
struct UCoreItemBundleWidget : UCoreBaseUserWidget {
	char pad_2D8[0x8]; // 0x2d8(0x08)
};

// Class DBDUIViewsCore.CoreItemInteractionWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreItemInteractionWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreItemWidget
// Size: 0x288 (Inherited: 0x280)
struct UCoreItemWidget : UCoreBaseLoadoutPartWidget {
	char pad_280[0x8]; // 0x280(0x08)
};

// Class DBDUIViewsCore.CoreLeaningArrowsWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreLeaningArrowsWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreMatchResultWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreMatchResultWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreOfferingInteractionWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreOfferingInteractionWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreOfferingWidget
// Size: 0x288 (Inherited: 0x280)
struct UCoreOfferingWidget : UCoreBaseLoadoutPartWidget {
	char pad_280[0x8]; // 0x280(0x08)
};

// Class DBDUIViewsCore.CoreOnboardingMenuTitleWidget
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCoreOnboardingMenuTitleWidget : UCoreBaseUserWidget {

	void SetOnboardingMenuTitle(struct FText menuTitle); // Function DBDUIViewsCore.CoreOnboardingMenuTitleWidget.SetOnboardingMenuTitle // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetOnboardingMenuSubtitle(struct FText menuTitle); // Function DBDUIViewsCore.CoreOnboardingMenuTitleWidget.SetOnboardingMenuSubtitle // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetOnboardingMenuDoubleTitle(struct FText menuTitle, struct FText menuSubTitle); // Function DBDUIViewsCore.CoreOnboardingMenuTitleWidget.SetOnboardingMenuDoubleTitle // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ResetOnboardingMenuSubtitle(); // Function DBDUIViewsCore.CoreOnboardingMenuTitleWidget.ResetOnboardingMenuSubtitle // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreOnboardingMenuWidget
// Size: 0x310 (Inherited: 0x2d8)
struct UCoreOnboardingMenuWidget : UCoreBaseUserWidget {
	char pad_2D8[0x8]; // 0x2d8(0x08)
	struct UCoreTabContainerWidget* OnboardingMenuTabs; // 0x2e0(0x08)
	struct FMulticastInlineDelegate BackActionDelegate; // 0x2e8(0x10)
	struct FMulticastInlineDelegate TabSelectionChangedActionDelegate; // 0x2f8(0x10)
	char pad_308[0x8]; // 0x308(0x08)

	void OnOnboardingTabChanged(int32_t tabIndex); // Function DBDUIViewsCore.CoreOnboardingMenuWidget.OnOnboardingTabChanged // (Final|Native|Public) // @ game+0x2719a30
};

// Class DBDUIViewsCore.CoreOnboardingTutorialButtonWidget
// Size: 0x3c0 (Inherited: 0x2e8)
struct UCoreOnboardingTutorialButtonWidget : UCoreButtonWidget {
	struct FMulticastInlineDelegate ButtonClickedDelegate; // 0x2e8(0x10)
	struct FMulticastInlineDelegate OnSetDataAnimationCompleteDelegate; // 0x2f8(0x10)
	struct UDBDTextBlock* TitleText; // 0x308(0x08)
	struct UDBDTextBlock* DescriptionText; // 0x310(0x08)
	struct UDBDImage* RoleIcon; // 0x318(0x08)
	struct UWidgetSwitcher* StateSwitcher; // 0x320(0x08)
	struct UDBDImage* LockedImage; // 0x328(0x08)
	struct UDBDImage* CompletedImage; // 0x330(0x08)
	struct TArray<struct UCoreRewardWrapperWidget*> RewardWrappers; // 0x338(0x10)
	struct FOnboardingTutorialButtonViewData viewData; // 0x348(0x78)

	void SetVisual(); // Function DBDUIViewsCore.CoreOnboardingTutorialButtonWidget.SetVisual // (Final|Native|Protected|BlueprintCallable) // @ game+0x2719ea0
	void SetUIEnabled(bool Enabled); // Function DBDUIViewsCore.CoreOnboardingTutorialButtonWidget.SetUIEnabled // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void SetData(struct FOnboardingTutorialButtonViewData viewData, bool isRefreshingWithAnimation); // Function DBDUIViewsCore.CoreOnboardingTutorialButtonWidget.SetData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3873200
	void OnRewardClicked(); // Function DBDUIViewsCore.CoreOnboardingTutorialButtonWidget.OnRewardClicked // (Final|Native|Private) // @ game+0x2719ab0
};

// Class DBDUIViewsCore.CoreOnboardingTutorialPanelWidget
// Size: 0x310 (Inherited: 0x2d8)
struct UCoreOnboardingTutorialPanelWidget : UCoreBaseUserWidget {
	char pad_2D8[0x8]; // 0x2d8(0x08)
	struct TArray<struct UCoreOnboardingTutorialButtonWidget*> TutorialButtons; // 0x2e0(0x10)
	struct FMulticastInlineDelegate TutorialSelectedDelegate; // 0x2f0(0x10)
	struct TArray<struct FPendingStepData> _pendingData; // 0x300(0x10)

	void NextPendingButtonUpdated(); // Function DBDUIViewsCore.CoreOnboardingTutorialPanelWidget.NextPendingButtonUpdated // (Final|Native|Private) // @ game+0x2719a10
	void CheckNextPendingButtonUpdate(); // Function DBDUIViewsCore.CoreOnboardingTutorialPanelWidget.CheckNextPendingButtonUpdate // (Final|Native|Private) // @ game+0x27191f0
};

// Class DBDUIViewsCore.CorePerksContainerWidget
// Size: 0x318 (Inherited: 0x2f0)
struct UCorePerksContainerWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct TArray<struct UCorePerkWidget*> PerkWidgets; // 0x2f8(0x10)
	struct TArray<struct TScriptInterface<None>> _perkViewInterfaces; // 0x308(0x10)
};

// Class DBDUIViewsCore.CorePerkWidget
// Size: 0x288 (Inherited: 0x280)
struct UCorePerkWidget : UCoreBaseLoadoutPartWidget {
	char pad_280[0x8]; // 0x280(0x08)
};

// Class DBDUIViewsCore.CorePingStatusWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCorePingStatusWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CorePlayerStatusesContainerWidget
// Size: 0x320 (Inherited: 0x2f0)
struct UCorePlayerStatusesContainerWidget : UCoreBaseHudWidget {
	char pad_2F0[0x10]; // 0x2f0(0x10)
	struct TArray<struct UCorePlayerStatusWidget*> PlayerStatusWidgets; // 0x300(0x10)
	struct TArray<struct TScriptInterface<None>> _playerStatusViewInterfaces; // 0x310(0x10)
};

// Class DBDUIViewsCore.CorePlayerStatusWidget
// Size: 0x3c8 (Inherited: 0x2f0)
struct UCorePlayerStatusWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UAkAudioEvent* ObsessionSfx; // 0x2f8(0x08)
	struct FPlayerStatusViewData _cachedViewData; // 0x300(0x78)
	char pad_378[0x50]; // 0x378(0x50)

	bool ShouldPlaySleepAnimation(enum class ESleepingUIState newSleepState); // Function DBDUIViewsCore.CorePlayerStatusWidget.ShouldPlaySleepAnimation // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719ec0
	bool HasTimerProgressChanged(float newTimerProgress); // Function DBDUIViewsCore.CorePlayerStatusWidget.HasTimerProgressChanged // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719980
	bool HasPlayerStatusDataChanged(struct FPlayerStatusViewData newViewData); // Function DBDUIViewsCore.CorePlayerStatusWidget.HasPlayerStatusDataChanged // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719800
	bool HasPlayerStateChanged(enum class EPlayerStatus newPlayerState); // Function DBDUIViewsCore.CorePlayerStatusWidget.HasPlayerStateChanged // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719770
	bool HasObsessionStateChanged(enum class EObsessionUIState newObsessionState); // Function DBDUIViewsCore.CorePlayerStatusWidget.HasObsessionStateChanged // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x27196e0
	bool HasKillerStatusDataChanged(struct FPlayerStatusViewData newViewData); // Function DBDUIViewsCore.CorePlayerStatusWidget.HasKillerStatusDataChanged // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x27195d0
	enum class EPlayerStateChangeType GetPlayerStateChangeType(struct FPlayerStatusViewData newViewData); // Function DBDUIViewsCore.CorePlayerStatusWidget.GetPlayerStateChangeType // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719350
};

// Class DBDUIViewsCore.CorePowerBundleWidget
// Size: 0x2e0 (Inherited: 0x2d8)
struct UCorePowerBundleWidget : UCoreBaseUserWidget {
	char pad_2D8[0x8]; // 0x2d8(0x08)
};

// Class DBDUIViewsCore.CorePowerWidget
// Size: 0x288 (Inherited: 0x280)
struct UCorePowerWidget : UCoreBaseLoadoutPartWidget {
	char pad_280[0x8]; // 0x280(0x08)
};

// Class DBDUIViewsCore.CoreProgressionRewardWidget
// Size: 0x270 (Inherited: 0x270)
struct UCoreProgressionRewardWidget : UCoreRewardWidget {

	void SetData(struct FProgressionRewardViewData ProgressionRewardViewData); // Function DBDUIViewsCore.CoreProgressionRewardWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreRewardWrapperWidget
// Size: 0x290 (Inherited: 0x260)
struct UCoreRewardWrapperWidget : UUserWidget {
	struct UCoreCharacterRewardWidget* CharacterRewardWidget; // 0x260(0x08)
	struct UCoreCurrencyRewardWidget* CurrencyRewardWidget; // 0x268(0x08)
	struct UCoreCustomizationRewardWidget* CustomizationRewardWidget; // 0x270(0x08)
	struct UCoreProgressionRewardWidget* ProgressionRewardWidget; // 0x278(0x08)
	struct UPanelWidget* RewardContainer; // 0x280(0x08)
	struct UCoreRewardWidget* _rewardWidget; // 0x288(0x08)

	void SetData(struct FRewardWrapperViewData viewData); // Function DBDUIViewsCore.CoreRewardWrapperWidget.SetData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2719af0
	struct UCoreRewardWidget* GetRewardWidget(); // Function DBDUIViewsCore.CoreRewardWrapperWidget.GetRewardWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x2719460
	void ClearData(); // Function DBDUIViewsCore.CoreRewardWrapperWidget.ClearData // (Final|Native|Public|BlueprintCallable) // @ game+0x2719210
};

// Class DBDUIViewsCore.CoreScreenIndicatorsContainerWidget
// Size: 0x370 (Inherited: 0x2f0)
struct UCoreScreenIndicatorsContainerWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	float InactiveThreshold; // 0x2f8(0x04)
	char pad_2FC[0x4]; // 0x2fc(0x04)
	struct UCanvasPanel* Container; // 0x300(0x08)
	struct UCoreScreenIndicatorWidget* ScreenIndicatorClass; // 0x308(0x08)
	struct TMap<struct FString, struct UCoreScreenIndicatorWidget*> _screenIndicatorsMap; // 0x310(0x50)
	struct TArray<struct UCoreScreenIndicatorWidget*> _screenIndicatorsPool; // 0x360(0x10)

	struct TMap<struct FString, struct UCoreScreenIndicatorWidget*> GetScreenIndicatorsMap(); // Function DBDUIViewsCore.CoreScreenIndicatorsContainerWidget.GetScreenIndicatorsMap // (Final|Native|Protected|BlueprintCallable) // @ game+0x2719480
	struct FString FindScreenIndicatorKey(struct UCoreScreenIndicatorWidget* value); // Function DBDUIViewsCore.CoreScreenIndicatorsContainerWidget.FindScreenIndicatorKey // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719230
};

// Class DBDUIViewsCore.CoreScreenIndicatorWidget
// Size: 0x2f8 (Inherited: 0x2d8)
struct UCoreScreenIndicatorWidget : UCoreBaseUserWidget {
	float InactiveTime; // 0x2d8(0x04)
	struct FVector2D IndicatorPadding; // 0x2dc(0x08)
	struct FVector2D DistanceClamping; // 0x2e4(0x08)
	float MinDistanceRatio; // 0x2ec(0x04)
	float MinDistanceAlpha; // 0x2f0(0x04)
	char pad_2F4[0x4]; // 0x2f4(0x04)

	void SetData(struct FScreenIndicatorViewData Data); // Function DBDUIViewsCore.CoreScreenIndicatorWidget.SetData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void ClearData(); // Function DBDUIViewsCore.CoreScreenIndicatorWidget.ClearData // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreSkillCheckWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreSkillCheckWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreSpectateBarWidget
// Size: 0x328 (Inherited: 0x2f0)
struct UCoreSpectateBarWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FMulticastInlineDelegate _leaveButtonClickDelegate; // 0x2f8(0x10)
	struct FMulticastInlineDelegate _leftArrowClickDelegate; // 0x308(0x10)
	struct FMulticastInlineDelegate _rightArrowClickDelegate; // 0x318(0x10)
};

// Class DBDUIViewsCore.CoreStartSequenceWidget
// Size: 0x390 (Inherited: 0x2f0)
struct UCoreStartSequenceWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	float FadeInDuration; // 0x2f8(0x04)
	float FadeOutDuration; // 0x2fc(0x04)
	enum class EEasingType FadeInEasing; // 0x300(0x01)
	enum class EEasingType FadeOutEasing; // 0x301(0x01)
	char pad_302[0x6]; // 0x302(0x06)
	struct TMap<enum class EThemeColorId, struct FLinearColor> BorderColors; // 0x308(0x50)
	struct FLinearColor DefaultColor; // 0x358(0x10)
	struct UDBDTextBlock* ThemeNameTextfield; // 0x368(0x08)
	struct UImage* SeparatorImage; // 0x370(0x08)
	struct UDBDTextBlock* MapNameTextfield; // 0x378(0x08)
	struct FMulticastInlineDelegate StartSequenceFadeOutDelegate; // 0x380(0x10)
};

// Class DBDUIViewsCore.CoreStatusEffectIcon
// Size: 0x308 (Inherited: 0x2d8)
struct UCoreStatusEffectIcon : UCoreBaseUserWidget {
	char pad_2D8[0x30]; // 0x2d8(0x30)

	void UpdateWidget(); // Function DBDUIViewsCore.CoreStatusEffectIcon.UpdateWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void UpdatePercentageFill(float Percentage); // Function DBDUIViewsCore.CoreStatusEffectIcon.UpdatePercentageFill // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetStatusEffectData(struct FStatusEffectViewData Data); // Function DBDUIViewsCore.CoreStatusEffectIcon.SetStatusEffectData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2719de0
	void SetInactiveTicks(int32_t inactiveTicks); // Function DBDUIViewsCore.CoreStatusEffectIcon.SetInactiveTicks // (Final|Native|Public|BlueprintCallable) // @ game+0x2719c90
	struct FStatusEffectViewData GetStatusEffectData(); // Function DBDUIViewsCore.CoreStatusEffectIcon.GetStatusEffectData // (Final|Native|Public|BlueprintCallable) // @ game+0x2719590
	int32_t GetInactiveTicks(); // Function DBDUIViewsCore.CoreStatusEffectIcon.GetInactiveTicks // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2719330
};

// Class DBDUIViewsCore.CoreStatusEffectWidget
// Size: 0x388 (Inherited: 0x2f0)
struct UCoreStatusEffectWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	int32_t InactiveThreshold; // 0x2f8(0x04)
	int32_t PrepooledItemAmount; // 0x2fc(0x04)
	int32_t ItemsByColumn; // 0x300(0x04)
	float EvenColumnOffset; // 0x304(0x04)
	struct UCoreStatusEffectIcon* CoreStatusEffectIconClass; // 0x308(0x08)
	struct UGridPanel* StatusEffectContainer; // 0x310(0x08)
	struct TArray<struct UCoreStatusEffectIcon*> _statusEffectPool; // 0x318(0x10)
	struct TArray<struct FName> _statusEffectOrder; // 0x328(0x10)
	struct TMap<struct FName, struct UCoreStatusEffectIcon*> _statusEffectMap; // 0x338(0x50)

	struct TMap<struct FName, struct UCoreStatusEffectIcon*> GetStatusEffectMap(); // Function DBDUIViewsCore.CoreStatusEffectWidget.GetStatusEffectMap // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f0f0
};

// Class DBDUIViewsCore.CoreTabContainerWidget
// Size: 0x340 (Inherited: 0x2d8)
struct UCoreTabContainerWidget : UCoreBaseUserWidget {
	struct TArray<struct FTabWidgetData> TabsData; // 0x2d8(0x10)
	bool AlignHorizontally; // 0x2e8(0x01)
	char pad_2E9[0x3]; // 0x2e9(0x03)
	struct FMargin TabPadding; // 0x2ec(0x10)
	char pad_2FC[0x4]; // 0x2fc(0x04)
	struct UCoreTabWidget* CoreTabClass; // 0x300(0x08)
	struct UGridPanel* TabContainer; // 0x308(0x08)
	bool UseControllerTabSwitching; // 0x310(0x01)
	bool CanLoop; // 0x311(0x01)
	char pad_312[0x6]; // 0x312(0x06)
	struct FMulticastInlineDelegate _selectedTabChangedDelegate; // 0x318(0x10)
	struct TArray<struct UCoreTabWidget*> _tabs; // 0x328(0x10)
	char pad_338[0x8]; // 0x338(0x08)

	void SetAllTabsEnabled(bool Enabled); // Function DBDUIViewsCore.CoreTabContainerWidget.SetAllTabsEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x271f7e0
	void SelectTab(int32_t tabIndex); // Function DBDUIViewsCore.CoreTabContainerWidget.SelectTab // (Final|Native|Public|BlueprintCallable) // @ game+0x271f760
	void SelectPreviousTab(); // Function DBDUIViewsCore.CoreTabContainerWidget.SelectPreviousTab // (Final|Native|Public|BlueprintCallable) // @ game+0x271f740
	void SelectNextTab(); // Function DBDUIViewsCore.CoreTabContainerWidget.SelectNextTab // (Final|Native|Public|BlueprintCallable) // @ game+0x271f720
	void OnSelectedTabChanged(int32_t newTabIndex); // Function DBDUIViewsCore.CoreTabContainerWidget.OnSelectedTabChanged // (Final|Native|Private) // @ game+0x271f500
	void Init(); // Function DBDUIViewsCore.CoreTabContainerWidget.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x271f440
	void Clear(); // Function DBDUIViewsCore.CoreTabContainerWidget.Clear // (Final|Native|Public|BlueprintCallable) // @ game+0x271f050
};

// Class DBDUIViewsCore.CoreTabWidget
// Size: 0xcc0 (Inherited: 0x2e8)
struct UCoreTabWidget : UCoreButtonWidget {
	bool IsUsingCustomWidgetStateStyles; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct FTabStyle WidgetDefaultStyle; // 0x2f0(0x338)
	struct FTabStyle WidgetSelectedStyle; // 0x628(0x338)
	struct FTabStyle WidgetDisabledStyle; // 0x960(0x338)
	int32_t tabIndex; // 0xc98(0x04)
	char pad_C9C[0x4]; // 0xc9c(0x04)
	struct UDBDTextBlock* TabTextField; // 0xca0(0x08)
	struct UDBDImage* TabImage; // 0xca8(0x08)
	struct FMulticastInlineDelegate _tabTriggeredDelegate; // 0xcb0(0x10)

	void SetVisualState(enum class ETabWidgetState newState); // Function DBDUIViewsCore.CoreTabWidget.SetVisualState // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void ButtonClicked(); // Function DBDUIViewsCore.CoreTabWidget.ButtonClicked // (Final|Native|Private) // @ game+0x271f030
};

// Class DBDUIViewsCore.CoreTemplateWidget
// Size: 0x268 (Inherited: 0x260)
struct UCoreTemplateWidget : UUserWidget {
	char pad_260[0x8]; // 0x260(0x08)
};

// Class DBDUIViewsCore.CoreTestBuildFlagWidget
// Size: 0x308 (Inherited: 0x2f0)
struct UCoreTestBuildFlagWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UTextBlock* TopLineTextfield; // 0x2f8(0x08)
	struct UTextBlock* BottomLineTextfield; // 0x300(0x08)
};

// Class DBDUIViewsCore.CoreTutorialMysteryNoteWidget
// Size: 0x2f8 (Inherited: 0x2f0)
struct UCoreTutorialMysteryNoteWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
};

// Class DBDUIViewsCore.CoreTutorialObjectiveItem
// Size: 0x2e8 (Inherited: 0x2d8)
struct UCoreTutorialObjectiveItem : UCoreBaseUserWidget {
	struct FMulticastInlineDelegate TutorialObjectiveCompletedDelegate; // 0x2d8(0x10)

	void SetObjectiveCompleted(bool removeAfterCompletion); // Function DBDUIViewsCore.CoreTutorialObjectiveItem.SetObjectiveCompleted // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void InitObjective(struct FTutorialObjectivesViewData interactionsViewData); // Function DBDUIViewsCore.CoreTutorialObjectiveItem.InitObjective // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CoreTutorialObjectivesContainer
// Size: 0x370 (Inherited: 0x2f0)
struct UCoreTutorialObjectivesContainer : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UCoreTutorialObjectiveItem* CoreTutorialObjectiveItemClass; // 0x2f8(0x08)
	int32_t BasePooledInstanceAmount; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	struct UGridPanel* ObjectiveContainer; // 0x308(0x08)
	struct TArray<struct UCoreTutorialObjectiveItem*> _objectivePool; // 0x310(0x10)
	struct TMap<struct FName, struct UCoreTutorialObjectiveItem*> _objectiveItems; // 0x320(0x50)

	void OnTutorialObjectiveCompleted(struct UCoreTutorialObjectiveItem* item); // Function DBDUIViewsCore.CoreTutorialObjectivesContainer.OnTutorialObjectiveCompleted // (Final|Native|Private) // @ game+0x271f6a0
};

// Class DBDUIViewsCore.CoreTutorialPopupWidget
// Size: 0x310 (Inherited: 0x2f0)
struct UCoreTutorialPopupWidget : UCoreBaseHudWidget {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UAkAudioEvent* ClosePopupSfx; // 0x2f8(0x08)
	struct FMulticastInlineDelegate _notifTutoConfirmButtonClickDelegate; // 0x300(0x10)
};

// Class DBDUIViewsCore.CurrencyTooltipWidget
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCurrencyTooltipWidget : UCoreBaseUserWidget {

	void SetTooltipData(struct FCurrencyTooltipViewData currencyViewData); // Function DBDUIViewsCore.CurrencyTooltipWidget.SetTooltipData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.CustomizationTooltipWidget
// Size: 0x2d8 (Inherited: 0x2d8)
struct UCustomizationTooltipWidget : UCoreBaseUserWidget {

	void SetTooltipData(struct FCustomizationTooltipViewData customizationViewData); // Function DBDUIViewsCore.CustomizationTooltipWidget.SetTooltipData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3873200
};

// Class DBDUIViewsCore.DBDButton
// Size: 0x498 (Inherited: 0x498)
struct UDBDButton : UButton {
};

// Class DBDUIViewsCore.DBDImage
// Size: 0x250 (Inherited: 0x248)
struct UDBDImage : UImage {
	struct UTexture2D* DefaultImage; // 0x248(0x08)

	void SetBrushFromTextureWithDefault(struct UTexture2D* Texture, bool matchSize); // Function DBDUIViewsCore.DBDImage.SetBrushFromTextureWithDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x271f870
};

// Class DBDUIViewsCore.DBDRichTextBlock
// Size: 0x6e0 (Inherited: 0x6c8)
struct UDBDRichTextBlock : URichTextBlock {
	bool _debugPreviewUndockedState; // 0x6c8(0x01)
	char pad_6C9[0xf]; // 0x6c9(0x0f)
	bool _isUpperCase; // 0x6d8(0x01)
	bool _hasUndocking; // 0x6d9(0x01)
	char pad_6DA[0x6]; // 0x6da(0x06)

	void SetIsUpperCase(bool isUpperCase); // Function DBDUIViewsCore.DBDRichTextBlock.SetIsUpperCase // (Final|Native|Public|BlueprintCallable) // @ game+0x271fda0
	void SetHTMLText(struct FText InText); // Function DBDUIViewsCore.DBDRichTextBlock.SetHTMLText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x271fa50
	void SetHasUndocking(bool hasUndocking); // Function DBDUIViewsCore.DBDRichTextBlock.SetHasUndocking // (Final|Native|Public|BlueprintCallable) // @ game+0x271fb20
	void OnSwitchDockStateChanged(bool isDocked); // Function DBDUIViewsCore.DBDRichTextBlock.OnSwitchDockStateChanged // (Final|Native|Protected) // @ game+0x271f580
	bool GetIsUpperCase(); // Function DBDUIViewsCore.DBDRichTextBlock.GetIsUpperCase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f0b0
	bool GetHasUndocking(); // Function DBDUIViewsCore.DBDRichTextBlock.GetHasUndocking // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f070
};

// Class DBDUIViewsCore.DBDScrollBox
// Size: 0x938 (Inherited: 0x908)
struct UDBDScrollBox : UScrollBox {
	bool _useControllerScroll; // 0x908(0x01)
	bool _shouldScrollOnMouseOver; // 0x909(0x01)
	char pad_90A[0x2]; // 0x90a(0x02)
	float _scrollSpeed; // 0x90c(0x04)
	struct UCoreInputPromptTextWidget* _displayPrompt; // 0x910(0x08)
	struct FText _displayPromptText; // 0x918(0x18)
	enum class EShowScrollDisplayPrompt _showDisplayPrompt; // 0x930(0x01)
	char pad_931[0x7]; // 0x931(0x07)

	void UpdateDisplayPrompt(); // Function DBDUIViewsCore.DBDScrollBox.UpdateDisplayPrompt // (Final|Native|Protected|BlueprintCallable) // @ game+0x2720760
	void OnControlModeChanged(enum class EControlMode controlMode); // Function DBDUIViewsCore.DBDScrollBox.OnControlModeChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x271f480
	bool IsMouseOver(); // Function DBDUIViewsCore.DBDScrollBox.IsMouseOver // (Final|Native|Public|BlueprintCallable) // @ game+0x271f460
	void HandleControllerInput(float analogValue); // Function DBDUIViewsCore.DBDScrollBox.HandleControllerInput // (Final|Native|Protected|BlueprintCallable) // @ game+0x271f3a0
};

// Class DBDUIViewsCore.DBDTextBlock
// Size: 0x388 (Inherited: 0x2e8)
struct UDBDTextBlock : UTextBlock {
	bool _debugPreviewUndockedState; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct USwitchDockStateManager* _switchDockStateManager; // 0x2f0(0x08)
	bool _isUpperCase; // 0x2f8(0x01)
	bool _hasUndocking; // 0x2f9(0x01)
	char pad_2FA[0x6]; // 0x2fa(0x06)
	struct FDBDTextDockingProperties _undockedProperties; // 0x300(0x40)
	char pad_340[0x48]; // 0x340(0x48)

	void SetUndockedProperties(struct FDBDTextDockingProperties undockedProperties); // Function DBDUIViewsCore.DBDTextBlock.SetUndockedProperties // (Final|Native|Public|BlueprintCallable) // @ game+0x271ffc0
	void SetIsUpperCase(bool isUpperCase); // Function DBDUIViewsCore.DBDTextBlock.SetIsUpperCase // (Final|Native|Public|BlueprintCallable) // @ game+0x271fe20
	void SetHasUndocking(bool hasUndocking); // Function DBDUIViewsCore.DBDTextBlock.SetHasUndocking // (Final|Native|Public|BlueprintCallable) // @ game+0x271fba0
	void OnSwitchDockStateChanged(bool isDocked); // Function DBDUIViewsCore.DBDTextBlock.OnSwitchDockStateChanged // (Final|Native|Protected) // @ game+0x271f610
	struct FDBDTextDockingProperties GetUndockedProperties(); // Function DBDUIViewsCore.DBDTextBlock.GetUndockedProperties // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f2a0
	bool GetIsUpperCase(); // Function DBDUIViewsCore.DBDTextBlock.GetIsUpperCase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f0d0
	bool GetHasUndocking(); // Function DBDUIViewsCore.DBDTextBlock.GetHasUndocking // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f090
};

// Class DBDUIViewsCore.DBDTooltipManager
// Size: 0x50 (Inherited: 0x38)
struct UDBDTooltipManager : UGameInstanceSubsystem {
	char pad_38[0x10]; // 0x38(0x10)
	struct UUserWidget* _currentTooltip; // 0x48(0x08)

	void ShowCustomizationTooltip(struct FCustomizationTooltipViewData tooltipViewData, struct FGeometry triggerGeometry); // Function DBDUIViewsCore.DBDTooltipManager.ShowCustomizationTooltip // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x27205e0
	void ShowCurrencyTooltip(struct FCurrencyTooltipViewData tooltipViewData, struct FGeometry triggerGeometry); // Function DBDUIViewsCore.DBDTooltipManager.ShowCurrencyTooltip // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2720410
	void ShowCharacterTooltip(struct FCharacterTooltipViewData tooltipViewData, struct FGeometry triggerGeometry); // Function DBDUIViewsCore.DBDTooltipManager.ShowCharacterTooltip // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2720220
	void HideTooltip(); // Function DBDUIViewsCore.DBDTooltipManager.HideTooltip // (Final|Native|Public|BlueprintCallable) // @ game+0x271f420
};

// Class DBDUIViewsCore.DBDWrapBox
// Size: 0x160 (Inherited: 0x140)
struct UDBDWrapBox : UPanelWidget {
	struct FVector2D InnerSlotPadding; // 0x140(0x08)
	float WrapWidth; // 0x148(0x04)
	bool bExplicitWrapWidth; // 0x14c(0x01)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x14d(0x01)
	char pad_14E[0x12]; // 0x14e(0x12)

	void SetInnerSlotPadding(struct FVector2D InPadding); // Function DBDUIViewsCore.DBDWrapBox.SetInnerSlotPadding // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x271fd20
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function DBDUIViewsCore.DBDWrapBox.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x271fc20
	struct UDBDWrapBoxSlot* AddChildToWrapBox(struct UWidget* Content); // Function DBDUIViewsCore.DBDWrapBox.AddChildToWrapBox // (Final|Native|Public|BlueprintCallable) // @ game+0x271efa0
};

// Class DBDUIViewsCore.DBDWrapBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct UDBDWrapBoxSlot : UPanelSlot {
	struct FMargin Padding; // 0x40(0x10)
	bool bFillEmptySpace; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float FillSpanWhenLessThan; // 0x54(0x04)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x58(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x59(0x01)
	char pad_5A[0xe]; // 0x5a(0x0e)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function DBDUIViewsCore.DBDWrapBoxSlot.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x27201a0
	void SetPadding(struct FMargin InPadding); // Function DBDUIViewsCore.DBDWrapBoxSlot.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0x271fea0
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function DBDUIViewsCore.DBDWrapBoxSlot.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x271fca0
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan); // Function DBDUIViewsCore.DBDWrapBoxSlot.SetFillSpanWhenLessThan // (Final|Native|Public|BlueprintCallable) // @ game+0x271f9d0
	void SetFillEmptySpace(bool InbFillEmptySpace); // Function DBDUIViewsCore.DBDWrapBoxSlot.SetFillEmptySpace // (Final|Native|Public|BlueprintCallable) // @ game+0x271f940
};

// Class DBDUIViewsCore.TestWidget
// Size: 0x270 (Inherited: 0x260)
struct UTestWidget : UUserWidget {
	struct UPanelWidget* Workbench; // 0x260(0x08)
	bool showWorkbench; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)

	void SetShowWorkbench(bool showWorkbench); // Function DBDUIViewsCore.TestWidget.SetShowWorkbench // (Final|Native|Public|BlueprintCallable) // @ game+0x271ff30
};

