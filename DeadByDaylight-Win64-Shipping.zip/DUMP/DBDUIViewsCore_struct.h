// Enum DBDUIViewsCore.EAnalogCursorStickiness
enum class EAnalogCursorStickiness : uint8 {
	None,
	ButtonSmall,
	ButtonMedium,
	ButtonLarge,
	Bloodweb,
	Slow,
	EAnalogCursorStickiness_MAX,
};

// Enum DBDUIViewsCore.EBackgroundProgressBarState
enum class EBackgroundProgressBarState : uint8 {
	Empty,
	Quarter,
	Half,
	ThreeQuarters,
	Full,
	EBackgroundProgressBarState_MAX,
};

// Enum DBDUIViewsCore.ETabWidgetState
enum class ETabWidgetState : uint8 {
	Unselected,
	Selected,
	Disabled,
	Hidden,
	ETabWidgetState_MAX,
};

// Enum DBDUIViewsCore.EShowScrollDisplayPrompt
enum class EShowScrollDisplayPrompt : uint8 {
	DontShow,
	AlwaysShow,
	ShowOnMouseOver,
	EShowScrollDisplayPrompt_MAX,
};

// Enum DBDUIViewsCore.ETooltipType
enum class ETooltipType : uint8 {
	None,
	Character,
	Currency,
	Customization,
	ETooltipType_MAX,
};

// ScriptStruct DBDUIViewsCore.OnboardingTutorialButtonViewData
// Size: 0x78 (Inherited: 0x00)
struct FOnboardingTutorialButtonViewData {
	enum class EOnboardingStepStatus StepStatus; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString stepId; // 0x08(0x10)
	struct FString tutorialId; // 0x18(0x10)
	struct FText Title; // 0x28(0x18)
	struct FText Description; // 0x40(0x18)
	struct UTexture2D* Icon; // 0x58(0x08)
	struct TArray<struct FRewardWrapperViewData> RewardsData; // 0x60(0x10)
	enum class EOnboardingTutorialButtonStyle ButtonStyle; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct DBDUIViewsCore.PendingStepData
// Size: 0x10 (Inherited: 0x00)
struct FPendingStepData {
	struct TArray<struct FPendingTutorialData> tutorialData; // 0x00(0x10)
};

// ScriptStruct DBDUIViewsCore.PendingTutorialData
// Size: 0x80 (Inherited: 0x00)
struct FPendingTutorialData {
	int32_t buttonIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FOnboardingTutorialButtonViewData buttonViewData; // 0x08(0x78)
};

// ScriptStruct DBDUIViewsCore.TabStyle
// Size: 0x338 (Inherited: 0x00)
struct FTabStyle {
	struct FButtonStyle WidgetDefaultStyle; // 0x00(0x2a8)
	struct FTabTextProperties TextDefaultStyle; // 0x2a8(0x90)
};

// ScriptStruct DBDUIViewsCore.TabTextProperties
// Size: 0x90 (Inherited: 0x00)
struct FTabTextProperties {
	struct FSlateColor ColorAndOpacity; // 0x00(0x28)
	struct FSlateFontInfo Font; // 0x28(0x58)
	struct FLinearColor ShadowColorAndOpacity; // 0x80(0x10)
};

// ScriptStruct DBDUIViewsCore.TabWidgetData
// Size: 0x20 (Inherited: 0x00)
struct FTabWidgetData {
	struct FText Title; // 0x00(0x18)
	enum class ETabWidgetState DefaultState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DBDUIViewsCore.HtmlToRichTagConvertRow
// Size: 0x28 (Inherited: 0x08)
struct FHtmlToRichTagConvertRow : FTableRowBase {
	struct FString HtmlTag; // 0x08(0x10)
	struct FString RichTextTag; // 0x18(0x10)
};

// ScriptStruct DBDUIViewsCore.DBDTextDockingProperties
// Size: 0x40 (Inherited: 0x00)
struct FDBDTextDockingProperties {
	bool UseColor; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSlateColor Color; // 0x08(0x28)
	bool UseOpacity; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float Opacity; // 0x34(0x04)
	bool UseSize; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t Size; // 0x3c(0x04)
};

// ScriptStruct DBDUIViewsCore.InputPromptDataRow
// Size: 0x78 (Inherited: 0x08)
struct FInputPromptDataRow : FTableRowBase {
	struct FText InputLabel; // 0x08(0x18)
	struct FKey InputKey; // 0x20(0x20)
	struct TSoftObjectPtr<struct UTexture2D> PromptTexture; // 0x40(0x30)
	bool ShowLabel; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct DBDUIViewsCore.TooltipWidgetData
// Size: 0x18 (Inherited: 0x08)
struct FTooltipWidgetData : FDBDTableRowBase {
	enum class ETooltipType TooltipType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UUserWidget* WidgetClass; // 0x10(0x08)
};

