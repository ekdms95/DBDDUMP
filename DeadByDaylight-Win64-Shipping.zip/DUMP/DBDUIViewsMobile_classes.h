// Class DBDUIViewsMobile.FriendsMenuUtilities
// Size: 0x30 (Inherited: 0x30)
struct UFriendsMenuUtilities : UBlueprintFunctionLibrary {
};

// Class DBDUIViewsMobile.MobileBaseUserWidget
// Size: 0x300 (Inherited: 0x260)
struct UMobileBaseUserWidget : UUserWidget {
	char pad_260[0x10]; // 0x260(0x10)
	struct UWidget* HighlightWidget; // 0x270(0x08)
	struct FName _tutorialAnimationName; // 0x278(0x0c)
	int32_t _tutorialNumberOfLoops; // 0x284(0x04)
	char pad_288[0x78]; // 0x288(0x78)

	void TutorialAnimationFinished(); // Function DBDUIViewsMobile.MobileBaseUserWidget.TutorialAnimationFinished // (Final|Native|Private) // @ game+0x27e9fe0
	void TryBroadcastOnHighlightWidgetClicked(); // Function DBDUIViewsMobile.MobileBaseUserWidget.TryBroadcastOnHighlightWidgetClicked // (Final|Native|Protected|BlueprintCallable) // @ game+0x27e9fc0
	void TriggerTutorialVisuals(); // Function DBDUIViewsMobile.MobileBaseUserWidget.TriggerTutorialVisuals // (Native|Public|BlueprintCallable) // @ game+0x2713590
	void PropagateOnHighlightWidgetClicked(struct FName onBoardingID); // Function DBDUIViewsMobile.MobileBaseUserWidget.PropagateOnHighlightWidgetClicked // (Final|Native|Public) // @ game+0x27e9ea0
	void OnSynchronizeProperties(); // Function DBDUIViewsMobile.MobileBaseUserWidget.OnSynchronizeProperties // (Event|Public|BlueprintEvent) // @ game+0x3873200
	bool IsInTutorialState(); // Function DBDUIViewsMobile.MobileBaseUserWidget.IsInTutorialState // (Final|Native|Public|BlueprintCallable) // @ game+0x27e9e70
	void FinishTutorialVisuals(); // Function DBDUIViewsMobile.MobileBaseUserWidget.FinishTutorialVisuals // (Native|Public|BlueprintCallable) // @ game+0x27e9be0
};

// Class DBDUIViewsMobile.UMGBaseButtonWidget
// Size: 0x430 (Inherited: 0x300)
struct UUMGBaseButtonWidget : UMobileBaseUserWidget {
	struct FMulticastInlineDelegate OnBaseButtonClickedEvent; // 0x300(0x10)
	struct FMulticastInlineDelegate OnBaseButtonPressedEvent; // 0x310(0x10)
	struct FMulticastInlineDelegate OnBaseButtonReleasedEvent; // 0x320(0x10)
	struct FMulticastInlineDelegate OnBaseButtonLongPressEvent; // 0x330(0x10)
	struct UButton* Button; // 0x340(0x08)
	struct UImage* IconPicture; // 0x348(0x08)
	struct UTextBlock* ButtonLabel; // 0x350(0x08)
	struct FSlateBrush ButtonPictureBrush; // 0x358(0x90)
	struct FText ButtonText; // 0x3e8(0x18)
	struct UAkAudioEvent* OnPressSound; // 0x400(0x08)
	struct UAkAudioEvent* OnClickSound; // 0x408(0x08)
	struct UAkAudioEvent* OnLongPressSound; // 0x410(0x08)
	struct UAkAudioEvent* OnReleaseSound; // 0x418(0x08)
	struct UAkAudioEvent* OnHoveredSound; // 0x420(0x08)
	char pad_428[0x8]; // 0x428(0x08)

	void OnBaseButtonReleased__DelegateSignature(); // DelegateFunction DBDUIViewsMobile.UMGBaseButtonWidget.OnBaseButtonReleased__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnBaseButtonPressed__DelegateSignature(); // DelegateFunction DBDUIViewsMobile.UMGBaseButtonWidget.OnBaseButtonPressed__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnBaseButtonLongPress__DelegateSignature(); // DelegateFunction DBDUIViewsMobile.UMGBaseButtonWidget.OnBaseButtonLongPress__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnBaseButtonClicked__DelegateSignature(); // DelegateFunction DBDUIViewsMobile.UMGBaseButtonWidget.OnBaseButtonClicked__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void HandleButtonReleasedEvent(); // Function DBDUIViewsMobile.UMGBaseButtonWidget.HandleButtonReleasedEvent // (Native|Protected|BlueprintCallable) // @ game+0x27e9d00
	void HandleButtonPressedEvent(); // Function DBDUIViewsMobile.UMGBaseButtonWidget.HandleButtonPressedEvent // (Native|Protected|BlueprintCallable) // @ game+0x27e9ce0
	void HandleButtonLongPressEvent(); // Function DBDUIViewsMobile.UMGBaseButtonWidget.HandleButtonLongPressEvent // (Native|Protected|BlueprintCallable) // @ game+0x27e9cc0
	void HandleButtonHoveredEvent(); // Function DBDUIViewsMobile.UMGBaseButtonWidget.HandleButtonHoveredEvent // (Native|Protected|BlueprintCallable) // @ game+0x27e9ca0
	void HandleButtonClickedEvent(); // Function DBDUIViewsMobile.UMGBaseButtonWidget.HandleButtonClickedEvent // (Native|Protected|BlueprintCallable) // @ game+0x27e9c80
};

// Class DBDUIViewsMobile.UMGBaseFriendListContextualMenuWidget
// Size: 0x348 (Inherited: 0x300)
struct UUMGBaseFriendListContextualMenuWidget : UMobileBaseUserWidget {
	char pad_300[0x18]; // 0x300(0x18)
	struct UUMGFriendButtonWidget* InviteToPartyButton; // 0x318(0x08)
	struct UUMGFriendButtonWidget* MuteButton; // 0x320(0x08)
	struct UUMGFriendButtonWidget* UnmuteButton; // 0x328(0x08)
	struct UUMGFriendButtonWidget* RemoveFriendButton; // 0x330(0x08)
	char pad_338[0x10]; // 0x338(0x10)

	void HandleActionTriggered(enum class EActionOnFriendType actionType); // Function DBDUIViewsMobile.UMGBaseFriendListContextualMenuWidget.HandleActionTriggered // (Final|Native|Protected|BlueprintCallable) // @ game+0x27e9c00
};

// Class DBDUIViewsMobile.UMGBaseFriendListElement
// Size: 0x3c0 (Inherited: 0x300)
struct UUMGBaseFriendListElement : UMobileBaseUserWidget {
	struct UImage* StatusPicture; // 0x300(0x08)
	struct UTextBlock* FriendName; // 0x308(0x08)
	struct UTextBlock* FriendStatus; // 0x310(0x08)
	struct UCanvasPanel* SelectionHighlight; // 0x318(0x08)
	struct UButton* ItemSelectionButton; // 0x320(0x08)
	struct UNamedSlot* ContextualMenuPosition; // 0x328(0x08)
	struct FAtlantaFriendUIData _cachedFriendData; // 0x330(0x68)
	struct UDataTable* FriendUIStatusDataTable; // 0x398(0x08)
	char pad_3A0[0x20]; // 0x3a0(0x20)

	void TriggerActionOnThisFriend(enum class EActionOnFriendType actionType); // Function DBDUIViewsMobile.UMGBaseFriendListElement.TriggerActionOnThisFriend // (Final|Native|Public|BlueprintCallable) // @ game+0x27e9f40
};

// Class DBDUIViewsMobile.UMGBaseTabButtonWidget
// Size: 0x4a0 (Inherited: 0x430)
struct UUMGBaseTabButtonWidget : UUMGBaseButtonWidget {
	char pad_430[0x18]; // 0x430(0x18)
	struct URichTextBlock* TabText; // 0x448(0x08)
	struct UTextBlock* NotificationCountText; // 0x450(0x08)
	struct UCanvasPanel* NotificationPanel; // 0x458(0x08)
	struct UImage* TabButtonSelected; // 0x460(0x08)
	char tabIndex; // 0x468(0x01)
	char pad_469[0x7]; // 0x469(0x07)
	struct FText TitleOfTab; // 0x470(0x18)
	char pad_488[0x8]; // 0x488(0x08)
	struct FString _tabTextParameter; // 0x490(0x10)
};

// Class DBDUIViewsMobile.UMGBaseTabListWidget
// Size: 0x300 (Inherited: 0x300)
struct UUMGBaseTabListWidget : UMobileBaseUserWidget {
};

// Class DBDUIViewsMobile.UMGExpandableListWidget
// Size: 0x3a0 (Inherited: 0x300)
struct UUMGExpandableListWidget : UMobileBaseUserWidget {
	bool ShouldHideExpandableListIfEmpty; // 0x300(0x01)
	bool IsExtendedAtStart; // 0x301(0x01)
	char pad_302[0x6]; // 0x302(0x06)
	struct UVerticalBox* ItemContainer; // 0x308(0x08)
	struct UTextBlock* CategorieName; // 0x310(0x08)
	struct UTextBlock* itemCount; // 0x318(0x08)
	struct UExpandableArea* ExpandableArea; // 0x320(0x08)
	struct FText HeaderTitle; // 0x328(0x18)
	char pad_340[0x8]; // 0x340(0x08)
	struct TArray<struct UUserWidget*> _childWidgets; // 0x348(0x10)
	char pad_358[0x48]; // 0x358(0x48)
};

// Class DBDUIViewsMobile.UMGFriendBaseTabListWidget
// Size: 0x300 (Inherited: 0x300)
struct UUMGFriendBaseTabListWidget : UUMGBaseTabListWidget {
};

// Class DBDUIViewsMobile.UMGFriendButtonWidget
// Size: 0x450 (Inherited: 0x430)
struct UUMGFriendButtonWidget : UUMGBaseButtonWidget {
	struct UCanvasPanel* InteractableButtonStatePanel; // 0x430(0x08)
	struct UCanvasPanel* NonInteractableButtonStatePanel; // 0x438(0x08)
	struct UTextBlock* NonInteractableExplanationText; // 0x440(0x08)
	bool _isInteractable; // 0x448(0x01)
	char pad_449[0x7]; // 0x449(0x07)
};

// Class DBDUIViewsMobile.UMGFriendContextualMenuWidget
// Size: 0x348 (Inherited: 0x348)
struct UUMGFriendContextualMenuWidget : UUMGBaseFriendListContextualMenuWidget {
};

// Class DBDUIViewsMobile.UMGFriendElementWidget
// Size: 0x598 (Inherited: 0x3c0)
struct UUMGFriendElementWidget : UUMGBaseFriendListElement {
	struct UImage* FavoriteSlot; // 0x3c0(0x08)
	struct UButton* FavoriteButton; // 0x3c8(0x08)
	struct UImage* SelectionImage; // 0x3d0(0x08)
	struct UImage* SelectedPicture; // 0x3d8(0x08)
	struct UImage* FriendIcon; // 0x3e0(0x08)
	struct FSlateBrush UnFavoriteBrush; // 0x3e8(0x90)
	struct FSlateBrush FavoriteBrush; // 0x478(0x90)
	struct FSlateBrush MutedBrush; // 0x508(0x90)

	void HandleSelectionButton(); // Function DBDUIViewsMobile.UMGFriendElementWidget.HandleSelectionButton // (Final|Native|Protected) // @ game+0x27e9d80
	void HandleFavoriteButtonClicked(); // Function DBDUIViewsMobile.UMGFriendElementWidget.HandleFavoriteButtonClicked // (Final|Native|Protected|BlueprintCallable) // @ game+0x27e9d40
};

// Class DBDUIViewsMobile.UMGFriendListTabWidget
// Size: 0x318 (Inherited: 0x300)
struct UUMGFriendListTabWidget : UUMGFriendBaseTabListWidget {
	struct UUMGExpandableListWidget* SentInviteToParty; // 0x300(0x08)
	struct UUMGExpandableListWidget* ConnectedFriendsExpandableList; // 0x308(0x08)
	struct UUMGExpandableListWidget* DisconnectedFriendsExpandableList; // 0x310(0x08)
};

// Class DBDUIViewsMobile.UMGFriendPartyListElementWidget
// Size: 0x6d0 (Inherited: 0x598)
struct UUMGFriendPartyListElementWidget : UUMGFriendElementWidget {
	struct UWidgetSwitcher* ButtonOrStatusSwitcher; // 0x598(0x08)
	struct UButton* CancelInviteButton; // 0x5a0(0x08)
	struct UImage* PartyStatusImage; // 0x5a8(0x08)
	struct FSlateBrush IconNotReady; // 0x5b0(0x90)
	struct FSlateBrush IconReady; // 0x640(0x90)

	void HandleCancelInviteButtonClicked(); // Function DBDUIViewsMobile.UMGFriendPartyListElementWidget.HandleCancelInviteButtonClicked // (Final|Native|Protected) // @ game+0x27e9d20
};

// Class DBDUIViewsMobile.UMGFriendSearchBarWidget
// Size: 0x340 (Inherited: 0x300)
struct UUMGFriendSearchBarWidget : UMobileBaseUserWidget {
	char pad_300[0x30]; // 0x300(0x30)
	struct UEditableTextBox* InputTextField; // 0x330(0x08)
	struct UButton* SearchButton; // 0x338(0x08)

	void HandleTextInputChanged(struct FText textInput); // Function DBDUIViewsMobile.UMGFriendSearchBarWidget.HandleTextInputChanged // (Final|Native|Private|HasOutParms) // @ game+0x27e9da0
	void HandleSearchButtonClicked(); // Function DBDUIViewsMobile.UMGFriendSearchBarWidget.HandleSearchButtonClicked // (Final|Native|Private) // @ game+0x27e9d60
};

// Class DBDUIViewsMobile.UMGFriendTabButtonWidget
// Size: 0x4f0 (Inherited: 0x4a0)
struct UUMGFriendTabButtonWidget : UUMGBaseTabButtonWidget {
	char pad_4A0[0x50]; // 0x4a0(0x50)
};

// Class DBDUIViewsMobile.UMGRequestsListTabWidget
// Size: 0x310 (Inherited: 0x300)
struct UUMGRequestsListTabWidget : UUMGFriendBaseTabListWidget {
	struct UUMGExpandableListWidget* FriendRequestExpandableList; // 0x300(0x08)
	struct UUMGExpandableListWidget* PendingExpandableList; // 0x308(0x08)
};

// Class DBDUIViewsMobile.UMGSuggestionsListTabWidget
// Size: 0x310 (Inherited: 0x300)
struct UUMGSuggestionsListTabWidget : UUMGFriendBaseTabListWidget {
	struct UUMGExpandableListWidget* PlayedWithFriendsExpandableList; // 0x300(0x08)
	struct UUMGExpandableListWidget* SocialFriendsExpandableList; // 0x308(0x08)
};

