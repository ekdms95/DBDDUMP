// Enum DBDUIViewsMobile.EActionOnFriendType
enum class EActionOnFriendType : uint8 {
	None,
	SendFriendRequest,
	ConfirmFriendRequest,
	DeclineFriendRequest,
	RemoveFriend,
	AddToFavorite,
	RemoveToFavorite,
	Mute,
	Unmute,
	InviteToParty,
	CancelInviteToParty,
	Select,
	ConfirmAction,
	DeclineAction,
	Count,
	EActionOnFriendType_MAX,
};

// Enum DBDUIViewsMobile.EAtlantaFriendUIStatus
enum class EAtlantaFriendUIStatus : uint8 {
	Undefined,
	FriendSuggestion,
	FriendRequestSent,
	FriendRequestReceived,
	Available,
	InAMatch,
	Offline,
	AddFriendToSeeStatus,
	EAtlantaFriendUIStatus_MAX,
};

// ScriptStruct DBDUIViewsMobile.ActionOnFriend
// Size: 0x78 (Inherited: 0x00)
struct FActionOnFriend {
	enum class EActionOnFriendType ActionToProceed; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FAtlantaFriendUIData AtlantaFriendDataToUpdate; // 0x08(0x68)
	struct UUMGBaseFriendListElement* ActionOwner; // 0x70(0x08)
};

// ScriptStruct DBDUIViewsMobile.AtlantaFriendUIData
// Size: 0x68 (Inherited: 0x00)
struct FAtlantaFriendUIData {
	char pad_0[0x68]; // 0x00(0x68)
};

// ScriptStruct DBDUIViewsMobile.FriendStatusUIData
// Size: 0x58 (Inherited: 0x08)
struct FFriendStatusUIData : FDBDTableRowBase {
	enum class EAtlantaFriendUIStatus FriendStatus; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftObjectPtr<struct UTexture2D> StatusIcon; // 0x10(0x30)
	struct FText StatusText; // 0x40(0x18)
};

