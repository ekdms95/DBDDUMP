// Enum DeadByDaylight.EInputInteractionType
enum class EInputInteractionType : uint8 {
	VE_None,
	VE_Interact,
	VE_AttackInteract,
	VE_ItemInteract,
	VE_Rush,
	VE_ItemUse,
	VE_ItemDrop,
	VE_InteractMash,
	VE_LeftRightMash,
	VE_ExternalRequestDrop,
	VE_ExternalRequestFlashlightStunUncloak,
	VE_ExternalRequestPalletStun,
	VE_ExternalRequestStunUncloak,
	VE_ExternalRequestPalletStunUncloak,
	VE_ExternalRequestStun,
	VE_ExternalRequestDropByStunning,
	VE_ExternalRequestDropByStunningByPallet,
	VE_ExternalRequestDropByWiggleFree,
	VE_ExternalRequestDropBySkillCheck,
	VE_ExternalRequestKillerCaughtInBearTrap,
	VE_ExternalRequestDestroyWithPowerAttack,
	VE_ExternalRequestHarpoonRifleStun,
	VE_ExternalRequestGeneratorTrapStun,
	VE_FastInteract,
	VE_ExternalRequestSlashedOutOfTrap,
	VE_ExternalRequestSacrifice,
	VE_Gesture01,
	VE_Gesture02,
	VE_Gesture03,
	VE_Gesture04,
	VE_ExternalChainBlink,
	VE_ExternalRequestStunEvilWithin,
	VE_ExternalRequestKickStun,
	VE_ExternalRequestEscape,
	VE_Struggle,
	VE_Action,
	VE_ExternalRequestPutToSleepStun,
	VE_Crouch,
	VE_ExternalRequestRBTExecute,
	VE_ActionKiller,
	VE_ExternalRequestRBTExecuteAtExit,
	VE_ExternalRequestStunBySkillCheck,
	VE_AbilityUse,
	VE_ExternalRequestClosetStun,
	VE_ExternalRequestClosetExitFast,
	VE_ActivatablePerk01,
	VE_ActivatablePerk02,
	VE_ActivatablePerk03,
	VE_ActivatablePerk04,
	VE_CancelCharge,
	VE_WiggleLeft,
	VE_WiggleRight,
	VE_Count,
	VE_MAX,
};

// Enum DeadByDaylight.EInventoryType
enum class EInventoryType : uint8 {
	Main,
	Backpack,
	EInventoryType_MAX,
};

// Enum DeadByDaylight.EAttachToSocketNameEnum
enum class EAttachToSocketNameEnum : uint8 {
	ManualAttachment,
	HandItemSocket,
	Weapon_SocketLT,
	Weapon_SocketRT,
	LanternCollectableSocket,
	Tentacle_SocketLT,
	EAttachToSocketNameEnum_MAX,
};

// Enum DeadByDaylight.ECollectableState
enum class ECollectableState : uint8 {
	OnGround,
	Stored,
	Equipped,
	ToBeDropped,
	InSearchable,
	ECollectableState_MAX,
};

// Enum DeadByDaylight.ECollectableCategory
enum class ECollectableCategory : uint8 {
	Common,
	Rare,
	ECollectableCategory_MAX,
};

// Enum DeadByDaylight.EItemHandPosition
enum class EItemHandPosition : uint8 {
	None,
	HandleItem,
	AimItem,
	SmallItem,
	FirecrackerItem,
	VaccineItem,
	EItemHandPosition_MAX,
};

// Enum DeadByDaylight.EAtlantaItemProgressionBarEnum
enum class EAtlantaItemProgressionBarEnum : uint8 {
	PrimaryBar,
	SecondaryBar,
	EAtlantaItemProgressionBarEnum_MAX,
};

// Enum DeadByDaylight.EDBDScoreTypes
enum class EDBDScoreTypes : uint8 {
	DBDCamperScore_SurviveHealthy,
	DBDCamperScore_SurviveWounded,
	DBDCamperScore_SurviveKO,
	DBDCamperScore_UnlockHatch,
	DBDCamperScore_EscapeThroughHatch,
	DBDCamperScore_AllEscapeThroughHatch,
	DBDCamperScore_EscapeCarry,
	DBDCamperScore_SurviveStreakSmall,
	DBDCamperScore_SurviveStreakBig,
	DBDCamperScore_DamageStateChanged,
	DBDCamperScore_NearFriendInNeed,
	DBDCamperScore_NearFriendInNeed_PostExit,
	DBDCamperScore_FoundCamper,
	DBDCamperScore_CoopObjectives,
	DBDCamperScore_OpenDoorPercent,
	DBDCamperScore_OpenDoor,
	DBDCamperScore_GeneratorPercent,
	DBDCamperScore_GeneratorSkillCheckSuccess,
	DBDCamperScore_GeneratorSkillCheckBonus,
	DBDCamperScore_SearchablePercent,
	DBDCamperScore_SearchCompleteFinalContributionPercent,
	DBDCamperScore_AddItemToMap,
	DBDCamperScore_FixGenerator,
	DBDCamperScore_FixSpecialMapGenerator,
	DBDCamperScore_LastSurvivorFixGenerator,
	DBDCamperScore_RepairDamagedGenerator,
	DBDCamperScore_PowerExitGates,
	DBDCamperScore_CoopAltruism,
	DBDCamperScore_HealPercent,
	DBDCamperScore_HealPercent_PostExit,
	DBDCamperScore_HealFromDying,
	DBDCamperScore_HealFromDying_PostExit,
	DBDCamperScore_HealFromInjured,
	DBDCamperScore_HealFromInjured_PostExit,
	DBDCamperScore_HealSkillCheckSuccess,
	DBDCamperScore_HealSkillCheckBonus,
	DBDCamperScore_HealSelfPercent,
	DBDCamperScore_HealSelfSkillCheckSuccess,
	DBDCamperScore_HealSelfSkillCheckBonus,
	DBDCamperScore_HitAfterHookSave,
	DBDCamperScore_HitNearFriendInNeed,
	DBDCamperScore_HitNearUnhookedFriendInNeed,
	DBDCamperScore_SabotageHook,
	DBDCamperScore_SabotageHookSkillCheckSuccess,
	DBDCamperScore_SabotageHookSkillCheckBonus,
	DBDCamperScore_EscapeFromHook,
	DBDCamperScore_HookStrugglePerSecond,
	DBDCamperScore_SaveFromHook,
	DBDCamperScore_SaveFromHook_PostExit,
	DBDCamperScore_WasUnhooked,
	DBDCamperScore_SabotageBearTrap,
	DBDCamperScore_SabotageBearTrapSkillCheckSuccess,
	DBDCamperScore_SabotageBearTrapSkillCheckBonus,
	DBDCamperScore_DisableBearTrap,
	DBDCamperScore_SaveFromBearTrap,
	DBDCamperScore_SaveFromBearTrap_PostExit,
	DBDCamperScore_EscapeBearTrap,
	DBDCamperScore_BasementChillingPerSecond,
	DBDCamperScore_CoopBoldness,
	DBDCamperScore_SlasherStun,
	DBDCamperScore_SlasherStunCarrying,
	DBDCamperScore_SlasherBlind,
	DBDCamperScore_SlasherBurnInvisibility,
	DBDCamperScore_ChasePerSecond,
	DBDCamperScore_ChaseEscape,
	DBDCamperScore_ChaseSteal,
	DBDCamperScore_ChaseBlind,
	DBDCamperScore_VaultInChase,
	DBDCamperScore_NoiseDistraction,
	DBDCamperScore_SprintingNearSlasherPerSecond,
	DBDCamperScore_UnhideNearSlasher,
	DBDCamperScore_EscapeWhileChased,
	DBDCamperScore_DestroyPhantomTrap,
	DBDCamperScore_NewItem,
	DBDCamperScore_StartMatchWithUltraRareItem,
	DBDCamperScore_ItemFrom,
	DBDCamperScore_ExposerAdded,
	DBDSlasherScore_Destroy,
	DBDSlasherScore_Kill,
	DBDSlasherScore_BleedOut,
	DBDSlasherScore_BleedOutPercent,
	DBDSlasherScore_AttackSuccess,
	DBDSlasherScore_AttackDeviousness,
	DBDSlasherScore_InterruptGenerator,
	DBDSlasherScore_InterruptWindow,
	DBDSlasherScore_InterruptHide,
	DBDSlasherScore_InterruptExit,
	DBDSlasherScore_InterruptUnhook,
	DBDSlasherScore_InterruptChest,
	DBDSlasherScore_InterruptOpenHatch,
	DBDSlasherScore_InterruptExitHatch,
	DBDSlasherScore_FindHiding,
	DBDSlasherScore_PlaceTrap,
	DBDSlasherScore_Trap,
	DBDSlasherScore_TrapPickup,
	DBDSlasherScore_Hook,
	DBDSlasherScore_SacrificePercent,
	DBDSlasherScore_SacrificeSuccess,
	DBDSlasherScore_SacrificedCount,
	DBDSlasherScore_NoEscape,
	DBDSlasherScore_ChaseStart,
	DBDSlasherScore_ChasePerSecond,
	DBDSlasherScore_CloakStalkPerSecond,
	DBDSlasherScore_UncloakInView,
	DBDSlasherScore_UncloakAttack,
	DBDSlasherScore_EvadeInvisBurn,
	DBDSlasherScore_EvadeBlind,
	DBDSlasherScore_CamperDisconnect,
	DBDSlasherScore_HitCamperWithChainsaw,
	DBDSlasherScore_RunningWithChainsaw,
	DBDSlasherScore_ChainBlinkAttack,
	DBDSlasherScore_ChainBlinkInterrupt,
	DBDSlasherScore_ChainBlinkInterruptAfter3,
	DBDSlasherScore_ChainBlinkStartChase,
	DBDSlasherScore_StalkpointGained,
	DBDSlasherScore_StalkerTierIncrement,
	DBDSlasherScore_StalkerTierFirstTime,
	DBDSlasherScore_StalkerKillAllCampers,
	DBDSlasherScore_PhantomTrapSet,
	DBDSlasherScore_PhantomTrapTrigger,
	DBDSlasherScore_PhantomTrapTriggerAttack,
	DBDSlasherScore_PhantomTrapTeleportAttack,
	DBDSlasherScore_PhantomTrapTeleportAttackAllCampers,
	DBDSlasherScore_ThrillOfTheHunt,
	DBDPlayerScore_BloodwebLevelUp,
	DBDPlayerScore_BloodwebPrestigeLevelUp,
	DBDPlayerScore_BloodwebPrestige3LevelUp,
	DBDPlayerScore_AwardPips,
	DBDPlayerScore_AddBloodpoints,
	DBDPlayerScore_BloodpointsOneCategory,
	DBDPlayerScore_MaxBloodpointsAllCategories,
	DBDPlayerScore_AddNewPerk,
	DBDPlayerScore_PerkLevelUp,
	DBDPlayerScore_BurnOfferingUltraRare,
	DBDPlayerScore_StartGame,
	DBDPlayerScore_UnlockRanking,
	DBDPlayerScore_FinishWithPerks,
	DBDCamperScore_CheatObjectives,
	DBDCamperScore_CheatSurvival,
	DBDCamperScore_CheatAltruism,
	DBDCamperScore_CheatBoldness,
	DBDSlasherScore_CheatSacrifice,
	DBDSlasherScore_CheatBrutality,
	DBDSlasherScore_CheatDeviousness,
	DBDSlasherScore_CheatHunter,
	DBDCamperScore_CleanseDullTotem,
	DBDCamperScore_CleanseHexTotem,
	DBDPlayerScore_BalancedLanding,
	DBDPlayerScore_Lithe,
	DBDSlasherScore_DamageGenerator,
	DBDSlasherScore_Vault,
	DBDCamperScore_StartInjuredBleedout,
	DBDCamperScore_FullRecovery,
	DBDCamperScore_FirstTimeDying,
	DBDCamperScore_SecondTimeDying,
	DBDCamperScore_FirecrackerDisturbance,
	DBDCamperScore_GeneratorSkillCheckRuinBonus,
	DBDCamperScore_SlasherBurnBlink,
	DBDCamperScore_DieSacrificed,
	DBDCamperScore_DieBleedOut,
	DBDCamperScore_DieKill,
	DBDPlayerScore_EndGame,
	DBDPlayerScore_EnterParadise,
	DBDSlasherScore_CamperHookedFirstTime,
	DBDSlasherScore_CamperEnterHookStrugglePhase,
	DBDSlasherScore_ElectroShockSurvivor,
	DBDSlasherScore_BringAllSurvivorsToMadnessTier3,
	DBDSlasherScore_BringSurvivorUpOneMadnessTier,
	DBDSlasherScore_HitSurvivorAfterElectroShock,
	DBDSlasherScore_PickupCamper,
	DBDSlasherScore_Blink,
	DBDSlasherScore_TeleportToPhantomTrap,
	DBDSlasherScore_HatchetThrow,
	DBDSlasherScore_HatchetHit,
	DBDSlasherScore_HatchetSkillShotHit,
	DBDSlasherScore_HatchetFarHit,
	DBDCamperScore_QuickVault,
	DBDCamperScore_QuickCloset,
	DBDCamperScore_StartGeneratorRepair,
	DBDCamperScore_StartCleansingTotem,
	DBDCamperScore_FirstRepairSkillCheck,
	DBDSlasherScore_CamperDisconnectedBeforeMatchStart,
	DBDSlasherScore_CamperDisconnectedDuringMatch,
	DBDCamperScore_NearFriendInNeed_GeneratorsComplete,
	DBDCamperScore_HealPercent_GeneratorsComplete,
	DBDCamperScore_HealFromDying_GeneratorsComplete,
	DBDCamperScore_SaveFromHook_GeneratorsComplete,
	DBDCamperScore_SaveFromBearTrap_GeneratorsComplete,
	DBDCamperScore_SnapOutOfIt,
	DBDSlasherScore_HookInBasement,
	DBDSlasherScore_LFChainsawHit,
	DBDCamperScore_PalletDrop,
	DBDCamperScore_Vault,
	DBDSlasherScore_StartChaseWithChainsawAttack,
	DBDSlasherScore_MissedAttackInChase,
	DBDCamperScore_DodgeAndVault,
	DBDCamperScore_BeginQuickVault,
	DBDSlasherScore_StartChainsawAttack,
	DBDCamperScore_WakeUpBySkillCheck,
	DBDCamperScore_FallAsleep,
	DBDCamperScore_WakeUpSelf,
	DBDCamperScore_WakeUpOther,
	DBDSlasherScore_RecentlyAsleepAttack,
	DBDSlasherScore_SurvivorPartyOnBasementHooks,
	DBDCamperScore_LootBasementChest,
	DBDPlayerScore_OpenMysteryBox,
	DBDGameEvent_SurvivorDowned,
	DBDGameEvent_SurvivorDied,
	DBDGameEvent_KillerCloak,
	DBDSlasherScore_SetReverseBearTrap,
	DBDSlasherScore_AbductionDash,
	DBDSlasherScore_DashHitSuccess,
	DBDSlasherScore_KillWithReverseBearTrap,
	DBDCamperScore_SearchRBTKey,
	DBDCamperScore_EscapeRBT,
	DBDGameEvent_ReplacedGoodSkillCheckAsGreat,
	DBDCamperScore_RemoveReverseBearTrapSkillCheckSuccess,
	DBDCamperScore_RemoveReverseBearTrapSkillCheckBonus,
	DBDSlasherScore_DamageGeneratorWhileHooked,
	DBDGameEvent_SurvivorDamaged,
	DBDGameEvent_SurvivorHealed,
	DBDGameEvent_Interruption,
	DBDGameEvent_SurvivorFailedHealSkillcheck,
	DBDGameEvent_HookedSurvivorSacrificeBegin,
	DBDGameEvent_AcquireEventKillerCoin,
	DBDGameEvent_AcquireEventSurvivorCoin,
	DBDCamperScore_EventGeneratorFixed,
	DBDSlasherScore_HookedOnEventHook,
	DBDGameEvent_GeneratorProgress,
	DBDSlasherScore_DownSmokedCamper,
	DBDSlasherScore_HitSmokedCamper,
	DBDSlasherScore_SurvivorEnterGasCloud,
	DBDSlasherScore_BombDirectHit,
	DBDSlasherScore_ThrowBomb,
	DBDGameEvent_CoopAction,
	DBDSlasherScore_StartActivePhaseWalk,
	DBDScore_Count,
	EDBDScoreTypes_MAX,
};

// Enum DeadByDaylight.EDBDCameraSocketID
enum class EDBDCameraSocketID : uint8 {
	VE_None,
	VE_Default,
	VE_Killcam,
	VE_Reaction,
	VE_Struggle,
	VE_Sacrifice,
	VE_MAX,
};

// Enum DeadByDaylight.ECharacterStance
enum class ECharacterStance : uint8 {
	VE_Stand,
	VE_Crouch,
	VE_Crawl,
	VE_MAX,
};

// Enum DeadByDaylight.EAuthoritativeMovementFlag
enum class EAuthoritativeMovementFlag : uint8 {
	INTERACTION,
	SLASHED,
	CHEAT,
	DROPPED,
	NOPUSH,
	INTERACTIONNOPUSH,
	DREAMWORLD_NOSLASHERCOLLISION,
	COUNT,
	EAuthoritativeMovementFlag_MAX,
};

// Enum DeadByDaylight.ECustomizationCategory
enum class ECustomizationCategory : uint8 {
	None,
	SurvivorHead,
	SurvivorTorso,
	SurvivorLegs,
	KillerHead,
	KillerBody,
	KillerWeapon,
	Outfits,
	Charm,
	ECustomizationCategory_MAX,
};

// Enum DeadByDaylight.EEndGameReason
enum class EEndGameReason : uint8 {
	None,
	Normal,
	KillerLeft,
	PlayerLeftDuringLoading,
	KillerLeftEarly,
	InvalidPlayerRoles,
	EEndGameReason_MAX,
};

// Enum DeadByDaylight.ETileSpawnPointType
enum class ETileSpawnPointType : uint8 {
	Unspecified,
	Survivor,
	SurvivorItem,
	Killer,
	KillerItem,
	InteractableObject,
	Count,
	ETileSpawnPointType_MAX,
};

// Enum DeadByDaylight.ECamperDamageState
enum class ECamperDamageState : uint8 {
	VE_Healthy,
	VE_Injured,
	VE_KO,
	VE_Dead,
	VE_MAX,
};

// Enum DeadByDaylight.ECamperImmobilizeState
enum class ECamperImmobilizeState : uint8 {
	VE_None,
	VE_Hooked,
	VE_Trapped,
	VE_Hiding,
	VE_Dead,
	VE_InDeathBed,
	VE_MAX,
};

// Enum DeadByDaylight.EAttackZoneSet
enum class EAttackZoneSet : uint8 {
	VE_OriginalZones,
	VE_WedgeZones,
	VE_MAX,
};

// Enum DeadByDaylight.ESlasherGuidedAction
enum class ESlasherGuidedAction : uint8 {
	VE_None,
	VE_Hooking,
	VE_PickingUp,
	VE_PuttingDown,
	VE_MAX,
};

// Enum DeadByDaylight.ETutorialStep
enum class ETutorialStep : uint8 {
	Survivor_NotStarted,
	Survivor_CompleteGenerator,
	Survivor_EvadeKiller,
	Survivor_OnHook,
	Done,
	Invalid,
	ETutorialStep_MAX,
};

// Enum DeadByDaylight.EInventoryItemType
enum class EInventoryItemType : uint8 {
	None,
	Item,
	ItemAddOn,
	CamperPerk,
	Power,
	PowerAddOn,
	SlasherPerk,
	Favor,
	Customization,
	Count,
	EInventoryItemType_MAX,
};

// Enum DeadByDaylight.EPerkCategory
enum class EPerkCategory : uint8 {
	None,
	Navigation,
	Perception,
	Safeguard,
	Concealment,
	Strategy,
	Support,
	Adaptation,
	Chasing,
	Tracking,
	Cruelty,
	Trickery,
	Obstruction,
	Hinderance,
	Enhancement,
	EPerkCategory_MAX,
};

// Enum DeadByDaylight.ELanternState
enum class ELanternState : uint8 {
	Collectable,
	Collected,
	Destroyed,
	Destroyable,
	ELanternState_MAX,
};

// Enum DeadByDaylight.EHitValidatorConfigName
enum class EHitValidatorConfigName : uint8 {
	Default,
	Hatchet,
	Bomb,
	Harpoon,
	Oni,
	Whip,
	DefaultProjectile,
	EHitValidatorConfigName_MAX,
};

// Enum DeadByDaylight.EGhostStealthState
enum class EGhostStealthState : uint8 {
	AWAITING_ACTIVATION,
	ACTIVATED,
	COOLDOWN,
	EGhostStealthState_MAX,
};

// Enum DeadByDaylight.EAudioCustomizationCategory
enum class EAudioCustomizationCategory : uint8 {
	AudioCharacterName,
	AudioCharacterSubName,
	AudioCharacterHead,
	AudioCharacterClothes,
	AudioCharacterShoes,
	AudioCharacterWeapon,
	AudioCharacterAmbiance,
	AudioCharacterState,
	EAudioCustomizationCategory_MAX,
};

// Enum DeadByDaylight.EActionButtonState
enum class EActionButtonState : uint8 {
	Normal,
	Toggled,
	Disabled,
	Hidden,
	EActionButtonState_MAX,
};

// Enum DeadByDaylight.EKnowledgeSharingType
enum class EKnowledgeSharingType : uint8 {
	Possessor,
	Survivors,
	Killers,
	All,
	EKnowledgeSharingType_MAX,
};

// Enum DeadByDaylight.EGameplayElementType
enum class EGameplayElementType : uint8 {
	Generic,
	MeatLocker_Small,
	TileLights,
	MeatLocker_Big,
	Searchable,
	EdgeObjects,
	LivingWorldObjects,
	Hatch,
	Bookshelves,
	Totems,
	QuadrantSpawn,
	EdgeObjectsBlocker,
	BreakableWalls,
	Escape,
	Count,
	EGameplayElementType_MAX,
};

// Enum DeadByDaylight.EArchivesTab
enum class EArchivesTab : uint8 {
	CurrentStory,
	Rewards,
	PastStories,
	TabCount,
	EArchivesTab_MAX,
};

// Enum DeadByDaylight.EArchiveNodeType
enum class EArchiveNodeType : uint8 {
	Narrative,
	Task,
	Challenge,
	Contextual,
	None,
	EArchiveNodeType_MAX,
};

// Enum DeadByDaylight.EArchiveNodeStatus
enum class EArchiveNodeStatus : uint8 {
	Closed,
	Completed,
	Open,
	Paused,
	Waiting,
	Error,
	EArchiveNodeStatus_MAX,
};

// Enum DeadByDaylight.EOwnershipBehaviour
enum class EOwnershipBehaviour : uint8 {
	Personal,
	Shared,
	EOwnershipBehaviour_MAX,
};

// Enum DeadByDaylight.EStackingBehaviours
enum class EStackingBehaviours : uint8 {
	Stackable,
	Override,
	EStackingBehaviours_MAX,
};

// Enum DeadByDaylight.EAdditiveBehaviour
enum class EAdditiveBehaviour : uint8 {
	AddValues,
	MaxValue,
	EAdditiveBehaviour_MAX,
};

// Enum DeadByDaylight.EContextualType
enum class EContextualType : uint8 {
	None,
	RedGlyph,
	BlueGlyph,
	GlyphUpperBound,
	ToxinPlantHalloween2020,
	EContextualType_MAX,
};

// Enum DeadByDaylight.EArm
enum class EArm : uint8 {
	Left,
	Right,
	EArm_MAX,
};

// Enum DeadByDaylight.EAtlantaRitualRewardUIType
enum class EAtlantaRitualRewardUIType : uint8 {
	Item,
	AddOn,
	Offering,
	BloodPoints,
	IridescentShards,
	AuricCells,
	Customization,
	CustoTicket,
	MysteryBox,
	EAtlantaRitualRewardUIType_MAX,
};

// Enum DeadByDaylight.EAltantaRitualUIType
enum class EAltantaRitualUIType : uint8 {
	Single,
	Master,
	Special,
	EAltantaRitualUIType_MAX,
};

// Enum DeadByDaylight.EAttackEventType
enum class EAttackEventType : uint8 {
	VE_None,
	VE_BasicAttackAttempt,
	VE_BasicAttackHit,
	VE_SpecialAttackAttempt,
	VE_SpecialAttackHit,
	VE_MAX,
};

// Enum DeadByDaylight.EBlinkerState
enum class EBlinkerState : uint8 {
	VE_Ready,
	VE_ChainBlink,
	VE_AttackBlink,
	VE_CooldownRequested,
	VE_Cooldown,
	VE_MAX,
};

// Enum DeadByDaylight.EBloodwebFillingMethod
enum class EBloodwebFillingMethod : uint8 {
	RestrictionsBasedOnData,
	FillAll,
	EBloodwebFillingMethod_MAX,
};

// Enum DeadByDaylight.EBloodwebDefinitionContentType
enum class EBloodwebDefinitionContentType : uint8 {
	Empty,
	Nodes,
	Paths,
	NodesAndPaths,
	NodesNoPath,
	EBloodwebDefinitionContentType_MAX,
};

// Enum DeadByDaylight.EBloodwebDistributionType
enum class EBloodwebDistributionType : uint8 {
	PerWeb,
	PerRing,
	EBloodwebDistributionType_MAX,
};

// Enum DeadByDaylight.EBloodwebDataSource
enum class EBloodwebDataSource : uint8 {
	ByLevel,
	ByRing,
	EBloodwebDataSource_MAX,
};

// Enum DeadByDaylight.EBloodwebNodeGateTypes
enum class EBloodwebNodeGateTypes : uint8 {
	RequiredRank,
	RequiredItem,
	Count,
	EBloodwebNodeGateTypes_MAX,
};

// Enum DeadByDaylight.EBloodwebNodeContentType
enum class EBloodwebNodeContentType : uint8 {
	Empty,
	Perks,
	PerkBuffs_Do_Not_Use_Deprecated,
	Offerings,
	Items,
	AddOn,
	Chests,
	PerksPacks,
	IridiscentShards,
	EBloodwebNodeContentType_MAX,
};

// Enum DeadByDaylight.EBloodwebNodeState
enum class EBloodwebNodeState : uint8 {
	Inactive,
	Available,
	Locked_Do_Not_Use_Deprecated,
	Collected,
	Consumed,
	EBloodwebNodeState_MAX,
};

// Enum DeadByDaylight.EBloodwebRing
enum class EBloodwebRing : uint8 {
	CenterRing,
	InnerRing,
	MiddleRing,
	OuterRing,
	EntityRing,
	RingCount,
	EBloodwebRing_MAX,
};

// Enum DeadByDaylight.EBreakableState
enum class EBreakableState : uint8 {
	Unbroken,
	Broken,
	EBreakableState_MAX,
};

// Enum DeadByDaylight.ECameraOffsetState
enum class ECameraOffsetState : uint8 {
	None,
	Default,
	Crouching,
	Crawling,
	Carried,
	ECameraOffsetState_MAX,
};

// Enum DeadByDaylight.EEscapeType
enum class EEscapeType : uint8 {
	Escape_ExitGate,
	Escape_Hatch,
	Escape_KillerDisconnect,
	Escape_MAX,
};

// Enum DeadByDaylight.EChargeableInteractionBarType
enum class EChargeableInteractionBarType : uint8 {
	VE_Normal,
	VE_ProgressPips,
	VE_MAX,
};

// Enum DeadByDaylight.ECharmCategory
enum class ECharmCategory : uint8 {
	None,
	Small,
	Medium,
	Big,
	ECharmCategory_MAX,
};

// Enum DeadByDaylight.EItemDomain
enum class EItemDomain : uint8 {
	Store,
	Local,
	Any,
	EItemDomain_MAX,
};

// Enum DeadByDaylight.EOwnership
enum class EOwnership : uint8 {
	Owned,
	NotOwned,
	Any,
	EOwnership_MAX,
};

// Enum DeadByDaylight.EUMGDailyRewardWidgetState
enum class EUMGDailyRewardWidgetState : uint8 {
	Unknown,
	Locked,
	ReadyToCollect,
	NewlyCollected,
	Collected,
	MysteryLocked,
	MysteryReadyToDiscover,
	MysteryNewlyDiscovered,
	EUMGDailyRewardWidgetState_MAX,
};

// Enum DeadByDaylight.DBDScalabilityLevel
enum class DBDScalabilityLevel : uint8 {
	LOW,
	MEDIUM,
	HIGH,
	EPIC,
	ULTRA,
	DBDScalabilityLevel_MAX,
};

// Enum DeadByDaylight.EPawnInputPressTypes
enum class EPawnInputPressTypes : uint8 {
	None,
	FastInteract,
	Interact,
	Wiggle,
	Struggle,
	Slash,
	Attack,
	Action,
	SecondaryAction,
	UseItem,
	DropItem,
	Gesture01,
	Gesture02,
	Gesture03,
	Gesture04,
	EPawnInputPressTypes_MAX,
};

// Enum DeadByDaylight.EAIDifficultyLevel
enum class EAIDifficultyLevel : uint8 {
	VeryEasy,
	Easy,
	Medium,
	Hard,
	None,
	Max,
	EAIDifficultyLevel_MAX,
};

// Enum DeadByDaylight.ECharacterMovementTypes
enum class ECharacterMovementTypes : uint8 {
	Normal,
	Run,
	Crouch,
	ECharacterMovementTypes_MAX,
};

// Enum DeadByDaylight.EAITerrorLevel
enum class EAITerrorLevel : uint8 {
	None,
	Low,
	Min,
	Medium,
	High,
	VeryHigh,
	Max,
	EAITerrorLevel_MAX,
};

// Enum DeadByDaylight.EDBDAnalyticsGameMode
enum class EDBDAnalyticsGameMode : uint8 {
	AnalyticsServer,
	AnalyticsClient,
	AnalyticsLoading,
	AnalyticsLobby,
	AnalyticsMenu,
	AnalyticsPostGame,
	AnalyticsPerfTests,
	AnalyticsSplashScreen,
	EDBDAnalyticsGameMode_MAX,
};

// Enum DeadByDaylight.ECamperGuidedAction
enum class ECamperGuidedAction : uint8 {
	VE_None,
	VE_PrepBeingKilled,
	VE_BeingKilled,
	VE_PrepGuidedAction,
	VE_BeingHelpedOffHookFront,
	VE_BeingHelpedOffHookBack,
	VE_BeingPickedUp,
	VE_BeingPutDown,
	VE_BeingCarried,
	VE_BeingPutOnHook,
	VE_BeingHealed,
	VE_BeingPulledFromCloset,
	VE_BeingHelpedFromTrap,
	VE_AttachReverseBearTrap,
	VE_BeingMended,
	VE_BeingInjectedWithSerum,
	VE_MAX,
};

// Enum DeadByDaylight.EMovementCurveType
enum class EMovementCurveType : uint8 {
	AdditiveSpeedCurve,
	MultiplicativeSpeedCurve,
	EMovementCurveType_MAX,
};

// Enum DeadByDaylight.ECustomMovementMode
enum class ECustomMovementMode : uint8 {
	CUSTOM_MOVE_None,
	CUSTOM_MOVE_Snapping,
	CUSTOM_MOVE_MAX,
};

// Enum DeadByDaylight.EDiceRollType
enum class EDiceRollType : uint8 {
	VE_EscapeHook,
	VE_EscapeTrap,
	VE_TrapInflictsDying,
	VE_TriggerSkillCheck,
	VE_TriggerFootNoise,
	VE_TriggerCrowAlert,
	VE_MAX,
};

// Enum DeadByDaylight.EEmblemProgressionType
enum class EEmblemProgressionType : uint8 {
	SurvivorLightbringerStartingValue,
	SurvivorLightbringerGeneratorRepair,
	SurvivorLightbringerTotemCleanse,
	SurvivorLightbringerKillerDiversion,
	SurvivorLightbringerExitGameOpen,
	SurvivorUnbrokenTimeAlive,
	SurvivorBenevolentStartingValue,
	SurvivorBenevolentHealing,
	SurvivorBenevolentHooked,
	SurvivorBenevolentUnhook,
	SurvivorBenevolentPerformUnhook,
	SurvivorBenevolentSaveFromKiller,
	SurvivorBenevolentUnsafeUnhook,
	SurvivorBenevolentHitWhileCarrying,
	SurvivorEvaderStartingValue,
	SurvivorEvaderSneaking,
	SurvivorEvaderChaseWon,
	SurvivorEvaderChaseLost,
	SurvivorEvaderPalletStun,
	KillerGatekeeperStartingValue,
	KillerGatekeeperGeneratorDefense,
	KillerGatekeeperGatesClosed,
	KillerDevoutStartingValue,
	KillerDevoutSacrifice,
	KillerDevoutDisconnect,
	KillerDevoutMoris,
	KillerDevoutAllSurvivorsHooked,
	KillerDevoutHooksBonus,
	KillerMaliciousStartingValue,
	KillerMaliciousInjuries,
	KillerMaliciousHookStages,
	KillerMaliciousInjuriesHealed,
	KillerMaliciousEscapeGrasp,
	KillerMaliciousDisconnect,
	KillerChaserStartingValue,
	KillerChaserSurvivorFound,
	KillerChaserSurvivorLost,
	KillerChaserHit,
	KillerChaserChaseWon,
	KillerChaserProximityToHookPenalty,
	Invalid,
	EEmblemProgressionType_MAX,
};

// Enum DeadByDaylight.EEmblemQuality
enum class EEmblemQuality : uint8 {
	None,
	Bronze,
	Silver,
	Gold,
	Iridescent,
	Count,
	EEmblemQuality_MAX,
};

// Enum DeadByDaylight.EEmblemEvaluation
enum class EEmblemEvaluation : uint8 {
	Authority,
	Local,
	EEmblemEvaluation_MAX,
};

// Enum DeadByDaylight.EErrorCodes
enum class EErrorCodes : uint8 {
	None,
	SavefileDeserializationFailure,
	SavefileDecryptionFailure,
	SavefileEmpty,
	SavefileBadPlayerId,
	SavefileEmptyPlayerUID,
	SavefileInvalidUniqueNetID,
	SavefileInvalidPlayerState,
	SavefileBackendError,
	KrakenRankError,
	KrakenRatingsError,
	SavefileKrakenPlayerForbidden,
	SyncCachedCurrencyError,
	CurrencyTransactionError,
	SavefileEncryptionFailure,
	SaveFailedInvalidData,
	SaveFailedInvalidJSON,
	SaveFailedDecodeDataString,
	SaveFailedCompressDataString,
	SaveFailedEncryptString,
	SaveFailedCloudErrorTimeout,
	JsonToPersistenDataFailed,
	SaveFailedCloudErrorAfterRetries,
	GetPlayerLevelRequestError,
	EarnPlayerXpRequestError,
	EarnPlayerXpParamError,
	OnboardingFailGet,
	OnboardingFailUpdate,
	OnboardingFailRequest,
	EErrorCodes_MAX,
};

// Enum DeadByDaylight.EGameIntroSteps
enum class EGameIntroSteps : uint8 {
	Idling,
	PlayingIntro,
	LoopingCamView,
	EGameIntroSteps_MAX,
};

// Enum DeadByDaylight.EDisconnectErrors
enum class EDisconnectErrors : uint8 {
	None,
	SteamAuthFailure,
	SteamAuthFailureKickedFromServer,
	EACServerValidationFailure,
	EACValidationFailureKickedFromServer,
	EACClientNotRunning,
	EACClientIntegrityViolation,
	PlayerRemovedOnSuspend,
	LostConnectionToHost,
	LostConnectionToProfileService,
	MirrorsUnscheduledSessionDestruction,
	SessionKilledByMirrors,
	UnableToSaveProfileAfterRetries,
	UnableToGetPlayerLevel,
	UnableToEarnPlayerXp,
	UnableToUpdatePips,
	UnableToUpdateRatings,
	ClientProviderAuthenticationFailed,
	UnableToSyncCachedCurrency,
	EDisconnectErrors_MAX,
};

// Enum DeadByDaylight.ELevelLoadingSteps
enum class ELevelLoadingSteps : uint8 {
	Invalid,
	WaitingForPlayersToBeSpawned,
	WaitingForAIPawnToBeSpawned,
	WaitingForLoadoutAndTheme,
	WaitingForPIAToBeSpawnedAndInitialized,
	WaitingForNavmeshComputationToStart,
	WaitingForNavmeshComputationToFinish,
	SetGameLoadedAndReadyToPlay,
	WaitingForIntroToBeDone,
	LoadingCompleted,
	ELevelLoadingSteps_MAX,
};

// Enum DeadByDaylight.ELoadProgress
enum class ELoadProgress : uint8 {
	NotStarted,
	Init,
	ArtificialDelay,
	DisconnectingPresencePlugin,
	ValidateOnlineSubsystem,
	CheckingPlatformService,
	ConnectingToMirrors,
	StartEAC,
	LoadingBackendConfigs,
	SetupRichPresence,
	LoadingBackendTunables,
	ApplyingCDNPatch,
	AquiringExternalAuthentication,
	LoadingPlayerIndependentShopData,
	LicenseCache,
	LoadingEvents,
	LoadingInventory,
	SyncingOwnedCharacters,
	LoadingProfile,
	LoadingMirrorCurrencies,
	LoadingWallet,
	LoadingConsent,
	LoadingGameConfigs,
	LoadingCharacterXPTables,
	CheckingPendingTransactions,
	LoadingContentSchedule,
	LoadingNews,
	SendingAnalytics,
	ValidateData,
	ValidatingClientVersion,
	CheckingNeedForCurrencyMigration,
	MigratingCurrenciesToMirror,
	SyncingFriendsList,
	Complete,
	Locating,
	InitializingRTMConnection,
	ELoadProgress_MAX,
};

// Enum DeadByDaylight.EProceduralDebugMode
enum class EProceduralDebugMode : uint8 {
	None,
	NoMap,
	TilesSmall,
	TilesBig,
	Count,
	EProceduralDebugMode_MAX,
};

// Enum DeadByDaylight.EAIEvadeLoopSides
enum class EAIEvadeLoopSides : uint8 {
	Left,
	Right,
	Count,
	EAIEvadeLoopSides_MAX,
};

// Enum DeadByDaylight.EPlayerGameplayEventType
enum class EPlayerGameplayEventType : uint8 {
	VE_UnhookedOther,
	VE_UntrappedOther,
	VE_HealedOther,
	VE_MAX,
};

// Enum DeadByDaylight.EVisibleMenuActorType
enum class EVisibleMenuActorType : uint8 {
	None,
	Pawn,
	Hook,
	Charm,
	EVisibleMenuActorType_MAX,
};

// Enum DeadByDaylight.ELoginType
enum class ELoginType : uint8 {
	Reservation,
	Join,
	None,
	ELoginType_MAX,
};

// Enum DeadByDaylight.EGameType
enum class EGameType : uint8 {
	Online,
	KillYourFriends,
	SurvivorGroup,
	Tutorial,
	TutorialBotMatch,
	None,
	EGameType_MAX,
};

// Enum DeadByDaylight.EToastInputType
enum class EToastInputType : uint8 {
	Toast_Accept,
	Toast_Reject,
	Toast_Close,
	Toast_MAX,
};

// Enum DeadByDaylight.EShadowSystem
enum class EShadowSystem : uint8 {
	CascadedShadowMap,
	CacheWholeSceneStaticShadowMap,
	AdaptiveShadowMap,
	EShadowSystem_MAX,
};

// Enum DeadByDaylight.EDemogorgonPortalState
enum class EDemogorgonPortalState : uint8 {
	Hidden,
	InUse,
	Exposed,
	EDemogorgonPortalState_MAX,
};

// Enum DeadByDaylight.EDoctorAbilityPhase
enum class EDoctorAbilityPhase : uint8 {
	VE_Charging,
	VE_Firing,
	VE_None,
	VE_MAX,
};

// Enum DeadByDaylight.EDoctorAbilityType
enum class EDoctorAbilityType : uint8 {
	VE_ShockTherapy,
	VE_StaticBlast,
	VE_None,
	VE_MAX,
};

// Enum DeadByDaylight.EEndGameScenarioTrigger
enum class EEndGameScenarioTrigger : uint8 {
	ClosedHatch,
	OpenedGate,
	CheatUsed,
	NotActivated,
	EEndGameScenarioTrigger_MAX,
};

// Enum DeadByDaylight.EEnergyTypeEnum
enum class EEnergyTypeEnum : uint8 {
	EInvalid,
	EBattery,
	EHealth,
	EEnergyTypeEnum_MAX,
};

// Enum DeadByDaylight.EEscapeDoorActivationMode
enum class EEscapeDoorActivationMode : uint8 {
	Standard,
	Tutorial,
	EEscapeDoorActivationMode_MAX,
};

// Enum DeadByDaylight.EConditionSubject
enum class EConditionSubject : uint8 {
	Instigator,
	Target,
	EConditionSubject_MAX,
};

// Enum DeadByDaylight.ELoadoutType
enum class ELoadoutType : uint8 {
	Item,
	Perk,
	Offering,
	ELoadoutType_MAX,
};

// Enum DeadByDaylight.FlickeringLightType
enum class FlickeringLightType : uint8 {
	Point,
	Rect,
	Spot,
	FlickeringLightType_MAX,
};

// Enum DeadByDaylight.EFrenzyEndReason
enum class EFrenzyEndReason : uint8 {
	OutOfTime,
	Manual,
	PickUpCamper,
	Stunned,
	Mori,
	Blinded,
	EFrenzyEndReason_MAX,
};

// Enum DeadByDaylight.EFriendUIRichPresence
enum class EFriendUIRichPresence : uint8 {
	Undefined,
	InMenus,
	InLobby,
	InMatch,
	Connected,
	Closing,
	EFriendUIRichPresence_MAX,
};

// Enum DeadByDaylight.EFriendUIStatus
enum class EFriendUIStatus : uint8 {
	Offline,
	Online,
	PlayingDBD,
	PendingSentRequest,
	PendingReceivedRequest,
	NotFriend,
	Self,
	EFriendUIStatus_MAX,
};

// Enum DeadByDaylight.EFlowTransitionType
enum class EFlowTransitionType : uint8 {
	Tally,
	OnlineLobby,
	PartyLobby,
	OfflineLobby,
	Splash,
	RoleSelection,
	None,
	EFlowTransitionType_MAX,
};

// Enum DeadByDaylight.EUIFlowEvent
enum class EUIFlowEvent : uint8 {
	None,
	AtlantaRoleSelectionScreenReady,
	AtlantaNavigationScreenReady,
	InGameHudReady,
	LoadingScreenReady,
	OfflineLobbyScreenReady,
	OnlineLobbyScreenReady,
	RoleSelectionScreenReady,
	SplashScreenReady,
	TallyScreenReady,
	PartyLobbyScreenReady,
	StoreScreenReady,
	EUIFlowEvent_MAX,
};

// Enum DeadByDaylight.EWorldFlowEvent
enum class EWorldFlowEvent : uint8 {
	None,
	GameLevelLoaded,
	LoadingGameLevel,
	LoadingOfflineParadise,
	LoadingOnlineLobbyLevel,
	OfflineLobbyMapLoaded,
	OfflineParadiseLoaded,
	OnlineLobbyMapLoaded,
	StartScreenMapLoaded,
	LoadingSplashScreen,
	EWorldFlowEvent_MAX,
};

// Enum DeadByDaylight.EGameFlowStep
enum class EGameFlowStep : uint8 {
	None,
	InGame,
	OfflineLobby,
	OfflineTally,
	OnlineLobby,
	SplashScreen,
	PartyLobby,
	Store,
	RoleSelection,
	EGameFlowStep_MAX,
};

// Enum DeadByDaylight.EGameplayModifierSource
enum class EGameplayModifierSource : uint8 {
	VE_Perk,
	VE_StatusEffect,
	VE_Item,
	VE_ItemAddon,
	VE_All,
	VE_PerkOrStatusEffect,
	VE_PerkStatusOrAddon,
	VE_MAX,
};

// Enum DeadByDaylight.EGateType
enum class EGateType : uint8 {
	VE_AndGate,
	VE_TimerGate,
	VE_MAX,
};

// Enum DeadByDaylight.EGestureID
enum class EGestureID : uint8 {
	POINT,
	COME,
	EGestureID_MAX,
};

// Enum DeadByDaylight.EHatchState
enum class EHatchState : uint8 {
	Hidden,
	DefaultClose,
	Opened,
	ForcedClose,
	EHatchState_MAX,
};

// Enum DeadByDaylight.EHintCategory
enum class EHintCategory : uint8 {
	Lore,
	Survivor,
	Killer,
	EHintCategory_MAX,
};

// Enum DeadByDaylight.EHookType
enum class EHookType : uint8 {
	Hook,
	DeathBed,
	None,
	EHookType_MAX,
};

// Enum DeadByDaylight.EProgressModifier
enum class EProgressModifier : uint8 {
	Default,
	Buff,
	Debuff,
	EProgressModifier_MAX,
};

// Enum DeadByDaylight.EInteractionLayer
enum class EInteractionLayer : uint8 {
	VE_Camper,
	VE_Slasher,
	VE_MAX,
};

// Enum DeadByDaylight.ESnapBackPositionType
enum class ESnapBackPositionType : uint8 {
	SnapBackToInitialPosition,
	SnapBackToOffsetPositionFromSnap,
	ESnapBackPositionType_MAX,
};

// Enum DeadByDaylight.ESnapBackType
enum class ESnapBackType : uint8 {
	None,
	Always,
	OnInteractionCancelledOnly,
	OnInteractionEndOnly,
	ESnapBackType_MAX,
};

// Enum DeadByDaylight.EPowerProgressBar
enum class EPowerProgressBar : uint8 {
	NoProgressBar,
	ChargeBar,
	EPowerProgressBar_MAX,
};

// Enum DeadByDaylight.EInteractionOwnership
enum class EInteractionOwnership : uint8 {
	AnyCanUse,
	OnlyOwnerCanUse,
	OwnerCannotUse,
	EInteractionOwnership_MAX,
};

// Enum DeadByDaylight.EKillerHeight
enum class EKillerHeight : uint8 {
	Short,
	Average,
	Tall,
	EKillerHeight_MAX,
};

// Enum DeadByDaylight.EDisplayStandActorType
enum class EDisplayStandActorType : uint8 {
	None,
	Character,
	Hook,
	Charm,
	EDisplayStandActorType_MAX,
};

// Enum DeadByDaylight.EPlayerDataType
enum class EPlayerDataType : uint8 {
	None,
	PlayerState,
	SocialPartyMember,
	EPlayerDataType_MAX,
};

// Enum DeadByDaylight.ELobbyWaitStopReason
enum class ELobbyWaitStopReason : uint8 {
	StartMatchWait,
	PlayerCancelled,
	Unknown,
	ELobbyWaitStopReason_MAX,
};

// Enum DeadByDaylight.EMainMenuButton
enum class EMainMenuButton : uint8 {
	News,
	PlaySurvivor,
	PlayKiller,
	KillYourFriends,
	DailyRituals,
	Store,
	Settings,
	Onboarding,
	Credits,
	QuitGame,
	Friends,
	Archives,
	CrowdChoice,
	Support,
	PlaySurvivorFromCrowdChoice,
	PlayKillerFromCrowdChoice,
	EMainMenuButton_MAX,
};

// Enum DeadByDaylight.EMapActorCategory
enum class EMapActorCategory : uint8 {
	None,
	Objective,
	Chest,
	BlackLock,
	KillerObject,
	ExitGate,
	EMapActorCategory_MAX,
};

// Enum DeadByDaylight.EQuadDirection
enum class EQuadDirection : uint8 {
	None,
	Up,
	Down,
	Left,
	Right,
	Empty,
	EQuadDirection_MAX,
};

// Enum DeadByDaylight.ETileVariation
enum class ETileVariation : uint8 {
	None,
	BlueTag,
	PinkTag,
	YellowTag,
	GreenTag,
	Empty,
	ETileVariation_MAX,
};

// Enum DeadByDaylight.EPathType
enum class EPathType : uint8 {
	None,
	Straight,
	DeadEnd,
	Corner,
	Crossroads,
	TJunction,
	OrientationOnly,
	Unspecified,
	OrientedCrossroads,
	EPathType_MAX,
};

// Enum DeadByDaylight.EDensity
enum class EDensity : uint8 {
	Unspecified,
	Light,
	Moderate,
	Heavy,
	Empty,
	EDensity_MAX,
};

// Enum DeadByDaylight.ETileType
enum class ETileType : uint8 {
	None,
	Blocker,
	Any,
	Forest,
	Building,
	Maze,
	Landmark,
	Signature,
	ETileType_MAX,
};

// Enum DeadByDaylight.EDirection
enum class EDirection : uint8 {
	Up,
	Down,
	Left,
	Right,
	UpLeft,
	UpRight,
	DownLeft,
	DownRight,
	EDirection_MAX,
};

// Enum DeadByDaylight.EBasementType
enum class EBasementType : uint8 {
	None,
	Basic,
	MainBuilding,
	Shack,
	Count,
	EBasementType_MAX,
};

// Enum DeadByDaylight.EQuadrantSpawnType
enum class EQuadrantSpawnType : uint8 {
	L_Shape,
	Square,
	Rect_X,
	Rect_Y,
	Rect,
	None,
	EQuadrantSpawnType_MAX,
};

// Enum DeadByDaylight.EQuadrant
enum class EQuadrant : uint8 {
	BottomRight,
	BottomLeft,
	TopLeft,
	TopRight,
	Count,
	EQuadrant_MAX,
};

// Enum DeadByDaylight.EPlayerAnimState
enum class EPlayerAnimState : uint8 {
	VE_Default,
	VE_Injured,
	VE_InjuredCrouch,
	VE_Crouch,
	VE_MAX,
};

// Enum DeadByDaylight.EOfferingEffectType
enum class EOfferingEffectType : uint8 {
	SlasherPointsAll,
	PointsBrutality,
	PointsDeviouness,
	PointsSacrice,
	PointsHunting,
	CamperPointsAll,
	PointsObjective,
	PointsSurvival,
	PointsAltruism,
	PointsBoldness,
	CamperItemLostPrevention,
	KillerItemLostPrevention,
	Luck,
	IndustrialThemeSelectionModifier,
	JunkyardThemeSelectionModifier,
	FarmThemeSelectionModifier,
	SwampThemeSelectionModifier,
	MapModifier,
	ChestCountModifier,
	PortableHookCountModifier,
	LairCountModifier,
	PlayerGrouping,
	FarKiller,
	KillAllowedModifier,
	LightingModification,
	FogModification,
	LivingWorldObjectCountModifier,
	LivingWorldObjectMultModifier,
	KillLastSurvivor,
	SuburbsThemeSelectionModifier,
	AsylumThemeSelectionModifier,
	KillerSelectionModifier,
	HospitalThemeSelectionModifier,
	KillAllowedAfterStrugglePhase,
	BorealThemeSelectionModifier,
	SpringwoodThemeSelectionModifier,
	FinlandThemeSelectionModifier,
	JapaneseCountrySideSelectionModifier,
	KenyaThemeSelectionModifier,
	QatarThemeSelectionModifier,
	UkraineThemeSelectionModifier,
	WalesThemeSelectionModifier,
	CancelThemeSelectionModifier,
	BasementMainBuildingModifier,
	BasementShackModifier,
	HatchMainBuildingModifier,
	HatchShackModifier,
	EclipseThemeSelectionModifier,
	SpecialEvent,
	ObjectSubsitution,
	ObjectAddition,
	EOfferingEffectType_MAX,
};

// Enum DeadByDaylight.EOfferingCategory
enum class EOfferingCategory : uint8 {
	None,
	Bloodpoints,
	Mapmods,
	Realms,
	Shrouds,
	Wards,
	Luck,
	Moris,
	EOfferingCategory_MAX,
};

// Enum DeadByDaylight.EOfferingType
enum class EOfferingType : uint8 {
	None,
	Atmosphere,
	Lighting,
	Points,
	Zone,
	Position,
	Chest,
	Hook,
	Protection,
	Hatch,
	Odds,
	Killing,
	World,
	Luck,
	Killer,
	ProceduralGeneration,
	Count,
	EOfferingType_MAX,
};

// Enum DeadByDaylight.EOfferingCombinationResult
enum class EOfferingCombinationResult : uint8 {
	None,
	Stacked,
	CoConsummed,
	Overruling,
	Cancelled,
	EOfferingCombinationResult_MAX,
};

// Enum DeadByDaylight.EOfferingAnimState
enum class EOfferingAnimState : uint8 {
	None,
	Idle,
	Init,
	Reveal,
	ShowInteraction,
	Burned,
	Returned,
	Cancel,
	Hidden,
	EOfferingAnimState_MAX,
};

// Enum DeadByDaylight.EOfferingSequenceState
enum class EOfferingSequenceState : uint8 {
	SmokeIn,
	FadeOut,
	FadeIn,
	NotInitialized,
	Idle,
	Init,
	InitDone,
	Reveal,
	RevealDone,
	ShowInteraction,
	Finalize,
	Done,
	EOfferingSequenceState_MAX,
};

// Enum DeadByDaylight.EOfflineLobbyState
enum class EOfflineLobbyState : uint8 {
	None,
	RoleSelection,
	OfflineLobby,
	Store,
	PartyLobby,
	Archives,
	EOfflineLobbyState_MAX,
};

// Enum DeadByDaylight.EOniAttackType
enum class EOniAttackType : uint8 {
	VE_NotDemonMode,
	VE_DemonBasicAttack,
	VE_DemonPowerAttack,
	VE_DemonDashAttack,
	VE_MAX,
};

// Enum DeadByDaylight.EJoinSessionFailureType
enum class EJoinSessionFailureType : uint8 {
	None,
	JoiningAlreadyStartedGame,
	JoiningPrivateGame,
	JoiningAlreadyFullGame,
	JoiningInvitation,
	JoiningFailedOnDisconnect,
	JoiningHostUnreachable,
	EJoinSessionFailureType_MAX,
};

// Enum DeadByDaylight.EOnlineOperation
enum class EOnlineOperation : uint8 {
	None,
	HostGame,
	EndingSession,
	DestroyingSession,
	JoinGame,
	JoinCancelled,
	OnlineCheck,
	CancellingMatchmaking,
	EOnlineOperation_MAX,
};

// Enum DeadByDaylight.EOverlayMode
enum class EOverlayMode : uint8 {
	Default,
	TrialOrTally,
	TutorialLevel,
	TutorialBotMatch,
	EOverlayMode_MAX,
};

// Enum DeadByDaylight.EOverlayTabs
enum class EOverlayTabs : uint8 {
	Settings,
	Controls,
	Help,
	Survivors,
	CoreTabCount,
	About,
	Language,
	EOverlayTabs_MAX,
};

// Enum DeadByDaylight.EPalletPushSideStrategy
enum class EPalletPushSideStrategy : uint8 {
	PushToClosestPalletSide,
	PushOppositeToPlayerExecutingPulldown,
	EPalletPushSideStrategy_MAX,
};

// Enum DeadByDaylight.EPalletSide
enum class EPalletSide : uint8 {
	None,
	Left,
	Right,
	EPalletSide_MAX,
};

// Enum DeadByDaylight.EPalletState
enum class EPalletState : uint8 {
	Up,
	Falling,
	Fallen,
	Destroyed,
	Illusionary,
	EPalletState_MAX,
};

// Enum DeadByDaylight.EInventoryGridFormat
enum class EInventoryGridFormat : uint8 {
	DEFAULT,
	DIAMOND,
	HONEYCOMB,
	EInventoryGridFormat_MAX,
};

// Enum DeadByDaylight.ERequestState
enum class ERequestState : uint8 {
	VE_None,
	VE_Pending,
	VE_Success,
	VE_Fail,
	VE_MAX,
};

// Enum DeadByDaylight.EInteractionValidationState
enum class EInteractionValidationState : uint8 {
	None,
	Predicted,
	Authorized,
	DeniedByRaceCondition,
	DeniedByTimeout,
	DeniedByError,
	EInteractionValidationState_MAX,
};

// Enum DeadByDaylight.EPreLevelGenerationModifierType
enum class EPreLevelGenerationModifierType : uint8 {
	None,
	ModifyKillerObjectCount,
	EPreLevelGenerationModifierType_MAX,
};

// Enum DeadByDaylight.ESurvivorGrouping
enum class ESurvivorGrouping : uint8 {
	Invalid,
	Separated,
	Grouped2_3,
	Grouped3_2,
	Grouped4_1,
	ESurvivorGrouping_MAX,
};

// Enum DeadByDaylight.EscapeStrategyType
enum class EscapeStrategyType : uint8 {
	EscapeDoor,
	EscapeHatch,
	EscapeStrategyType_MAX,
};

// Enum DeadByDaylight.ELevelBuildingState
enum class ELevelBuildingState : uint8 {
	NotInitialized,
	WaitingForInitialSync,
	SyncSeeds,
	GetAvailableItems,
	PendingGettingItems,
	GettingLevelsDone,
	PendingPremadeMapStreaming,
	GetThemedTiles,
	PendingGettingTiles,
	SpawnRequiredTiles,
	SpawningLevelTiles,
	SpawnInterTileElements,
	PendingInterTileElementsSpawning,
	SpawningActors,
	SpawningMultiPassActors,
	StallingForRemotes,
	BuildingDone,
	BuildingStateCount,
	ELevelBuildingState_MAX,
};

// Enum DeadByDaylight.ESaveGameErrorCategory
enum class ESaveGameErrorCategory : uint8 {
	EvaluateDisconnectPenalty,
	SaveGameSaveError,
	SaveGameUnreadable,
	SaveGameValidation,
	SaveFailed,
	ESaveGameErrorCategory_MAX,
};

// Enum DeadByDaylight.EScreenType
enum class EScreenType : uint8 {
	eScaleformScreen,
	eUMGScreen,
	eMixedScaleformUMG,
	EScreenType_MAX,
};

// Enum DeadByDaylight.SettingsId
enum class SettingsId : uint8 {
	None,
	Language,
	RevokeConsent,
	BhvrAccount,
	AllowCrossplayGeneric,
	AllowCrossplayLive,
	AutoDeclineFriendRequests,
	PlayerId,
	PartyPrivacy,
	Quality,
	AutoAdjust,
	Resolution,
	FullScreen,
	MenuScaleFactor,
	HudScaleFactor,
	SkillCheckScaleFactor,
	MainVolume,
	MenuMusicVolume,
	Headphones,
	MuteOnFocusLost,
	InvertYAxis,
	SurvivorMouseSensitivity,
	SurvivorControllerSensitivity,
	SurvivorCameraSensitivity,
	KillerMouseSensitivity,
	KillerControllerSensitivity,
	KillerCameraSensitivity,
	ColorBarPalette,
	ColorBlindMode,
	ColorBlindModeIntensity,
	BeginnerMode,
	SettingsId_MAX,
};

// Enum DeadByDaylight.SettingsSubCategory
enum class SettingsSubCategory : uint8 {
	None,
	Language,
	Tutorial,
	Privacy,
	Online,
	Graphics,
	UIHud,
	Audio,
	CommonControls,
	SurvivorControls,
	KillerControls,
	ColorBlindMode,
	SettingsSubCategory_MAX,
};

// Enum DeadByDaylight.SettingsCategory
enum class SettingsCategory : uint8 {
	General,
	Graphics,
	Audio,
	Controls,
	SettingsCategory_MAX,
};

// Enum DeadByDaylight.SettingsType
enum class SettingsType : uint8 {
	None,
	Button,
	PlayerId,
	NumericStepper,
	Dropdown,
	ColorBar,
	TextStepper,
	BoolTextStepper,
	SettingsType_MAX,
};

// Enum DeadByDaylight.EShopLoadProgress
enum class EShopLoadProgress : uint8 {
	None,
	LoadCatalog,
	LoadCurrencyPacks,
	PlatformStoreCatalog,
	Inventory,
	Wallet,
	FeaturedPageContent,
	EShopLoadProgress_MAX,
};

// Enum DeadByDaylight.ESoftBanReason
enum class ESoftBanReason : uint8 {
	Invalid,
	Harassment,
	Griefing,
	Exploits,
	Unsportsmanlike,
	Count,
	ESoftBanReason_MAX,
};

// Enum DeadByDaylight.ESpecialEventGameMode
enum class ESpecialEventGameMode : uint8 {
	Progression,
	Counter,
	Collection,
	ESpecialEventGameMode_MAX,
};

// Enum DeadByDaylight.ESpecialEventStatus
enum class ESpecialEventStatus : uint8 {
	Inactive,
	ActiveMain,
	ActivePost,
	ESpecialEventStatus_MAX,
};

// Enum DeadByDaylight.ELoadCompleteState
enum class ELoadCompleteState : uint8 {
	InProgress,
	Success,
	ReloginRequested,
	FailedEAC,
	FailedRecoverable,
	FailedRecoverableProfileLoad,
	FailedBlocking,
	FailedBlockingNoDBDServer,
	FailedBlockingNotConnected,
	FailedBlockedNoNetworkConnection,
	FailedBlockingPlatformNotAuthenticated,
	FailedBlockingPlatformSubsystemNotInitialized,
	FailedBlockingOnlinePresenceNotInitialized,
	FailedBlockingPlatformNetUniqueIdInvalid,
	FailedBlockingInvalidLocalPlayer,
	FailedBlockingInvalidGameObjects,
	FailedBlockingInvalidSDA,
	FailedBlockingInvalidClientVersion,
	FailedBlockingWindowsStoreAccountNotLoggedIn,
	FailedBlockingSSLCACert,
	FailedBlockingCDNContentError,
	FailedBlockingCDNCantFindContentToDownload,
	FailedBlockingCDNNoPatchForCurrentPlatformAndVersion,
	FailedBlockingCDNNotEnoughDiskSpace,
	FailedBlockingCDNFailureToRetrieveContent,
	FailedRecoverableCDNUserCancelled,
	FailedBlockingVersionFileError,
	FailedBlockingRTMConnection,
	ELoadCompleteState_MAX,
};

// Enum DeadByDaylight.EExternalEffectSource
enum class EExternalEffectSource : uint8 {
	None,
	Perk,
	Addon,
	Power,
	EExternalEffectSource_MAX,
};

// Enum DeadByDaylight.EStoreBannerLocation
enum class EStoreBannerLocation : uint8 {
	Primary,
	Secondary,
	EStoreBannerLocation_MAX,
};

// Enum DeadByDaylight.EInteractionStorerRole
enum class EInteractionStorerRole : uint8 {
	None,
	AuthorityAndAutonomousProxy,
	ClientAndAutonomousProxy,
	AuthorityAndSimulatedProxy,
	ClientAndSimulatedProxy,
	EInteractionStorerRole_MAX,
};

// Enum DeadByDaylight.ETextBannerPosition
enum class ETextBannerPosition : uint8 {
	TopLeft,
	MiddleLeft,
	BottomLeft,
	MiddleRight,
	BottomRight,
	TopCenter,
	MiddleCenter,
	BottomCenter,
	ETextBannerPosition_MAX,
};

// Enum DeadByDaylight.EStoreTab
enum class EStoreTab : uint8 {
	Featured,
	Characters,
	Currency,
	ShrineOfSecrets,
	TabCount,
	EStoreTab_MAX,
};

// Enum DeadByDaylight.EStoreState
enum class EStoreState : uint8 {
	None,
	Featured,
	CharacterSelection,
	CharacterStory,
	CharacterCatalog,
	BuyCurrency,
	ShrineOfSecrets,
	EStoreState_MAX,
};

// Enum DeadByDaylight.EStoryNodeState
enum class EStoryNodeState : uint8 {
	None,
	Unavailable,
	AvailableDefault,
	AvailableActive,
	AvailablePaused,
	Completed,
	Claimed,
	EStoryNodeState_MAX,
};

// Enum DeadByDaylight.ETeachableStatus
enum class ETeachableStatus : uint8 {
	Unknown,
	Locked,
	AvailableInBloodWeb,
	AvailableInShrine,
	Acquired,
	ETeachableStatus_MAX,
};

// Enum DeadByDaylight.EPromptType
enum class EPromptType : uint8 {
	None,
	ExitsPowered,
	HatchSpawned,
	HatchOpened,
	EPromptType_MAX,
};

// Enum DeadByDaylight.ENotificationStyle
enum class ENotificationStyle : uint8 {
	None,
	Game,
	Tutorial,
	ENotificationStyle_MAX,
};

// Enum DeadByDaylight.EPromptPriority
enum class EPromptPriority : uint8 {
	Tutorial,
	High,
	Medium,
	Low,
	EPromptPriority_MAX,
};

// Enum DeadByDaylight.ELegalTermsStatus
enum class ELegalTermsStatus : uint8 {
	None,
	Accepted,
	Declined,
	ELegalTermsStatus_MAX,
};

// Enum DeadByDaylight.ELoadoutSlot
enum class ELoadoutSlot : uint8 {
	SKIN,
	ITEM_POWER,
	ADD_ON_2,
	ADD_ON_3,
	PERK_2,
	PERK_3,
	PERK_4,
	PERK_5,
	FAVOR,
	ELoadoutSlot_MAX,
};

// Enum DeadByDaylight.ENewContentType
enum class ENewContentType : uint8 {
	COMING_SOON,
	NEW_CONTENT,
	PATCH_NOTES,
	DEV_MESSAGES,
	EVENTS,
	ENewContentType_MAX,
};

// Enum DeadByDaylight.EOverlayButtonOptions
enum class EOverlayButtonOptions : uint8 {
	HIDDEN,
	DISABLED,
	ENABLED,
	EOverlayButtonOptions_MAX,
};

// Enum DeadByDaylight.ESlasherMatchResultScore
enum class ESlasherMatchResultScore : uint8 {
	DisgracefulDefeat,
	EntityDispleased,
	BrutalKiller,
	RuthlessKiller,
	MercilessKiller,
	ESlasherMatchResultScore_MAX,
};

// Enum DeadByDaylight.EUIControllerType
enum class EUIControllerType : uint8 {
	KeyboardMouse,
	GamePad,
	EUIControllerType_MAX,
};

// Enum DeadByDaylight.EScreenShotBatching
enum class EScreenShotBatching : uint8 {
	SelectedItemOrOutfit,
	SelectedCharacter,
	SelectedCharacterAndCategory,
	ItemsMissingIcon,
	AllItems,
	SelectedCharacterOutfits,
	AllOutfits,
	AllCharms,
	EScreenShotBatching_MAX,
};

// Enum DeadByDaylight.ELeaveLobbyReason
enum class ELeaveLobbyReason : uint8 {
	eNone,
	eNetworkDisconnect,
	eProfileOffline,
	eAppSuspended,
	eInternetDisconnect,
	eHostDisconnect,
	eDLCInstalled,
	eTrialExtensionExpired,
	ePartyManagementError,
	ELeaveLobbyReason_MAX,
};

// Enum DeadByDaylight.EFriendSearchPanelOption
enum class EFriendSearchPanelOption : uint8 {
	NotFoundPanel,
	NonFriendPanel,
	FriendRequestReceivedPanel,
	FriendRequestSentPanel,
	FriendPanel,
	IsOwnerPanel,
	EFriendSearchPanelOption_MAX,
};

// Enum DeadByDaylight.EFriendContainerType
enum class EFriendContainerType : uint8 {
	Connected,
	Disconnected,
	PendingSentRequest,
	RecentlyPlayed,
	SocialSuggestions,
	PendingReceivedRequest,
	QueriedPlayer,
	Unknown,
	EFriendContainerType_MAX,
};

// Enum DeadByDaylight.EAtlantaSettingMenuType
enum class EAtlantaSettingMenuType : uint8 {
	TabButton,
	AlwaysDisplay,
	EAtlantaSettingMenuType_MAX,
};

// Enum DeadByDaylight.EBloodStoreRowStyle
enum class EBloodStoreRowStyle : uint8 {
	FiveItemRow,
	ThreeItemRow,
	EBloodStoreRowStyle_MAX,
};

// Enum DeadByDaylight.EButtonType
enum class EButtonType : uint8 {
	None,
	AttackButton,
	PowerButton,
	CancelButton,
	SettingsButton,
	SecondaryActionButton,
	EButtonType_MAX,
};

// Enum DeadByDaylight.EInboxMessageTimeUnit
enum class EInboxMessageTimeUnit : uint8 {
	Days,
	Hours,
	Minutes,
	EInboxMessageTimeUnit_MAX,
};

// Enum DeadByDaylight.EInboxMessageUIState
enum class EInboxMessageUIState : uint8 {
	New,
	Read,
	Archived,
	EInboxMessageUIState_MAX,
};

// Enum DeadByDaylight.EInboxMessageUIType
enum class EInboxMessageUIType : uint8 {
	None,
	Social,
	Rewards,
	News,
	EInboxMessageUIType_MAX,
};

// Enum DeadByDaylight.EPartyPlayerSlotWidgetState
enum class EPartyPlayerSlotWidgetState : uint8 {
	None,
	Empty,
	NotReady,
	Ready,
	Hidden,
	EPartyPlayerSlotWidgetState_MAX,
};

// Enum DeadByDaylight.ESettingScreenButtonData
enum class ESettingScreenButtonData : uint8 {
	PRIVACY,
	EULA,
	CREDITS,
	ESettingScreenButtonData_MAX,
};

// Enum DeadByDaylight.ENavigationState
enum class ENavigationState : uint8 {
	RoleSelection,
	Customization,
	CharacterSelection,
	Lobby,
	BloodStore,
	None,
	ENavigationState_MAX,
};

// Enum DeadByDaylight.ELobbyState
enum class ELobbyState : uint8 {
	Searching,
	Joined,
	Offering,
	Fog,
	ELobbyState_MAX,
};

// Enum DeadByDaylight.EInventoryButtonState
enum class EInventoryButtonState : uint8 {
	StateDisabled,
	StateEmpty,
	StateLocked,
	StateWithItem,
	StateWithItemDisabled,
	StateWithItemLocked,
	StatePrivate,
	EInventoryButtonState_MAX,
};

// Enum DeadByDaylight.ERoleSelectionScreenButton
enum class ERoleSelectionScreenButton : uint8 {
	DailyRitual,
	Inbox,
	InviteFriend,
	Setting,
	ERoleSelectionScreenButton_MAX,
};

// Enum DeadByDaylight.ENavigationScreenButton
enum class ENavigationScreenButton : uint8 {
	AddCurrency,
	Start,
	ChangeRole,
	CharacterSelection,
	Loadout,
	Customization,
	Bloodweb,
	Back,
	ENavigationScreenButton_MAX,
};

// Enum DeadByDaylight.EInboxScreenButton
enum class EInboxScreenButton : uint8 {
	Rewards,
	Social,
	News,
	Back,
	EInboxScreenButton_MAX,
};

// Enum DeadByDaylight.EAtlantaRewardType
enum class EAtlantaRewardType : uint8 {
	Item,
	AddOn,
	Offering,
	BloodPoints,
	IridescentShards,
	AuricCells,
	Customization,
	FreeTicket,
	MysteryBox,
	Character,
	Count,
	EAtlantaRewardType_MAX,
};

// Enum DeadByDaylight.ETallyListPageID
enum class ETallyListPageID : uint8 {
	Scoreboard,
	Bloodpoints,
	Rank,
	PlayerLevel,
	CharacterLevel,
	NumberOfPages,
	ETallyListPageID_MAX,
};

// Enum DeadByDaylight.EToastWidgetType
enum class EToastWidgetType : uint8 {
	Simple,
	Interactable,
	EToastWidgetType_MAX,
};

// Enum DeadByDaylight.ELinkedVomitState
enum class ELinkedVomitState : uint8 {
	Idle,
	Charging,
	Vomiting,
	ELinkedVomitState_MAX,
};

// ScriptStruct DeadByDaylight.SpecialBehaviourObjectsInfo
// Size: 0x14 (Inherited: 0x00)
struct FSpecialBehaviourObjectsInfo {
	struct FName SpecialBehaviourId; // 0x00(0x0c)
	int32_t AmountRequired; // 0x0c(0x04)
	int32_t TimesInteractedWith; // 0x10(0x04)
};

// ScriptStruct DeadByDaylight.GameEventData
// Size: 0x28 (Inherited: 0x00)
struct FGameEventData {
	struct ADBDPlayer* Instigator; // 0x00(0x08)
	struct AActor* Target; // 0x08(0x08)
	float CustomValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct UObject* CustomObjectParameter; // 0x18(0x08)
	int32_t CustomIntValue; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.InteractionArray
// Size: 0x10 (Inherited: 0x00)
struct FInteractionArray {
	struct TArray<struct TWeakObjectPtr<struct UInteractionDefinition>> _interactions; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.FearMarketOfferingInstance
// Size: 0x20 (Inherited: 0x00)
struct FFearMarketOfferingInstance {
	struct TArray<struct FFearMarketItemInstance> ObjectsForSale; // 0x00(0x10)
	struct FDateTime StartTime; // 0x10(0x08)
	struct FDateTime EndTime; // 0x18(0x08)
};

// ScriptStruct DeadByDaylight.FearMarketItemInstance
// Size: 0x18 (Inherited: 0x00)
struct FFearMarketItemInstance {
	struct FName ItemId; // 0x00(0x0c)
	int32_t Cost; // 0x0c(0x04)
	int32_t BloodpointConversion; // 0x10(0x04)
	bool Purchased; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct DeadByDaylight.ScoreEventData
// Size: 0x18 (Inherited: 0x00)
struct FScoreEventData {
	struct AActor* Target; // 0x00(0x08)
	float PercentToAward; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UObject* CustomObjectParameter; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.AnimData
// Size: 0x01 (Inherited: 0x00)
struct FAnimData {
	enum class ECharacterStance Stance; // 0x00(0x01)
};

// ScriptStruct DeadByDaylight.InteractionPlayerProperties
// Size: 0x50 (Inherited: 0x00)
struct FInteractionPlayerProperties {
	struct FVector_NetQuantize AverageVelocityAtStart; // 0x00(0x0c)
	struct FVector_NetQuantize PlayerPositionAtStart; // 0x0c(0x0c)
	struct FRotator PlayerRotationAtStart; // 0x18(0x0c)
	struct TWeakObjectPtr<struct ADBDPlayer> Requester; // 0x24(0x08)
	struct FVector_NetQuantize SnapPositionAtStart; // 0x2c(0x0c)
	struct FRotator SnapRotationAtStart; // 0x38(0x0c)
	float SnapDistanceAtStart; // 0x44(0x04)
	float SnapTimeAtStart; // 0x48(0x04)
	bool ShouldSnapPosition; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// ScriptStruct DeadByDaylight.EffectCameraTypeSettings
// Size: 0x03 (Inherited: 0x00)
struct FEffectCameraTypeSettings {
	enum class ECustomizationCategory Category; // 0x00(0x01)
	bool VisibilityInFirstPerson; // 0x01(0x01)
	bool VisibilityInThirdPerson; // 0x02(0x01)
};

// ScriptStruct DeadByDaylight.Offering
// Size: 0x190 (Inherited: 0x00)
struct FOffering {
	char pad_0[0x190]; // 0x00(0x190)
};

// ScriptStruct DeadByDaylight.SelectedOffering
// Size: 0x10 (Inherited: 0x00)
struct FSelectedOffering {
	int32_t ownerId; // 0x00(0x04)
	struct FName OfferingName; // 0x04(0x0c)
};

// ScriptStruct DeadByDaylight.BuiltLevelData
// Size: 0x78 (Inherited: 0x00)
struct FBuiltLevelData {
	struct FName ThemeName; // 0x00(0x0c)
	struct FName ThemeWeather; // 0x0c(0x0c)
	struct FName AudioStateThemes; // 0x18(0x0c)
	struct FName AudioStateWeather; // 0x24(0x0c)
	struct FName AudioGameStartEvent; // 0x30(0x0c)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString MapName; // 0x40(0x10)
	int32_t TileCount; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TArray<struct FDependency> Dependencies; // 0x58(0x10)
	struct FName SpecialEventId; // 0x68(0x0c)
	char pad_74[0x4]; // 0x74(0x04)
};

// ScriptStruct DeadByDaylight.Dependency
// Size: 0x38 (Inherited: 0x00)
struct FDependency {
	enum class ETileSpawnPointType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSoftObjectPath AssetReference; // 0x08(0x20)
	struct AActor* Object; // 0x28(0x08)
	bool Unique; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t count; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.GamePresetData
// Size: 0x78 (Inherited: 0x00)
struct FGamePresetData {
	struct TArray<char> _mapAvailabilities; // 0x00(0x10)
	struct TArray<char> _perkAvailabilities; // 0x10(0x10)
	struct TArray<char> _offeringAvailabilities; // 0x20(0x10)
	struct TArray<char> _itemAvailabilities; // 0x30(0x10)
	struct TArray<char> _itemAddonAvailabilities; // 0x40(0x10)
	struct TArray<char> _customizationItemAvailabilities; // 0x50(0x10)
	struct TArray<char> _characterAvailabilities; // 0x60(0x10)
	bool _allowDlcContent; // 0x70(0x01)
	bool _privateMatch; // 0x71(0x01)
	bool _isTrainingMatch; // 0x72(0x01)
	char pad_73[0x5]; // 0x73(0x05)
};

// ScriptStruct DeadByDaylight.OfferingData
// Size: 0x18 (Inherited: 0x00)
struct FOfferingData {
	bool OfferingReady; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FSelectedOffering> offerings; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.CamperHealResult
// Size: 0x18 (Inherited: 0x00)
struct FCamperHealResult {
	enum class ECamperDamageState PreviousDamageState; // 0x00(0x01)
	enum class ECamperDamageState CurrentDamageState; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t HealAmount; // 0x04(0x04)
	struct TArray<struct ADBDPlayer*> Healers; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.DBDTimer
// Size: 0x28 (Inherited: 0x00)
struct FDBDTimer {
	char pad_0[0x8]; // 0x00(0x08)
	float _startTime; // 0x08(0x04)
	bool _startTimeDirty; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FFloat_NetQuantize8 _timeLeft; // 0x10(0x08)
	bool _replicateTimeLeft; // 0x18(0x01)
	char pad_19[0xb]; // 0x19(0x0b)
	float _interpSpeed; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.AttackDelegatePair
// Size: 0x10 (Inherited: 0x00)
struct FAttackDelegatePair {
	struct UDBDAttack* _attack; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.TargetFocusTimer
// Size: 0x38 (Inherited: 0x00)
struct FTargetFocusTimer {
	struct ACamperPlayer* _camper; // 0x00(0x08)
	struct FDBDTimer _cooldownTimer; // 0x08(0x28)
	float _totalTime; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.InventorySlotData
// Size: 0xf8 (Inherited: 0x00)
struct FInventorySlotData {
	struct FName ItemId; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString IconFilePath; // 0x10(0x10)
	struct FString DisplayName; // 0x20(0x10)
	struct FString ParentDisplayName; // 0x30(0x10)
	struct FString Description; // 0x40(0x10)
	struct TArray<enum class EPerkCategory> PerkCategory; // 0x50(0x10)
	enum class EInventoryItemType ItemType; // 0x60(0x01)
	enum class EItemRarity Rarity; // 0x61(0x01)
	enum class EStatusEffectType StatusEffectType; // 0x62(0x01)
	char pad_63[0x1]; // 0x63(0x01)
	int32_t Level; // 0x64(0x04)
	struct FString subtitle; // 0x68(0x10)
	int32_t StackCount; // 0x78(0x04)
	enum class EItemAvailability Availability; // 0x7c(0x01)
	bool IsTeachablePerk; // 0x7d(0x01)
	bool IsSlasherPerk; // 0x7e(0x01)
	bool IsPerkAvailableInFearMarket; // 0x7f(0x01)
	bool IsPerkAvailableInBloodWeb; // 0x80(0x01)
	char pad_81[0x3]; // 0x81(0x03)
	int32_t TeachableLevel; // 0x84(0x04)
	struct FString DlcDisplayName; // 0x88(0x10)
	bool IsLocked; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FSpecialEventUIInfo EventInfo; // 0xa0(0x50)
	int32_t UnlockableLevel; // 0xf0(0x04)
	char pad_F4[0x4]; // 0xf4(0x04)
};

// ScriptStruct DeadByDaylight.SpecialEventUIInfo
// Size: 0x50 (Inherited: 0x00)
struct FSpecialEventUIInfo {
	struct FString EventId; // 0x00(0x10)
	struct FString EventBannerFrameLabel; // 0x10(0x10)
	struct FText EventName; // 0x20(0x18)
	bool IsPastEvent; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FString BloodwebCollectSoundEvent; // 0x40(0x10)
};

// ScriptStruct DeadByDaylight.TooltipPressedData
// Size: 0x08 (Inherited: 0x00)
struct FTooltipPressedData {
	struct FVector2D touchPosition; // 0x00(0x08)
};

// ScriptStruct DeadByDaylight.StoreItemSlotData
// Size: 0x160 (Inherited: 0x00)
struct FStoreItemSlotData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FName ItemId; // 0x08(0x0c)
	enum class ECustomizationCategory Category; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FName MirrorsId; // 0x18(0x0c)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString IconPath; // 0x28(0x10)
	struct FString DisplayName; // 0x38(0x10)
	struct FString DisplayCollectionName; // 0x48(0x10)
	struct FString Description; // 0x58(0x10)
	struct FString RoleCategoryInfo; // 0x68(0x10)
	struct FString RarityPartInfo; // 0x78(0x10)
	enum class EItemRarity Rarity; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FSpecialEventUIInfo EventInfo; // 0x90(0x50)
	struct TArray<struct FPurchaseCurrencyData> PurchaseDataList; // 0xe0(0x10)
	struct FCustomTransformation CustomTransformation; // 0xf0(0x14)
	bool IsOwned; // 0x104(0x01)
	bool IsBuyable; // 0x105(0x01)
	bool IsEquipped; // 0x106(0x01)
	bool IsNewInStore; // 0x107(0x01)
	bool IsLocked; // 0x108(0x01)
	bool IsInStore; // 0x109(0x01)
	enum class EPlayerRole AssociatedRole; // 0x10a(0x01)
	char pad_10B[0x5]; // 0x10b(0x05)
	struct FDateTime ReleaseDate; // 0x110(0x08)
	char pad_118[0x48]; // 0x118(0x48)
};

// ScriptStruct DeadByDaylight.CustomTransformation
// Size: 0x14 (Inherited: 0x00)
struct FCustomTransformation {
	bool UseCustomTransformation; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector2D CustomScale; // 0x04(0x08)
	struct FVector2D CustomTranslation; // 0x0c(0x08)
};

// ScriptStruct DeadByDaylight.PurchaseCurrencyData
// Size: 0x18 (Inherited: 0x00)
struct FPurchaseCurrencyData {
	char pad_0[0x8]; // 0x00(0x08)
	enum class ECurrencyType CurrencyType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t Price; // 0x0c(0x04)
	float DiscountPercentage; // 0x10(0x04)
	bool IsAffordable; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct DeadByDaylight.FirecrackerEffectData
// Size: 0x10 (Inherited: 0x00)
struct FFirecrackerEffectData {
	struct AFirecracker* Firecracker; // 0x00(0x08)
	bool IsInRange; // 0x08(0x01)
	bool IsFirstTime; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
};

// ScriptStruct DeadByDaylight.PhaseWalkInfo
// Size: 0x20 (Inherited: 0x00)
struct FPhaseWalkInfo {
	bool IsActivePhaseWalking; // 0x00(0x01)
	bool IsPassivePhaseWalking; // 0x01(0x01)
	bool IsInteractionPhaseWalking; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	struct FVector HuskLocation; // 0x04(0x0c)
	struct FRotator HuskRotation; // 0x10(0x0c)
	bool TeleportToHusk; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct DeadByDaylight.PortalRestrictedLocation
// Size: 0x10 (Inherited: 0x00)
struct FPortalRestrictedLocation {
	struct FVector Location; // 0x00(0x0c)
	float DistanceSquared; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.SecondaryInteractionProperties
// Size: 0x30 (Inherited: 0x00)
struct FSecondaryInteractionProperties {
	struct FString SecondaryInteractionID; // 0x00(0x10)
	enum class EInputInteractionType SecondaryInteractionInputType; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FText SecondaryInteractionDescriptionText; // 0x18(0x18)
};

// ScriptStruct DeadByDaylight.UniquelyIdentifiedAnalytic
// Size: 0x68 (Inherited: 0x18)
struct FUniquelyIdentifiedAnalytic : FBaseSingleStructIndexAnalytics {
	struct FString Version; // 0x18(0x10)
	struct FString MirrorsId; // 0x28(0x10)
	struct FString ClientId; // 0x38(0x10)
	struct FString platform; // 0x48(0x10)
	struct FString BackendEnv; // 0x58(0x10)
};

// ScriptStruct DeadByDaylight.AIDetectedStimulus
// Size: 0x5c (Inherited: 0x00)
struct FAIDetectedStimulus {
	struct TWeakObjectPtr<struct AActor> Instigator; // 0x00(0x08)
	struct FVector Location; // 0x08(0x0c)
	struct FRotator Rotation; // 0x14(0x0c)
	struct FVector Velocity; // 0x20(0x0c)
	float AtTime; // 0x2c(0x04)
	char pad_30[0x2c]; // 0x30(0x2c)
};

// ScriptStruct DeadByDaylight.AITunableParameter
// Size: 0x10 (Inherited: 0x00)
struct FAITunableParameter {
	float defaultValue; // 0x00(0x04)
	struct FName TunableName; // 0x04(0x0c)
};

// ScriptStruct DeadByDaylight.DataTableDropdown
// Size: 0x30 (Inherited: 0x00)
struct FDataTableDropdown {
	struct FName RowValue; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString DataTableName; // 0x10(0x10)
	struct FName ColumnName; // 0x20(0x0c)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DeadByDaylight.AkObservedPlayerSoundLoop
// Size: 0x40 (Inherited: 0x28)
struct FAkObservedPlayerSoundLoop : FAkSoundLoop {
	char pad_28[0x10]; // 0x28(0x10)
	struct UPlayerPerspectiveComponent* _perspectiveComponent; // 0x38(0x08)
};

// ScriptStruct DeadByDaylight.ClippedActor
// Size: 0x60 (Inherited: 0x00)
struct FClippedActor {
	struct TArray<struct TWeakObjectPtr<struct UPrimitiveComponent>> DisplayComponents; // 0x00(0x10)
	struct TMap<struct UPrimitiveComponent*, struct TWeakObjectPtr<struct UPrimitiveComponent>> CollidingPrimitives; // 0x10(0x50)
};

// ScriptStruct DeadByDaylight.ActorSpawnerProperties
// Size: 0x38 (Inherited: 0x00)
struct FActorSpawnerProperties {
	SoftClassProperty SceneElement; // 0x00(0x30)
	float Weight; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.SpawnerElement
// Size: 0x10 (Inherited: 0x00)
struct FSpawnerElement {
	struct TArray<struct FActorSpawnerProperties> ObjectsToBeSpawned; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.ActorVariationElements
// Size: 0x38 (Inherited: 0x00)
struct FActorVariationElements {
	enum class ETileVariation Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	SoftClassProperty Element; // 0x08(0x30)
};

// ScriptStruct DeadByDaylight.AimAssistInfo
// Size: 0x18 (Inherited: 0x00)
struct FAimAssistInfo {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DeadByDaylight.AITerrorEvent
// Size: 0x28 (Inherited: 0x00)
struct FAITerrorEvent {
	struct FVector Location; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct AActor* Instigator; // 0x10(0x08)
	struct UTerrorRadiusEmitterComponent* TerrorEmitter; // 0x18(0x08)
	struct FGenericTeamId TeamIdentifier; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DeadByDaylight.AITrailEvent
// Size: 0x30 (Inherited: 0x00)
struct FAITrailEvent {
	struct FVector Location; // 0x00(0x0c)
	float StartTime; // 0x0c(0x04)
	float EndTime; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct AActor* Instigator; // 0x18(0x08)
	struct FGameplayTag IgnoreOnPerkTag; // 0x20(0x0c)
	struct FGenericTeamId TeamIdentifier; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct DeadByDaylight.AnimationMappingRow
// Size: 0x18 (Inherited: 0x08)
struct FAnimationMappingRow : FDBDTableRowBase {
	struct TArray<struct FAnimationMapping> Mappings; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.AnimationMapping
// Size: 0x58 (Inherited: 0x08)
struct FAnimationMapping : FDBDTableRowBase {
	struct TSoftObjectPtr<struct UAnimMontage> MontageAsset; // 0x08(0x30)
	struct TArray<struct FName> Tags; // 0x38(0x10)
	struct UAnimMontage* _montage; // 0x48(0x08)
	bool _loadAttempted; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct DeadByDaylight.ArchiveQuestSpecialBehaviour
// Size: 0x48 (Inherited: 0x18)
struct FArchiveQuestSpecialBehaviour : FDBDTableRowBaseWithId {
	struct FText Description; // 0x18(0x18)
	enum class EContextualType Type; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName SpawnObjectId; // 0x34(0x0c)
	enum class EAdditiveBehaviour AdditiveBehaviour; // 0x40(0x01)
	enum class EStackingBehaviours StackableBehaviour; // 0x41(0x01)
	enum class EOwnershipBehaviour OwnershipBehaviour; // 0x42(0x01)
	char pad_43[0x1]; // 0x43(0x01)
	int32_t SpawnQuantity; // 0x44(0x04)
};

// ScriptStruct DeadByDaylight.ArchiveDefinition
// Size: 0x88 (Inherited: 0x18)
struct FArchiveDefinition : FDBDTableRowBaseWithId {
	struct FText Title; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
	struct TArray<struct FString> HiddenImages; // 0x48(0x10)
	struct FString PurchasePassPicturePath; // 0x58(0x10)
	struct FString PurchaseTierPicturePath; // 0x68(0x10)
	struct FString StyleFrameLabel; // 0x78(0x10)
};

// ScriptStruct DeadByDaylight.QuestEventDefinition
// Size: 0x58 (Inherited: 0x18)
struct FQuestEventDefinition : FDBDTableRowBaseWithId {
	struct TArray<struct FGameplayTag> TrackedGameEvents; // 0x18(0x10)
	SoftClassProperty QuestEventEvaluator; // 0x28(0x30)
};

// ScriptStruct DeadByDaylight.ArchiveQuestObjectiveDefinition
// Size: 0x60 (Inherited: 0x18)
struct FArchiveQuestObjectiveDefinition : FDBDTableRowBaseWithId {
	struct FText Description; // 0x18(0x18)
	struct FText RulesDescription; // 0x30(0x18)
	struct TArray<struct FName> DescriptionParameters; // 0x48(0x10)
	bool IsProgressionPercentage; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// ScriptStruct DeadByDaylight.ArchiveNodeDefinition
// Size: 0x68 (Inherited: 0x18)
struct FArchiveNodeDefinition : FDBDTableRowBaseWithId {
	struct FText DisplayName; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
	struct FString IconPath; // 0x48(0x10)
	enum class EPlayerRole PlayerRole; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FName CinematicId; // 0x5c(0x0c)
};

// ScriptStruct DeadByDaylight.PlayerDataForQuestConditions
// Size: 0x78 (Inherited: 0x00)
struct FPlayerDataForQuestConditions {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct DeadByDaylight.ArmIKSensorDatum
// Size: 0x30 (Inherited: 0x00)
struct FArmIKSensorDatum {
	struct FName ShoulderBoneName; // 0x00(0x0c)
	char pad_C[0x24]; // 0x0c(0x24)
};

// ScriptStruct DeadByDaylight.AssetLibraryLoader
// Size: 0x28 (Inherited: 0x00)
struct FAssetLibraryLoader {
	struct UAssetLibrary* AssetLibrary; // 0x00(0x08)
	char pad_8[0x20]; // 0x08(0x20)
};

// ScriptStruct DeadByDaylight.AssignedPerkProperties
// Size: 0x14 (Inherited: 0x00)
struct FAssignedPerkProperties {
	struct FName PerkId; // 0x00(0x0c)
	int32_t PerkLevel; // 0x0c(0x04)
	bool IsTeachable; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
};

// ScriptStruct DeadByDaylight.AtlantaKillerSoundDistanceData
// Size: 0x18 (Inherited: 0x08)
struct FAtlantaKillerSoundDistanceData : FDBDTableRowBase {
	float MinRadiusSoundDistance; // 0x08(0x04)
	float MaxRadiusSoundDistance; // 0x0c(0x04)
	float MinRangeSoundHeard; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.AtlantaOnBoardingData
// Size: 0x48 (Inherited: 0x08)
struct FAtlantaOnBoardingData : FDBDTableRowBase {
	struct FName onBoardingID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Title; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
};

// ScriptStruct DeadByDaylight.AtlantaRitualsUIScreenData
// Size: 0x30 (Inherited: 0x00)
struct FAtlantaRitualsUIScreenData {
	struct FDateTime DailyRefreshTime; // 0x00(0x08)
	struct FDateTime WeeklyRefreshTime; // 0x08(0x08)
	struct TArray<struct FAtlantaRitualUIData> DailyRituals; // 0x10(0x10)
	struct TArray<struct FAtlantaRitualUIData> WeeklyRituals; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.AtlantaRitualUIData
// Size: 0x68 (Inherited: 0x00)
struct FAtlantaRitualUIData {
	int32_t ID; // 0x00(0x04)
	enum class EAltantaRitualUIType Type; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString IconFilePath; // 0x28(0x10)
	bool IsNew; // 0x38(0x01)
	bool IsClaimed; // 0x39(0x01)
	char pad_3A[0x2]; // 0x3a(0x02)
	float ProgressPercentage; // 0x3c(0x04)
	int32_t RefreshPrice; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TArray<struct FAtlantaRitualRewardUIData> Rewards; // 0x48(0x10)
	struct TArray<struct FAtlantaSubRitualUIData> SubRituals; // 0x58(0x10)
};

// ScriptStruct DeadByDaylight.AtlantaSubRitualUIData
// Size: 0x18 (Inherited: 0x00)
struct FAtlantaSubRitualUIData {
	struct FString Description; // 0x00(0x10)
	int32_t TargetNumber; // 0x10(0x04)
	int32_t CurrentNumber; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.AtlantaRitualRewardUIData
// Size: 0x20 (Inherited: 0x00)
struct FAtlantaRitualRewardUIData {
	enum class EAtlantaRitualRewardUIType Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Quantity; // 0x04(0x04)
	struct FString IconFilePath; // 0x08(0x10)
	enum class EItemRarity Rarity; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DeadByDaylight.AtlCookedMapDescription
// Size: 0x40 (Inherited: 0x00)
struct FAtlCookedMapDescription {
	struct FName ThemeName; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TSoftObjectPtr<struct UWorld> MapAsset; // 0x10(0x30)
};

// ScriptStruct DeadByDaylight.AttackEventTypeDetails
// Size: 0x30 (Inherited: 0x08)
struct FAttackEventTypeDetails : FDBDTableRowBase {
	struct FGameplayTag GameplayTag; // 0x08(0x0c)
	enum class EAttackEventType AttackEventType; // 0x14(0x01)
	bool CanBeProtective; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	int32_t AssociatedCharacter; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString Description; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.AttackHitResult
// Size: 0x80 (Inherited: 0x00)
struct FAttackHitResult {
	struct ADBDPlayer* Attacker; // 0x00(0x08)
	struct ADBDPlayer* Target; // 0x08(0x08)
	struct UDBDAttack* Attack; // 0x10(0x08)
	bool IsBasicAttack; // 0x18(0x01)
	bool CosmeticOnly; // 0x19(0x01)
	char pad_1A[0x66]; // 0x1a(0x66)
};

// ScriptStruct DeadByDaylight.BaseItemData
// Size: 0xd8 (Inherited: 0x08)
struct FBaseItemData : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	enum class EInventoryItemType Type; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FItemUIData UIData; // 0x18(0x78)
	struct FText GenericDisplayName; // 0x90(0x18)
	SoftClassProperty ItemBlueprint; // 0xa8(0x30)
};

// ScriptStruct DeadByDaylight.ItemUIData
// Size: 0x78 (Inherited: 0x00)
struct FItemUIData {
	struct FText DisplayName; // 0x00(0x18)
	struct FText Description; // 0x18(0x18)
	struct TArray<struct FString> IconFilePathList; // 0x30(0x10)
	struct TArray<struct TSoftObjectPtr<struct UTexture2D>> IconAssetList; // 0x40(0x10)
	struct FCustomTransformation CustomTransformation; // 0x50(0x14)
	uint32_t PlatformsForIconUnlicensedFilePathListOverride; // 0x64(0x04)
	struct TArray<struct FString> IconUnlicensedFilePathListOverride; // 0x68(0x10)
};

// ScriptStruct DeadByDaylight.DBDBidirectionalTimer
// Size: 0x28 (Inherited: 0x28)
struct FDBDBidirectionalTimer : FDBDTimer {
};

// ScriptStruct DeadByDaylight.BlindPackData
// Size: 0xd8 (Inherited: 0xd8)
struct FBlindPackData : FBaseItemData {
};

// ScriptStruct DeadByDaylight.BlockableReplicatedDatum
// Size: 0x20 (Inherited: 0x00)
struct FBlockableReplicatedDatum {
	struct TArray<struct TWeakObjectPtr<struct UObject>> Sources; // 0x00(0x10)
	struct TArray<struct TWeakObjectPtr<struct ADBDPlayer>> BlockedPlayers; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.BloodstoreRowUnlockThreshold
// Size: 0x10 (Inherited: 0x08)
struct FBloodstoreRowUnlockThreshold : FDBDTableRowBase {
	int32_t PreviousRowPurchasedItemsCount; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebChest
// Size: 0x38 (Inherited: 0x08)
struct FBloodwebChest : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	struct FName EventId; // 0x14(0x0c)
	enum class EItemRarity Rarity; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct TArray<float> GivenItemRarity; // 0x28(0x10)
};

// ScriptStruct DeadByDaylight.BloodwebContentTypePerRingDistribution
// Size: 0x60 (Inherited: 0x08)
struct FBloodwebContentTypePerRingDistribution : FDBDTableRowBase {
	int32_t PerkPerRingMinCount; // 0x08(0x04)
	int32_t PerkPerRingMaxCount; // 0x0c(0x04)
	int32_t PerkPerRingWeight; // 0x10(0x04)
	int32_t OfferingPerRingMinCount; // 0x14(0x04)
	int32_t OfferingPerRingMaxCount; // 0x18(0x04)
	int32_t OfferingPerRingWeight; // 0x1c(0x04)
	int32_t ItemPerRingMinCount; // 0x20(0x04)
	int32_t ItemPerRingMaxCount; // 0x24(0x04)
	int32_t ItemPerRingWeight; // 0x28(0x04)
	int32_t AddOnPerRingMinCount; // 0x2c(0x04)
	int32_t AddOnPerRingMaxCount; // 0x30(0x04)
	int32_t AddOnPerRingWeight; // 0x34(0x04)
	int32_t ChestPerRingMinCount; // 0x38(0x04)
	int32_t ChestPerRingMaxCount; // 0x3c(0x04)
	int32_t ChestPerRingWeight; // 0x40(0x04)
	int32_t PerksPackPerRingMinCount; // 0x44(0x04)
	int32_t PerksPackPerRingMaxCount; // 0x48(0x04)
	int32_t PerksPackPerRingWeight; // 0x4c(0x04)
	int32_t IridiscentShardsPackPerRingMinCount; // 0x50(0x04)
	int32_t IridiscentShardsPackPerRingMaxCount; // 0x54(0x04)
	int32_t IridiscentShardsPackPerRingWeight; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebCostModifier
// Size: 0x10 (Inherited: 0x08)
struct FBloodwebCostModifier : FDBDTableRowBase {
	enum class EBloodwebNodeContentType Type; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float CostModifier; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.BlockingNode
// Size: 0x18 (Inherited: 0x00)
struct FBlockingNode {
	struct FString ID; // 0x00(0x10)
	int32_t BlockingCount; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebMandatoryContentByLevel
// Size: 0x30 (Inherited: 0x08)
struct FBloodwebMandatoryContentByLevel : FDBDTableRowBase {
	int32_t Level; // 0x08(0x04)
	struct FName ForcedItem01; // 0x0c(0x0c)
	struct FName ForcedItem02; // 0x18(0x0c)
	struct FName ForcedItem03; // 0x24(0x0c)
};

// ScriptStruct DeadByDaylight.BloodwebNode
// Size: 0x88 (Inherited: 0x00)
struct FBloodwebNode {
	struct FBloodwebNodeProperties Properties; // 0x00(0x18)
	struct TArray<struct FBloodwebNodeGate> Gates; // 0x18(0x10)
	enum class EBloodwebNodeState State; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString nodeID; // 0x30(0x10)
	struct FName ContentId; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FBloodwebChest BloodwebChest; // 0x50(0x38)
};

// ScriptStruct DeadByDaylight.BloodwebNodeGate
// Size: 0x08 (Inherited: 0x08)
struct FBloodwebNodeGate : FDBDTableRowBase {
};

// ScriptStruct DeadByDaylight.BloodwebNodeProperties
// Size: 0x18 (Inherited: 0x00)
struct FBloodwebNodeProperties {
	enum class EBloodwebNodeContentType ContentType; // 0x00(0x01)
	enum class EItemRarity Rarity; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FString> Tags; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.ContentPerWebDistribution
// Size: 0x0c (Inherited: 0x00)
struct FContentPerWebDistribution {
	int32_t Weight; // 0x00(0x04)
	int32_t MinCount; // 0x04(0x04)
	int32_t MaxCount; // 0x08(0x04)
};

// ScriptStruct DeadByDaylight.ContentPerRingDistribution
// Size: 0x30 (Inherited: 0x00)
struct FContentPerRingDistribution {
	struct TArray<int32_t> WeightList; // 0x00(0x10)
	struct TArray<int32_t> MinCountList; // 0x10(0x10)
	struct TArray<int32_t> MaxCountList; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.RarityPerWebDistribution
// Size: 0x0c (Inherited: 0x00)
struct FRarityPerWebDistribution {
	int32_t Weight; // 0x00(0x04)
	int32_t MinCount; // 0x04(0x04)
	int32_t MaxCount; // 0x08(0x04)
};

// ScriptStruct DeadByDaylight.RarityPerRingDistribution
// Size: 0x30 (Inherited: 0x00)
struct FRarityPerRingDistribution {
	struct TArray<int32_t> WeightList; // 0x00(0x10)
	struct TArray<int32_t> MinCountList; // 0x10(0x10)
	struct TArray<int32_t> MaxCountList; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.AccessNode
// Size: 0x18 (Inherited: 0x00)
struct FAccessNode {
	struct FString ID; // 0x00(0x10)
	int32_t AccessCost; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebNodeCost
// Size: 0x10 (Inherited: 0x08)
struct FBloodwebNodeCost : FDBDTableRowBase {
	enum class EItemRarity Rarity; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t Cost; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebNodeRarityCost
// Size: 0x10 (Inherited: 0x08)
struct FBloodwebNodeRarityCost : FDBDTableRowBase {
	enum class EItemRarity Rarity; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t Cost; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebNodesPerRingDistribution
// Size: 0x10 (Inherited: 0x08)
struct FBloodwebNodesPerRingDistribution : FDBDTableRowBase {
	int32_t MinCount; // 0x08(0x04)
	int32_t MaxCount; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.BloodWebPersistentData
// Size: 0x40 (Inherited: 0x00)
struct FBloodWebPersistentData {
	int32_t VersionNumber; // 0x00(0x04)
	int32_t Level; // 0x04(0x04)
	struct TArray<struct FBloodWebRingPersistentData> RingData; // 0x08(0x10)
	struct TArray<struct FName> Paths; // 0x18(0x10)
	struct FString EntityCurrentNode; // 0x28(0x10)
	struct FDateTime GenerationDate; // 0x38(0x08)
};

// ScriptStruct DeadByDaylight.BloodWebRingPersistentData
// Size: 0x10 (Inherited: 0x00)
struct FBloodWebRingPersistentData {
	struct TArray<struct FBloodwebNode> NodeData; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.BloodwebPrestigeModifiers
// Size: 0x28 (Inherited: 0x08)
struct FBloodwebPrestigeModifiers : FDBDTableRowBase {
	float CommonItemProbabilityModifier; // 0x08(0x04)
	float UncommonItemProbabilityModifier; // 0x0c(0x04)
	float RareItemProbabilityModifier; // 0x10(0x04)
	float VeryRareItemProbabilityModifier; // 0x14(0x04)
	float UltraRareItemProbabilityModifier; // 0x18(0x04)
	float ArtifactItemProbabilityModifier; // 0x1c(0x04)
	float SpectralItemProbabilityModifier; // 0x20(0x04)
	float LegendaryItemProbabilityModifier; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebProgressionValue
// Size: 0xd0 (Inherited: 0x08)
struct FBloodwebProgressionValue : FDBDTableRowBase {
	int32_t InnerRingNodeCount; // 0x08(0x04)
	int32_t MiddleRingNodeCount; // 0x0c(0x04)
	int32_t OuterRingNodeCount; // 0x10(0x04)
	int32_t Common_MinCount; // 0x14(0x04)
	int32_t Common_MaxCount; // 0x18(0x04)
	int32_t Uncommon_MinCount; // 0x1c(0x04)
	int32_t Uncommon_MaxCount; // 0x20(0x04)
	int32_t Rare_MinCount; // 0x24(0x04)
	int32_t Rare_MaxCount; // 0x28(0x04)
	int32_t VeryRare_MinCount; // 0x2c(0x04)
	int32_t VeryRare_MaxCount; // 0x30(0x04)
	int32_t UltraRare_MinCount; // 0x34(0x04)
	int32_t UltraRare_MaxCount; // 0x38(0x04)
	int32_t Artifact_MinCount; // 0x3c(0x04)
	int32_t Artifact_MaxCount; // 0x40(0x04)
	int32_t Spectral_MinCount; // 0x44(0x04)
	int32_t Spectral_MaxCount; // 0x48(0x04)
	int32_t SpecialEvent_MinCount; // 0x4c(0x04)
	int32_t SpecialEvent_MaxCount; // 0x50(0x04)
	int32_t Legendary_MinCount; // 0x54(0x04)
	int32_t Legendary_MaxCount; // 0x58(0x04)
	int32_t InnerRingCommonItemProbability; // 0x5c(0x04)
	int32_t MiddleRingCommonItemProbability; // 0x60(0x04)
	int32_t OuterRingCommonItemProbability; // 0x64(0x04)
	int32_t InnerRingUncommonItemProbability; // 0x68(0x04)
	int32_t MiddleRingUncommonItemProbability; // 0x6c(0x04)
	int32_t OuterRingUncommonItemProbability; // 0x70(0x04)
	int32_t InnerRingRareItemProbability; // 0x74(0x04)
	int32_t MiddleRingRareItemProbability; // 0x78(0x04)
	int32_t OuterRingRareItemProbability; // 0x7c(0x04)
	int32_t InnerRingVeryRareItemProbability; // 0x80(0x04)
	int32_t MiddleRingVeryRareItemProbability; // 0x84(0x04)
	int32_t OuterRingVeryRareItemProbability; // 0x88(0x04)
	int32_t InnerRingUltraRareItemProbability; // 0x8c(0x04)
	int32_t MiddleRingUltraRareItemProbability; // 0x90(0x04)
	int32_t OuterRingUltraRareItemProbability; // 0x94(0x04)
	int32_t InnerRingArtifactItemProbability; // 0x98(0x04)
	int32_t MiddleRingArtifactItemProbability; // 0x9c(0x04)
	int32_t OuterRingArtifactItemProbability; // 0xa0(0x04)
	int32_t InnerRingSpectralItemProbability; // 0xa4(0x04)
	int32_t MiddleRingSpectralItemProbability; // 0xa8(0x04)
	int32_t OuterRingSpectralItemProbability; // 0xac(0x04)
	int32_t InnerRingSpecialEventItemProbability; // 0xb0(0x04)
	int32_t MiddleRingSpecialEventItemProbability; // 0xb4(0x04)
	int32_t OuterRingSpecialEventItemProbability; // 0xb8(0x04)
	int32_t InnerRingLegendaryItemProbability; // 0xbc(0x04)
	int32_t MiddleRingLegendaryItemProbability; // 0xc0(0x04)
	int32_t OuterRingLegendaryItemProbability; // 0xc4(0x04)
	int32_t EntityStartingRound; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// ScriptStruct DeadByDaylight.BloodwebRarityPerRingDistribution
// Size: 0x78 (Inherited: 0x08)
struct FBloodwebRarityPerRingDistribution : FDBDTableRowBase {
	int32_t CommonMinCount; // 0x08(0x04)
	int32_t CommonMaxCount; // 0x0c(0x04)
	int32_t CommonWeight; // 0x10(0x04)
	int32_t UncommonMinCount; // 0x14(0x04)
	int32_t UncommonMaxCount; // 0x18(0x04)
	int32_t UncommonWeight; // 0x1c(0x04)
	int32_t RareMinCount; // 0x20(0x04)
	int32_t RareMaxCount; // 0x24(0x04)
	int32_t RareWeight; // 0x28(0x04)
	int32_t VeryRareMinCount; // 0x2c(0x04)
	int32_t VeryRareMaxCount; // 0x30(0x04)
	int32_t VeryRareWeight; // 0x34(0x04)
	int32_t UltraRareMinCount; // 0x38(0x04)
	int32_t UltraRareMaxCount; // 0x3c(0x04)
	int32_t UltraRareWeight; // 0x40(0x04)
	int32_t ArtefactMinCount; // 0x44(0x04)
	int32_t ArtefactMaxCount; // 0x48(0x04)
	int32_t ArtefactWeight; // 0x4c(0x04)
	int32_t SpectralMinCount; // 0x50(0x04)
	int32_t SpectralMaxCount; // 0x54(0x04)
	int32_t SpectralWeight; // 0x58(0x04)
	int32_t SpecialEventMinCount; // 0x5c(0x04)
	int32_t SpecialEventMaxCount; // 0x60(0x04)
	int32_t SpecialEventWeight; // 0x64(0x04)
	int32_t LegendaryMinCount; // 0x68(0x04)
	int32_t LegendaryMaxCount; // 0x6c(0x04)
	int32_t LegendaryWeight; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// ScriptStruct DeadByDaylight.DBDPerPlatformFloat
// Size: 0x04 (Inherited: 0x00)
struct FDBDPerPlatformFloat {
	struct FPerPlatformFloat value; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.DBDPerPlatformInt
// Size: 0x04 (Inherited: 0x00)
struct FDBDPerPlatformInt {
	struct FPerPlatformInt value; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.BorderElements
// Size: 0x18 (Inherited: 0x00)
struct FBorderElements {
	enum class EDirection Direction; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct UActorSpawner*> Elements; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.BundleData
// Size: 0x88 (Inherited: 0x00)
struct FBundleData {
	struct FName ID; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FItemUIData UIData; // 0x10(0x78)
};

// ScriptStruct DeadByDaylight.CameraAttachment
// Size: 0x18 (Inherited: 0x00)
struct FCameraAttachment {
	struct USceneComponent* Parent; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.CamperDamageResult
// Size: 0x58 (Inherited: 0x00)
struct FCamperDamageResult {
	char pad_0[0x10]; // 0x00(0x10)
	struct AActor* damageSource; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct UGameplayModifierContainer* KOPreventedSource; // 0x20(0x08)
	char pad_28[0x30]; // 0x28(0x30)
};

// ScriptStruct DeadByDaylight.RoleDropdown
// Size: 0x02 (Inherited: 0x00)
struct FRoleDropdown {
	bool ShowRoleSelection; // 0x00(0x01)
	enum class EPlayerRole Role; // 0x01(0x01)
};

// ScriptStruct DeadByDaylight.CharacterDropdown
// Size: 0x08 (Inherited: 0x02)
struct FCharacterDropdown : FRoleDropdown {
	char pad_2[0x2]; // 0x02(0x02)
	int32_t characterId; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.RoleItemCategoryDropdown
// Size: 0x0c (Inherited: 0x08)
struct FRoleItemCategoryDropdown : FCharacterDropdown {
	bool IncludeOutfits; // 0x08(0x01)
	bool IncludeNone; // 0x09(0x01)
	enum class ECustomizationCategory Category; // 0x0a(0x01)
	char pad_B[0x1]; // 0x0b(0x01)
};

// ScriptStruct DeadByDaylight.CharacterAnimationDropdown
// Size: 0x28 (Inherited: 0x0c)
struct FCharacterAnimationDropdown : FRoleItemCategoryDropdown {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UAnimationAsset* Animation; // 0x10(0x08)
	struct FString AnimationPath; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.CharacterCustomizationDataTable
// Size: 0x40 (Inherited: 0x08)
struct FCharacterCustomizationDataTable : FDBDTableRowBase {
	int32_t CharacterIndex; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TSoftObjectPtr<struct UDataTable> CustomizationStoreDB; // 0x10(0x30)
};

// ScriptStruct DeadByDaylight.CharacterCustomizationDropdown
// Size: 0x5c (Inherited: 0x08)
struct FCharacterCustomizationDropdown : FCharacterDropdown {
	struct FName OutfitId; // 0x08(0x0c)
	struct FName SurvivorHead; // 0x14(0x0c)
	struct FName SurvivorTorso; // 0x20(0x0c)
	struct FName SurvivorLegs; // 0x2c(0x0c)
	struct FName KillerHead; // 0x38(0x0c)
	struct FName KillerBody; // 0x44(0x0c)
	struct FName KillerWeapon; // 0x50(0x0c)
};

// ScriptStruct DeadByDaylight.CharacterDescription
// Size: 0x200 (Inherited: 0x08)
struct FCharacterDescription : FDBDTableRowBase {
	int32_t CharacterIndex; // 0x08(0x04)
	enum class EPlayerRole Role; // 0x0c(0x01)
	enum class ECharacterDifficulty Difficulty; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
	struct FText DisplayName; // 0x10(0x18)
	struct FText BackStory; // 0x28(0x18)
	struct FText Biography; // 0x40(0x18)
	struct FName IconFilePath; // 0x58(0x0c)
	char pad_64[0x4]; // 0x64(0x04)
	struct UTexture2D* HudIcon; // 0x68(0x08)
	struct FName BackgroundImagePath; // 0x70(0x0c)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TArray<struct FCustomizedMeshPart> CustomizationDescription; // 0x80(0x10)
	struct FString ChapterDlcId; // 0x90(0x10)
	struct TArray<struct FString> AdditionalDlcIds; // 0xa0(0x10)
	bool AvailableIfDlcInstalled; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	struct FName IdName; // 0xb4(0x0c)
	struct FName DebugName; // 0xc0(0x0c)
	bool IsInChunk0; // 0xcc(0x01)
	bool IsAvailableInNonViolentBuild; // 0xcd(0x01)
	bool IsAvailableInAtlantaBuild; // 0xce(0x01)
	char pad_CF[0x1]; // 0xcf(0x01)
	uint32_t PlatformExclusiveFlag; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	SoftClassProperty GamePawn; // 0xd8(0x30)
	SoftClassProperty MenuPawn; // 0x108(0x30)
	struct FName DefaultItem; // 0x138(0x0c)
	enum class EGender Gender; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct TArray<enum class EKillerAbilities> KillerAbilities; // 0x148(0x10)
	struct FDataTableProxy TunableDB; // 0x158(0x40)
	enum class EKillerHeight KillerHeight; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
	struct FSlideShowDescription SlideShowDescriptions; // 0x1a0(0x50)
	struct TArray<struct FName> CustomizationCategories; // 0x1f0(0x10)
};

// ScriptStruct DeadByDaylight.SlideShowDescription
// Size: 0x50 (Inherited: 0x00)
struct FSlideShowDescription {
	struct FText Overview; // 0x00(0x18)
	struct FText Playstyle; // 0x18(0x18)
	struct FString ImageFilePath; // 0x30(0x10)
	struct TArray<enum class EPerkCategory> PerkCategory; // 0x40(0x10)
};

// ScriptStruct DeadByDaylight.CustomizedMeshPart
// Size: 0x48 (Inherited: 0x00)
struct FCustomizedMeshPart {
	enum class ECustomizationCategory Category; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FDataTableDropdown DefaultItemId; // 0x08(0x30)
	struct FName SocketName; // 0x38(0x0c)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct DeadByDaylight.CharacterDescriptionOverride
// Size: 0x60 (Inherited: 0x08)
struct FCharacterDescriptionOverride : FDBDTableRowBase {
	struct FName RequiredItemId; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText DisplayNameOverride; // 0x18(0x18)
	struct TSoftObjectPtr<struct UTexture2D> HudIconOverride; // 0x30(0x30)
};

// ScriptStruct DeadByDaylight.CharacterInfoData
// Size: 0x228 (Inherited: 0x00)
struct FCharacterInfoData {
	struct FCharacterSlotData SlotData; // 0x00(0x100)
	struct FString Description; // 0x100(0x10)
	struct TArray<struct FTeachableData> TeachablePerksData; // 0x110(0x10)
	struct FInventorySlotData PowerData; // 0x120(0xf8)
	struct FKillerAttributesData KillerAttributesData; // 0x218(0x0c)
	bool IsKiller; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
};

// ScriptStruct DeadByDaylight.KillerAttributesData
// Size: 0x0c (Inherited: 0x00)
struct FKillerAttributesData {
	float Speed; // 0x00(0x04)
	float TerrorRadius; // 0x04(0x04)
	enum class EKillerHeight Height; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct DeadByDaylight.TeachableData
// Size: 0x110 (Inherited: 0x00)
struct FTeachableData {
	struct FInventorySlotData InventorySlotData; // 0x00(0xf8)
	enum class ETeachableStatus status; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	int32_t UnlockLevel; // 0xfc(0x04)
	struct FString Message; // 0x100(0x10)
};

// ScriptStruct DeadByDaylight.CharacterSlotData
// Size: 0x100 (Inherited: 0x00)
struct FCharacterSlotData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FName ID; // 0x08(0x0c)
	int32_t CharacterIndex; // 0x14(0x04)
	struct FString IconFilePath; // 0x18(0x10)
	struct FString BackgroundImagePath; // 0x28(0x10)
	struct FString DisplayName; // 0x38(0x10)
	struct FString Biography; // 0x48(0x10)
	struct FString DLCId; // 0x58(0x10)
	struct FString DLCTitle; // 0x68(0x10)
	int32_t Level; // 0x78(0x04)
	int32_t Prestige; // 0x7c(0x04)
	enum class ECharacterDifficulty Difficulty; // 0x80(0x01)
	bool IsUnlocked; // 0x81(0x01)
	bool IsDLCPurchasable; // 0x82(0x01)
	char pad_83[0x5]; // 0x83(0x05)
	struct TArray<struct FPurchaseCurrencyData> PurchaseDataList; // 0x88(0x10)
	int32_t ItemsOwned; // 0x98(0x04)
	int32_t TotalItems; // 0x9c(0x04)
	bool ShowNew; // 0xa0(0x01)
	bool IsDlcLockedKiller; // 0xa1(0x01)
	char pad_A2[0x6]; // 0xa2(0x06)
	struct FSpecialEventUIInfo EventInfo; // 0xa8(0x50)
	char pad_F8[0x8]; // 0xf8(0x08)
};

// ScriptStruct DeadByDaylight.CharacterLevelData
// Size: 0x20 (Inherited: 0x00)
struct FCharacterLevelData {
	int32_t Level; // 0x00(0x04)
	int32_t ExperienceToNextLevel; // 0x04(0x04)
	bool IsComplete; // 0x08(0x01)
	bool HasPerksBeenSelected; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct TArray<struct FAssignedPerkProperties> PerkSelection; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.CharacterSlideData
// Size: 0x70 (Inherited: 0x00)
struct FCharacterSlideData {
	struct FString DisplayName; // 0x00(0x10)
	struct FString Overview; // 0x10(0x10)
	struct FString Playstyle; // 0x20(0x10)
	enum class EPlayerRole Role; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString ImageFilePath; // 0x38(0x10)
	struct TArray<enum class EPerkCategory> SurvivorPerkCategories; // 0x48(0x10)
	struct FString KillerPowerIconPath; // 0x58(0x10)
	char pad_68[0x8]; // 0x68(0x08)
};

// ScriptStruct DeadByDaylight.SnappingData
// Size: 0x24 (Inherited: 0x00)
struct FSnappingData {
	bool DoSnapPosition; // 0x00(0x01)
	bool DoSnapRotation; // 0x01(0x01)
	bool DoSnapRoll; // 0x02(0x01)
	bool useZCoord; // 0x03(0x01)
	bool sweepOnFinalSnap; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FVector targetPosition; // 0x08(0x0c)
	struct FRotator TargetRotation; // 0x14(0x0c)
	float Duration; // 0x20(0x04)
};

// ScriptStruct DeadByDaylight.CharacterToolData
// Size: 0x70 (Inherited: 0x00)
struct FCharacterToolData {
	enum class EPlayerRole Role; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t characterId; // 0x04(0x04)
	struct FName OutfitId; // 0x08(0x0c)
	struct FName CharmId; // 0x14(0x0c)
	struct FName SurvivorHead; // 0x20(0x0c)
	struct FName SurvivorTorso; // 0x2c(0x0c)
	struct FName SurvivorLegs; // 0x38(0x0c)
	struct FName KillerHead; // 0x44(0x0c)
	struct FName KillerBody; // 0x50(0x0c)
	struct FName KillerWeapon; // 0x5c(0x0c)
	struct UAnimationAsset* AnimationToPlay; // 0x68(0x08)
};

// ScriptStruct DeadByDaylight.ChargeData
// Size: 0x10 (Inherited: 0x00)
struct FChargeData {
	struct AActor* Instigator; // 0x00(0x08)
	float ChargeAmount; // 0x08(0x04)
	bool BypassSkillCheckFail; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct DeadByDaylight.CharmAttacherAnimationTweak
// Size: 0x20 (Inherited: 0x00)
struct FCharmAttacherAnimationTweak {
	struct FVector AttachPointTranslation; // 0x00(0x0c)
	struct FRotator AttachPointRotation; // 0x0c(0x0c)
	int32_t ConstraintType; // 0x18(0x04)
	float MagicTweakingFloat; // 0x1c(0x04)
};

// ScriptStruct DeadByDaylight.CharmDropdown
// Size: 0x10 (Inherited: 0x02)
struct FCharmDropdown : FRoleDropdown {
	char pad_2[0x2]; // 0x02(0x02)
	struct FName CharmId; // 0x04(0x0c)
};

// ScriptStruct DeadByDaylight.CharmSlot
// Size: 0xb0 (Inherited: 0x00)
struct FCharmSlot {
	int32_t SlotIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	SoftClassProperty CharmAttacherClass; // 0x08(0x30)
	struct FCharmAttacherAnimationTweak DefaultAnimationTweak; // 0x38(0x20)
	struct TMap<struct FName, struct FCharmAttacherAnimationTweak> AnimationTweakByTag; // 0x58(0x50)
	struct ACharmAttacher* CharmAttacherSpawned; // 0xa8(0x08)
};

// ScriptStruct DeadByDaylight.ChaseUpdateInfo
// Size: 0x40 (Inherited: 0x00)
struct FChaseUpdateInfo {
	struct FTargetFocusTimer ChaseTimer; // 0x00(0x38)
	float SurvivorTravelDistance; // 0x38(0x04)
	float KillerTravelDistance; // 0x3c(0x04)
};

// ScriptStruct DeadByDaylight.Cinematic
// Size: 0x58 (Inherited: 0x00)
struct FCinematic {
	struct TSoftObjectPtr<struct UMediaSource> Source; // 0x00(0x30)
	struct FVector2D SourceSize; // 0x30(0x08)
	bool SourceHasAudio; // 0x38(0x01)
	char pad_39[0x1f]; // 0x39(0x1f)
};

// ScriptStruct DeadByDaylight.MaterialOriginalState
// Size: 0x18 (Inherited: 0x00)
struct FMaterialOriginalState {
	struct UMeshComponent* MeshWithChangedMaterials; // 0x00(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterial; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.MaterialMapForClip
// Size: 0x18 (Inherited: 0x08)
struct FMaterialMapForClip : FDBDTableRowBase {
	struct UMaterialInterface* SrcMaterial; // 0x08(0x08)
	struct UMaterialInterface* DstMaterial; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.CombinedPartyFriendData
// Size: 0x120 (Inherited: 0x00)
struct FCombinedPartyFriendData {
	char pad_0[0x120]; // 0x00(0x120)
};

// ScriptStruct DeadByDaylight.CombinedSpecialEventData
// Size: 0x170 (Inherited: 0x00)
struct FCombinedSpecialEventData {
	char pad_0[0x170]; // 0x00(0x170)
};

// ScriptStruct DeadByDaylight.ContextEventData
// Size: 0x58 (Inherited: 0x00)
struct FContextEventData {
	struct FString ContextGroupName; // 0x00(0x10)
	uint32_t ContextGroupUid; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString PreviousContextName; // 0x18(0x10)
	struct FString CurrentContextName; // 0x28(0x10)
	uint32_t CurrentContextUid; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString NextContextName; // 0x40(0x10)
	struct FDateTime Timestamp; // 0x50(0x08)
};

// ScriptStruct DeadByDaylight.CurrencyPurchaseData
// Size: 0x58 (Inherited: 0x00)
struct FCurrencyPurchaseData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString IconPath; // 0x08(0x10)
	struct FString CurrencyName; // 0x18(0x10)
	struct FString CurrencyIcon; // 0x28(0x10)
	int32_t CurrencyAmount; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString DisplayedPrice; // 0x40(0x10)
	float BonusPercentage; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct DeadByDaylight.CustomizationCategoryData
// Size: 0x48 (Inherited: 0x08)
struct FCustomizationCategoryData : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	enum class ECustomizationCategory Category; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FString IconPath; // 0x18(0x10)
	struct FText DisplayName; // 0x28(0x18)
	enum class EPlayerRole Role; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct DeadByDaylight.CustomizationData
// Size: 0xc8 (Inherited: 0x08)
struct FCustomizationData : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	int32_t AssociatedCharacter; // 0x14(0x04)
	enum class EPlayerRole AssociatedRole; // 0x18(0x01)
	enum class EItemRarity Rarity; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct FItemUIData UIData; // 0x20(0x78)
	struct FItemAvailability Availability; // 0x98(0x30)
};

// ScriptStruct DeadByDaylight.ItemAvailability
// Size: 0x30 (Inherited: 0x00)
struct FItemAvailability {
	enum class EItemAvailability ItemAvailability; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString DLCId; // 0x08(0x10)
	int32_t CloudInventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString CommunityId; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.CustomizationItemData
// Size: 0x2d0 (Inherited: 0xc8)
struct FCustomizationItemData : FCustomizationData {
	enum class ECustomizationCategory Category; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
	struct TSoftObjectPtr<struct USkeletalMesh> ItemMesh; // 0xd0(0x30)
	SoftClassProperty AnimClass; // 0x100(0x30)
	SoftClassProperty ItemBlueprint; // 0x130(0x30)
	struct TArray<struct FMaterialReplacerData> MaterialsMap; // 0x160(0x10)
	struct FConditionalMaterialReplacer ConditionalMaterialReplacer; // 0x170(0x60)
	struct TArray<struct FName> SkeletalComponentTags; // 0x1d0(0x10)
	struct FText CollectionName; // 0x1e0(0x18)
	struct FText CollectionDescription; // 0x1f8(0x18)
	int32_t PrestigeUlockLevel; // 0x210(0x04)
	char pad_214[0x4]; // 0x214(0x04)
	struct FString PrestigeUnlockDate; // 0x218(0x10)
	struct FName EventId; // 0x228(0x0c)
	enum class ECharmCategory CharmCategory; // 0x234(0x01)
	char pad_235[0x3]; // 0x235(0x03)
	struct TArray<struct FBPAttachementSocketData> SocketAttachements; // 0x238(0x10)
	struct TArray<struct FUnlockSaveStatCondition> UnlockingConditions; // 0x248(0x10)
	bool IsInStore; // 0x258(0x01)
	bool IsInNonViolentBuild; // 0x259(0x01)
	bool IsAvailableInAtlantaBuild; // 0x25a(0x01)
	char pad_25B[0x1]; // 0x25b(0x01)
	uint32_t PlatformExclusiveFlag; // 0x25c(0x04)
	struct TArray<struct FCustomSoundFXData> CustomSFXs; // 0x260(0x10)
	struct FCustomAnimData AnimationData; // 0x270(0x60)
};

// ScriptStruct DeadByDaylight.CustomAnimData
// Size: 0x60 (Inherited: 0x00)
struct FCustomAnimData {
	SoftClassProperty MenuAnimationBlueprint; // 0x00(0x30)
	SoftClassProperty InGameAnimationBlueprint; // 0x30(0x30)
};

// ScriptStruct DeadByDaylight.CustomSoundFXData
// Size: 0x18 (Inherited: 0x00)
struct FCustomSoundFXData {
	enum class EAudioCustomizationCategory AudioCategory; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString switchState; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.UnlockSaveStatCondition
// Size: 0x14 (Inherited: 0x00)
struct FUnlockSaveStatCondition {
	struct FName StatName; // 0x00(0x0c)
	float ValueRequired; // 0x0c(0x04)
	bool isCharacterSpecific; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
};

// ScriptStruct DeadByDaylight.BPAttachementSocketData
// Size: 0xe0 (Inherited: 0x00)
struct FBPAttachementSocketData {
	SoftClassProperty AttachementBlueprint; // 0x00(0x30)
	struct TSoftObjectPtr<struct USkeletalMesh> SkeletalMesh; // 0x30(0x30)
	struct FName SocketName; // 0x60(0x0c)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct TArray<struct FMaterialReplacerData> MaterialsMap; // 0x70(0x10)
	struct FConditionalMaterialReplacer ConditionalMaterialReplacer; // 0x80(0x60)
};

// ScriptStruct DeadByDaylight.ConditionalMaterialReplacer
// Size: 0x60 (Inherited: 0x00)
struct FConditionalMaterialReplacer {
	struct FName ItemTag; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TMap<struct FName, struct FMaterialReplacerArray> ConditionalMaterials; // 0x10(0x50)
};

// ScriptStruct DeadByDaylight.MaterialReplacerArray
// Size: 0x10 (Inherited: 0x00)
struct FMaterialReplacerArray {
	struct TArray<struct FMaterialReplacerData> MaterialsMap; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.MaterialReplacerData
// Size: 0x60 (Inherited: 0x00)
struct FMaterialReplacerData {
	struct TSoftObjectPtr<struct UMaterialInterface> From; // 0x00(0x30)
	struct TSoftObjectPtr<struct UMaterialInterface> To; // 0x30(0x30)
};

// ScriptStruct DeadByDaylight.MapSoundsToAvoid
// Size: 0x10 (Inherited: 0x00)
struct FMapSoundsToAvoid {
	struct UPrimitiveComponent* Component; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.MapMeshToAkAudioEvent
// Size: 0x40 (Inherited: 0x00)
struct FMapMeshToAkAudioEvent {
	struct TSoftObjectPtr<struct UStaticMesh> Mesh; // 0x00(0x30)
	struct UAkAudioEvent* SoundEvent; // 0x30(0x08)
	float MinDelayBetweenEvents; // 0x38(0x04)
	float MinDelayBetweenObject; // 0x3c(0x04)
};

// ScriptStruct DeadByDaylight.DBD_SoundSpawnerData
// Size: 0x28 (Inherited: 0x00)
struct FDBD_SoundSpawnerData {
	struct TArray<SoftClassProperty> TriggerObject; // 0x00(0x10)
	bool TriggerVisualForCamper; // 0x10(0x01)
	bool TriggerVisualForSlasher; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
	struct TArray<SoftClassProperty> ActorToSpawnVisual; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.AIRoll
// Size: 0x24 (Inherited: 0x00)
struct FAIRoll {
	struct FAITunableParameter Random; // 0x00(0x10)
	struct FAITunableParameter OnFailCooldown; // 0x10(0x10)
	char pad_20[0x4]; // 0x20(0x04)
};

// ScriptStruct DeadByDaylight.AIDifficultyTunableRowData
// Size: 0x18 (Inherited: 0x08)
struct FAIDifficultyTunableRowData : FDBDTableRowBase {
	float VeryEasy; // 0x08(0x04)
	float Easy; // 0x0c(0x04)
	float Medium; // 0x10(0x04)
	float Hard; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.DBDAttackTargetTracker
// Size: 0xb8 (Inherited: 0x00)
struct FDBDAttackTargetTracker {
	bool _useTargetTracking; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FStatProperty _targetSnapDistance; // 0x08(0x88)
	struct FName _ownerEyeSocketName; // 0x90(0x0c)
	struct FName _targetBoneName; // 0x9c(0x0c)
	struct TWeakObjectPtr<struct ACharacter> _trackedTarget; // 0xa8(0x08)
	struct TWeakObjectPtr<struct ADBDPlayer> _owningPlayer; // 0xb0(0x08)
};

// ScriptStruct DeadByDaylight.AuthenticationInfo
// Size: 0x18 (Inherited: 0x00)
struct FAuthenticationInfo {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DeadByDaylight.PerMeshInstancingData
// Size: 0xa0 (Inherited: 0x00)
struct FPerMeshInstancingData {
	struct TMap<uint32_t, struct UInstancedStaticMeshComponent*> hashToInstancedMeshes; // 0x00(0x50)
	char pad_50[0x50]; // 0x50(0x50)
};

// ScriptStruct DeadByDaylight.WebPath
// Size: 0x28 (Inherited: 0x00)
struct FWebPath {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct DeadByDaylight.WebNode
// Size: 0x28 (Inherited: 0x00)
struct FWebNode {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct DeadByDaylight.CharacterSavedProfileData
// Size: 0x158 (Inherited: 0x00)
struct FCharacterSavedProfileData {
	int32_t BloodWebLevel; // 0x00(0x04)
	int32_t TimesConfronted; // 0x04(0x04)
	struct TArray<struct FDateTime> PrestigeEarnedDates; // 0x08(0x10)
	struct FBloodWebPersistentData BloodWebData; // 0x18(0x40)
	struct FPlayerLoadoutData CharacterLoadoutData; // 0x58(0x98)
	struct TArray<struct FName> CurrentCustomization; // 0xf0(0x10)
	struct TArray<struct FCharmIdSlot> CurrentCharmCustomization; // 0x100(0x10)
	struct TArray<struct FName> UniquePerksAdded; // 0x110(0x10)
	struct TArray<struct FCharacterSavedInventoryData> InventoryData; // 0x120(0x10)
	struct TArray<struct FSavedCharacterLevelData> CharacterLevelData; // 0x130(0x10)
	struct TArray<struct FSavedStatsData> StatProgression; // 0x140(0x10)
	int32_t PrestigeLevel; // 0x150(0x04)
	int32_t CharacterExperience; // 0x154(0x04)
};

// ScriptStruct DeadByDaylight.SavedStatsData
// Size: 0x14 (Inherited: 0x00)
struct FSavedStatsData {
	uint32_t Version; // 0x00(0x04)
	struct FName Name; // 0x04(0x0c)
	float value; // 0x10(0x04)
};

// ScriptStruct DeadByDaylight.SavedCharacterLevelData
// Size: 0x18 (Inherited: 0x00)
struct FSavedCharacterLevelData {
	int32_t Level; // 0x00(0x04)
	bool HasPerksBeenSelected; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct TArray<struct FAssignedPerkProperties> PerkSelection; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.CharacterSavedInventoryData
// Size: 0x10 (Inherited: 0x00)
struct FCharacterSavedInventoryData {
	uint32_t Version; // 0x00(0x04)
	struct FName Name; // 0x04(0x0c)
};

// ScriptStruct DeadByDaylight.PlayerLoadoutData
// Size: 0x98 (Inherited: 0x00)
struct FPlayerLoadoutData {
	struct FName item; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FName> ItemAddOns; // 0x10(0x10)
	struct TArray<struct FName> CamperPerks; // 0x20(0x10)
	struct TArray<int32_t> CamperPerkLevels; // 0x30(0x10)
	struct FName CamperFavor; // 0x40(0x0c)
	struct FName Power; // 0x4c(0x0c)
	struct TArray<struct FName> PowerAddOns; // 0x58(0x10)
	struct TArray<struct FName> SlasherPerks; // 0x68(0x10)
	struct TArray<int32_t> SlasherPerkLevels; // 0x78(0x10)
	struct FName SlasherFavor; // 0x88(0x0c)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct DeadByDaylight.SpawnInfo
// Size: 0x40 (Inherited: 0x00)
struct FSpawnInfo {
	struct UObject* actorClass; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform Transform; // 0x10(0x30)
};

// ScriptStruct DeadByDaylight.AffectedMaterialAndVariant
// Size: 0x10 (Inherited: 0x00)
struct FAffectedMaterialAndVariant {
	struct UMaterialInterface* AffectedMaterial; // 0x00(0x08)
	struct UMaterialInterface* MaterialVariant; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.DBDCustomizationToolData
// Size: 0xbb8 (Inherited: 0x00)
struct FDBDCustomizationToolData {
	struct FCustomizationItemData Head; // 0x00(0x2d0)
	struct FCustomizationItemData Torso; // 0x2d0(0x2d0)
	struct FCustomizationItemData Leg; // 0x5a0(0x2d0)
	struct FCustomizationItemData Bodies; // 0x870(0x2d0)
	struct FString characterName; // 0xb40(0x10)
	struct FString RoleName; // 0xb50(0x10)
	struct USkeletalMesh* BaseSkeleton; // 0xb60(0x08)
	struct UTexture2D* MaskTexture; // 0xb68(0x08)
	struct UAnimationAsset* AnimationToPlay; // 0xb70(0x08)
	struct FString StrHeadDLC; // 0xb78(0x10)
	struct FString StrTorsoDLC; // 0xb88(0x10)
	struct FString StrLegDLC; // 0xb98(0x10)
	struct FString StrBodiesDLC; // 0xba8(0x10)
};

// ScriptStruct DeadByDaylight.DailyRitualContainer
// Size: 0x28 (Inherited: 0x00)
struct FDailyRitualContainer {
	struct FDateTime LastRitualReceivedDate; // 0x00(0x08)
	struct FDateTime LastRitualPopupDate; // 0x08(0x08)
	struct FDateTime LastRitualDismissedDate; // 0x10(0x08)
	struct TArray<struct FDailyRitualInstance> Rituals; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.DailyRitualInstance
// Size: 0x78 (Inherited: 0x00)
struct FDailyRitualInstance {
	struct FName RitualKey; // 0x00(0x0c)
	int32_t DifficultyTier; // 0x0c(0x04)
	struct TArray<enum class EDBDScoreTypes> TrackedEvents; // 0x10(0x10)
	struct TArray<struct FGameplayTag> TrackedGameEvents; // 0x20(0x10)
	struct TArray<int32_t> CharacterIDs; // 0x30(0x10)
	struct TArray<enum class EPlayerRole> Roles; // 0x40(0x10)
	float Progress; // 0x50(0x04)
	float Threshold; // 0x54(0x04)
	float Tolerance; // 0x58(0x04)
	float DisplayThreshold; // 0x5c(0x04)
	float ExpReward; // 0x60(0x04)
	bool Active; // 0x64(0x01)
	bool IsNew; // 0x65(0x01)
	char pad_66[0x2]; // 0x66(0x02)
	struct FDateTime DateAssigned; // 0x68(0x08)
	int32_t NbGameElapsed; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// ScriptStruct DeadByDaylight.DailyRitualDefinition
// Size: 0xd8 (Inherited: 0x08)
struct FDailyRitualDefinition : FDBDTableRowBase {
	struct FText DisplayName; // 0x08(0x18)
	struct FText Description; // 0x20(0x18)
	struct FString IconPath; // 0x38(0x10)
	struct FDailyRitualPossibleCharacters PossibleCharacters; // 0x48(0x30)
	struct TArray<enum class EDBDScoreTypes> TrackedEvents; // 0x78(0x10)
	struct TArray<struct FGameplayTag> TrackedGameEvents; // 0x88(0x10)
	struct TArray<struct FDailyRitualLevel> DifficultyLevels; // 0x98(0x10)
	SoftClassProperty Evaluator; // 0xa8(0x30)
};

// ScriptStruct DeadByDaylight.DailyRitualLevel
// Size: 0x10 (Inherited: 0x00)
struct FDailyRitualLevel {
	float Threshold; // 0x00(0x04)
	float Tolerance; // 0x04(0x04)
	int32_t DisplayTotal; // 0x08(0x04)
	float BloodpointsReward; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.DailyRitualPossibleCharacters
// Size: 0x30 (Inherited: 0x00)
struct FDailyRitualPossibleCharacters {
	struct TArray<int32_t> CharacterIDs; // 0x00(0x10)
	struct TArray<enum class EPlayerRole> Roles; // 0x10(0x10)
	struct TArray<enum class EPlayerRole> SelectOneCharacterFromRoles; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.RitualEvent
// Size: 0x30 (Inherited: 0x00)
struct FRitualEvent {
	enum class EDBDScoreTypes scoreType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag gameEventType; // 0x04(0x0c)
	float amount; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct ADBDPlayer* Instigator; // 0x18(0x08)
	struct ADBDPlayerState* InstigatorPlayerState; // 0x20(0x08)
	struct AActor* Target; // 0x28(0x08)
};

// ScriptStruct DeadByDaylight.SlasherLoadout
// Size: 0x80 (Inherited: 0x00)
struct FSlasherLoadout {
	struct FCharacterCustomizationDropdown Slasher; // 0x00(0x5c)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TArray<struct FDebugLoadoutAddon> PowerAddonIDs; // 0x60(0x10)
	struct TArray<struct FDebugLoadoutPerk> Perks; // 0x70(0x10)
};

// ScriptStruct DeadByDaylight.DebugLoadoutPerk
// Size: 0x38 (Inherited: 0x00)
struct FDebugLoadoutPerk {
	struct FDataTableDropdown PerkId; // 0x00(0x30)
	int32_t PerkLevel; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.DebugLoadoutAddon
// Size: 0x30 (Inherited: 0x00)
struct FDebugLoadoutAddon {
	struct FDataTableDropdown AddonID; // 0x00(0x30)
};

// ScriptStruct DeadByDaylight.CamperLoadout
// Size: 0xe0 (Inherited: 0x00)
struct FCamperLoadout {
	struct FCharacterCustomizationDropdown camper; // 0x00(0x5c)
	struct FCharmDropdown Slot0_CharmID; // 0x5c(0x10)
	struct FCharmDropdown Slot1_CharmID; // 0x6c(0x10)
	struct FCharmDropdown Slot2_CharmID; // 0x7c(0x10)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FDataTableDropdown ItemId; // 0x90(0x30)
	struct TArray<struct FDebugLoadoutAddon> AddonIDs; // 0xc0(0x10)
	struct TArray<struct FDebugLoadoutPerk> Perks; // 0xd0(0x10)
};

// ScriptStruct DeadByDaylight.AttackTypeDetails
// Size: 0x28 (Inherited: 0x08)
struct FAttackTypeDetails : FDBDTableRowBase {
	enum class EAttackType attackType; // 0x08(0x01)
	bool IsBasicAttack; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
	int32_t AssociatedCharacter; // 0x0c(0x04)
	struct FText Description; // 0x10(0x18)
};

// ScriptStruct DeadByDaylight.LevelUpDetails
// Size: 0x58 (Inherited: 0x08)
struct FLevelUpDetails : FDBDTableRowBase {
	int32_t Level; // 0x08(0x04)
	int32_t Prestige; // 0x0c(0x04)
	struct FText Title; // 0x10(0x18)
	struct FText Description; // 0x28(0x18)
	struct FName ItemId; // 0x40(0x0c)
	enum class EInventoryItemType ItemType; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32_t AssociatedCharacter; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct DeadByDaylight.PerkLevelDefinition
// Size: 0x04 (Inherited: 0x00)
struct FPerkLevelDefinition {
	int32_t CountRequired; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.EACClientInfo
// Size: 0x28 (Inherited: 0x00)
struct FEACClientInfo {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct DeadByDaylight.ProgressionPoints
// Size: 0x08 (Inherited: 0x00)
struct FProgressionPoints {
	enum class EEmblemProgressionType Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Points; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.DBDEmblemDefinition
// Size: 0xb0 (Inherited: 0x08)
struct FDBDEmblemDefinition : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Name; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
	struct TArray<enum class EPlayerRole> Roles; // 0x48(0x10)
	SoftClassProperty CustomEmblem; // 0x58(0x30)
	struct TArray<struct FString> IconFilePaths; // 0x88(0x10)
	enum class EEmblemEvaluation EmblemEvaluation; // 0x98(0x01)
	bool Enabled; // 0x99(0x01)
	char pad_9A[0x6]; // 0x9a(0x06)
	struct TArray<struct FEmblemProgressionID> EmblemProgressionData; // 0xa0(0x10)
};

// ScriptStruct DeadByDaylight.EmblemProgressionID
// Size: 0x30 (Inherited: 0x00)
struct FEmblemProgressionID {
	enum class EEmblemProgressionType EmblemProgressionType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText DefaultDescription; // 0x08(0x18)
	struct TArray<struct FEmblemProgressionDescriptionByQuality> DescriptionsByQuality; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.EmblemProgressionDescriptionByQuality
// Size: 0x20 (Inherited: 0x00)
struct FEmblemProgressionDescriptionByQuality {
	enum class EEmblemQuality EmblemQuality; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText Description; // 0x08(0x18)
};

// ScriptStruct DeadByDaylight.SharedAuthenticationTokenInformation
// Size: 0x20 (Inherited: 0x00)
struct FSharedAuthenticationTokenInformation {
	struct FString LoginProvider; // 0x00(0x10)
	struct FString AuthToken; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.KeyDisplayInfo
// Size: 0x40 (Inherited: 0x00)
struct FKeyDisplayInfo {
	struct FKey Key; // 0x00(0x20)
	struct FString KeyDisplayName; // 0x20(0x10)
	struct FString PromptType; // 0x30(0x10)
};

// ScriptStruct DeadByDaylight.SaveDataBase
// Size: 0x10 (Inherited: 0x00)
struct FSaveDataBase {
	char pad_0[0x8]; // 0x00(0x08)
	int32_t VersionNumber; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.LegacyPlayerSavedProfileData
// Size: 0x1e0 (Inherited: 0x10)
struct FLegacyPlayerSavedProfileData : FSaveDataBase {
	struct FString PlayerUID; // 0x10(0x10)
	struct FLegacyPlayerSavedProfileDataShared SharedData; // 0x20(0x40)
	struct FLegacyPlayerSavedProfileDataLocal LocalData; // 0x60(0x180)
};

// ScriptStruct DeadByDaylight.LegacyPlayerSavedProfileDataLocal
// Size: 0x180 (Inherited: 0x00)
struct FLegacyPlayerSavedProfileDataLocal {
	int32_t Tokens; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FName> offerings; // 0x08(0x10)
	bool FirstTimePlaying; // 0x18(0x01)
	bool HasBeenGivenKillerTutorialEndReward; // 0x19(0x01)
	bool HasBeenGivenSurvivorTutorialEndReward; // 0x1a(0x01)
	char pad_1B[0x1]; // 0x1b(0x01)
	int32_t Wins; // 0x1c(0x04)
	int32_t Losses; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TMap<int32_t, struct FLegacyCharacterSavedProfileData> CharacterData; // 0x28(0x50)
	uint64_t CurrentSeasonTicks; // 0x78(0x08)
	struct FLegacySavedDailyRitualContainer DailyRituals; // 0x80(0x18)
	struct FLegacySavedFearMarketOfferingInstance FearMarket; // 0x98(0x20)
	struct FLegacySavedPlayerLoadoutData LastConnectedLoadout; // 0xb8(0x98)
	int32_t LastConnectedCharacterIndex; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct FDateTime DisconnectPenaltyTime; // 0x158(0x08)
	int32_t _bloodpoints; // 0x160(0x04)
	int32_t _bonusBloodpoints; // 0x164(0x04)
	int32_t _unclampedBloodpoints; // 0x168(0x04)
	int32_t _fearTokens; // 0x16c(0x04)
	struct FDateTime _ongoingGameTime; // 0x170(0x08)
	bool _fearTokensMigrated; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
};

// ScriptStruct DeadByDaylight.LegacySavedPlayerLoadoutData
// Size: 0x98 (Inherited: 0x00)
struct FLegacySavedPlayerLoadoutData {
	struct FName item; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FName> ItemAddOns; // 0x10(0x10)
	struct TArray<struct FName> CamperPerks; // 0x20(0x10)
	struct TArray<int32_t> CamperPerkLevels; // 0x30(0x10)
	struct FName CamperFavor; // 0x40(0x0c)
	struct FName Power; // 0x4c(0x0c)
	struct TArray<struct FName> PowerAddOns; // 0x58(0x10)
	struct TArray<struct FName> SlasherPerks; // 0x68(0x10)
	struct TArray<int32_t> SlasherPerkLevels; // 0x78(0x10)
	struct FName SlasherFavor; // 0x88(0x0c)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct DeadByDaylight.LegacySavedFearMarketOfferingInstance
// Size: 0x20 (Inherited: 0x00)
struct FLegacySavedFearMarketOfferingInstance {
	struct TArray<struct FLegacySavedFearMarketItemInstance> ObjectsForSale; // 0x00(0x10)
	struct FDateTime StartTime; // 0x10(0x08)
	struct FDateTime EndTime; // 0x18(0x08)
};

// ScriptStruct DeadByDaylight.LegacySavedFearMarketItemInstance
// Size: 0x18 (Inherited: 0x00)
struct FLegacySavedFearMarketItemInstance {
	struct FName ItemId; // 0x00(0x0c)
	int32_t Cost; // 0x0c(0x04)
	int32_t BloodpointConversion; // 0x10(0x04)
	bool Purchased; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct DeadByDaylight.LegacySavedDailyRitualContainer
// Size: 0x18 (Inherited: 0x00)
struct FLegacySavedDailyRitualContainer {
	struct FDateTime LastRitualReceivedDate; // 0x00(0x08)
	struct TArray<struct FLegacySavedDailyRitualInstance> Rituals; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.LegacySavedDailyRitualInstance
// Size: 0x78 (Inherited: 0x00)
struct FLegacySavedDailyRitualInstance {
	struct FName RitualKey; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<int32_t> CharacterIDs; // 0x10(0x10)
	struct TArray<enum class EPlayerRole> Roles; // 0x20(0x10)
	float Progress; // 0x30(0x04)
	float Threshold; // 0x34(0x04)
	float Tolerance; // 0x38(0x04)
	float DisplayThreshold; // 0x3c(0x04)
	float ExpReward; // 0x40(0x04)
	bool Active; // 0x44(0x01)
	bool Rewarded; // 0x45(0x01)
	bool StateChanged; // 0x46(0x01)
	char pad_47[0x1]; // 0x47(0x01)
	struct FDateTime DateAssigned; // 0x48(0x08)
	int32_t NbGameElapsed; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TArray<enum class EDBDScoreTypes> TrackedEvents; // 0x58(0x10)
	struct TArray<struct FGameplayTag> TrackedGameEvents; // 0x68(0x10)
};

// ScriptStruct DeadByDaylight.LegacyCharacterSavedProfileData
// Size: 0x130 (Inherited: 0x00)
struct FLegacyCharacterSavedProfileData {
	int32_t VersionNumber; // 0x00(0x04)
	int32_t BloodPoints; // 0x04(0x04)
	int32_t BloodWebLevel; // 0x08(0x04)
	int32_t PrestigeLevel; // 0x0c(0x04)
	int32_t TimesConfronted; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FDateTime> PrestigeDates; // 0x18(0x10)
	struct FLegacySavedBloodWebPersistentData BloodWebData; // 0x28(0x40)
	struct FLegacySavedPlayerLoadoutData CharacterLoadoutData; // 0x68(0x98)
	struct TArray<struct FName> Inventory; // 0x100(0x10)
	struct TArray<struct FLegacyCharacterSavedInventoryData> InventoryData; // 0x110(0x10)
	struct TArray<struct FName> CurrentCustomization; // 0x120(0x10)
};

// ScriptStruct DeadByDaylight.LegacyCharacterSavedInventoryData
// Size: 0x18 (Inherited: 0x00)
struct FLegacyCharacterSavedInventoryData {
	uint32_t Version; // 0x00(0x04)
	struct FName Name; // 0x04(0x0c)
	int64_t TimeObtainedSinceEpoch; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodWebPersistentData
// Size: 0x40 (Inherited: 0x00)
struct FLegacySavedBloodWebPersistentData {
	int32_t VersionNumber; // 0x00(0x04)
	int32_t Level; // 0x04(0x04)
	struct TArray<struct FLegacySavedBloodWebRingPersistentData> RingData; // 0x08(0x10)
	struct TArray<struct FName> Paths; // 0x18(0x10)
	struct FString EntityCurrentNode; // 0x28(0x10)
	struct FDateTime GenerationDate; // 0x38(0x08)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodWebRingPersistentData
// Size: 0x10 (Inherited: 0x00)
struct FLegacySavedBloodWebRingPersistentData {
	struct TArray<struct FLegacySavedBloodwebNode> NodeData; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodwebNode
// Size: 0x80 (Inherited: 0x00)
struct FLegacySavedBloodwebNode {
	struct FLegacySavedBloodwebNodeProperties Properties; // 0x00(0x18)
	struct TArray<struct FLegacySavedBloodwebNodeGate> Gates; // 0x18(0x10)
	enum class EBloodwebNodeState State; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString nodeID; // 0x30(0x10)
	struct FName ContentId; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FLegacySavedBloodwebChest BloodwebChest; // 0x50(0x30)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodwebChest
// Size: 0x30 (Inherited: 0x00)
struct FLegacySavedBloodwebChest {
	struct FName ID; // 0x00(0x0c)
	struct FName EventId; // 0x0c(0x0c)
	enum class EItemRarity Rarity; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<float> GivenItemRarity; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodwebNodeGate
// Size: 0x20 (Inherited: 0x00)
struct FLegacySavedBloodwebNodeGate {
	struct FName Description; // 0x00(0x0c)
	enum class EItemRarity Rarity; // 0x0c(0x01)
	enum class EPlayerRole Role; // 0x0d(0x01)
	enum class EBloodwebNodeGateTypes GateType; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
	struct FString Param; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.LegacySavedBloodwebNodeProperties
// Size: 0x18 (Inherited: 0x00)
struct FLegacySavedBloodwebNodeProperties {
	enum class EBloodwebNodeContentType ContentType; // 0x00(0x01)
	enum class EItemRarity Rarity; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FString> Tags; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.LegacyPlayerSavedProfileDataShared
// Size: 0x40 (Inherited: 0x00)
struct FLegacyPlayerSavedProfileDataShared {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString PlayerName; // 0x08(0x10)
	int32_t SelectedCamperIndex; // 0x18(0x04)
	int32_t SelectedSlasherIndex; // 0x1c(0x04)
	struct TArray<struct FName> SelectedCharacterCustomization; // 0x20(0x10)
	int32_t SlasherSkulls; // 0x30(0x04)
	int32_t CamperSkulls; // 0x34(0x04)
	int32_t CamperStreak; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct DeadByDaylight.TypeFoliageToAutomateDensity
// Size: 0x68 (Inherited: 0x00)
struct FTypeFoliageToAutomateDensity {
	struct TSoftObjectPtr<struct UStaticMesh> SourceMesh; // 0x00(0x30)
	struct TSoftObjectPtr<struct UStaticMesh> ReplacementMesh; // 0x30(0x30)
	bool bGenerateOverlaps; // 0x60(0x01)
	bool bReceiveDecals; // 0x61(0x01)
	enum class ECanBeCharacterBase bCanCharacterStepOn; // 0x62(0x01)
	enum class EDetailMode DetailMode; // 0x63(0x01)
	float MinimumFoliageRadius; // 0x64(0x04)
};

// ScriptStruct DeadByDaylight.OutlineConfiguration
// Size: 0x20 (Inherited: 0x00)
struct FOutlineConfiguration {
	struct TArray<struct UMaterialInterface*> TranslucencyMaterials; // 0x00(0x10)
	struct TArray<struct UMaterialInterface*> LocallyControlledTranslucencyMaterials; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.OutlineColourConfiguration
// Size: 0x10 (Inherited: 0x00)
struct FOutlineColourConfiguration {
	struct FLinearColor ColourValue; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.DBDOutlineRenderStrategySelector
// Size: 0x10 (Inherited: 0x00)
struct FDBDOutlineRenderStrategySelector {
	struct AActor* _actorForStrategy; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.PlayerPersistentData
// Size: 0x710 (Inherited: 0x00)
struct FPlayerPersistentData {
	enum class EPlayerRole GameRole; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FPlayerLoadoutData StartingLoadout; // 0x08(0x98)
	struct FPlayerLoadoutData CurrentLoadout; // 0xa0(0x98)
	char pad_138[0x98]; // 0x138(0x98)
	struct FDailyRitualInstance CachedAvailableRitual; // 0x1d0(0x78)
	struct FPlayerSavedProfileData SavedData; // 0x248(0x488)
	enum class EPlatformFlag PlayerPlatform; // 0x6d0(0x04)
	enum class EProviderFlag PlayerProvider; // 0x6d4(0x04)
	uint32_t _playerId; // 0x6d8(0x04)
	char pad_6DC[0x14]; // 0x6dc(0x14)
	struct FString _contentVersion; // 0x6f0(0x10)
	struct FDateTime _startSessionTime; // 0x700(0x08)
	char pad_708[0x8]; // 0x708(0x08)
};

// ScriptStruct DeadByDaylight.PlayerSavedProfileData
// Size: 0x488 (Inherited: 0x00)
struct FPlayerSavedProfileData {
	struct FString PlayerUID; // 0x00(0x10)
	struct FPlayerSavedProfileDataShared SharedData; // 0x10(0x50)
	struct FPlayerSavedProfileDataLocal LocalData; // 0x60(0x3b8)
	struct FConsoleUserSettings ConsoleUserSettings; // 0x418(0x70)
};

// ScriptStruct DeadByDaylight.ConsoleUserSettings
// Size: 0x70 (Inherited: 0x00)
struct FConsoleUserSettings {
	struct TArray<struct FInputActionKeyMapping> ActionMappings; // 0x00(0x10)
	struct TArray<struct FInputAxisKeyMapping> AxisMappings; // 0x10(0x10)
	int32_t MenuScaleFactor; // 0x20(0x04)
	int32_t HudScaleFactor; // 0x24(0x04)
	int32_t SkillCheckScaleFactor; // 0x28(0x04)
	int32_t MainVolume; // 0x2c(0x04)
	int32_t MenuMusicVolume; // 0x30(0x04)
	bool UseHeadphones; // 0x34(0x01)
	bool MuteOnFocusLost; // 0x35(0x01)
	char pad_36[0x2]; // 0x36(0x02)
	int32_t KillerMouseSensitivity; // 0x38(0x04)
	int32_t SurvivorMouseSensitivity; // 0x3c(0x04)
	int32_t KillerControllerSensitivity; // 0x40(0x04)
	int32_t SurvivorControllerSensitivity; // 0x44(0x04)
	bool InvertY; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32_t HighestWeightSeenNews; // 0x4c(0x04)
	bool HasAcceptedCrossplayPopup; // 0x50(0x01)
	bool HasAcceptedCrossProgressionPopup; // 0x51(0x01)
	char pad_52[0x6]; // 0x52(0x06)
	struct FString PartyPrivacyState; // 0x58(0x10)
	int32_t ColorBlindMode; // 0x68(0x04)
	int32_t ColorBlindModeIntensity; // 0x6c(0x04)
};

// ScriptStruct DeadByDaylight.PlayerSavedProfileDataLocal
// Size: 0x3b8 (Inherited: 0x00)
struct FPlayerSavedProfileDataLocal {
	int32_t Tokens; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FName> offerings; // 0x08(0x10)
	struct TMap<struct FName, bool> PageVisited; // 0x18(0x50)
	struct TMap<struct FName, bool> ChatVisible; // 0x68(0x50)
	struct TMap<struct FName, bool> OnBoardingCompleted; // 0xb8(0x50)
	int32_t ConsecutiveMatchStreak; // 0x108(0x04)
	int32_t Wins; // 0x10c(0x04)
	int32_t Losses; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	uint64_t CurrentSeasonTicks; // 0x118(0x08)
	struct FDailyRitualContainer DailyRituals; // 0x120(0x28)
	struct FFearMarketOfferingInstance FearMarket; // 0x148(0x20)
	struct FPlayerLoadoutData LastConnectedLoadout; // 0x168(0x98)
	int32_t LastConnectedCharacterIndex; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
	struct FDateTime DisconnectPenaltyTime; // 0x208(0x08)
	struct FDateTime LastMatchEndTime; // 0x210(0x08)
	struct FDateTime LastMatchStartTime; // 0x218(0x08)
	struct FDateTime LastKillerMatchEndTime; // 0x220(0x08)
	struct FDateTime LastSurvivorMatchEndTime; // 0x228(0x08)
	struct FBloodWebPersistentData BloodStoreKillers; // 0x230(0x40)
	struct FBloodWebPersistentData BloodStoreSurvivors; // 0x270(0x40)
	bool CrossplayAllowed; // 0x2b0(0x01)
	bool AutoDeclineFriendInvites; // 0x2b1(0x01)
	char pad_2B2[0x6]; // 0x2b2(0x06)
	struct FDateTime _ongoingGameTime; // 0x2b8(0x08)
	struct FPlayerSavedProfileCumulativeData _cumulativeData; // 0x2c0(0x38)
	struct TArray<struct FSavedStatsData> _savedPlayerStats; // 0x2f8(0x10)
	bool _hasBeenGivenKillerTutorialEndReward; // 0x308(0x01)
	bool _hasBeenGivenSurvivorTutorialEndReward; // 0x309(0x01)
	char pad_30A[0x6]; // 0x30a(0x06)
	struct TMap<int32_t, struct FCharacterSavedProfileData> _characterData; // 0x310(0x50)
	struct TMap<struct FName, struct FSpecialEventSavedData> _specialEvent; // 0x360(0x50)
	bool _hasBeginnerTooltipsBeenDisabledAtLevel; // 0x3b0(0x01)
	char pad_3B1[0x7]; // 0x3b1(0x07)
};

// ScriptStruct DeadByDaylight.SpecialEventSavedData
// Size: 0x18 (Inherited: 0x00)
struct FSpecialEventSavedData {
	struct TArray<int32_t> SeenCinematics; // 0x00(0x10)
	bool EventEntryScreenOpened; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct DeadByDaylight.PlayerSavedProfileCumulativeData
// Size: 0x38 (Inherited: 0x00)
struct FPlayerSavedProfileCumulativeData {
	bool FirstTimePlaying; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t CumulativeMatches; // 0x04(0x04)
	int32_t CumulativeMatchesAsSurvivor; // 0x08(0x04)
	int32_t CumulativeMatchesAsKiller; // 0x0c(0x04)
	int32_t CumulativeMatchesAsSurvivorNoFriends; // 0x10(0x04)
	int32_t CumulativeMatchesAsKillerNoFriends; // 0x14(0x04)
	struct FDateTime LastMatchTimestamp; // 0x18(0x08)
	struct FDateTime LastSessionTimestamp; // 0x20(0x08)
	int32_t CumulativeSessions; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FTimespan CumulativePlaytime; // 0x30(0x08)
};

// ScriptStruct DeadByDaylight.PlayerSavedProfileDataShared
// Size: 0x50 (Inherited: 0x00)
struct FPlayerSavedProfileDataShared {
	struct FString PlayerName; // 0x00(0x10)
	int32_t SelectedCamperIndex; // 0x10(0x04)
	int32_t SelectedSlasherIndex; // 0x14(0x04)
	struct TArray<struct FName> SelectedCharacterCustomization; // 0x18(0x10)
	struct TArray<struct FCharmIdSlot> SelectedCharacterCharms; // 0x28(0x10)
	int32_t CamperStreak; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString PlatformId; // 0x40(0x10)
};

// ScriptStruct DeadByDaylight.GamePersistentData
// Size: 0xf0 (Inherited: 0x00)
struct FGamePersistentData {
	int32_t PlayerCount; // 0x00(0x04)
	int32_t spectatorCount; // 0x04(0x04)
	struct FGamePresetData GamePresetData; // 0x08(0x78)
	char pad_80[0x70]; // 0x80(0x70)
};

// ScriptStruct DeadByDaylight.SessionInfos
// Size: 0x48 (Inherited: 0x00)
struct FSessionInfos {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct DeadByDaylight.CloudInventoryItem
// Size: 0x10 (Inherited: 0x00)
struct FCloudInventoryItem {
	int32_t DefinitionId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	uint64_t InstanceId; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.LookInputScalingData
// Size: 0x80 (Inherited: 0x00)
struct FLookInputScalingData {
	char pad_0[0x80]; // 0x00(0x80)
};

// ScriptStruct DeadByDaylight.LookInputAxisScalingData
// Size: 0x40 (Inherited: 0x00)
struct FLookInputAxisScalingData {
	struct FDBDTimer ScalingTimer; // 0x00(0x28)
	char pad_28[0x18]; // 0x28(0x18)
};

// ScriptStruct DeadByDaylight.CharacterStateData
// Size: 0x20 (Inherited: 0x00)
struct FCharacterStateData {
	int32_t _pips; // 0x00(0x04)
	struct FName _powerId; // 0x04(0x0c)
	struct TArray<struct FName> _addonIds; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.PlayerDataSync
// Size: 0x78 (Inherited: 0x00)
struct FPlayerDataSync {
	struct FPlayerStateData PlayerData; // 0x00(0x38)
	struct TArray<struct FName> CustomizationMesh; // 0x38(0x10)
	struct TArray<struct FCharmIdSlot> customizationCharms; // 0x48(0x10)
	struct FName EquipedItemId; // 0x58(0x0c)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FName> EquipedItemAddonIds; // 0x68(0x10)
};

// ScriptStruct DeadByDaylight.PlayerStateData
// Size: 0x38 (Inherited: 0x00)
struct FPlayerStateData {
	int32_t CharacterLevel; // 0x00(0x04)
	struct FName EquipedFavorId; // 0x04(0x0c)
	struct TArray<struct FName> EquipedPerkIds; // 0x10(0x10)
	struct TArray<int32_t> EquipedPerkLevels; // 0x20(0x10)
	bool IsLeavingMatch; // 0x30(0x01)
	enum class EGameState _playerGameState; // 0x31(0x01)
	bool _isEscapeHatch; // 0x32(0x01)
	char pad_33[0x1]; // 0x33(0x01)
	int32_t _prestigeLevel; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.PlayerHUDInfos
// Size: 0x60 (Inherited: 0x08)
struct FPlayerHUDInfos : FDBDTableRowBase {
	enum class EPlayerRole Role; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	SoftClassProperty HUDClass; // 0x10(0x30)
	struct FSoftObjectPath TouchInterfaceName; // 0x40(0x20)
};

// ScriptStruct DeadByDaylight.AttackSubstateRequestResult
// Size: 0x03 (Inherited: 0x00)
struct FAttackSubstateRequestResult {
	bool IsValid; // 0x00(0x01)
	enum class EAttackSubstate RequestedNextSubstate; // 0x01(0x01)
	enum class EAttackSubstate ServerNextSubstate; // 0x02(0x01)
};

// ScriptStruct DeadByDaylight.RankResetStartingPips
// Size: 0x04 (Inherited: 0x00)
struct FRankResetStartingPips {
	int32_t NewPipAmount; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.RankGroupDefinition
// Size: 0x18 (Inherited: 0x00)
struct FRankGroupDefinition {
	int32_t RankThreshold; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<float> PipThresholds; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.RankDefinition
// Size: 0x04 (Inherited: 0x00)
struct FRankDefinition {
	int32_t PipsRequired; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.SaveDataV7
// Size: 0x380 (Inherited: 0x10)
struct FSaveDataV7 : FSaveDataBase {
	struct FString PlayerUID; // 0x10(0x10)
	int32_t SelectedCamperIndex; // 0x20(0x04)
	int32_t SelectedSlasherIndex; // 0x24(0x04)
	struct TArray<struct FName> offerings; // 0x28(0x10)
	bool FirstTimePlaying; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t ConsecutiveMatchStreak; // 0x3c(0x04)
	bool HasBeenGivenKillerTutorialEndReward; // 0x40(0x01)
	bool HasBeenGivenSurvivorTutorialEndReward; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
	uint64_t CurrentSeasonTicks; // 0x48(0x08)
	int32_t LastConnectedCharacterIndex; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct FString DisconnectPenaltyTime; // 0x58(0x10)
	struct FString LastMatchEndTime; // 0x68(0x10)
	struct FString LastMatchStartTime; // 0x78(0x10)
	struct FString LastKillerMatchEndTime; // 0x88(0x10)
	struct FString LastSurvivorMatchEndTime; // 0x98(0x10)
	int32_t Experience; // 0xa8(0x04)
	int32_t BonusExperience; // 0xac(0x04)
	int32_t FearTokens; // 0xb0(0x04)
	bool FearTokensMigrated; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct FString OngoingGameTime; // 0xb8(0x10)
	int32_t CumulativeMatches; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TArray<struct FKeyTupleBool> PageVisited; // 0xd0(0x10)
	struct TArray<struct FKeyTupleBool> ChatVisible; // 0xe0(0x10)
	int32_t CumulativeMatchesAsSurvivor; // 0xf0(0x04)
	int32_t CumulativeMatchesAsKiller; // 0xf4(0x04)
	struct FDateTime LastMatchTimestamp; // 0xf8(0x08)
	struct FDateTime LastSessionTimestamp; // 0x100(0x08)
	int32_t CumulativeSessions; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct FString CumulativePlaytime; // 0x110(0x10)
	struct TArray<struct FCharacterKeyTuple> CharacterData; // 0x120(0x10)
	struct TArray<struct FName> OwnedCharms; // 0x130(0x10)
	struct FSavedDailyRitualContainerV7 DailyRituals; // 0x140(0x40)
	struct FSavedFearMarketOfferingInstanceV7 FearMarket; // 0x180(0x30)
	struct FLegacySavedPlayerLoadoutData LastLoadout; // 0x1b0(0x98)
	struct FConsoleUserSettings ConsoleUserSettings; // 0x248(0x70)
	struct TArray<struct FSavedStatsDataV7> PlayerStatProgression; // 0x2b8(0x10)
	struct TArray<struct FString> OwnedContent; // 0x2c8(0x10)
	struct TArray<struct FSavedSpecialEventDataV7> SpecialEvent; // 0x2d8(0x10)
	struct FLegacySavedBloodWebPersistentData BloodStoreKillers; // 0x2e8(0x40)
	struct FLegacySavedBloodWebPersistentData BloodStoreSurvivors; // 0x328(0x40)
	struct TArray<struct FKeyTupleBool> OnBoardingCompleted; // 0x368(0x10)
	bool IsCrossplayAllowed; // 0x378(0x01)
	bool AutoDeclineFriendInvites; // 0x379(0x01)
	char pad_37A[0x6]; // 0x37a(0x06)
};

// ScriptStruct DeadByDaylight.KeyTupleBool
// Size: 0x10 (Inherited: 0x00)
struct FKeyTupleBool {
	struct FName Key; // 0x00(0x0c)
	bool value; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct DeadByDaylight.SavedSpecialEventDataV7
// Size: 0x28 (Inherited: 0x00)
struct FSavedSpecialEventDataV7 {
	struct FName EventId; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<int32_t> SeenCinematics; // 0x10(0x10)
	bool EventEntryScreenOpened; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DeadByDaylight.SavedStatsDataV7
// Size: 0x10 (Inherited: 0x00)
struct FSavedStatsDataV7 {
	struct FName Name; // 0x00(0x0c)
	float value; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.SavedFearMarketOfferingInstanceV7
// Size: 0x30 (Inherited: 0x00)
struct FSavedFearMarketOfferingInstanceV7 {
	struct TArray<struct FLegacySavedFearMarketItemInstance> ObjectsForSale; // 0x00(0x10)
	struct FString StartTime; // 0x10(0x10)
	struct FString EndTime; // 0x20(0x10)
};

// ScriptStruct DeadByDaylight.SavedDailyRitualContainerV7
// Size: 0x40 (Inherited: 0x00)
struct FSavedDailyRitualContainerV7 {
	struct FString LastRitualReceivedDate; // 0x00(0x10)
	struct FString LastRitualPopupDate; // 0x10(0x10)
	struct FString LastRitualDismissedDate; // 0x20(0x10)
	struct TArray<struct FLegacySavedDailyRitualInstance> Rituals; // 0x30(0x10)
};

// ScriptStruct DeadByDaylight.CharacterKeyTuple
// Size: 0x160 (Inherited: 0x00)
struct FCharacterKeyTuple {
	int32_t Key; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FCharacterSavedProfileDataV7 Data; // 0x08(0x158)
};

// ScriptStruct DeadByDaylight.CharacterSavedProfileDataV7
// Size: 0x158 (Inherited: 0x00)
struct FCharacterSavedProfileDataV7 {
	int32_t BloodWebLevel; // 0x00(0x04)
	int32_t PrestigeLevel; // 0x04(0x04)
	int32_t CharacterExperience; // 0x08(0x04)
	int32_t TimesConfronted; // 0x0c(0x04)
	struct TArray<struct FString> PrestigeDates; // 0x10(0x10)
	struct FLegacySavedBloodWebPersistentData BloodWebData; // 0x20(0x40)
	struct FLegacySavedPlayerLoadoutData CharacterLoadoutData; // 0x60(0x98)
	struct TArray<struct FCharacterSavedInventoryDataV7> Inventory; // 0xf8(0x10)
	struct TArray<struct FSavedCharacterLevelDataV7> CharacterProgression; // 0x108(0x10)
	struct TArray<struct FSavedStatsDataV7> StatProgression; // 0x118(0x10)
	struct TArray<struct FName> CurrentCustomization; // 0x128(0x10)
	struct TArray<struct FSavedCharmSlotData> CurrentCharmCustomization; // 0x138(0x10)
	struct TArray<struct FName> UniquePerksAdded; // 0x148(0x10)
};

// ScriptStruct DeadByDaylight.SavedCharmSlotData
// Size: 0x10 (Inherited: 0x00)
struct FSavedCharmSlotData {
	int8_t SlotIndex; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName CharmId; // 0x04(0x0c)
};

// ScriptStruct DeadByDaylight.SavedCharacterLevelDataV7
// Size: 0x18 (Inherited: 0x00)
struct FSavedCharacterLevelDataV7 {
	int32_t Level; // 0x00(0x04)
	bool HasPerksBeenSelected; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct TArray<struct FAssignedPerkPropertiesV7> PerkSelection; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.AssignedPerkPropertiesV7
// Size: 0x14 (Inherited: 0x00)
struct FAssignedPerkPropertiesV7 {
	struct FName PerkId; // 0x00(0x0c)
	int32_t PerkLevel; // 0x0c(0x04)
	bool IsTeachable; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
};

// ScriptStruct DeadByDaylight.CharacterSavedInventoryDataV7
// Size: 0x20 (Inherited: 0x00)
struct FCharacterSavedInventoryDataV7 {
	struct FName ID; // 0x00(0x0c)
	int32_t Num; // 0x0c(0x04)
	struct FString I; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.SaveDataV8
// Size: 0x370 (Inherited: 0x10)
struct FSaveDataV8 : FSaveDataBase {
	struct FString PlayerUID; // 0x10(0x10)
	int32_t SelectedCamperIndex; // 0x20(0x04)
	int32_t SelectedSlasherIndex; // 0x24(0x04)
	struct TArray<struct FName> offerings; // 0x28(0x10)
	bool FirstTimePlaying; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t ConsecutiveMatchStreak; // 0x3c(0x04)
	bool HasBeenGivenKillerTutorialEndReward; // 0x40(0x01)
	bool HasBeenGivenSurvivorTutorialEndReward; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
	uint64_t CurrentSeasonTicks; // 0x48(0x08)
	int32_t LastConnectedCharacterIndex; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct FString DisconnectPenaltyTime; // 0x58(0x10)
	struct FString LastMatchEndTime; // 0x68(0x10)
	struct FString LastMatchStartTime; // 0x78(0x10)
	struct FString LastKillerMatchEndTime; // 0x88(0x10)
	struct FString LastSurvivorMatchEndTime; // 0x98(0x10)
	struct FString OngoingGameTime; // 0xa8(0x10)
	int32_t CumulativeMatches; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct TArray<struct FKeyTupleBool> PageVisited; // 0xc0(0x10)
	struct TArray<struct FKeyTupleBool> ChatVisible; // 0xd0(0x10)
	int32_t CumulativeMatchesAsSurvivor; // 0xe0(0x04)
	int32_t CumulativeMatchesAsKiller; // 0xe4(0x04)
	struct FDateTime LastMatchTimestamp; // 0xe8(0x08)
	struct FDateTime LastSessionTimestamp; // 0xf0(0x08)
	int32_t CumulativeSessions; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct FString CumulativePlaytime; // 0x100(0x10)
	struct TArray<struct FCharacterKeyTuple> CharacterData; // 0x110(0x10)
	struct TArray<struct FName> OwnedCharms; // 0x120(0x10)
	struct FSavedDailyRitualContainerV7 DailyRituals; // 0x130(0x40)
	struct FSavedFearMarketOfferingInstanceV7 FearMarket; // 0x170(0x30)
	struct FLegacySavedPlayerLoadoutData LastLoadout; // 0x1a0(0x98)
	struct FConsoleUserSettings ConsoleUserSettings; // 0x238(0x70)
	struct TArray<struct FSavedStatsDataV7> PlayerStatProgression; // 0x2a8(0x10)
	struct TArray<struct FString> OwnedContent; // 0x2b8(0x10)
	struct TArray<struct FSavedSpecialEventDataV7> SpecialEvent; // 0x2c8(0x10)
	struct FLegacySavedBloodWebPersistentData BloodStoreKillers; // 0x2d8(0x40)
	struct FLegacySavedBloodWebPersistentData BloodStoreSurvivors; // 0x318(0x40)
	struct TArray<struct FKeyTupleBool> OnBoardingCompleted; // 0x358(0x10)
	bool IsCrossplayAllowed; // 0x368(0x01)
	bool AutoDeclineFriendInvites; // 0x369(0x01)
	bool HasBeginnerTooltipsBeenDisabledAtLevel; // 0x36a(0x01)
	char pad_36B[0x5]; // 0x36b(0x05)
};

// ScriptStruct DeadByDaylight.SaveValidationData
// Size: 0x60 (Inherited: 0x00)
struct FSaveValidationData {
	struct FString PlayerUID; // 0x00(0x10)
	struct TMap<int32_t, struct FCharacterValidationData> CharacterData; // 0x10(0x50)
};

// ScriptStruct DeadByDaylight.CharacterValidationData
// Size: 0x08 (Inherited: 0x00)
struct FCharacterValidationData {
	int32_t PrestigeLevel; // 0x00(0x04)
	int32_t BloodWebLevel; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.ScoreValue
// Size: 0x48 (Inherited: 0x08)
struct FScoreValue : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	enum class EDBDScoreCategory Category; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	int32_t BloodpointValue; // 0x18(0x04)
	int32_t MaxBloodpointValue; // 0x1c(0x04)
	struct UCurveFloat* BloodpointDepreciationCurve; // 0x20(0x08)
	float OngoingWaitTime; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FText DisplayName; // 0x30(0x18)
};

// ScriptStruct DeadByDaylight.ScoreCategoryData
// Size: 0x18 (Inherited: 0x08)
struct FScoreCategoryData : FDBDTableRowBase {
	enum class EDBDScoreCategory Category; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t ScoreCap; // 0x0c(0x04)
	int32_t ProgressionCap; // 0x10(0x04)
	int32_t AchievementCap; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.PlayerstateDataCache
// Size: 0x58 (Inherited: 0x00)
struct FPlayerstateDataCache {
	struct TMap<struct FName, struct FAwardedScores> awardedScoresByType; // 0x00(0x50)
	bool IsDataCacheValid; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct DeadByDaylight.AwardedScores
// Size: 0x10 (Inherited: 0x00)
struct FAwardedScores {
	struct TArray<struct FAwardedScore> Array; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.AwardedScore
// Size: 0x10 (Inherited: 0x00)
struct FAwardedScore {
	struct FName ScoreTypeId; // 0x00(0x0c)
	float BloodpointsAwarded; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.UserGameStats
// Size: 0xb0 (Inherited: 0x00)
struct FUserGameStats {
	bool Disconnected; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t FearTokens; // 0x04(0x04)
	int32_t Skulls; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TMap<enum class EDBDScoreCategory, int32_t> BonusBloodpoints; // 0x10(0x50)
	struct TMap<enum class EDBDScoreCategory, int32_t> _bloodpoints; // 0x60(0x50)
};

// ScriptStruct DeadByDaylight.OngoingScoreData
// Size: 0x30 (Inherited: 0x00)
struct FOngoingScoreData {
	enum class EDBDScoreTypes scoreType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag scoreTypeTag; // 0x04(0x0c)
	float TimeSinceScore; // 0x10(0x04)
	float ApplyScoreTimeout; // 0x14(0x04)
	float AccumulatedPercent; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct AActor* Target; // 0x20(0x08)
	struct UObject* CustomObjectParameter; // 0x28(0x08)
};

// ScriptStruct DeadByDaylight.PlayerFloatTuple
// Size: 0x10 (Inherited: 0x00)
struct FPlayerFloatTuple {
	struct ACharacter* Player; // 0x00(0x08)
	float value; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.SurfaceTypeName
// Size: 0x18 (Inherited: 0x08)
struct FSurfaceTypeName : FDBDTableRowBase {
	struct FName Name; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.Toast
// Size: 0xb0 (Inherited: 0x08)
struct FToast : FDBDTableRowBase {
	float DisplayDuration; // 0x08(0x04)
	float lifetime; // 0x0c(0x04)
	struct FText ToastText; // 0x10(0x18)
	struct TMap<enum class EToastInputType, struct FToastButton> ButtonsData; // 0x28(0x50)
	float DelayBeforeInteraction; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TSoftObjectPtr<struct UTexture2D> ToastIcon; // 0x80(0x30)
};

// ScriptStruct DeadByDaylight.ToastButton
// Size: 0x20 (Inherited: 0x00)
struct FToastButton {
	struct FText ButtonText; // 0x00(0x18)
	bool IsRegression; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DeadByDaylight.DedicatedSessionSearchCompletedEventData
// Size: 0x58 (Inherited: 0x00)
struct FDedicatedSessionSearchCompletedEventData {
	struct FString GameLiftSessionId; // 0x00(0x10)
	struct FString MatchID; // 0x10(0x10)
	struct FString FleetId; // 0x20(0x10)
	struct FString IpAddress; // 0x30(0x10)
	int32_t Port; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FString DnsName; // 0x48(0x10)
};

// ScriptStruct DeadByDaylight.GeneratorQueryHandlePair
// Size: 0x28 (Inherited: 0x00)
struct FGeneratorQueryHandlePair {
	struct AGenerator* Generator; // 0x00(0x08)
	char pad_8[0x20]; // 0x08(0x20)
};

// ScriptStruct DeadByDaylight.DownloadProgression
// Size: 0x30 (Inherited: 0x00)
struct FDownloadProgression {
	float DownloadSize; // 0x00(0x04)
	float TotalDownloadedSize; // 0x04(0x04)
	float DownloadSpeed; // 0x08(0x04)
	float InstallProgress; // 0x0c(0x04)
	bool IsDownloading; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FText DownloadStatus; // 0x18(0x18)
};

// ScriptStruct DeadByDaylight.EffectsLocatorTargets
// Size: 0x08 (Inherited: 0x00)
struct FEffectsLocatorTargets {
	struct AActor* TargetActorClass; // 0x00(0x08)
};

// ScriptStruct DeadByDaylight.EmblemSlotData
// Size: 0x68 (Inherited: 0x00)
struct FEmblemSlotData {
	enum class EEmblemQuality Quality; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	int32_t Score; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FString> IconPaths; // 0x30(0x10)
	struct TArray<int32_t> ThresholdPoints; // 0x40(0x10)
	float CurrentPoints; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TArray<struct FEmblemProgressionData> ProgressionData; // 0x58(0x10)
};

// ScriptStruct DeadByDaylight.EmblemProgressionData
// Size: 0x18 (Inherited: 0x00)
struct FEmblemProgressionData {
	struct FString ProgressionText; // 0x00(0x10)
	float ProgressionPercent; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.EventSubstitionData
// Size: 0x58 (Inherited: 0x00)
struct FEventSubstitionData {
	struct FName _name; // 0x00(0x0c)
	bool _allowSubstitutionInKYF; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	int32_t _baseNumOfSubstitutionPerGroup; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FGameplayElementSubstitutions> _gameplaySubstitutionElements; // 0x18(0x10)
	struct TArray<struct FDependencyElementSubstitutions> _dependencySubstitutionElements; // 0x28(0x10)
	struct TArray<struct FDependencyElementAddition> _dependencyElementAdditions; // 0x38(0x10)
	struct TArray<struct FGameplayElementAddition> _gameplayElementAdditions; // 0x48(0x10)
};

// ScriptStruct DeadByDaylight.GameplayElementAddition
// Size: 0x40 (Inherited: 0x00)
struct FGameplayElementAddition {
	SoftClassProperty _elementToAdd; // 0x00(0x30)
	enum class EGameplayElementType _spawnerType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t _numberToAdd; // 0x34(0x04)
	bool _numberToAddAffectedByOffering; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DeadByDaylight.DependencyElementAddition
// Size: 0x38 (Inherited: 0x00)
struct FDependencyElementAddition {
	SoftClassProperty _object; // 0x00(0x30)
	enum class ETileSpawnPointType _type; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t _numberToAdd; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.ElementSubstitutions
// Size: 0x10 (Inherited: 0x00)
struct FElementSubstitutions {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.DependencyElementSubstitutions
// Size: 0x28 (Inherited: 0x10)
struct FDependencyElementSubstitutions : FElementSubstitutions {
	struct TArray<struct FSubstitutionElements> _replacements; // 0x10(0x10)
	enum class ETileSpawnPointType _type; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DeadByDaylight.SubstitutionElements
// Size: 0x60 (Inherited: 0x00)
struct FSubstitutionElements {
	SoftClassProperty _elementToReplace; // 0x00(0x30)
	SoftClassProperty _elementToReplaceWith; // 0x30(0x30)
};

// ScriptStruct DeadByDaylight.GameplayElementSubstitutions
// Size: 0x28 (Inherited: 0x10)
struct FGameplayElementSubstitutions : FElementSubstitutions {
	struct TArray<struct FSubstitutionElements> _replacements; // 0x10(0x10)
	enum class EGameplayElementType _type; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DeadByDaylight.PathPosition
// Size: 0x18 (Inherited: 0x00)
struct FPathPosition {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DeadByDaylight.FilterLoadoutData
// Size: 0x78 (Inherited: 0x08)
struct FFilterLoadoutData : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x18(0x30)
	struct FText Title; // 0x48(0x18)
	struct TArray<enum class EPlayerRole> Role; // 0x60(0x10)
	enum class ELoadoutType LoadoutType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct DeadByDaylight.FootStep
// Size: 0x28 (Inherited: 0x00)
struct FFootStep {
	struct UDecalComponent* Decal; // 0x00(0x08)
	char pad_8[0x20]; // 0x08(0x20)
};

// ScriptStruct DeadByDaylight.GameEventDispatcherHandleBP
// Size: 0x20 (Inherited: 0x00)
struct FGameEventDispatcherHandleBP {
	struct FGameplayTag Filter; // 0x00(0x0c)
	struct FDelegate GameEventDelegate; // 0x0c(0x14)
};

// ScriptStruct DeadByDaylight.GameNotificationData
// Size: 0x28 (Inherited: 0x08)
struct FGameNotificationData : FDBDTableRowBase {
	enum class EPromptType PromptType; // 0x08(0x01)
	enum class EPromptPriority Priority; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FText Content; // 0x10(0x18)
};

// ScriptStruct DeadByDaylight.NotificationHistoryElement
// Size: 0x18 (Inherited: 0x00)
struct FNotificationHistoryElement {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DeadByDaylight.GameplayNotificationData
// Size: 0x58 (Inherited: 0x00)
struct FGameplayNotificationData {
	struct FName SourceId; // 0x00(0x0c)
	enum class EInventoryItemType SourceType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	int32_t SourceIconIndex; // 0x10(0x04)
	int32_t SourceLevel; // 0x14(0x04)
	struct FName EffectID; // 0x18(0x0c)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString EffectIconFilePath; // 0x28(0x10)
	enum class EStatusEffectType EffectType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FText EffectDisplayName; // 0x40(0x18)
};

// ScriptStruct DeadByDaylight.GarantiedRarityRingDistributionValues
// Size: 0x78 (Inherited: 0x08)
struct FGarantiedRarityRingDistributionValues : FDBDTableRowBase {
	int32_t InnerRingCommonItemProbability; // 0x08(0x04)
	int32_t MiddleRingCommonItemProbability; // 0x0c(0x04)
	int32_t OuterRingCommonItemProbability; // 0x10(0x04)
	int32_t InnerRingUncommonItemProbability; // 0x14(0x04)
	int32_t MiddleRingUncommonItemProbability; // 0x18(0x04)
	int32_t OuterRingUncommonItemProbability; // 0x1c(0x04)
	int32_t InnerRingRareItemProbability; // 0x20(0x04)
	int32_t MiddleRingRareItemProbability; // 0x24(0x04)
	int32_t OuterRingRareItemProbability; // 0x28(0x04)
	int32_t InnerRingVeryRareItemProbability; // 0x2c(0x04)
	int32_t MiddleRingVeryRareItemProbability; // 0x30(0x04)
	int32_t OuterRingVeryRareItemProbability; // 0x34(0x04)
	int32_t InnerRingUltraRareItemProbability; // 0x38(0x04)
	int32_t MiddleRingUltraRareItemProbability; // 0x3c(0x04)
	int32_t OuterRingUltraRareItemProbability; // 0x40(0x04)
	int32_t InnerRingArtifactItemProbability; // 0x44(0x04)
	int32_t MiddleRingArtifactItemProbability; // 0x48(0x04)
	int32_t OuterRingArtifactItemProbability; // 0x4c(0x04)
	int32_t InnerRingSpectralItemProbability; // 0x50(0x04)
	int32_t MiddleRingSpectralItemProbability; // 0x54(0x04)
	int32_t OuterRingSpectralItemProbability; // 0x58(0x04)
	int32_t InnerRingSpecialEventItemProbability; // 0x5c(0x04)
	int32_t MiddleRingSpecialEventItemProbability; // 0x60(0x04)
	int32_t OuterRingSpecialEventItemProbability; // 0x64(0x04)
	int32_t InnerRingLegendaryItemProbability; // 0x68(0x04)
	int32_t MiddleRingLegendaryItemProbability; // 0x6c(0x04)
	int32_t OuterRingLegendaryItemProbability; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// ScriptStruct DeadByDaylight.DamageData
// Size: 0x20 (Inherited: 0x00)
struct FDamageData {
	bool _isRegressing; // 0x00(0x01)
	bool _isIntense; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct TWeakObjectPtr<struct ADBDPlayer> _lastDamageChangeSource; // 0x04(0x08)
	char pad_C[0x14]; // 0x0c(0x14)
};

// ScriptStruct DeadByDaylight.HintData
// Size: 0x60 (Inherited: 0x08)
struct FHintData : FDBDTableRowBase {
	enum class EHintCategory Category; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FText Title; // 0x10(0x18)
	struct FText Description; // 0x28(0x18)
	struct FString IconPath; // 0x40(0x10)
	int32_t levelMin; // 0x50(0x04)
	int32_t levelMax; // 0x54(0x04)
	int32_t relevantCharacterID; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct DeadByDaylight.HitValidationEditorConfig
// Size: 0x18 (Inherited: 0x08)
struct FHitValidationEditorConfig : FTableRowBase {
	enum class EHitValidatorConfigName ConfigName; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float CapsuleInflation; // 0x0c(0x04)
	float MaximumDistance; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.PlayerInfoCache
// Size: 0x38 (Inherited: 0x00)
struct FPlayerInfoCache {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DeadByDaylight.InteractionProficiencyProperties
// Size: 0x80 (Inherited: 0x08)
struct FInteractionProficiencyProperties : FDBDTableRowBase {
	struct FName ProficiencyID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	SoftClassProperty ProficiencyBlueprint; // 0x18(0x30)
	struct TArray<float> BuffLevelThresholds; // 0x48(0x10)
	struct TArray<float> DebuffLevelThresholds; // 0x58(0x10)
	bool HasLevels; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FString IconFilePath; // 0x70(0x10)
};

// ScriptStruct DeadByDaylight.InteractionProficiencyData
// Size: 0x10 (Inherited: 0x00)
struct FInteractionProficiencyData {
	bool IsActive; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Level; // 0x04(0x04)
	enum class EStatusEffectType ProficiencyType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float value; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.InteractionRequest
// Size: 0x18 (Inherited: 0x00)
struct FInteractionRequest {
	struct UInteractionDefinition* _interaction; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct ADBDPlayer* _requester; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.ItemData
// Size: 0x158 (Inherited: 0xd8)
struct FItemData : FBaseItemData {
	struct TSoftObjectPtr<struct USkeletalMesh> ItemMesh; // 0xd8(0x30)
	enum class EItemHandPosition HandPosition; // 0x108(0x01)
	enum class EPlayerRole Role; // 0x109(0x01)
	enum class EItemRarity Rarity; // 0x10a(0x01)
	bool Inventory; // 0x10b(0x01)
	bool Chest; // 0x10c(0x01)
	enum class EKillerAbilities RequiredKillerAbility; // 0x10d(0x01)
	char pad_10E[0x2]; // 0x10e(0x02)
	struct FItemAvailability Availability; // 0x110(0x30)
	bool IsInNonViolentBuild; // 0x140(0x01)
	bool IsAvailableInAtlantaBuild; // 0x141(0x01)
	bool AntiDLC; // 0x142(0x01)
	bool Bloodweb; // 0x143(0x01)
	bool CanKeepInLoadout; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct FName EventId; // 0x148(0x0c)
	enum class ELoadoutItemType ItemType; // 0x154(0x04)
};

// ScriptStruct DeadByDaylight.ItemAddonProperties
// Size: 0x1b0 (Inherited: 0x158)
struct FItemAddonProperties : FItemData {
	SoftClassProperty ItemAddonBlueprint; // 0x158(0x30)
	struct FParentItemIDs parentItem; // 0x188(0x18)
	struct TArray<struct FName> PreLevelGenerationModifierID; // 0x1a0(0x10)
};

// ScriptStruct DeadByDaylight.ParentItemIDs
// Size: 0x18 (Inherited: 0x00)
struct FParentItemIDs {
	bool MatchAnyItemID; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FName> ItemIDs; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.Turn180Settings
// Size: 0x01 (Inherited: 0x00)
struct FTurn180Settings {
	char _settings; // 0x00(0x01)
};

// ScriptStruct DeadByDaylight.KillerSoundCueTracker
// Size: 0x1c (Inherited: 0x00)
struct FKillerSoundCueTracker {
	char pad_0[0x1c]; // 0x00(0x1c)
};

// ScriptStruct DeadByDaylight.ParadiseData
// Size: 0x40 (Inherited: 0x00)
struct FParadiseData {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct DeadByDaylight.LevelReadyToPlayRequirements
// Size: 0x10 (Inherited: 0x00)
struct FLevelReadyToPlayRequirements {
	struct ADBDPlayer* Player; // 0x00(0x08)
	char perkCount; // 0x08(0x01)
	char itemCount; // 0x09(0x01)
	char addonCount; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
};

// ScriptStruct DeadByDaylight.SceneLightingDescription
// Size: 0xd0 (Inherited: 0x00)
struct FSceneLightingDescription {
	struct FName ThemeName; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FLightingSpecifics LightingDetailsLowMedium; // 0x10(0x30)
	struct FLightingSpecifics LightingDetailsHighUltra; // 0x40(0x30)
	struct FLightingSpecifics LightingAtlanta; // 0x70(0x30)
	struct TSoftObjectPtr<struct UTextureCube> TextureCube; // 0xa0(0x30)
};

// ScriptStruct DeadByDaylight.LightingSpecifics
// Size: 0x30 (Inherited: 0x00)
struct FLightingSpecifics {
	SoftClassProperty LightBlueprint; // 0x00(0x30)
};

// ScriptStruct DeadByDaylight.DirectionalHeightFogInterpolationValues
// Size: 0x50 (Inherited: 0x00)
struct FDirectionalHeightFogInterpolationValues {
	float FogDensity; // 0x00(0x04)
	struct FLinearColor FogInscatteringColor; // 0x04(0x10)
	float DirectionalInscatteringExponent; // 0x14(0x04)
	float DirectionalInscatteringStartDistance; // 0x18(0x04)
	struct FLinearColor DirectionalInscatteringColor; // 0x1c(0x10)
	float FogHeightFalloff; // 0x2c(0x04)
	float FogMaxOpacity; // 0x30(0x04)
	float StartDistance; // 0x34(0x04)
	struct TArray<struct FHeightFogGradientEntry> FogGradient; // 0x38(0x10)
	float DistanceUntilFlatFog; // 0x48(0x04)
	float DistanceUntilNoFog; // 0x4c(0x04)
};

// ScriptStruct DeadByDaylight.LoadoutSlotUnlockLevelValue
// Size: 0x10 (Inherited: 0x08)
struct FLoadoutSlotUnlockLevelValue : FDBDTableRowBase {
	enum class ELoadoutSlot LoadoutSlot; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t BloodWebLevel; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.LobbyPlayerData
// Size: 0x58 (Inherited: 0x00)
struct FLobbyPlayerData {
	char pad_0[0x58]; // 0x00(0x58)
};

// ScriptStruct DeadByDaylight.Lock
// Size: 0x08 (Inherited: 0x00)
struct FLock {
	struct TWeakObjectPtr<struct UObject> _lockingObject; // 0x00(0x08)
};

// ScriptStruct DeadByDaylight.KillerClosetActorsTypes
// Size: 0x38 (Inherited: 0x08)
struct FKillerClosetActorsTypes : FDBDTableRowBase {
	SoftClassProperty ClosetActorClass; // 0x08(0x30)
};

// ScriptStruct DeadByDaylight.LoudNoiseIndicatorData
// Size: 0x20 (Inherited: 0x00)
struct FLoudNoiseIndicatorData {
	struct UStaticMeshComponent* MeshMask; // 0x00(0x08)
	struct UStaticMeshComponent* DistortionMesh; // 0x08(0x08)
	struct FVector Location; // 0x10(0x0c)
	float RemainingTime; // 0x1c(0x04)
};

// ScriptStruct DeadByDaylight.MainMenuButtonData
// Size: 0x90 (Inherited: 0x08)
struct FMainMenuButtonData : FDBDTableRowBase {
	enum class EMainMenuButton buttonType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FText Label; // 0x10(0x18)
	struct FText InfoTitle; // 0x28(0x18)
	struct FText InfoDescription; // 0x40(0x18)
	struct FText LockedInfoTitle; // 0x58(0x18)
	struct FText LockedInfoDescription; // 0x70(0x18)
	bool IsDisabled; // 0x88(0x01)
	bool IsLocked; // 0x89(0x01)
	bool IsHidden; // 0x8a(0x01)
	char pad_8B[0x5]; // 0x8b(0x05)
};

// ScriptStruct DeadByDaylight.TileProperties
// Size: 0x78 (Inherited: 0x00)
struct FTileProperties {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct DeadByDaylight.MatchmakingContextData
// Size: 0x04 (Inherited: 0x00)
struct FMatchmakingContextData {
	uint32_t ContextId; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.MenuIndexChangeEventData
// Size: 0x04 (Inherited: 0x00)
struct FMenuIndexChangeEventData {
	int32_t Index; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.MenuRoleChangeEventData
// Size: 0x01 (Inherited: 0x00)
struct FMenuRoleChangeEventData {
	enum class EPlayerRole PlayerRole; // 0x00(0x01)
};

// ScriptStruct DeadByDaylight.GameInfoEventData
// Size: 0x02 (Inherited: 0x00)
struct FGameInfoEventData {
	enum class EPlayerRole PlayerRole; // 0x00(0x01)
	enum class EGameType GameType; // 0x01(0x01)
};

// ScriptStruct DeadByDaylight.MontageInstanceInfo
// Size: 0x30 (Inherited: 0x00)
struct FMontageInstanceInfo {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct DeadByDaylight.NamedButton
// Size: 0x18 (Inherited: 0x00)
struct FNamedButton {
	int32_t ClickCounter; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString DisplayName; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.NodeContentDistributionValue
// Size: 0x60 (Inherited: 0x08)
struct FNodeContentDistributionValue : FDBDTableRowBase {
	int32_t Empty_Weight; // 0x08(0x04)
	int32_t Empty_MinCount; // 0x0c(0x04)
	int32_t Empty_MaxCount; // 0x10(0x04)
	int32_t Perks_Weight; // 0x14(0x04)
	int32_t Perks_MinCount; // 0x18(0x04)
	int32_t Perks_MaxCount; // 0x1c(0x04)
	int32_t PerksPacks_Weight; // 0x20(0x04)
	int32_t PerksPacks_MinCount; // 0x24(0x04)
	int32_t PerksPacks_MaxCount; // 0x28(0x04)
	int32_t Offerings_Weight; // 0x2c(0x04)
	int32_t Offerings_MinCount; // 0x30(0x04)
	int32_t Offerings_MaxCount; // 0x34(0x04)
	int32_t Items_Weight; // 0x38(0x04)
	int32_t Items_MinCount; // 0x3c(0x04)
	int32_t Items_MaxCount; // 0x40(0x04)
	int32_t AddOn_Weight; // 0x44(0x04)
	int32_t AddOn_MinCount; // 0x48(0x04)
	int32_t AddOn_MaxCount; // 0x4c(0x04)
	int32_t Chests_Weight; // 0x50(0x04)
	int32_t Chests_MinCount; // 0x54(0x04)
	int32_t Chests_MaxCount; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct DeadByDaylight.OfferingProperties
// Size: 0x190 (Inherited: 0x158)
struct FOfferingProperties : FItemData {
	enum class EOfferingType OfferingType; // 0x158(0x01)
	bool CanUseAfterEventEnd; // 0x159(0x01)
	char pad_15A[0x6]; // 0x15a(0x06)
	struct TArray<struct FName> Tags; // 0x160(0x10)
	struct TArray<struct FOfferingEffect> Effects; // 0x170(0x10)
	struct FString BigIconFilePath; // 0x180(0x10)
};

// ScriptStruct DeadByDaylight.OfferingEffect
// Size: 0x28 (Inherited: 0x00)
struct FOfferingEffect {
	enum class EOfferingEffectType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FName> Tags; // 0x08(0x10)
	struct FName value; // 0x18(0x0c)
	float Modifier; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.OfferingTypeTexture
// Size: 0x30 (Inherited: 0x00)
struct FOfferingTypeTexture {
	struct FName Type; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FSoftObjectPath TextureBack; // 0x10(0x20)
};

// ScriptStruct DeadByDaylight.RarityTexture
// Size: 0x30 (Inherited: 0x00)
struct FRarityTexture {
	struct FName Type; // 0x00(0x0c)
	enum class EItemRarity Rarity; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FSoftObjectPath Texture; // 0x10(0x20)
};

// ScriptStruct DeadByDaylight.OfferingRevealDelays
// Size: 0x08 (Inherited: 0x00)
struct FOfferingRevealDelays {
	enum class EOfferingSequenceState RevealState; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Delay; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.OfferingTriggerPositionData
// Size: 0x0c (Inherited: 0x00)
struct FOfferingTriggerPositionData {
	int32_t Index; // 0x00(0x04)
	float PosX; // 0x04(0x04)
	float PosY; // 0x08(0x04)
};

// ScriptStruct DeadByDaylight.DBDQueueTimeInfo
// Size: 0x18 (Inherited: 0x00)
struct FDBDQueueTimeInfo {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DeadByDaylight.DBDConnectionStatus
// Size: 0x10 (Inherited: 0x00)
struct FDBDConnectionStatus {
	char pad_0[0x8]; // 0x00(0x08)
	struct UDBDGameInstance* _gameInstance; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.DBDSearchParams
// Size: 0x80 (Inherited: 0x00)
struct FDBDSearchParams {
	char pad_0[0x80]; // 0x00(0x80)
};

// ScriptStruct DeadByDaylight.DBDJoinParams
// Size: 0x01 (Inherited: 0x00)
struct FDBDJoinParams {
	enum class EGameType GameType; // 0x00(0x01)
};

// ScriptStruct DeadByDaylight.OutfitData
// Size: 0x108 (Inherited: 0x08)
struct FOutfitData : FDBDTableRowBase {
	struct FName ID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FItemUIData UIData; // 0x18(0x78)
	struct FItemAvailability Availability; // 0x90(0x30)
	struct TArray<struct FName> OutfitItems; // 0xc0(0x10)
	struct FText CollectionName; // 0xd0(0x18)
	struct FText CollectionDescription; // 0xe8(0x18)
	bool IsAvailableInAtlantaBuild; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// ScriptStruct DeadByDaylight.OutfitDropdown
// Size: 0x14 (Inherited: 0x08)
struct FOutfitDropdown : FCharacterDropdown {
	struct FName OutfitId; // 0x08(0x0c)
};

// ScriptStruct DeadByDaylight.SurvivorInfoData
// Size: 0x38 (Inherited: 0x00)
struct FSurvivorInfoData {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DeadByDaylight.PalletPushSettings
// Size: 0x02 (Inherited: 0x00)
struct FPalletPushSettings {
	bool IgnorePlayerExecutingPulldown; // 0x00(0x01)
	enum class EPalletPushSideStrategy PalletPushSideStrategy; // 0x01(0x01)
};

// ScriptStruct DeadByDaylight.PartyMemberUIData
// Size: 0x30 (Inherited: 0x00)
struct FPartyMemberUIData {
	bool _isLocalPlayer; // 0x00(0x01)
	bool _isReady; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FString _mirrorId; // 0x08(0x10)
	struct FString _playerName; // 0x18(0x10)
	int32_t _playerId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DeadByDaylight.PerkProperties
// Size: 0x278 (Inherited: 0x158)
struct FPerkProperties : FItemData {
	struct TArray<struct FName> Tags; // 0x158(0x10)
	struct TArray<struct FOfferingEffect> Effects; // 0x168(0x10)
	int32_t AssociatedPlayerIndex; // 0x178(0x04)
	int32_t MandatoryOnBloodweblevel; // 0x17c(0x04)
	int32_t TeachableOnBloodweblevel; // 0x180(0x04)
	int32_t AtlantaTeachableLevel; // 0x184(0x04)
	struct TArray<enum class EPerkCategory> PerkCategory; // 0x188(0x10)
	SoftClassProperty PerkBlueprint; // 0x198(0x30)
	struct TArray<enum class EItemRarity> PerkLevelRarity; // 0x1c8(0x10)
	struct FText PerkDefaultDescription; // 0x1d8(0x18)
	struct TArray<struct FPerkLevelText> PerkLevelTunables; // 0x1f0(0x10)
	struct FText PerkLevel1Description; // 0x200(0x18)
	struct FText PerkLevel2Description; // 0x218(0x18)
	struct FText PerkLevel3Description; // 0x230(0x18)
	struct TArray<struct FString> AtlantaActivatableInteractionIDs; // 0x248(0x10)
	uint32_t PlatformsForPerkUnlicensedDescriptionOverride; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FText PerkUnlicensedDescriptionOverride; // 0x260(0x18)
};

// ScriptStruct DeadByDaylight.PerkLevelText
// Size: 0x28 (Inherited: 0x00)
struct FPerkLevelText {
	struct TArray<struct FString> Tunables; // 0x00(0x10)
	struct FText TextOverride; // 0x10(0x18)
};

// ScriptStruct DeadByDaylight.PlatformDlcData
// Size: 0xd8 (Inherited: 0x08)
struct FPlatformDlcData : FDBDTableRowBase {
	struct FString ID; // 0x08(0x10)
	struct FText UnlockDescription; // 0x18(0x18)
	struct FString Description; // 0x30(0x10)
	int32_t UISortOrder; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FString DlcIdSteam; // 0x48(0x10)
	struct FString DlcIdDmm; // 0x58(0x10)
	struct FString DlcIdPS4; // 0x68(0x10)
	struct FString DlcIdXB1; // 0x78(0x10)
	struct FString DlcIdXSX; // 0x88(0x10)
	struct FString DlcIdSwitch; // 0x98(0x10)
	struct FString DlcIdGRDK; // 0xa8(0x10)
	struct FString DlcIdPS5; // 0xb8(0x10)
	struct FString DlcIdStadia; // 0xc8(0x10)
};

// ScriptStruct DeadByDaylight.PlayerLevelData
// Size: 0x0c (Inherited: 0x00)
struct FPlayerLevelData {
	int32_t LevelValue; // 0x00(0x04)
	int32_t PrestigeValue; // 0x04(0x04)
	int32_t MaxXp; // 0x08(0x04)
};

// ScriptStruct DeadByDaylight.PlayerReadyStatusData
// Size: 0x08 (Inherited: 0x00)
struct FPlayerReadyStatusData {
	int32_t playerID; // 0x00(0x04)
	bool IsReady; // 0x04(0x01)
	bool IsSlasher; // 0x05(0x01)
	bool IsLocalPlayer; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
};

// ScriptStruct DeadByDaylight.PlayerRoundStartEventData
// Size: 0x28 (Inherited: 0x00)
struct FPlayerRoundStartEventData {
	enum class EPlayerRole PlayerRole; // 0x00(0x01)
	bool IsABot; // 0x01(0x01)
	enum class EAIDifficultyLevel BotDifficultyLevel; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	int32_t characterId; // 0x04(0x04)
	int32_t PlayerRankForRole; // 0x08(0x04)
	int32_t PrestigeLevel; // 0x0c(0x04)
	int32_t BloodWebLevel; // 0x10(0x04)
	int32_t Pips; // 0x14(0x04)
	struct TArray<struct FPlayerRankData> PlayerRankDataArray; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.PlayerRankData
// Size: 0x18 (Inherited: 0x00)
struct FPlayerRankData {
	struct FString MirrorsId; // 0x00(0x10)
	enum class EPlayerRole PlayerRole; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t PlayerRankForRole; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.PreLevelGenerationModifierProperties
// Size: 0x20 (Inherited: 0x08)
struct FPreLevelGenerationModifierProperties : FDBDTableRowBase {
	struct FName ModifierID; // 0x08(0x0c)
	enum class EPreLevelGenerationModifierType modifierType; // 0x14(0x01)
	enum class EKillerAbilities KillerAbiliy; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	float ModifierValue; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DeadByDaylight.PrestigeIconData
// Size: 0x40 (Inherited: 0x08)
struct FPrestigeIconData : FDBDTableRowBase {
	enum class EPlayerRole PlayerRole; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t PrestigeLevel; // 0x0c(0x04)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x10(0x30)
};

// ScriptStruct DeadByDaylight.ProceduralMap
// Size: 0xc0 (Inherited: 0x08)
struct FProceduralMap : FDBDTableRowBase {
	struct FName MapId; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Name; // 0x18(0x18)
	struct FText ThemeName; // 0x30(0x18)
	struct FText Description; // 0x48(0x18)
	float HookMinDistance; // 0x60(0x04)
	int32_t HookMinCount; // 0x64(0x04)
	int32_t HookMaxCount; // 0x68(0x04)
	float BookShelvesMinDistance; // 0x6c(0x04)
	int32_t BookShelvesMinCount; // 0x70(0x04)
	int32_t BookShelvesMaxCount; // 0x74(0x04)
	int32_t LivingWorldObjectsMinCount; // 0x78(0x04)
	int32_t LivingWorldObjectsMaxCount; // 0x7c(0x04)
	struct FString ThumbnailPath; // 0x80(0x10)
	int32_t SortingIndex; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FString DlcIDString; // 0x98(0x10)
	struct TArray<int32_t> FixedLayoutSeed; // 0xa8(0x10)
	bool IsInNonViolentBuild; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

// ScriptStruct DeadByDaylight.GeneratedLevelData
// Size: 0x2a0 (Inherited: 0x00)
struct FGeneratedLevelData {
	struct FString UsedPaperTileMap; // 0x00(0x10)
	struct FString PremadeMap; // 0x10(0x10)
	int32_t AvailableEscapeCount; // 0x20(0x04)
	int32_t AvailableSurvivorItemCount; // 0x24(0x04)
	enum class ESurvivorGrouping GroupingType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct USceneComponent* KillerSpawnPoint; // 0x30(0x08)
	struct TArray<struct USceneComponent*> SurvivorSpawnPoints; // 0x38(0x10)
	struct TArray<struct USceneComponent*> InteractableElementsSpawnPoints; // 0x48(0x10)
	struct TMap<struct FName, int32_t> SpecialBehaviourRequestCounts; // 0x58(0x50)
	struct TMap<struct FName, struct FArrayOfSceneComponent> SpecialBehaviourSpawnPoints; // 0xa8(0x50)
	struct TArray<struct USceneComponent*> SearchableSpawners; // 0xf8(0x10)
	struct TArray<struct USceneComponent*> HexSpawners; // 0x108(0x10)
	struct TArray<struct USceneComponent*> KillerLairSpawners; // 0x118(0x10)
	struct TArray<struct USceneComponent*> HatchSpawners; // 0x128(0x10)
	struct TArray<struct USceneComponent*> MainBuildingHatchSpawners; // 0x138(0x10)
	struct TArray<struct USceneComponent*> ShackHatchSpawners; // 0x148(0x10)
	struct TArray<struct USceneComponent*> BreakableWallSpawners; // 0x158(0x10)
	struct TArray<struct USceneComponent*> EscapeSpawners; // 0x168(0x10)
	struct FManagedGameplayElementData BookshelfManagedGameplayElementData; // 0x178(0x50)
	struct FManagedGameplayElementData MeatHookManagedGameplayElementData; // 0x1c8(0x50)
	struct TArray<struct FDependency> levelDependencies; // 0x218(0x10)
	struct TArray<struct AActor*> FixedMapTileIds; // 0x228(0x10)
	struct TArray<struct AActor*> FixedMapOrphanSpawners; // 0x238(0x10)
	struct FName SpecialEventId; // 0x248(0x0c)
	bool UseForcedMap; // 0x254(0x01)
	bool UsePremadeMap; // 0x255(0x01)
	char pad_256[0x2]; // 0x256(0x02)
	struct FString GenerationLogs; // 0x258(0x10)
	struct FString GenerationErrors; // 0x268(0x10)
	int32_t GenerationPlayerCount; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
	struct TArray<struct FForceSpawnTileData> ForceSpawnTileData; // 0x280(0x10)
	struct TArray<struct AActor*> LevelLightings; // 0x290(0x10)
};

// ScriptStruct DeadByDaylight.ForceSpawnTileData
// Size: 0x20 (Inherited: 0x00)
struct FForceSpawnTileData {
	struct FString Name; // 0x00(0x10)
	int32_t matrixX; // 0x10(0x04)
	int32_t matrixY; // 0x14(0x04)
	int32_t Rotation; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DeadByDaylight.ManagedGameplayElementData
// Size: 0x50 (Inherited: 0x00)
struct FManagedGameplayElementData {
	char pad_0[0x8]; // 0x00(0x08)
	struct TArray<struct UActorSpawner*> ActivatedSpawners; // 0x08(0x10)
	struct TArray<struct UActorSpawner*> RemovedSpawners; // 0x18(0x10)
	enum class EGameplayElementType PopulationType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float CurrentPopulationCost; // 0x2c(0x04)
	int32_t MaxPopulationCost; // 0x30(0x04)
	int32_t MinPopulationCost; // 0x34(0x04)
	float MapWidth; // 0x38(0x04)
	float MinProximityBetweenElements; // 0x3c(0x04)
	float MinDistSqrBetweenElements; // 0x40(0x04)
	float TileWidth; // 0x44(0x04)
	float FactorToAdjustToWhenOutOfProximity; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DeadByDaylight.ArrayOfSceneComponent
// Size: 0x10 (Inherited: 0x00)
struct FArrayOfSceneComponent {
	struct TArray<struct USceneComponent*> sceneComp; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.QuadrantSpawnTypeProperties
// Size: 0x18 (Inherited: 0x00)
struct FQuadrantSpawnTypeProperties {
	enum class EQuadrantSpawnType QuadrantSpawnType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FSectionLenghtsProperties> SectionLenghts; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.SectionLenghtsProperties
// Size: 0x08 (Inherited: 0x00)
struct FSectionLenghtsProperties {
	enum class EDirection Direction; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Lenght; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.SurvivorItemProperties
// Size: 0x0c (Inherited: 0x00)
struct FSurvivorItemProperties {
	enum class ECollectableCategory Category; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Weight; // 0x04(0x04)
	int32_t MaxPopulation; // 0x08(0x04)
};

// ScriptStruct DeadByDaylight.EscapeTypeObjects
// Size: 0x18 (Inherited: 0x00)
struct FEscapeTypeObjects {
	enum class EscapeStrategyType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<SoftClassProperty> EscapeObjects; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.KillerItemDependencies
// Size: 0x18 (Inherited: 0x00)
struct FKillerItemDependencies {
	enum class EKillerAbilities killerAbility; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FKillerItemProperty> Items; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.KillerItemProperty
// Size: 0x40 (Inherited: 0x00)
struct FKillerItemProperty {
	SoftClassProperty Object; // 0x00(0x30)
	struct UCurveFloat* Population; // 0x30(0x08)
	enum class EGameplayElementType _gameplayElementType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DeadByDaylight.EscapeStrategyProperty
// Size: 0x18 (Inherited: 0x00)
struct FEscapeStrategyProperty {
	enum class EscapeStrategyType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UCurveFloat* Population; // 0x08(0x08)
	float Weight; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.ManagedGameplayElementsPopulation
// Size: 0x48 (Inherited: 0x00)
struct FManagedGameplayElementsPopulation {
	enum class EGameplayElementType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	SoftClassProperty GameplayElementBlueprint; // 0x08(0x30)
	float MinDistance; // 0x38(0x04)
	int32_t MinPopulation; // 0x3c(0x04)
	int32_t MaxPopulation; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct DeadByDaylight.GameplayElementsPopulation
// Size: 0x48 (Inherited: 0x00)
struct FGameplayElementsPopulation {
	enum class EGameplayElementType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	SoftClassProperty GameplayElementBlueprint; // 0x08(0x30)
	int32_t MinPopulation; // 0x38(0x04)
	int32_t MaxPopulation; // 0x3c(0x04)
	int32_t MinGuaranteePopulation; // 0x40(0x04)
	int32_t SpawnPass; // 0x44(0x04)
};

// ScriptStruct DeadByDaylight.SurvivorGroupingProbability
// Size: 0x08 (Inherited: 0x00)
struct FSurvivorGroupingProbability {
	enum class ESurvivorGrouping Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Probability; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.ThemeProperties
// Size: 0xb8 (Inherited: 0x00)
struct FThemeProperties {
	struct FName Name; // 0x00(0x0c)
	struct FName Weather; // 0x0c(0x0c)
	struct FName AudioStateThemes; // 0x18(0x0c)
	struct FName AudioStateWeather; // 0x24(0x0c)
	struct FName AudioGameStartEvent; // 0x30(0x0c)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString TilePath; // 0x40(0x10)
	struct FString MapPath; // 0x50(0x10)
	int32_t ThemeNumber; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FText DisplayName; // 0x68(0x18)
	enum class EThemeColorId ThemeColorId; // 0x80(0x01)
	enum class EOfferingEffectType ThemeSelectionOfferingEffectType; // 0x81(0x01)
	char pad_82[0x6]; // 0x82(0x06)
	struct TArray<struct FGameplayElementSubstitutions> SubstitutionElements; // 0x88(0x10)
	struct FString DlcIDString; // 0x98(0x10)
	struct UBlackboardData* Blackboard; // 0xa8(0x08)
	bool Gesture; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// ScriptStruct DeadByDaylight.QuadrantSpawnCategories
// Size: 0x20 (Inherited: 0x00)
struct FQuadrantSpawnCategories {
	struct FName QuadrantSpawnTag; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FQuadrantSpawnItem> Items; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.QuadrantSpawnItem
// Size: 0x18 (Inherited: 0x00)
struct FQuadrantSpawnItem {
	enum class EQuadrantSpawnType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FWeightedItem> Elements; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.WeightedItem
// Size: 0x38 (Inherited: 0x00)
struct FWeightedItem {
	SoftClassProperty Element; // 0x00(0x30)
	float Weight; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.GenerationParams
// Size: 0x04 (Inherited: 0x00)
struct FGenerationParams {
	int32_t Seed; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.ProfileLoadEventData
// Size: 0x10 (Inherited: 0x00)
struct FProfileLoadEventData {
	bool FirstTimePlaying; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FDateTime Timestamp; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.RankUIData
// Size: 0x68 (Inherited: 0x08)
struct FRankUIData : FDBDTableRowBase {
	int32_t Rank; // 0x08(0x04)
	enum class EPlayerRole PlayerRole; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FSlateColor Color; // 0x10(0x28)
	struct TSoftObjectPtr<struct UTexture2D> Frame; // 0x38(0x30)
};

// ScriptStruct DeadByDaylight.RarityDistributionValue
// Size: 0x18 (Inherited: 0x08)
struct FRarityDistributionValue : FDBDTableRowBase {
	int32_t InnerRing; // 0x08(0x04)
	int32_t MiddleRing; // 0x0c(0x04)
	int32_t OuterRing; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DeadByDaylight.DBDRecentGameplayEvents
// Size: 0x50 (Inherited: 0x00)
struct FDBDRecentGameplayEvents {
	struct TMap<enum class EDBDScoreTypes, struct FDateTime> _recentGameplayEvents; // 0x00(0x50)
};

// ScriptStruct DeadByDaylight.Region
// Size: 0x20 (Inherited: 0x00)
struct FRegion {
	struct FName Region; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString IP; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.RewardItemData
// Size: 0x38 (Inherited: 0x00)
struct FRewardItemData {
	struct FString IconPath; // 0x00(0x10)
	struct FString Title; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	enum class EItemRarity Rarity; // 0x30(0x01)
	enum class EInventoryItemType ItemType; // 0x31(0x01)
	bool IsDuplicate; // 0x32(0x01)
	enum class ECurrencyType CurrencyType; // 0x33(0x01)
	int32_t CurrencyAmount; // 0x34(0x04)
};

// ScriptStruct DeadByDaylight.CharacterCameraTag
// Size: 0x18 (Inherited: 0x00)
struct FCharacterCameraTag {
	struct ACameraActor* Camera; // 0x00(0x08)
	struct TArray<struct FSimpleCharacterDropdown> Characters; // 0x08(0x10)
};

// ScriptStruct DeadByDaylight.SimpleCharacterDropdown
// Size: 0x04 (Inherited: 0x00)
struct FSimpleCharacterDropdown {
	int32_t characterId; // 0x00(0x04)
};

// ScriptStruct DeadByDaylight.SkillCheckDefinition
// Size: 0x24 (Inherited: 0x00)
struct FSkillCheckDefinition {
	float SuccessZoneStart; // 0x00(0x04)
	float SuccessZoneEnd; // 0x04(0x04)
	float BonusZoneLength; // 0x08(0x04)
	float BonusZoneStart; // 0x0c(0x04)
	float ProgressRate; // 0x10(0x04)
	float StartingTickerPosition; // 0x14(0x04)
	bool IsDeactivatedAfterResponse; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float WarningSoundDelay; // 0x1c(0x04)
	bool IsAudioMuted; // 0x20(0x01)
	bool IsJittering; // 0x21(0x01)
	bool IsSuccessZoneMirrorred; // 0x22(0x01)
	bool IsInsane; // 0x23(0x01)
};

// ScriptStruct DeadByDaylight.SkillCheckResponse
// Size: 0x18 (Inherited: 0x00)
struct FSkillCheckResponse {
	float ChargeChange; // 0x00(0x04)
	bool IsTriggeredByInput; // 0x04(0x01)
	bool IsSuccessful; // 0x05(0x01)
	bool IsBonus; // 0x06(0x01)
	bool IsInsane; // 0x07(0x01)
	bool IsTriggeringLoudNoise; // 0x08(0x01)
	enum class ESkillCheckCustomType Type; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct UChargeableInteractionDefinition* Interaction; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.SpawnPopulationHandler
// Size: 0xc8 (Inherited: 0x00)
struct FSpawnPopulationHandler {
	char pad_0[0xb8]; // 0x00(0xb8)
	struct TArray<struct USceneComponent*> _allAvailableSpawners; // 0xb8(0x10)
};

// ScriptStruct DeadByDaylight.SpecialBehaviourPopulation
// Size: 0x60 (Inherited: 0x00)
struct FSpecialBehaviourPopulation {
	struct FName _name; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<enum class EGameplayElementType> _spawnerTypes; // 0x10(0x10)
	struct TArray<enum class ETileSpawnPointType> _spawnPointTypes; // 0x20(0x10)
	SoftClassProperty _actor; // 0x30(0x30)
};

// ScriptStruct DeadByDaylight.SpecialEventData
// Size: 0x148 (Inherited: 0x08)
struct FSpecialEventData : FDBDTableRowBase {
	struct FName EventId; // 0x08(0x0c)
	enum class ECurrencyType CurrencyType; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FText EventName; // 0x18(0x18)
	struct FString EventBannerLabel; // 0x30(0x10)
	bool IsTrackedOnline; // 0x40(0x01)
	bool UseSpecialEventLoadingScreen; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
	struct TArray<struct FSpecialEventObjectiveData> Objectives; // 0x48(0x10)
	struct FColor ObjectOutlineColour; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FString LobbyName; // 0x60(0x10)
	struct FString ShopName; // 0x70(0x10)
	struct FName AudioStateSpecialEvent; // 0x80(0x0c)
	char pad_8C[0x4]; // 0x8c(0x04)
	SoftClassProperty GameplayPlayerComponent; // 0x90(0x30)
	SoftClassProperty GameplayStateComponent; // 0xc0(0x30)
	struct TArray<struct FSpecialEventCinematicData> Cinematics; // 0xf0(0x10)
	enum class ESpecialEventGameMode gameMode; // 0x100(0x01)
	bool UseEventEntryScreen; // 0x101(0x01)
	char pad_102[0x6]; // 0x102(0x06)
	struct FSpecialEventEntryPopupData EventEntryData; // 0x108(0x40)
};

// ScriptStruct DeadByDaylight.SpecialEventEntryPopupData
// Size: 0x40 (Inherited: 0x00)
struct FSpecialEventEntryPopupData {
	struct FText Title; // 0x00(0x18)
	struct FText Description; // 0x18(0x18)
	struct FString ImagePath; // 0x30(0x10)
};

// ScriptStruct DeadByDaylight.SpecialEventCinematicData
// Size: 0x28 (Inherited: 0x00)
struct FSpecialEventCinematicData {
	struct FDateTime StartTime; // 0x00(0x08)
	struct FName VideoThumbnailId; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString VideoIconPath; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.SpecialEventObjectiveData
// Size: 0xe0 (Inherited: 0x00)
struct FSpecialEventObjectiveData {
	struct FName ObjectiveId; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FText Title; // 0x10(0x18)
	struct FText Description; // 0x28(0x18)
	struct FString IconPath; // 0x40(0x10)
	struct FString ObjectiveFrameLabel; // 0x50(0x10)
	struct FText CompletedTitle; // 0x60(0x18)
	struct FText CompletedDescription; // 0x78(0x18)
	struct FName RewardId; // 0x90(0x0c)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct FString LockedRewardGenericIconPath; // 0xa0(0x10)
	struct FString UnlockedRewardGenericIconPath; // 0xb0(0x10)
	enum class EPlayerRole PlayerRole; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FString StatName; // 0xc8(0x10)
	uint32_t Sections; // 0xd8(0x04)
	uint32_t MaxValue; // 0xdc(0x04)
};

// ScriptStruct DeadByDaylight.SpecialEventLoadingTextData
// Size: 0x58 (Inherited: 0x08)
struct FSpecialEventLoadingTextData : FDBDTableRowBase {
	struct FName EventId; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Title; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
	struct FString IconPath; // 0x48(0x10)
};

// ScriptStruct DeadByDaylight.StatusEffectProperties
// Size: 0x1a0 (Inherited: 0x158)
struct FStatusEffectProperties : FItemData {
	struct TArray<struct FName> Tags; // 0x158(0x10)
	SoftClassProperty StatusEffectBlueprint; // 0x168(0x30)
	enum class EStatusEffectType StatusEffectType; // 0x198(0x01)
	enum class EExternalEffectSource ExternalEffectSource; // 0x199(0x01)
	char pad_19A[0x6]; // 0x19a(0x06)
};

// ScriptStruct DeadByDaylight.StatusEffectSlotData
// Size: 0x48 (Inherited: 0x00)
struct FStatusEffectSlotData {
	struct FString ID; // 0x00(0x10)
	struct FString IconFilePath; // 0x10(0x10)
	struct FString DisplayName; // 0x20(0x10)
	struct FString Description; // 0x30(0x10)
	enum class EStatusEffectType StatusEffectType; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32_t Level; // 0x44(0x04)
};

// ScriptStruct DeadByDaylight.StatusViewProperties
// Size: 0xc0 (Inherited: 0x08)
struct FStatusViewProperties : FDBDTableRowBase {
	struct FName StatusViewID; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Description; // 0x18(0x18)
	struct FText DisplayName; // 0x30(0x18)
	SoftClassProperty StatusViewBlueprint; // 0x48(0x30)
	enum class EStatusEffectType StatusType; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FString IconFilePath; // 0x80(0x10)
	struct TSoftObjectPtr<struct UTexture2D> IconAsset; // 0x90(0x30)
};

// ScriptStruct DeadByDaylight.StatusViewSource
// Size: 0x28 (Inherited: 0x00)
struct FStatusViewSource {
	struct FName SourceId; // 0x00(0x0c)
	bool IsActive; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float _remainingTime; // 0x10(0x04)
	float PercentageFill; // 0x14(0x04)
	int32_t Level; // 0x18(0x04)
	enum class EInventoryItemType SourceType; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	int32_t SourceIconIndex; // 0x20(0x04)
	int32_t SourceLevel; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.StoreBannersData
// Size: 0xa0 (Inherited: 0x08)
struct FStoreBannersData : FDBDTableRowBase {
	struct FName BannerId; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FStoreFeaturedBannerData BannerData; // 0x18(0x80)
	bool UseAsDefault; // 0x98(0x01)
	enum class EStoreBannerLocation DefaultLocation; // 0x99(0x01)
	char pad_9A[0x6]; // 0x9a(0x06)
};

// ScriptStruct DeadByDaylight.StoreFeaturedBannerData
// Size: 0x80 (Inherited: 0x00)
struct FStoreFeaturedBannerData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FText Title; // 0x08(0x18)
	struct FText subtitle; // 0x20(0x18)
	struct FString ImagePath; // 0x38(0x10)
	struct FString AssociatedDlcId; // 0x48(0x10)
	struct FString AssociatedCombinedItemId; // 0x58(0x10)
	struct FString AssociatedCombinedOutfitId; // 0x68(0x10)
	enum class ETextBannerPosition TextPosition; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// ScriptStruct DeadByDaylight.StoredInteraction
// Size: 0x60 (Inherited: 0x00)
struct FStoredInteraction {
	struct TWeakObjectPtr<struct UInteractionDefinition> _interaction; // 0x00(0x08)
	enum class EInputInteractionType _inputType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	struct FInteractionPlayerProperties _playerProperties; // 0x0c(0x50)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct DeadByDaylight.StoreFeaturedBannerUIData
// Size: 0x98 (Inherited: 0x00)
struct FStoreFeaturedBannerUIData {
	struct FName BannerId; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FStoreFeaturedBannerData BannerData; // 0x10(0x80)
	bool IsNew; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct DeadByDaylight.SurvivorHookTimer
// Size: 0x38 (Inherited: 0x00)
struct FSurvivorHookTimer {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DeadByDaylight.SurvivorSleepiness
// Size: 0x08 (Inherited: 0x00)
struct FSurvivorSleepiness {
	float _sleepiness; // 0x00(0x04)
	float _sleepThreshold; // 0x04(0x04)
};

// ScriptStruct DeadByDaylight.TallyItemChangedData
// Size: 0x2f0 (Inherited: 0x00)
struct FTallyItemChangedData {
	struct FInventorySlotData item; // 0x00(0xf8)
	struct FInventorySlotData Addon1; // 0xf8(0xf8)
	struct FInventorySlotData Addon2; // 0x1f0(0xf8)
	enum class EEnergyTypeEnum EnergyType; // 0x2e8(0x01)
	char pad_2E9[0x3]; // 0x2e9(0x03)
	float EnergyLevel; // 0x2ec(0x04)
};

// ScriptStruct DeadByDaylight.TallyPlayerResultData
// Size: 0x278 (Inherited: 0x00)
struct FTallyPlayerResultData {
	struct FName CharacterIconPath; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString playerID; // 0x10(0x10)
	struct FString PlatformAccountId; // 0x20(0x10)
	struct FString MirrorsId; // 0x30(0x10)
	struct FString PlayerName; // 0x40(0x10)
	int32_t PlayerScore; // 0x50(0x04)
	int32_t PlayerRank; // 0x54(0x04)
	enum class EGameState PlayerStatus; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FInventorySlotData OfferingData; // 0x60(0xf8)
	struct TArray<struct FInventorySlotData> PerksData; // 0x158(0x10)
	struct FInventorySlotData ItemData; // 0x168(0xf8)
	struct TArray<struct FInventorySlotData> AddonsData; // 0x260(0x10)
	bool IsReported; // 0x270(0x01)
	bool IsSlasher; // 0x271(0x01)
	bool IsMyScore; // 0x272(0x01)
	bool IsOffNetwork; // 0x273(0x01)
	char pad_274[0x4]; // 0x274(0x04)
};

// ScriptStruct DeadByDaylight.TallyScorePipsData
// Size: 0x30 (Inherited: 0x00)
struct FTallyScorePipsData {
	float Threshold; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<float> PipThresholds; // 0x08(0x10)
	struct TArray<struct FEmblemSlotData> Scores; // 0x18(0x10)
	int32_t PipsDelta; // 0x28(0x04)
	bool IsSlasher; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct DeadByDaylight.ArrayOfATile
// Size: 0x10 (Inherited: 0x00)
struct FArrayOfATile {
	struct TArray<struct ATile*> ArrayOfTiles; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.ArrayOfInt32
// Size: 0x10 (Inherited: 0x00)
struct FArrayOfInt32 {
	struct TArray<int32_t> value; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.QuadrantInfo
// Size: 0x20 (Inherited: 0x00)
struct FQuadrantInfo {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct DeadByDaylight.TransactionEventData
// Size: 0x88 (Inherited: 0x00)
struct FTransactionEventData {
	struct FString TransactionType; // 0x00(0x10)
	struct FString TransactionSource; // 0x10(0x10)
	struct FString SourceId; // 0x20(0x10)
	int32_t SourceTier; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString CurrencyType; // 0x38(0x10)
	int32_t CurrencyAmount; // 0x48(0x04)
	int32_t CurrencyBalance; // 0x4c(0x04)
	int32_t LevelAchieved; // 0x50(0x04)
	int32_t Prestige; // 0x54(0x04)
	struct FString ItemIDAcquired; // 0x58(0x10)
	int32_t Rank; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FString SelectedCharacter; // 0x70(0x10)
	bool TransactionTriggeredLevelUp; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct DeadByDaylight.PerPlatformTunable
// Size: 0x20 (Inherited: 0x08)
struct FPerPlatformTunable : FDBDTableRowBase {
	struct FPerPlatformFloat value; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Description; // 0x10(0x10)
};

// ScriptStruct DeadByDaylight.TunableValue
// Size: 0x28 (Inherited: 0x08)
struct FTunableValue : FDBDTunableRowBase {
	float value; // 0x08(0x04)
	float AtlantaOverriddenValue; // 0x0c(0x04)
	struct FString Description; // 0x10(0x10)
	bool OverriddenInAtlanta; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DeadByDaylight.TutorialEndReward
// Size: 0x10 (Inherited: 0x08)
struct FTutorialEndReward : FDBDTableRowBase {
	int32_t BloodpointReward; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DeadByDaylight.TutorialNotificationData
// Size: 0xb0 (Inherited: 0x08)
struct FTutorialNotificationData : FDBDTableRowBase {
	struct FText Title; // 0x08(0x18)
	struct FText Description; // 0x20(0x18)
	struct FString IconPath; // 0x38(0x10)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x48(0x30)
	struct TSoftObjectPtr<struct UTexture2D> Image; // 0x78(0x30)
	bool IsShowAnalyticEnabled; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// ScriptStruct DeadByDaylight.TutorialObjective
// Size: 0x28 (Inherited: 0x08)
struct FTutorialObjective : FDBDTableRowBase {
	struct FText Description; // 0x08(0x18)
	bool IsCompletionAnalyticEnabled; // 0x20(0x01)
	enum class EInteractionPromptType InteractionPromptType; // 0x21(0x01)
	enum class ETutorialObjectivePlayerActionMapping PlayerAction; // 0x22(0x01)
	enum class EInteractionPromptType SecondaryInteractionPromptType; // 0x23(0x01)
	enum class ETutorialObjectivePlayerActionMapping SecondaryPlayerAction; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct DeadByDaylight.CharacterAnimation
// Size: 0x38 (Inherited: 0x00)
struct FCharacterAnimation {
	struct FName Label; // 0x00(0x0c)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FCharacterAnimationDropdown Data; // 0x10(0x28)
};

// ScriptStruct DeadByDaylight.ItemViewSetting
// Size: 0x40 (Inherited: 0x00)
struct FItemViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FItemIdDropdown item; // 0x0c(0x0c)
	struct FScreenshotViewSetting Settings; // 0x18(0x28)
};

// ScriptStruct DeadByDaylight.ScreenshotViewSetting
// Size: 0x28 (Inherited: 0x00)
struct FScreenshotViewSetting {
	float Distance; // 0x00(0x04)
	float LateralOffset; // 0x04(0x04)
	float HeightOffset; // 0x08(0x04)
	float CharacterYaw; // 0x0c(0x04)
	float CharacterRoll; // 0x10(0x04)
	float CharacterPitch; // 0x14(0x04)
	float CameraPitch; // 0x18(0x04)
	struct FName SocketName; // 0x1c(0x0c)
};

// ScriptStruct DeadByDaylight.ItemIdDropdown
// Size: 0x0c (Inherited: 0x00)
struct FItemIdDropdown {
	struct FName ItemId; // 0x00(0x0c)
};

// ScriptStruct DeadByDaylight.CharacterItemCategoryViewSetting
// Size: 0x40 (Inherited: 0x00)
struct FCharacterItemCategoryViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FRoleItemCategoryDropdown CharacterDropdown; // 0x0c(0x0c)
	struct FScreenshotViewSetting Settings; // 0x18(0x28)
};

// ScriptStruct DeadByDaylight.CharmViewSetting
// Size: 0x44 (Inherited: 0x00)
struct FCharmViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FCharmDropdown CharmId; // 0x0c(0x10)
	struct FScreenshotViewSetting Settings; // 0x1c(0x28)
};

// ScriptStruct DeadByDaylight.CharmCategorySetting
// Size: 0x38 (Inherited: 0x00)
struct FCharmCategorySetting {
	struct FName Label; // 0x00(0x0c)
	enum class ECharmCategory CharmCategory; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FScreenshotViewSetting Settings; // 0x10(0x28)
};

// ScriptStruct DeadByDaylight.OutfitViewSetting
// Size: 0x48 (Inherited: 0x00)
struct FOutfitViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FOutfitDropdown OutfitDropdown; // 0x0c(0x14)
	struct FScreenshotViewSetting Settings; // 0x20(0x28)
};

// ScriptStruct DeadByDaylight.CharacterViewSetting
// Size: 0x3c (Inherited: 0x00)
struct FCharacterViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FCharacterDropdown CharacterDropdown; // 0x0c(0x08)
	struct FScreenshotViewSetting Settings; // 0x14(0x28)
};

// ScriptStruct DeadByDaylight.GenderViewSetting
// Size: 0x38 (Inherited: 0x00)
struct FGenderViewSetting {
	struct FRoleItemCategoryDropdown RoleItemCategory; // 0x00(0x0c)
	enum class EGender Gender; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FScreenshotViewSetting Settings; // 0x10(0x28)
};

// ScriptStruct DeadByDaylight.RoleGenderViewSetting
// Size: 0x38 (Inherited: 0x00)
struct FRoleGenderViewSetting {
	struct FName Label; // 0x00(0x0c)
	struct FRoleDropdown RoleDropdown; // 0x0c(0x02)
	enum class EGender Gender; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
	struct FScreenshotViewSetting Settings; // 0x10(0x28)
};

// ScriptStruct DeadByDaylight.FriendWidgetList
// Size: 0x10 (Inherited: 0x00)
struct FFriendWidgetList {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DeadByDaylight.WidgetFriendData
// Size: 0x10 (Inherited: 0x00)
struct FWidgetFriendData {
	char pad_0[0x8]; // 0x00(0x08)
	struct UUMGBaseFriendListElement* correspondingWidget; // 0x08(0x08)
};

// ScriptStruct DeadByDaylight.AtlantaSettingMenuData
// Size: 0x30 (Inherited: 0x08)
struct FAtlantaSettingMenuData : FDBDTableRowBase {
	enum class EOverlayTabs OverlayTab; // 0x08(0x01)
	enum class EOverlayMode OverlayMode; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FText DisplayName; // 0x10(0x18)
	enum class EAtlantaSettingMenuType MenuType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct DeadByDaylight.HtmlTagConvertRow
// Size: 0x28 (Inherited: 0x08)
struct FHtmlTagConvertRow : FTableRowBase {
	struct FString HtmlTag; // 0x08(0x10)
	struct FString RichTextTag; // 0x18(0x10)
};

// ScriptStruct DeadByDaylight.InteractButtonInfo
// Size: 0x58 (Inherited: 0x08)
struct FInteractButtonInfo : FTableRowBase {
	struct FName InteractButtonID; // 0x08(0x0c)
	struct FName InteractionID; // 0x14(0x0c)
	enum class EPlayerRole PlayerRole; // 0x20(0x01)
	enum class EInputInteractionType interactionInputType; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x28(0x30)
};

// ScriptStruct DeadByDaylight.InboxMessageElapsedTime
// Size: 0x08 (Inherited: 0x00)
struct FInboxMessageElapsedTime {
	int32_t ElapsedTime; // 0x00(0x04)
	enum class EInboxMessageTimeUnit TimeUnit; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct DeadByDaylight.InboxMessageUIData
// Size: 0x60 (Inherited: 0x00)
struct FInboxMessageUIData {
	struct FString MessageId; // 0x00(0x10)
	struct FDateTime ReceivedTime; // 0x10(0x08)
	enum class EInboxMessageUIType MessageType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString MessageTitle; // 0x20(0x10)
	struct FString MessageBody; // 0x30(0x10)
	enum class EInboxMessageUIState MessageState; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FClaimableInboxMessage AttachedClaimable; // 0x48(0x18)
};

// ScriptStruct DeadByDaylight.PlayerInfoData
// Size: 0x48 (Inherited: 0x00)
struct FPlayerInfoData {
	struct FString characterName; // 0x00(0x10)
	struct FString CharacterIconPath; // 0x10(0x10)
	struct FString PlayerName; // 0x20(0x10)
	int32_t PlayerLevel; // 0x30(0x04)
	int32_t PrestigeLevel; // 0x34(0x04)
	int32_t PlayerRank; // 0x38(0x04)
	int32_t ActivePips; // 0x3c(0x04)
	int32_t NumPipsToNextRank; // 0x40(0x04)
	bool Ready; // 0x44(0x01)
	bool IsSlasher; // 0x45(0x01)
	bool CanPrestige; // 0x46(0x01)
	char pad_47[0x1]; // 0x47(0x01)
};

// ScriptStruct DeadByDaylight.ScoreCategoryUIExtraData
// Size: 0x28 (Inherited: 0x00)
struct FScoreCategoryUIExtraData {
	struct FText ScoreCategoryName; // 0x00(0x18)
	struct UTexture2D* ScoreCategoryAsset; // 0x18(0x08)
	int32_t ScoreValue; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DeadByDaylight.VariationData
// Size: 0x30 (Inherited: 0x08)
struct FVariationData : FDBDTableRowBase {
	struct FGameplayTag Tag; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText Name; // 0x18(0x18)
};

// ScriptStruct DeadByDaylight.VideoThumbnailProperties
// Size: 0x50 (Inherited: 0x08)
struct FVideoThumbnailProperties : FDBDTableRowBase {
	struct FName _id; // 0x08(0x0c)
	bool _hasAudio; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FVector2D _size; // 0x18(0x08)
	struct TSoftObjectPtr<struct UMediaSource> _source; // 0x20(0x30)
};

// ScriptStruct DeadByDaylight.ArchivesJournal
// Size: 0x40 (Inherited: 0x18)
struct FArchivesJournal : FDBDTableRowBaseWithId {
	struct FText Title; // 0x18(0x18)
	struct TArray<struct FArchivesVignettes> Vignettes; // 0x30(0x10)
};

// ScriptStruct DeadByDaylight.ArchivesVignettes
// Size: 0x68 (Inherited: 0x08)
struct FArchivesVignettes : FDBDTableRowBase {
	struct FString VignetteId; // 0x08(0x10)
	struct FText Title; // 0x18(0x18)
	struct FText subtitle; // 0x30(0x18)
	struct TArray<struct FArchivesVignetteEntry> Entries; // 0x48(0x10)
	struct TArray<struct TSoftObjectPtr<struct UMediaSource>> CinematicPaths; // 0x58(0x10)
};

// ScriptStruct DeadByDaylight.ArchivesVignetteEntry
// Size: 0x40 (Inherited: 0x08)
struct FArchivesVignetteEntry : FDBDTableRowBase {
	struct FText Title; // 0x08(0x18)
	struct FText Text; // 0x20(0x18)
	bool HasAudio; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DeadByDaylight.WalesCypherEventData
// Size: 0x30 (Inherited: 0x00)
struct FWalesCypherEventData {
	struct FString EnteredSequence; // 0x00(0x10)
	struct FString ExpectedSequence; // 0x10(0x10)
	int32_t TimeoutThreshold; // 0x20(0x04)
	bool success; // 0x24(0x01)
	bool TIMEOUT; // 0x25(0x01)
	bool CharmGranted; // 0x26(0x01)
	char pad_27[0x1]; // 0x27(0x01)
	int32_t ValidCharacterSelcted; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DeadByDaylight.WalletUpdateTracker
// Size: 0x50 (Inherited: 0x00)
struct FWalletUpdateTracker {
	struct TMap<struct FString, int32_t> _walletChangeMap; // 0x00(0x50)
};

// ScriptStruct DeadByDaylight.NativeBlockIndicatorData
// Size: 0x18 (Inherited: 0x00)
struct FNativeBlockIndicatorData {
	bool IsBlockActive; // 0x00(0x01)
	bool IsBlockUpdating; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float CurrentBlockFade; // 0x04(0x04)
	struct UCurveFloat* FadeCurve; // 0x08(0x08)
	struct UActorComponent* BlockIndicator; // 0x10(0x08)
};

// ScriptStruct DeadByDaylight.VaultData
// Size: 0x38 (Inherited: 0x00)
struct FVaultData {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DeadByDaylight.XpBonusData
// Size: 0x18 (Inherited: 0x00)
struct FXpBonusData {
	struct FString Name; // 0x00(0x10)
	int32_t XpValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

