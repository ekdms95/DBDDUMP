// UserDefinedEnum ENiagaraBooleanLogicOps.ENiagaraBooleanLogicOps
enum class ENiagaraBooleanLogicOps : uint8 {
	NewEnumerator0,
	NewEnumerator2,
	NewEnumerator4,
	NewEnumerator5,
	ENiagaraBooleanLogicOps_MAX,
};

