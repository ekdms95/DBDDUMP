// UserDefinedEnum ENiagaraCoordinateSpace.ENiagaraCoordinateSpace
enum class ENiagaraCoordinateSpace : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	ENiagaraCoordinateSpace_MAX,
};

