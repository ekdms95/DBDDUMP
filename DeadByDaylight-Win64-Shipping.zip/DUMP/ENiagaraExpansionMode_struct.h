// UserDefinedEnum ENiagaraExpansionMode.ENiagaraExpansionMode
enum class ENiagaraExpansionMode : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	ENiagaraExpansionMode_MAX,
};

