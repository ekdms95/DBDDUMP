// UserDefinedEnum ENiagaraRandomnessMode.ENiagaraRandomnessMode
enum class ENiagaraRandomnessMode : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	ENiagaraRandomnessMode_MAX,
};

