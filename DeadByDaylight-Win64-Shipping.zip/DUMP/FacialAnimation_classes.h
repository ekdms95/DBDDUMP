// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x840 (Inherited: 0x800)
struct UAudioCurveSourceComponent : UAudioComponent {
	struct FName CurveSourceBindingName; // 0x800(0x0c)
	float CurveSyncOffset; // 0x80c(0x04)
	char pad_810[0x30]; // 0x810(0x30)
};

