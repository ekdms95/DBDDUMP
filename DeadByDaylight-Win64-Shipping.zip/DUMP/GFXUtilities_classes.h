// Class GFXUtilities.BatchMeshCommands
// Size: 0x2a0 (Inherited: 0x210)
struct UBatchMeshCommands : USceneComponent {
	char pad_210[0x60]; // 0x210(0x60)
	struct TArray<struct FMaterialNamedGroup> Groups; // 0x270(0x10)
	struct TArray<struct FMaterialHelperOriginalMeshState> TargetMeshes; // 0x280(0x10)
	struct FString _materialGroupName; // 0x290(0x10)

	void UpdateMaterials(); // Function GFXUtilities.BatchMeshCommands.UpdateMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x5822dc0
	void SetVectorParameter(struct FName ParameterName, struct FVector NewValue); // Function GFXUtilities.BatchMeshCommands.SetVectorParameter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5822cd0
	void SetTextureParameter(struct FName ParameterName, struct UTexture* newTexture); // Function GFXUtilities.BatchMeshCommands.SetTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x5822bf0
	void SetStencilIntegerScalarParameter(struct FName ParameterName, int32_t NewValue); // Function GFXUtilities.BatchMeshCommands.SetStencilIntegerScalarParameter // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5822b00
	void SetScalarParameter(struct FName ParameterName, float NewValue); // Function GFXUtilities.BatchMeshCommands.SetScalarParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x5822a20
	void SetRenderInMainPass(bool inRenderInMainPass); // Function GFXUtilities.BatchMeshCommands.SetRenderInMainPass // (Native|Public|BlueprintCallable) // @ game+0x5822990
	void SetRenderInCustomDepth(bool renderInCustomDepth); // Function GFXUtilities.BatchMeshCommands.SetRenderInCustomDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x5822900
	void SetRenderInCustomColourNoDepth(bool renderInCustomColour); // Function GFXUtilities.BatchMeshCommands.SetRenderInCustomColourNoDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x5822870
	void SetReceivesDecals(bool receivesDecals); // Function GFXUtilities.BatchMeshCommands.SetReceivesDecals // (Final|Native|Public|BlueprintCallable) // @ game+0x58227e0
	void SetMaterial(struct FString GroupName); // Function GFXUtilities.BatchMeshCommands.SetMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x5822740
	void SetLightingChannelForAllMeshes(struct FLightingChannels LightingChannels); // Function GFXUtilities.BatchMeshCommands.SetLightingChannelForAllMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0x58226c0
	void SetCustomDepthStencilValue(int32_t stencilValue); // Function GFXUtilities.BatchMeshCommands.SetCustomDepthStencilValue // (Final|Native|Public|BlueprintCallable) // @ game+0x5822640
	void SetColourParameter(struct FName ParameterName, struct FLinearColor NewValue); // Function GFXUtilities.BatchMeshCommands.SetColourParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5822560
	void SetCastCinematicShadows(bool castCinematicShadows); // Function GFXUtilities.BatchMeshCommands.SetCastCinematicShadows // (Final|Native|Public|BlueprintCallable) // @ game+0x58224d0
	void SetAllToSameMaterial(struct UMaterialInterface* MaterialInterface); // Function GFXUtilities.BatchMeshCommands.SetAllToSameMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x5822450
	void ResetMaterials(); // Function GFXUtilities.BatchMeshCommands.ResetMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0x5822430
	bool CopyFirstScalarParameter(struct FName ParameterName, float outValue); // Function GFXUtilities.BatchMeshCommands.CopyFirstScalarParameter // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5822330
	void BatchSetVisibility(bool bNewVisibility, bool bPropagateToChildren); // Function GFXUtilities.BatchMeshCommands.BatchSetVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x5822260
	void BatchSetSkipComponentAndChildrenTransformUpdate(bool Skip); // Function GFXUtilities.BatchMeshCommands.BatchSetSkipComponentAndChildrenTransformUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x58221d0
	void BatchSetComponentTickEnabled(bool Enabled); // Function GFXUtilities.BatchMeshCommands.BatchSetComponentTickEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5822140
};

// Class GFXUtilities.AlternatingColor
// Size: 0x78 (Inherited: 0x30)
struct UAlternatingColor : UObject {
	struct FLinearColor FirstColor; // 0x30(0x10)
	struct FLinearColor SecondColor; // 0x40(0x10)
	float ColorChangePeriod; // 0x50(0x04)
	char pad_54[0x24]; // 0x54(0x24)
};

// Class GFXUtilities.BaseOutlineRenderStrategy
// Size: 0x70 (Inherited: 0x30)
struct UBaseOutlineRenderStrategy : UObject {
	struct TArray<struct UBatchMeshCommands*> _batchCommands; // 0x30(0x10)
	char pad_40[0x30]; // 0x40(0x30)
};

// Class GFXUtilities.ClippableProviderComponent
// Size: 0x108 (Inherited: 0xb8)
struct UClippableProviderComponent : UActorComponent {
	struct TSet<struct UPrimitiveComponent*> _ignoredPrimitives; // 0xb8(0x50)

	void SetIgnoredPrimitives(struct TArray<struct UPrimitiveComponent*> ignoredPrimitives); // Function GFXUtilities.ClippableProviderComponent.SetIgnoredPrimitives // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5822f50
};

// Class GFXUtilities.ClonedMeshComponent
// Size: 0x340 (Inherited: 0x2a0)
struct UClonedMeshComponent : UBatchMeshCommands {
	struct TMap<struct USceneComponent*, struct UMeshComponent*> _originalToClone; // 0x2a0(0x50)
	struct TMap<struct UMeshComponent*, struct USceneComponent*> _cloneToOriginal; // 0x2f0(0x50)
};

// Class GFXUtilities.ClonedMeshComponentTranslucentOutline
// Size: 0x340 (Inherited: 0x340)
struct UClonedMeshComponentTranslucentOutline : UClonedMeshComponent {
};

// Class GFXUtilities.ClonedStaticMeshComponent
// Size: 0x4f0 (Inherited: 0x4f0)
struct UClonedStaticMeshComponent : UStaticMeshComponent {
};

// Class GFXUtilities.ClonedSkeletalMeshComponent
// Size: 0xb70 (Inherited: 0xb70)
struct UClonedSkeletalMeshComponent : USkeletalMeshComponent {
};

// Class GFXUtilities.CustomDepthOutlineRenderStrategy
// Size: 0x88 (Inherited: 0x70)
struct UCustomDepthOutlineRenderStrategy : UBaseOutlineRenderStrategy {
	struct UMaterialInterface* _replacementMaterial; // 0x70(0x08)
	struct TArray<struct UBatchMeshCommands*> _translucentCopies; // 0x78(0x10)
};

// Class GFXUtilities.DBDReflectionCaptureSpawnerComponent
// Size: 0x240 (Inherited: 0x210)
struct UDBDReflectionCaptureSpawnerComponent : USceneComponent {
	enum class EReflectionSourceType ReflectionSourceType; // 0x210(0x01)
	char pad_211[0x7]; // 0x211(0x07)
	struct UTextureCube* Cubemap; // 0x218(0x08)
	float SourceCubemapAngle; // 0x220(0x04)
	float Brightness; // 0x224(0x04)
	float ContributionFactor; // 0x228(0x04)
	struct FVector CaptureOffset; // 0x22c(0x0c)
	struct AReflectionCapture* SpawnedReflectionCapture; // 0x238(0x08)

	void SetContributionFactor(float ContributionFactor); // Function GFXUtilities.DBDReflectionCaptureSpawnerComponent.SetContributionFactor // (Final|Native|Public|BlueprintCallable) // @ game+0x5823ca0
	void SetBrightness(float Brightness); // Function GFXUtilities.DBDReflectionCaptureSpawnerComponent.SetBrightness // (Final|Native|Public|BlueprintCallable) // @ game+0x5823c20
};

// Class GFXUtilities.DBDBoxReflectionCaptureSpawnerComponent
// Size: 0x260 (Inherited: 0x240)
struct UDBDBoxReflectionCaptureSpawnerComponent : UDBDReflectionCaptureSpawnerComponent {
	struct FVector InfluenceBox; // 0x240(0x0c)
	float BoxTransitionDistance; // 0x24c(0x04)
	struct UBoxComponent* PreviewInfluenceBox; // 0x250(0x08)
	struct UBoxComponent* PreviewCaptureBox; // 0x258(0x08)
};

// Class GFXUtilities.DBDCullDistanceVolumeComponent
// Size: 0x240 (Inherited: 0x210)
struct UDBDCullDistanceVolumeComponent : USceneComponent {
	struct TArray<struct FDBDCullDistanceSizePair> CullDistances; // 0x210(0x10)
	struct FVector InfluenceBox; // 0x220(0x0c)
	bool Enabled; // 0x22c(0x01)
	bool Unbound; // 0x22d(0x01)
	char pad_22E[0x2]; // 0x22e(0x02)
	struct UBoxComponent* _previewInfluenceBox; // 0x230(0x08)
	char pad_238[0x8]; // 0x238(0x08)
};

// Class GFXUtilities.DBDSphereReflectionCaptureSpawnerComponent
// Size: 0x250 (Inherited: 0x240)
struct UDBDSphereReflectionCaptureSpawnerComponent : UDBDReflectionCaptureSpawnerComponent {
	float InfluenceRadius; // 0x240(0x04)
	char pad_244[0x4]; // 0x244(0x04)
	struct UDrawSphereComponent* PreviewInfluenceRadius; // 0x248(0x08)
};

// Class GFXUtilities.GFXUtilities
// Size: 0x30 (Inherited: 0x30)
struct UGFXUtilities : UBlueprintFunctionLibrary {

	void ActivateVFX(struct USkeletalMeshComponent* SkeletalMeshComponent, bool Active); // Function GFXUtilities.GFXUtilities.ActivateVFX // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5823fa0
};

// Class GFXUtilities.InFrustumComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UInFrustumComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class GFXUtilities.LightIntensityTimelineComponent
// Size: 0x110 (Inherited: 0xb8)
struct ULightIntensityTimelineComponent : UActorComponent {
	struct TArray<struct FLightUpdate> lights; // 0xb8(0x10)
	struct TArray<struct FLightMaterialUpdate> materialHelpers; // 0xc8(0x10)
	struct UCurveFloat* intensityCurve; // 0xd8(0x08)
	bool randomizeStart; // 0xe0(0x01)
	bool randomizeLength; // 0xe1(0x01)
	char pad_E2[0x2]; // 0xe2(0x02)
	float minLength; // 0xe4(0x04)
	float maxLength; // 0xe8(0x04)
	bool normalizeCurve; // 0xec(0x01)
	bool startTicking; // 0xed(0x01)
	enum class ELightUnits inputLightUnit; // 0xee(0x01)
	char pad_EF[0x1]; // 0xef(0x01)
	struct FMulticastInlineDelegate OnTimelineFinished; // 0xf0(0x10)
	char pad_100[0x10]; // 0x100(0x10)

	void SetRandomizeLength(bool isRandom); // Function GFXUtilities.LightIntensityTimelineComponent.SetRandomizeLength // (Final|Native|Public|BlueprintCallable) // @ game+0x5824c10
	void SetMinLength(float newMinValue); // Function GFXUtilities.LightIntensityTimelineComponent.SetMinLength // (Final|Native|Public|BlueprintCallable) // @ game+0x5824b90
	void SetMaxLength(float newMaxValue); // Function GFXUtilities.LightIntensityTimelineComponent.SetMaxLength // (Final|Native|Public|BlueprintCallable) // @ game+0x5824b10
	void SetLightToMaxValue(); // Function GFXUtilities.LightIntensityTimelineComponent.SetLightToMaxValue // (Final|Native|Public|BlueprintCallable) // @ game+0x5824af0
	void SetLightCurve(struct UCurveFloat* lightcurve); // Function GFXUtilities.LightIntensityTimelineComponent.SetLightCurve // (Final|Native|Public|BlueprintCallable) // @ game+0x5824a70
	void Reset(); // Function GFXUtilities.LightIntensityTimelineComponent.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0x5824a50
	void RegisterForTick(); // Function GFXUtilities.LightIntensityTimelineComponent.RegisterForTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5824a30
	void DeactivateTick(); // Function GFXUtilities.LightIntensityTimelineComponent.DeactivateTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5824a10
	void AddMaterialHelper(struct UMaterialHelper* matHelper, struct FName propName, float Multiplier); // Function GFXUtilities.LightIntensityTimelineComponent.AddMaterialHelper // (Final|Native|Public|BlueprintCallable) // @ game+0x58248f0
	void AddLight(struct ULightComponent* Light, float Multiplier); // Function GFXUtilities.LightIntensityTimelineComponent.AddLight // (Final|Native|Public|BlueprintCallable) // @ game+0x5824820
};

// Class GFXUtilities.MaterialHelper
// Size: 0x2a0 (Inherited: 0x2a0)
struct UMaterialHelper : UBatchMeshCommands {

	void RefreshMeshes(); // Function GFXUtilities.MaterialHelper.RefreshMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0x5824ed0
	void RefreshMesh(struct UMeshComponent* mc); // Function GFXUtilities.MaterialHelper.RefreshMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x5824e50
};

// Class GFXUtilities.MaterialHelperUnaffectedStaticMeshComp
// Size: 0x4f0 (Inherited: 0x4f0)
struct UMaterialHelperUnaffectedStaticMeshComp : UStaticMeshComponent {
};

// Class GFXUtilities.MeshCloningFactory
// Size: 0x2a0 (Inherited: 0x2a0)
struct UMeshCloningFactory : UBatchMeshCommands {
};

// Class GFXUtilities.OuterlineComponent
// Size: 0x240 (Inherited: 0x210)
struct UOuterlineComponent : USceneComponent {
	struct UMaterialInterface* CloneCustomDepthMaterial; // 0x210(0x08)
	struct UMaterialInterface* CloneTranslucentMaterial; // 0x218(0x08)
	struct UMaterialInstanceDynamic* _cloneCustomDepthMaterialDynamic; // 0x220(0x08)
	struct UMaterialInstanceDynamic* _cloneTranslucentMaterialDynamic; // 0x228(0x08)
	struct USkeletalMeshComponent* _customDepthSkeletalMesh; // 0x230(0x08)
	struct USkeletalMeshComponent* _overlaySkeletalMesh; // 0x238(0x08)

	void SetIntensity(float Intensity); // Function GFXUtilities.OuterlineComponent.SetIntensity // (Final|Native|Public|BlueprintCallable) // @ game+0x5825300
};

// Class GFXUtilities.StencilOutlineRenderStrategy
// Size: 0x98 (Inherited: 0x70)
struct UStencilOutlineRenderStrategy : UBaseOutlineRenderStrategy {
	struct TArray<struct UMaterialInterface*> _replacementMaterials; // 0x70(0x10)
	struct TArray<struct UBatchMeshCommands*> _translucentCopies; // 0x80(0x10)
	char pad_90[0x8]; // 0x90(0x08)
};

// Class GFXUtilities.TranslucentOutlineRenderStrategy
// Size: 0x80 (Inherited: 0x70)
struct UTranslucentOutlineRenderStrategy : UBaseOutlineRenderStrategy {
	struct TArray<struct UMaterialInterface*> _replacementMaterials; // 0x70(0x10)
};

