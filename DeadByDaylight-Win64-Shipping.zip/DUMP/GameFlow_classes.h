// Class GameFlow.GameFlowHandler
// Size: 0x90 (Inherited: 0x38)
struct UGameFlowHandler : UAbstractGameFlowHandler {
	char pad_38[0x58]; // 0x38(0x58)
};

