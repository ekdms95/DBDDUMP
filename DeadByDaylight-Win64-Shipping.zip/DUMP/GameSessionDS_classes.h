// Class GameSessionDS.GameSessionDS
// Size: 0x40 (Inherited: 0x30)
struct UGameSessionDS : UObject {
	char pad_30[0x10]; // 0x30(0x10)
};

