// Class GameflowNotifications.GameflowEventsNotifier
// Size: 0x30 (Inherited: 0x30)
struct UGameflowEventsNotifier : UInterface {
};

// Class GameflowNotifications.PlayerflowEventsNotifier
// Size: 0x30 (Inherited: 0x30)
struct UPlayerflowEventsNotifier : UInterface {
};

