// Class GameplayTagUtilities.DBDGameplayTagUtilities
// Size: 0x30 (Inherited: 0x30)
struct UDBDGameplayTagUtilities : UBlueprintFunctionLibrary {

	struct FName GetScoreModifierName(struct FName scoreEventID); // Function GameplayTagUtilities.DBDGameplayTagUtilities.GetScoreModifierName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x57d6bf0
	bool GameplayTagExists(struct FName TagName); // Function GameplayTagUtilities.DBDGameplayTagUtilities.GameplayTagExists // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x57d6b50
};

// Class GameplayTagUtilities.GameplayTagContainerComponent
// Size: 0x128 (Inherited: 0xb8)
struct UGameplayTagContainerComponent : UActorComponent {
	char pad_B8[0x70]; // 0xb8(0x70)

	void Remove(struct FGameplayTag State); // Function GameplayTagUtilities.GameplayTagContainerComponent.Remove // (Final|Native|Public|BlueprintCallable) // @ game+0x57d74a0
	void Add(struct FGameplayTag State); // Function GameplayTagUtilities.GameplayTagContainerComponent.Add // (Final|Native|Public|BlueprintCallable) // @ game+0x57d7400
};

// Class GameplayTagUtilities.ObjectStateProvider
// Size: 0x30 (Inherited: 0x30)
struct UObjectStateProvider : UInterface {
};

