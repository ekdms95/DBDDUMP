// ScriptStruct GameplayTagUtilities.TagStateBool
// Size: 0x30 (Inherited: 0x00)
struct FTagStateBool {
	bool _isTrue; // 0x00(0x01)
	char pad_1[0x2f]; // 0x01(0x2f)
};

