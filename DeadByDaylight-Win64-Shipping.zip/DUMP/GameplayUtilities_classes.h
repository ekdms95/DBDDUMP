// Class GameplayUtilities.CharacterPusherComponent
// Size: 0x170 (Inherited: 0xb8)
struct UCharacterPusherComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
	struct TArray<struct ACharacter*> _charactersToPush; // 0xe8(0x10)
	struct TSet<struct ACharacter*> _ignoredCharacters; // 0xf8(0x50)
	struct UCapsuleComponent* _characterDetector; // 0x148(0x08)
	struct UCapsuleComponent* _characterCollision; // 0x150(0x08)
	struct UBasePushStrategyComponent* _pushStrategy; // 0x158(0x08)
	struct TArray<struct ACharacter*> _ignoredByPushedCharacters; // 0x160(0x10)

	void SetIgnoredCharacter(struct ACharacter* Character, bool ignore); // Function GameplayUtilities.CharacterPusherComponent.SetIgnoredCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0x57faa90
	void OnCharacterDetectorOverlapExit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function GameplayUtilities.CharacterPusherComponent.OnCharacterDetectorOverlapExit // (Final|Native|Protected) // @ game+0x57fa6c0
	void Construct(struct UCapsuleComponent* characterDetector, struct UCapsuleComponent* characterCollision, struct UBasePushStrategyComponent* pushStrategy); // Function GameplayUtilities.CharacterPusherComponent.Construct // (Final|Native|Public|BlueprintCallable) // @ game+0x57fa050
};

// Class GameplayUtilities.BasePoolableActorComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UBasePoolableActorComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct FMulticastInlineDelegate OnAcquiredChanged; // 0xc0(0x10)

	void SetAcquired(bool Active); // Function GameplayUtilities.BasePoolableActorComponent.SetAcquired // (Native|Public|BlueprintCallable) // @ game+0x57faa00
	bool IsAcquired(); // Function GameplayUtilities.BasePoolableActorComponent.IsAcquired // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x57fa420
};

// Class GameplayUtilities.AuthoritativePoolableActorComponent
// Size: 0xd8 (Inherited: 0xd0)
struct UAuthoritativePoolableActorComponent : UBasePoolableActorComponent {
	bool _acquired; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	void OnRep_Acquired(); // Function GameplayUtilities.AuthoritativePoolableActorComponent.OnRep_Acquired // (Final|Native|Private) // @ game+0x57fa800
};

// Class GameplayUtilities.BaseInputAccelerationConstraintStrategy
// Size: 0xb8 (Inherited: 0xb8)
struct UBaseInputAccelerationConstraintStrategy : UActorComponent {
};

// Class GameplayUtilities.BaseCharacterVelocityAdditiveStrategy
// Size: 0xb8 (Inherited: 0xb8)
struct UBaseCharacterVelocityAdditiveStrategy : UActorComponent {
};

// Class GameplayUtilities.AuthoritativeActorPoolComponent
// Size: 0xf0 (Inherited: 0xb8)
struct UAuthoritativeActorPoolComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct AActor* _actorClass; // 0xd0(0x08)
	int32_t _size; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct TArray<struct AActor*> _pool; // 0xe0(0x10)

	void OnRep_Pool(struct TArray<struct AActor*> previousPool); // Function GameplayUtilities.AuthoritativeActorPoolComponent.OnRep_Pool // (Final|Native|Private) // @ game+0x57fa860
	void Authority_OnActorDestroyed(struct AActor* DestroyedActor); // Function GameplayUtilities.AuthoritativeActorPoolComponent.Authority_OnActorDestroyed // (Final|Native|Private) // @ game+0x57f9fd0
};

// Class GameplayUtilities.BasePushStrategyComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UBasePushStrategyComponent : UActorComponent {
};

// Class GameplayUtilities.BoxOcclusionQueryComponent
// Size: 0x470 (Inherited: 0x450)
struct UBoxOcclusionQueryComponent : UBoxComponent {
	float TimeUntilOccluded; // 0x450(0x04)
	char pad_454[0x1c]; // 0x454(0x1c)

	float GetVisiblePercentOfScreen(); // Function GameplayUtilities.BoxOcclusionQueryComponent.GetVisiblePercentOfScreen // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x57fa3f0
	float GetNumberOfVisiblePixels(); // Function GameplayUtilities.BoxOcclusionQueryComponent.GetNumberOfVisiblePixels // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x57fa340
	float GetEstimatedRenderedPixelCount(); // Function GameplayUtilities.BoxOcclusionQueryComponent.GetEstimatedRenderedPixelCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x57fa260
};

// Class GameplayUtilities.CameraUtilities
// Size: 0x30 (Inherited: 0x30)
struct UCameraUtilities : UBlueprintFunctionLibrary {

	bool IsLookingTowards(struct AController* Controller, struct FVector Position, float precisionAngle); // Function GameplayUtilities.CameraUtilities.IsLookingTowards // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x57fa460
};

// Class GameplayUtilities.CharacterPositionRecorderComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UCharacterPositionRecorderComponent : UActorComponent {
	float _cacheTimespan; // 0xb8(0x04)
	char pad_BC[0x1c]; // 0xbc(0x1c)
};

// Class GameplayUtilities.CharacterSightableComponent
// Size: 0x1a0 (Inherited: 0xb8)
struct UCharacterSightableComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
	struct FMulticastInlineDelegate OnHighestSightStatusChangedBP; // 0xe8(0x10)
	struct TMap<struct TWeakObjectPtr<struct ACharacter>, struct FDelegateHandleWrapper> _sightDelegateHandles; // 0xf8(0x50)
	struct TMap<struct TWeakObjectPtr<struct ACharacter>, enum class ESightStatus> _sightersStatus; // 0x148(0x50)
	char pad_198[0x8]; // 0x198(0x08)

	void OnHighestSightStatusChangedBP__DelegateSignature(enum class ESightStatus status); // DelegateFunction GameplayUtilities.CharacterSightableComponent.OnHighestSightStatusChangedBP__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	enum class ESightStatus GetHighestSightStatus(); // Function GameplayUtilities.CharacterSightableComponent.GetHighestSightStatus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x57fa290
};

// Class GameplayUtilities.CharacterSightComponent
// Size: 0x170 (Inherited: 0xb8)
struct UCharacterSightComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)
	float _minimumCharacterScreenPercent; // 0xf0(0x04)
	float _minimumCharacterVisiblePixelsPercent; // 0xf4(0x04)
	float _maximumSightDistance; // 0xf8(0x04)
	float _screenVisibilityZoneRadiusPercent; // 0xfc(0x04)
	float _sightingDelay; // 0x100(0x04)
	float _discerningDelay; // 0x104(0x04)
	float _undiscerningDelay; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct ACharacter* _sightableCharacterClass; // 0x110(0x08)
	struct TArray<struct FAuthorityDiscernedCharacter> _discernedCharacters; // 0x118(0x10)
	struct TArray<struct FDiscernibleCharacter> _localDiscernibleCharacters; // 0x128(0x10)
	bool _debugMode; // 0x138(0x01)
	bool _canSee; // 0x139(0x01)
	char pad_13A[0x6]; // 0x13a(0x06)
	struct FActivationDefinition _activationDefinition; // 0x140(0x28)
	char pad_168[0x8]; // 0x168(0x08)

	void SetScreenVisibilityZoneRadiusPercent(float value); // Function GameplayUtilities.CharacterSightComponent.SetScreenVisibilityZoneRadiusPercent // (Final|Native|Public|BlueprintCallable) // @ game+0x57face0
	void SetMinimumCharacterVisiblePixelsPercent(float value); // Function GameplayUtilities.CharacterSightComponent.SetMinimumCharacterVisiblePixelsPercent // (Final|Native|Public|BlueprintCallable) // @ game+0x57fac60
	void SetMinimumCharacterScreenPercent(float value); // Function GameplayUtilities.CharacterSightComponent.SetMinimumCharacterScreenPercent // (Final|Native|Public|BlueprintCallable) // @ game+0x57fabe0
	void SetMaximumSightDistance(float value); // Function GameplayUtilities.CharacterSightComponent.SetMaximumSightDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x57fab60
	void Server_UpdateDiscernedCharacters(struct TArray<struct ACharacter*> Characters); // Function GameplayUtilities.CharacterSightComponent.Server_UpdateDiscernedCharacters // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x57fa940
	void OnRep_DiscernibleCharacters(); // Function GameplayUtilities.CharacterSightComponent.OnRep_DiscernibleCharacters // (Final|Native|Private) // @ game+0x57fa840
	void OnRep_CanSee(); // Function GameplayUtilities.CharacterSightComponent.OnRep_CanSee // (Final|Native|Private) // @ game+0x57fa820
};

// Class GameplayUtilities.ChargeableUtilities
// Size: 0x30 (Inherited: 0x30)
struct UChargeableUtilities : UBlueprintFunctionLibrary {

	float ConvertSecondsToAddToRateMultiplier(float secondsToAdd, float baseMaxSeconds, float baseRate); // Function GameplayUtilities.ChargeableUtilities.ConvertSecondsToAddToRateMultiplier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x57fa150
};

// Class GameplayUtilities.ContainerUtilities
// Size: 0x30 (Inherited: 0x30)
struct UContainerUtilities : UBlueprintFunctionLibrary {
};

// Class GameplayUtilities.PoolableActor
// Size: 0x30 (Inherited: 0x30)
struct UPoolableActor : UInterface {
};

// Class GameplayUtilities.MockAuthoritativeActorPoolComponent
// Size: 0xf0 (Inherited: 0xf0)
struct UMockAuthoritativeActorPoolComponent : UAuthoritativeActorPoolComponent {
};

// Class GameplayUtilities.MockPoolableActor
// Size: 0x238 (Inherited: 0x230)
struct AMockPoolableActor : AActor {
	struct UPoolableActorComponent* _poolable; // 0x230(0x08)
};

// Class GameplayUtilities.MovableCamera
// Size: 0x2b8 (Inherited: 0x290)
struct AMovableCamera : APawn {
	float MovementSpeed; // 0x290(0x04)
	bool RequiresShiftModifierForInput; // 0x294(0x01)
	char pad_295[0x1b]; // 0x295(0x1b)
	struct APlayerController* _playerController; // 0x2b0(0x08)
};

// Class GameplayUtilities.MoveActorToComponent
// Size: 0xf0 (Inherited: 0xb8)
struct UMoveActorToComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)
};

// Class GameplayUtilities.MovementUtilities
// Size: 0x30 (Inherited: 0x30)
struct UMovementUtilities : UBlueprintFunctionLibrary {

	void Local_MoveActorTo(struct AActor* Actor, struct FVector Location, struct FRotator Rotation, float Duration); // Function GameplayUtilities.MovementUtilities.Local_MoveActorTo // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x57fa570
};

// Class GameplayUtilities.PawnUtilities
// Size: 0x30 (Inherited: 0x30)
struct UPawnUtilities : UBlueprintFunctionLibrary {

	struct APawn* GetOwningPawn(struct AActor* Origin); // Function GameplayUtilities.PawnUtilities.GetOwningPawn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x57fa370
	struct APawn* GetLocallyObservedPawn(struct UObject* WorldContext); // Function GameplayUtilities.PawnUtilities.GetLocallyObservedPawn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x57fa2c0
};

// Class GameplayUtilities.PlayerStateExt
// Size: 0x30 (Inherited: 0x30)
struct UPlayerStateExt : UBlueprintFunctionLibrary {
};

// Class GameplayUtilities.PoolableActorComponent
// Size: 0xd8 (Inherited: 0xd0)
struct UPoolableActorComponent : UBasePoolableActorComponent {
	char pad_D0[0x8]; // 0xd0(0x08)
};

// Class GameplayUtilities.SceneComponentExt
// Size: 0x30 (Inherited: 0x30)
struct USceneComponentExt : UBlueprintFunctionLibrary {
};

// Class GameplayUtilities.SidePushStrategyComponent
// Size: 0xc8 (Inherited: 0xb8)
struct USidePushStrategyComponent : UBasePushStrategyComponent {
	float _maxImpulseStrength; // 0xb8(0x04)
	float _minImpulseStrength; // 0xbc(0x04)
	float _detectorCapsuleInflation; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// Class GameplayUtilities.VisualLoggerExt
// Size: 0x30 (Inherited: 0x30)
struct UVisualLoggerExt : UObject {
};

