// Class GraphicsExtensions.GMAdaptiveShadowMapAtlas
// Size: 0xe8 (Inherited: 0x30)
struct UGMAdaptiveShadowMapAtlas : UObject {
	char pad_30[0xb8]; // 0x30(0xb8)
};

// Class GraphicsExtensions.GMAdaptiveShadowMapController
// Size: 0xc8 (Inherited: 0x30)
struct UGMAdaptiveShadowMapController : UObject {
	struct UGMAdaptiveShadowMapAtlas* _atlas; // 0x30(0x08)
	struct UMaterialInterface* _lightFunctionMaterial; // 0x38(0x08)
	struct TArray<struct UGMAdaptiveShadowMapSource*> _shadowMapSourceList; // 0x40(0x10)
	struct TArray<struct UGMAdaptiveShadowMapSource*> _shadowMapSourceActivatedList; // 0x50(0x10)
	char pad_60[0x68]; // 0x60(0x68)
};

// Class GraphicsExtensions.GMAdaptiveShadowMapControllerComponent
// Size: 0x3f0 (Inherited: 0x210)
struct UGMAdaptiveShadowMapControllerComponent : USceneComponent {
	struct FBHVRPerDetailModeInt TileSize; // 0x210(0xa0)
	int32_t TileCountX; // 0x2b0(0x04)
	int32_t TileCountY; // 0x2b4(0x04)
	struct FIntPoint GridSize; // 0x2b8(0x08)
	int32_t GeneratedTilesPerFrame; // 0x2c0(0x04)
	char pad_2C4[0x4]; // 0x2c4(0x04)
	struct FBHVRPerDetailModeInt MaxPreallocatedTilesPerFrame; // 0x2c8(0xa0)
	bool bSupportsDirectionalLights; // 0x368(0x01)
	bool bSupportsSpotLights; // 0x369(0x01)
	char pad_36A[0x6]; // 0x36a(0x06)
	struct UMaterialInterface* LightFunctionMaterial; // 0x370(0x08)
	float CullShadowIfPixelSizeLessThan; // 0x378(0x04)
	bool bPreviewOnly; // 0x37c(0x01)
	char pad_37D[0x13]; // 0x37d(0x13)
	struct UGMAdaptiveShadowMapAtlas* _atlas; // 0x390(0x08)
	struct UGMAdaptiveShadowMapController* _controller; // 0x398(0x08)
	struct TMap<struct UGMAdaptiveShadowMapSourceComponent*, struct UGMAdaptiveShadowMapSource*> _shadowMapSources; // 0x3a0(0x50)

	void RebuildAtlas(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.RebuildAtlas // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9b20
	bool IsControllerDonePreallocatingTiles(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.IsControllerDonePreallocatingTiles // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9af0
	int32_t GetTileSize(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.GetTileSize // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9ac0
	int32_t GetTileCountY(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.GetTileCountY // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9a90
	int32_t GetTileCountX(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.GetTileCountX // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9a60
	void DumpDebugInfo(); // Function GraphicsExtensions.GMAdaptiveShadowMapControllerComponent.DumpDebugInfo // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x33c9a40
};

// Class GraphicsExtensions.GMAdaptiveShadowMapSource
// Size: 0x300 (Inherited: 0x30)
struct UGMAdaptiveShadowMapSource : UObject {
	struct UGMAdaptiveShadowMapAtlas* _atlas; // 0x30(0x08)
	struct ULightComponent* _lightComponent; // 0x38(0x08)
	char pad_40[0x2c0]; // 0x40(0x2c0)
};

// Class GraphicsExtensions.GMAdaptiveShadowMapSourceComponent
// Size: 0x230 (Inherited: 0x210)
struct UGMAdaptiveShadowMapSourceComponent : USceneComponent {
	bool bUseAutoRadius; // 0x210(0x01)
	char pad_211[0x3]; // 0x211(0x03)
	float Radius; // 0x214(0x04)
	float DepthMin; // 0x218(0x04)
	float DepthMax; // 0x21c(0x04)
	int32_t Levels; // 0x220(0x04)
	int32_t PreGeneratedLevels; // 0x224(0x04)
	char pad_228[0x8]; // 0x228(0x08)

	void SetLightRadiusWithBounds(struct FVector BoundingSphereCenter, float BoundingSphereRadius); // Function GraphicsExtensions.GMAdaptiveShadowMapSourceComponent.SetLightRadiusWithBounds // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x33c9f80
};

// Class GraphicsExtensions.GMAdaptiveShadowMapSourceComponentSpawner
// Size: 0x240 (Inherited: 0x230)
struct AGMAdaptiveShadowMapSourceComponentSpawner : AActor {
	bool bCreateASMSourceComponentOnBeginPlay; // 0x230(0x01)
	bool bRemoveCastForCinematicOnlyFlagOnLights; // 0x231(0x01)
	bool bRemoveLightFunctionMaterialOnLights; // 0x232(0x01)
	char pad_233[0x1]; // 0x233(0x01)
	int32_t NumLevelPerSource; // 0x234(0x04)
	int32_t NumPreGeneratedLevelPerSource; // 0x238(0x04)
	bool bPreviewOnly; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
};

// Class GraphicsExtensions.GMAdaptiveShadowMapSourceDirectional
// Size: 0x350 (Inherited: 0x300)
struct UGMAdaptiveShadowMapSourceDirectional : UGMAdaptiveShadowMapSource {
	struct UDirectionalLightComponent* _directionalLightComponent; // 0x2f8(0x08)
	char pad_308[0x48]; // 0x308(0x48)
};

// Class GraphicsExtensions.GMAdaptiveShadowMapSourceSpot
// Size: 0x360 (Inherited: 0x300)
struct UGMAdaptiveShadowMapSourceSpot : UGMAdaptiveShadowMapSource {
	struct USpotLightComponent* _spotLightComponent; // 0x2f8(0x08)
	char pad_308[0x58]; // 0x308(0x58)
};

