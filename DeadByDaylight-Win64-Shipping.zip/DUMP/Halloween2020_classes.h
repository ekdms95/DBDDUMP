// Class Halloween2020.BlightedSerumAddon
// Size: 0x2d0 (Inherited: 0x278)
struct UBlightedSerumAddon : UItemAddon {
	struct ACollectable* _blightedSerumCollectable; // 0x278(0x08)
	struct UBlightedSerumDashInteraction* _dashInteraction; // 0x280(0x08)
	int32_t _theBlightExtraTokens; // 0x288(0x04)
	int32_t _numberOfDashesPerEvent; // 0x28c(0x04)
	char pad_290[0x40]; // 0x290(0x40)

	void OnRep_DashInteraction(); // Function Halloween2020.BlightedSerumAddon.OnRep_DashInteraction // (Final|Native|Private) // @ game+0x33ccd40
	void OnBlightedDashEnabledVfxSfx(); // Function Halloween2020.BlightedSerumAddon.OnBlightedDashEnabledVfxSfx // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
};

// Class Halloween2020.BlightedSerumCollisionInteraction
// Size: 0x570 (Inherited: 0x560)
struct UBlightedSerumCollisionInteraction : UInteractionDefinition {
	struct UBlightedSerumCooldownInteraction* _cooldownInteraction; // 0x558(0x08)
	float _bounceTime; // 0x560(0x04)
	char pad_56C[0x4]; // 0x56c(0x04)

	void SetCooldownInteraction(struct UBlightedSerumCooldownInteraction* cooldownInteraction); // Function Halloween2020.BlightedSerumCollisionInteraction.SetCooldownInteraction // (Final|Native|Public|BlueprintCallable) // @ game+0x33cced0
};

// Class Halloween2020.BlightedSerumCooldownInteraction
// Size: 0x570 (Inherited: 0x560)
struct UBlightedSerumCooldownInteraction : UInteractionDefinition {
	float _cooldownTime; // 0x558(0x04)
	float _cameraPitchRecenterTime; // 0x55c(0x04)
	char pad_568[0x8]; // 0x568(0x08)
};

// Class Halloween2020.BlightedSerumDashInteraction
// Size: 0x5f0 (Inherited: 0x560)
struct UBlightedSerumDashInteraction : UInteractionDefinition {
	struct UBlightedSerumCooldownInteraction* _cooldownInteraction; // 0x558(0x08)
	struct UBlightedSerumCollisionInteraction* _collisionInteraction; // 0x560(0x08)
	struct UCurveFloat* _dashSpeedCurve; // 0x568(0x08)
	struct UCurveFloat* _lookAngleToTurnRateCurveController; // 0x570(0x08)
	struct UCurveFloat* _lookAngleToTurnRateCurveMouse; // 0x578(0x08)
	float _dashDuration; // 0x580(0x04)
	float _vectorInterpToSpeed; // 0x584(0x04)
	float _wallDashAccelerationMultiplier; // 0x588(0x04)
	float _cameraPitchRecenterTime; // 0x58c(0x04)
	float _lookAngleTurnRateModifier; // 0x590(0x04)
	float _wallDashCollisionRadius; // 0x594(0x04)
	float _wallDashCollisionHeight; // 0x598(0x04)
	float _wallDashCollisionRange; // 0x59c(0x04)
	char pad_5A8[0x48]; // 0x5a8(0x48)

	void SetCooldownInteraction(struct UBlightedSerumCooldownInteraction* cooldownInteraction); // Function Halloween2020.BlightedSerumDashInteraction.SetCooldownInteraction // (Final|Native|Public|BlueprintCallable) // @ game+0x33cced0
	void SetCollisionInteraction(struct UBlightedSerumCollisionInteraction* collisionInteraction); // Function Halloween2020.BlightedSerumDashInteraction.SetCollisionInteraction // (Final|Native|Public|BlueprintCallable) // @ game+0x33cd200
};

// Class Halloween2020.ToxinPlantInteractable
// Size: 0x320 (Inherited: 0x318)
struct AToxinPlantInteractable : ASpecialBehaviourInteractable {
	char pad_318[0x8]; // 0x318(0x08)

	void SetToxinPlantComplete(bool IsComplete); // Function Halloween2020.ToxinPlantInteractable.SetToxinPlantComplete // (Final|Native|Public|BlueprintCallable) // @ game+0x33cd590
	void OnToxinPlantComplete(); // Function Halloween2020.ToxinPlantInteractable.OnToxinPlantComplete // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnSalvageInteractionStart(); // Function Halloween2020.ToxinPlantInteractable.OnSalvageInteractionStart // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnSalvageInteractionFinished(); // Function Halloween2020.ToxinPlantInteractable.OnSalvageInteractionFinished // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	bool IsToxinPlantComplete(); // Function Halloween2020.ToxinPlantInteractable.IsToxinPlantComplete // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33cd560
};

