// Class Interaction.AIInteractableTargetInterface
// Size: 0x30 (Inherited: 0x30)
struct UAIInteractableTargetInterface : UInterface {
};

// Class Interaction.Interaction
// Size: 0x30 (Inherited: 0x30)
struct UInteraction : UInterface {
};

// Class Interaction.InteractionPerformer
// Size: 0x30 (Inherited: 0x30)
struct UInteractionPerformer : UInterface {
};

