// BlueprintGeneratedClass LevelGenerator.LevelGenerator_C
// Size: 0xe64 (Inherited: 0xe50)
struct ALevelGenerator_C : AProceduralLevelBuilder {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe50(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0xe58(0x08)
	float initialMistDensity; // 0xe60(0x04)

	void RemoveMist(); // Function LevelGenerator.LevelGenerator_C.RemoveMist // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void ApplyMist(float Modifier); // Function LevelGenerator.LevelGenerator_C.ApplyMist // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_LevelGenerator(int32_t EntryPoint); // Function LevelGenerator.LevelGenerator_C.ExecuteUbergraph_LevelGenerator // (Final|UbergraphFunction) // @ game+0x3873200
};

