// BlueprintGeneratedClass LevelTransition_LightsEffects.LevelTransition_LightsEffects_C
// Size: 0x240 (Inherited: 0x238)
struct ALevelTransition_LightsEffects_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)

	void ReceiveBeginPlay(); // Function LevelTransition_LightsEffects.LevelTransition_LightsEffects_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void ReceiveTick(float DeltaSeconds); // Function LevelTransition_LightsEffects.LevelTransition_LightsEffects_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_LevelTransition_LightsEffects(int32_t EntryPoint); // Function LevelTransition_LightsEffects.LevelTransition_LightsEffects_C.ExecuteUbergraph_LevelTransition_LightsEffects // (Final|UbergraphFunction) // @ game+0x3873200
};

