// Class LiveLinkInterface.LiveLinkSourceFactory
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkSourceFactory : UObject {
};

// Class LiveLinkInterface.LiveLinkRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkRole : UObject {
};

// Class LiveLinkInterface.LiveLinkBasicRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkBasicRole : ULiveLinkRole {
};

// Class LiveLinkInterface.LiveLinkAnimationRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkAnimationRole : ULiveLinkBasicRole {
};

// Class LiveLinkInterface.LiveLinkTransformRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkTransformRole : ULiveLinkBasicRole {
};

// Class LiveLinkInterface.LiveLinkCameraRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkCameraRole : ULiveLinkTransformRole {
};

// Class LiveLinkInterface.LiveLinkController
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkController : UObject {
};

// Class LiveLinkInterface.LiveLinkSourceSettings
// Size: 0xa0 (Inherited: 0x30)
struct ULiveLinkSourceSettings : UObject {
	enum class ELiveLinkSourceMode Mode; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FLiveLinkSourceBufferManagementSettings BufferSettings; // 0x38(0x50)
	struct FString ConnectionString; // 0x88(0x10)
	struct ULiveLinkSourceFactory* Factory; // 0x98(0x08)
};

// Class LiveLinkInterface.LiveLinkCurveRemapSettings
// Size: 0xf0 (Inherited: 0xa0)
struct ULiveLinkCurveRemapSettings : ULiveLinkSourceSettings {
	struct FLiveLinkCurveConversionSettings CurveConversionSettings; // 0xa0(0x50)
};

// Class LiveLinkInterface.LiveLinkFrameInterpolationProcessor
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkFrameInterpolationProcessor : UObject {
};

// Class LiveLinkInterface.LiveLinkFramePreProcessor
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkFramePreProcessor : UObject {
};

// Class LiveLinkInterface.LiveLinkFrameTranslator
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkFrameTranslator : UObject {
};

// Class LiveLinkInterface.LiveLinkLightRole
// Size: 0x30 (Inherited: 0x30)
struct ULiveLinkLightRole : ULiveLinkTransformRole {
};

// Class LiveLinkInterface.LiveLinkSubjectSettings
// Size: 0x60 (Inherited: 0x30)
struct ULiveLinkSubjectSettings : UObject {
	struct TArray<struct ULiveLinkFramePreProcessor*> PreProcessors; // 0x30(0x10)
	struct ULiveLinkFrameInterpolationProcessor* InterpolationProcessor; // 0x40(0x08)
	struct TArray<struct ULiveLinkFrameTranslator*> Translators; // 0x48(0x10)
	struct ULiveLinkRole* Role; // 0x58(0x08)
};

// Class LiveLinkInterface.LiveLinkVirtualSubject
// Size: 0xe8 (Inherited: 0x30)
struct ULiveLinkVirtualSubject : UObject {
	char pad_30[0x8]; // 0x30(0x08)
	struct ULiveLinkRole* Role; // 0x38(0x08)
	struct TArray<struct FLiveLinkSubjectName> Subjects; // 0x40(0x10)
	struct TArray<struct ULiveLinkFrameTranslator*> FrameTranslators; // 0x50(0x10)
	char pad_60[0x88]; // 0x60(0x88)
};

