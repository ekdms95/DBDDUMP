// Class MRMesh.MeshReconstructorBase
// Size: 0x30 (Inherited: 0x30)
struct UMeshReconstructorBase : UObject {

	void StopReconstruction(); // Function MRMesh.MeshReconstructorBase.StopReconstruction // (Native|Public|BlueprintCallable) // @ game+0x3259920
	void StartReconstruction(); // Function MRMesh.MeshReconstructorBase.StartReconstruction // (Native|Public|BlueprintCallable) // @ game+0x4332950
	void PauseReconstruction(); // Function MRMesh.MeshReconstructorBase.PauseReconstruction // (Native|Public|BlueprintCallable) // @ game+0x3259340
	bool IsReconstructionStarted(); // Function MRMesh.MeshReconstructorBase.IsReconstructionStarted // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4332920
	bool IsReconstructionPaused(); // Function MRMesh.MeshReconstructorBase.IsReconstructionPaused // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x43328f0
	void DisconnectMRMesh(); // Function MRMesh.MeshReconstructorBase.DisconnectMRMesh // (Native|Public) // @ game+0x43327f0
	void ConnectMRMesh(struct UMRMeshComponent* Mesh); // Function MRMesh.MeshReconstructorBase.ConnectMRMesh // (Native|Public) // @ game+0x43326e0
};

// Class MRMesh.MockDataMeshTrackerComponent
// Size: 0x280 (Inherited: 0x210)
struct UMockDataMeshTrackerComponent : USceneComponent {
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // 0x210(0x10)
	bool ScanWorld; // 0x220(0x01)
	bool RequestNormals; // 0x221(0x01)
	bool RequestVertexConfidence; // 0x222(0x01)
	enum class EMeshTrackerVertexColorMode VertexColorMode; // 0x223(0x01)
	char pad_224[0x4]; // 0x224(0x04)
	struct TArray<struct FColor> BlockVertexColors; // 0x228(0x10)
	struct FLinearColor VertexColorFromConfidenceZero; // 0x238(0x10)
	struct FLinearColor VertexColorFromConfidenceOne; // 0x248(0x10)
	float UpdateInterval; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct UMRMeshComponent* MRMesh; // 0x260(0x08)
	char pad_268[0x18]; // 0x268(0x18)

	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector> Vertices, struct TArray<int32_t> Triangles, struct TArray<struct FVector> Normals, struct TArray<float> Confidence); // DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x4332810
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x4332770
};

// Class MRMesh.MRMeshComponent
// Size: 0x4a0 (Inherited: 0x430)
struct UMRMeshComponent : UPrimitiveComponent {
	struct UMaterialInterface* Material; // 0x430(0x08)
	bool bCreateMeshProxySections; // 0x438(0x01)
	bool bUpdateNavMeshOnMeshUpdate; // 0x439(0x01)
	bool bNeverCreateCollisionMesh; // 0x43a(0x01)
	char pad_43B[0x5]; // 0x43b(0x05)
	struct UBodySetup* CachedBodySetup; // 0x440(0x08)
	struct TArray<struct UBodySetup*> BodySetups; // 0x448(0x10)
	struct UMaterialInterface* WireframeMaterial; // 0x458(0x08)
	char pad_460[0x40]; // 0x460(0x40)

	bool IsConnected(); // Function MRMesh.MRMeshComponent.IsConnected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x43328b0
	void ForceNavMeshUpdate(); // Function MRMesh.MRMeshComponent.ForceNavMeshUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x4332890
	void Clear(); // Function MRMesh.MRMeshComponent.Clear // (Final|Native|Public|BlueprintCallable) // @ game+0x43326b0
};

