// Class MagicLeapAudio.MagicLeapAudioFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapAudioFunctionLibrary : UBlueprintFunctionLibrary {

	bool SetOnAudioJackUnpluggedDelegate(struct FDelegate ResultDelegate); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetOnAudioJackUnpluggedDelegate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a61700
	bool SetOnAudioJackPluggedDelegate(struct FDelegate ResultDelegate); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetOnAudioJackPluggedDelegate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a61640
	bool SetMicMute(bool IsMuted); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetMicMute // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a615c0
	bool IsMicMuted(); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.IsMicMuted // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x27cc5f0
};

