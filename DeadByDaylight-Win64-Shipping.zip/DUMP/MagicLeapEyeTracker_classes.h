// Class MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapEyeTrackerFunctionLibrary : UBlueprintFunctionLibrary {

	bool GetEyeBlinkState(struct FMagicLeapEyeBlinkState BlinkState); // Function MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary.GetEyeBlinkState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2a687c0
	enum class EMagicLeapEyeTrackingCalibrationStatus GetCalibrationStatus(); // Function MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary.GetCalibrationStatus // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a68790
};

