// Class MagicLeapImageTracker.MagicLeapImageTrackerComponent
// Size: 0x290 (Inherited: 0x210)
struct UMagicLeapImageTrackerComponent : USceneComponent {
	struct UTexture2D* TargetImageTexture; // 0x210(0x08)
	struct FString Name; // 0x218(0x10)
	float LongerDimension; // 0x228(0x04)
	bool bIsStationary; // 0x22c(0x01)
	bool bUseUnreliablePose; // 0x22d(0x01)
	char pad_22E[0x2]; // 0x22e(0x02)
	struct FMulticastInlineDelegate OnSetImageTargetSucceeded; // 0x230(0x10)
	struct FMulticastInlineDelegate OnSetImageTargetFailed; // 0x240(0x10)
	struct FMulticastInlineDelegate OnImageTargetFound; // 0x250(0x10)
	struct FMulticastInlineDelegate OnImageTargetLost; // 0x260(0x10)
	struct FMulticastInlineDelegate OnImageTargetUnreliableTracking; // 0x270(0x10)
	char pad_280[0x10]; // 0x280(0x10)

	bool SetTargetAsync(struct UTexture2D* ImageTarget); // Function MagicLeapImageTracker.MagicLeapImageTrackerComponent.SetTargetAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x2a79570
	bool RemoveTargetAsync(); // Function MagicLeapImageTracker.MagicLeapImageTrackerComponent.RemoveTargetAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x2a794d0
};

// Class MagicLeapImageTracker.MagicLeapImageTrackerFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapImageTrackerFunctionLibrary : UBlueprintFunctionLibrary {

	void SetMaxSimultaneousTargets(int32_t MaxSimultaneousTargets); // Function MagicLeapImageTracker.MagicLeapImageTrackerFunctionLibrary.SetMaxSimultaneousTargets // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a79500
	bool IsImageTrackingEnabled(); // Function MagicLeapImageTracker.MagicLeapImageTrackerFunctionLibrary.IsImageTrackingEnabled // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a794a0
	int32_t GetMaxSimultaneousTargets(); // Function MagicLeapImageTracker.MagicLeapImageTrackerFunctionLibrary.GetMaxSimultaneousTargets // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a79470
	void EnableImageTracking(bool bEnable); // Function MagicLeapImageTracker.MagicLeapImageTrackerFunctionLibrary.EnableImageTracking // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a793f0
};

