// Class MagicLeapLightEstimation.MagicLeapLightingTrackingComponent
// Size: 0xc8 (Inherited: 0xb8)
struct UMagicLeapLightingTrackingComponent : UActorComponent {
	bool UseGlobalAmbience; // 0xb8(0x01)
	bool UseColorTemp; // 0xb9(0x01)
	char pad_BA[0xe]; // 0xba(0x0e)
};

// Class MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapLightEstimationFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsTrackerValid(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.IsTrackerValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a80f90
	bool GetColorTemperatureState(struct FMagicLeapLightEstimationColorTemperatureState ColorTemperatureState); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.GetColorTemperatureState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a80f00
	bool GetAmbientGlobalState(struct FMagicLeapLightEstimationAmbientGlobalState GlobalAmbientState); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.GetAmbientGlobalState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a80e50
	void DestroyTracker(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.DestroyTracker // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a80e30
	bool CreateTracker(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.CreateTracker // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a80e00
};

