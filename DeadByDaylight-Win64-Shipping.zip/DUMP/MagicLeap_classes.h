// Class MagicLeap.InAppPurchaseComponent
// Size: 0x130 (Inherited: 0xb8)
struct UInAppPurchaseComponent : UActorComponent {
	struct FMulticastInlineDelegate InAppPurchaseLogMessage; // 0xb8(0x10)
	struct FMulticastInlineDelegate GetItemsDetailsSuccess; // 0xc8(0x10)
	struct FMulticastInlineDelegate GetItemsDetailsFailure; // 0xd8(0x10)
	struct FMulticastInlineDelegate PurchaseConfirmationSuccess; // 0xe8(0x10)
	struct FMulticastInlineDelegate PurchaseConfirmationFailure; // 0xf8(0x10)
	struct FMulticastInlineDelegate GetPurchaseHistorySuccess; // 0x108(0x10)
	struct FMulticastInlineDelegate GetPurchaseHistoryFailure; // 0x118(0x10)
	char pad_128[0x8]; // 0x128(0x08)

	bool TryPurchaseItemAsync(struct FPurchaseItemDetails ItemDetails); // Function MagicLeap.InAppPurchaseComponent.TryPurchaseItemAsync // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a5a820
	bool TryGetPurchaseHistoryAsync(int32_t InNumPages); // Function MagicLeap.InAppPurchaseComponent.TryGetPurchaseHistoryAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x2a5a790
	bool TryGetItemsDetailsAsync(struct TArray<struct FString> ItemIDs); // Function MagicLeap.InAppPurchaseComponent.TryGetItemsDetailsAsync // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a5a6b0
	void PurchaseConfirmationSuccess__DelegateSignature(struct FPurchaseConfirmation PurchaseConfirmations); // DelegateFunction MagicLeap.InAppPurchaseComponent.PurchaseConfirmationSuccess__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	void PurchaseConfirmationFailure__DelegateSignature(); // DelegateFunction MagicLeap.InAppPurchaseComponent.PurchaseConfirmationFailure__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void InAppPurchaseLogMessage__DelegateSignature(struct FString LogMessage); // DelegateFunction MagicLeap.InAppPurchaseComponent.InAppPurchaseLogMessage__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void GetPurchaseHistorySuccess__DelegateSignature(struct TArray<struct FPurchaseConfirmation> PurchaseHistory); // DelegateFunction MagicLeap.InAppPurchaseComponent.GetPurchaseHistorySuccess__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	void GetPurchaseHistoryFailure__DelegateSignature(); // DelegateFunction MagicLeap.InAppPurchaseComponent.GetPurchaseHistoryFailure__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void GetItemsDetailsSuccess__DelegateSignature(struct TArray<struct FPurchaseItemDetails> ItemsDetails); // DelegateFunction MagicLeap.InAppPurchaseComponent.GetItemsDetailsSuccess__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	void GetItemsDetailsFailure__DelegateSignature(); // DelegateFunction MagicLeap.InAppPurchaseComponent.GetItemsDetailsFailure__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
};

// Class MagicLeap.LuminApplicationLifecycleComponent
// Size: 0x198 (Inherited: 0x148)
struct ULuminApplicationLifecycleComponent : UApplicationLifecycleComponent {
	struct FMulticastInlineDelegate DeviceHasReactivatedDelegate; // 0x148(0x10)
	struct FMulticastInlineDelegate DeviceWillEnterRealityModeDelegate; // 0x158(0x10)
	struct FMulticastInlineDelegate DeviceWillGoInStandbyDelegate; // 0x168(0x10)
	struct FMulticastInlineDelegate FocusLostDelegate; // 0x178(0x10)
	struct FMulticastInlineDelegate FocusGainedDelegate; // 0x188(0x10)
};

// Class MagicLeap.MagicLeapHeadTrackingNotificationsComponent
// Size: 0x1d8 (Inherited: 0x148)
struct UMagicLeapHeadTrackingNotificationsComponent : UVRNotificationsComponent {
	struct FMulticastInlineDelegate OnHeadTrackingLost; // 0x148(0x10)
	struct FMulticastInlineDelegate OnHeadTrackingRecovered; // 0x158(0x10)
	struct FMulticastInlineDelegate OnHeadTrackingRecoveryFailed; // 0x168(0x10)
	struct FMulticastInlineDelegate OnHeadTrackingNewSessionStarted; // 0x178(0x10)
	char pad_188[0x50]; // 0x188(0x50)
};

// Class MagicLeap.MagicLeapHMDFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapHMDFunctionLibrary : UBlueprintFunctionLibrary {

	void SetStabilizationDepthActor(struct AActor* InStabilizationDepthActor, bool bSetFocusActor); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetStabilizationDepthActor // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a5a5f0
	void SetFocusActor(struct AActor* InFocusActor, bool bSetStabilizationActor); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetFocusActor // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a5a530
	void SetBaseRotation(struct FRotator InBaseRotation); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetBaseRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a5a4b0
	void SetBasePosition(struct FVector InBasePosition); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetBasePosition // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a5a4b0
	void SetBaseOrientation(struct FQuat InBaseOrientation); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetBaseOrientation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a5a4b0
	bool SetAppReady(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.SetAppReady // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a5a480
	bool IsRunningOnMagicLeapHMD(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.IsRunningOnMagicLeapHMD // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59e40
	int32_t GetPlatformAPILevel(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetPlatformAPILevel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59db0
	int32_t GetMLSDKVersionRevision(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetMLSDKVersionRevision // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59db0
	int32_t GetMLSDKVersionMinor(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetMLSDKVersionMinor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59db0
	int32_t GetMLSDKVersionMajor(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetMLSDKVersionMajor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59db0
	struct FString GetMLSDKVersion(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetMLSDKVersion // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59d30
	int32_t GetMinimumAPILevel(); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetMinimumAPILevel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a59de0
	bool GetHeadTrackingState(struct FMagicLeapHeadTrackingState State); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetHeadTrackingState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2a59ca0
	bool GetHeadTrackingMapEvents(struct TSet<enum class EMagicLeapHeadTrackingMapEvent> MapEvents); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetHeadTrackingMapEvents // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2a59b10
	bool GetGraphicsClientPerformanceInfo(struct FMagicLeapGraphicsClientPerformanceInfo PerformanceInfo); // Function MagicLeap.MagicLeapHMDFunctionLibrary.GetGraphicsClientPerformanceInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a59a60
};

// Class MagicLeap.MagicLeapMeshTrackerComponent
// Size: 0x2a0 (Inherited: 0x210)
struct UMagicLeapMeshTrackerComponent : USceneComponent {
	char pad_210[0x8]; // 0x210(0x08)
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // 0x218(0x10)
	bool ScanWorld; // 0x228(0x01)
	enum class EMagicLeapMeshType MeshType; // 0x229(0x01)
	char pad_22A[0x6]; // 0x22a(0x06)
	struct UBoxComponent* BoundingVolume; // 0x230(0x08)
	enum class EMagicLeapMeshLOD LevelOfDetail; // 0x238(0x01)
	char pad_239[0x3]; // 0x239(0x03)
	float PerimeterOfGapsToFill; // 0x23c(0x04)
	bool Planarize; // 0x240(0x01)
	char pad_241[0x3]; // 0x241(0x03)
	float DisconnectedSectionArea; // 0x244(0x04)
	bool RequestNormals; // 0x248(0x01)
	bool RequestVertexConfidence; // 0x249(0x01)
	enum class EMagicLeapMeshVertexColorMode VertexColorMode; // 0x24a(0x01)
	char pad_24B[0x5]; // 0x24b(0x05)
	struct TArray<struct FColor> BlockVertexColors; // 0x250(0x10)
	struct FLinearColor VertexColorFromConfidenceZero; // 0x260(0x10)
	struct FLinearColor VertexColorFromConfidenceOne; // 0x270(0x10)
	bool RemoveOverlappingTriangles; // 0x280(0x01)
	char pad_281[0x7]; // 0x281(0x07)
	struct UMRMeshComponent* MRMesh; // 0x288(0x08)
	int32_t BricksPerFrame; // 0x290(0x04)
	char pad_294[0xc]; // 0x294(0x0c)

	void SelectMeshBlocks(struct FMagicLeapTrackingMeshInfo NewMeshInfo, struct TArray<struct FMagicLeapMeshBlockRequest> RequestedMesh); // Function MagicLeap.MagicLeapMeshTrackerComponent.SelectMeshBlocks // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2a5a360
	void OnMeshTrackerUpdated__DelegateSignature(struct FGuid ID, struct TArray<struct FVector> Vertices, struct TArray<int32_t> Triangles, struct TArray<struct FVector> Normals, struct TArray<float> Confidence); // DelegateFunction MagicLeap.MagicLeapMeshTrackerComponent.OnMeshTrackerUpdated__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults) // @ game+0x3873200
	int32_t GetNumQueuedBlockUpdates(); // Function MagicLeap.MagicLeapMeshTrackerComponent.GetNumQueuedBlockUpdates // (Final|Native|Public|BlueprintCallable) // @ game+0x2a59e10
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MagicLeap.MagicLeapMeshTrackerComponent.DisconnectMRMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x2a599e0
	void DisconnectBlockSelector(); // Function MagicLeap.MagicLeapMeshTrackerComponent.DisconnectBlockSelector // (Final|Native|Public|BlueprintCallable) // @ game+0x2a599c0
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MagicLeap.MagicLeapMeshTrackerComponent.ConnectMRMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x2a59940
	void ConnectBlockSelector(struct TScriptInterface<None> Selector); // Function MagicLeap.MagicLeapMeshTrackerComponent.ConnectBlockSelector // (Final|Native|Public|BlueprintCallable) // @ game+0x2a598a0
};

// Class MagicLeap.MagicLeapSettings
// Size: 0x38 (Inherited: 0x30)
struct UMagicLeapSettings : UObject {
	bool bEnableZI; // 0x30(0x01)
	bool bUseVulkanForZI; // 0x31(0x01)
	bool bUseMLAudioForZI; // 0x32(0x01)
	char pad_33[0x5]; // 0x33(0x05)
};

// Class MagicLeap.MagicLeapMeshBlockSelectorInterface
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapMeshBlockSelectorInterface : UInterface {

	void SelectMeshBlocks(struct FMagicLeapTrackingMeshInfo NewMeshInfo, struct TArray<struct FMagicLeapMeshBlockRequest> RequestedMesh); // Function MagicLeap.MagicLeapMeshBlockSelectorInterface.SelectMeshBlocks // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2a5a240
};

// Class MagicLeap.MagicLeapRaycastComponent
// Size: 0x120 (Inherited: 0xb8)
struct UMagicLeapRaycastComponent : UActorComponent {
	char pad_B8[0x68]; // 0xb8(0x68)

	bool RequestRaycast(struct FMagicLeapRaycastQueryParams RequestParams, struct FDelegate ResultDelegate); // Function MagicLeap.MagicLeapRaycastComponent.RequestRaycast // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a5a0f0
	void RaycastResultDelegate__DelegateSignature(struct FMagicLeapRaycastHitResult HitResult); // DelegateFunction MagicLeap.MagicLeapRaycastComponent.RaycastResultDelegate__DelegateSignature // (Public|Delegate) // @ game+0x3873200
};

// Class MagicLeap.MagicLeapRaycastFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UMagicLeapRaycastFunctionLibrary : UBlueprintFunctionLibrary {

	struct FMagicLeapRaycastQueryParams MakeRaycastQueryParams(struct FVector Position, struct FVector Direction, struct FVector UpVector, int32_t Width, int32_t Height, float HorizontalFovDegrees, bool CollideWithUnobserved, int32_t UserData); // Function MagicLeap.MagicLeapRaycastFunctionLibrary.MakeRaycastQueryParams // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2a59e70
};

