// ScriptStruct MathUtilities.Cone
// Size: 0x20 (Inherited: 0x00)
struct FCone {
	char pad_0[0x20]; // 0x00(0x20)
};

