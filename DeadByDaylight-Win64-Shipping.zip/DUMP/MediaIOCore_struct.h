// Enum MediaIOCore.EFileMediaOutputPixelFormat
enum class EFileMediaOutputPixelFormat : uint8 {
	B8G8R8A8,
	FloatRGBA,
	EFileMediaOutputPixelFormat_MAX,
};

// Enum MediaIOCore.EMediaCaptureCroppingType
enum class EMediaCaptureCroppingType : uint8 {
	None,
	Center,
	TopLeft,
	Custom,
	EMediaCaptureCroppingType_MAX,
};

// Enum MediaIOCore.EMediaCaptureState
enum class EMediaCaptureState : uint8 {
	Error,
	Capturing,
	Preparing,
	StopRequested,
	Stopped,
	EMediaCaptureState_MAX,
};

// Enum MediaIOCore.EMediaIOReferenceType
enum class EMediaIOReferenceType : uint8 {
	FreeRun,
	External,
	Input,
	EMediaIOReferenceType_MAX,
};

// Enum MediaIOCore.EMediaIOOutputType
enum class EMediaIOOutputType : uint8 {
	Fill,
	FillAndKey,
	EMediaIOOutputType_MAX,
};

// Enum MediaIOCore.EMediaIOInputType
enum class EMediaIOInputType : uint8 {
	Fill,
	FillAndKey,
	EMediaIOInputType_MAX,
};

// Enum MediaIOCore.EMediaIOTimecodeFormat
enum class EMediaIOTimecodeFormat : uint8 {
	None,
	LTC,
	VITC,
	EMediaIOTimecodeFormat_MAX,
};

// Enum MediaIOCore.EMediaIOStandardType
enum class EMediaIOStandardType : uint8 {
	Progressive,
	Interlaced,
	ProgressiveSegmentedFrame,
	EMediaIOStandardType_MAX,
};

// Enum MediaIOCore.EMediaIOQuadLinkTransportType
enum class EMediaIOQuadLinkTransportType : uint8 {
	SquareDivision,
	TwoSampleInterleave,
	EMediaIOQuadLinkTransportType_MAX,
};

// Enum MediaIOCore.EMediaIOTransportType
enum class EMediaIOTransportType : uint8 {
	SingleLink,
	DualLink,
	QuadLink,
	HDMI,
	EMediaIOTransportType_MAX,
};

// ScriptStruct MediaIOCore.MediaCaptureOptions
// Size: 0x10 (Inherited: 0x00)
struct FMediaCaptureOptions {
	enum class EMediaCaptureCroppingType Crop; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FIntPoint CustomCapturePoint; // 0x04(0x08)
	bool bResizeSourceBuffer; // 0x0c(0x01)
	bool bSkipFrameWhenRunningExpensiveTasks; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct MediaIOCore.MediaIOOutputConfiguration
// Size: 0x54 (Inherited: 0x00)
struct FMediaIOOutputConfiguration {
	struct FMediaIOConfiguration MediaConfiguration; // 0x00(0x44)
	enum class EMediaIOOutputType OutputType; // 0x44(0x04)
	int32_t KeyPortIdentifier; // 0x48(0x04)
	enum class EMediaIOReferenceType OutputReference; // 0x4c(0x04)
	int32_t ReferencePortIdentifier; // 0x50(0x04)
};

// ScriptStruct MediaIOCore.MediaIOConfiguration
// Size: 0x44 (Inherited: 0x00)
struct FMediaIOConfiguration {
	bool bIsInput; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FMediaIOConnection MediaConnection; // 0x04(0x28)
	struct FMediaIOMode MediaMode; // 0x2c(0x18)
};

// ScriptStruct MediaIOCore.MediaIOMode
// Size: 0x18 (Inherited: 0x00)
struct FMediaIOMode {
	struct FFrameRate FrameRate; // 0x00(0x08)
	struct FIntPoint Resolution; // 0x08(0x08)
	enum class EMediaIOStandardType Standard; // 0x10(0x04)
	int32_t DeviceModeIdentifier; // 0x14(0x04)
};

// ScriptStruct MediaIOCore.MediaIOConnection
// Size: 0x28 (Inherited: 0x00)
struct FMediaIOConnection {
	struct FMediaIODevice Device; // 0x00(0x10)
	struct FName protocol; // 0x10(0x0c)
	enum class EMediaIOTransportType TransportType; // 0x1c(0x04)
	enum class EMediaIOQuadLinkTransportType QuadTransportType; // 0x20(0x04)
	int32_t PortIdentifier; // 0x24(0x04)
};

// ScriptStruct MediaIOCore.MediaIODevice
// Size: 0x10 (Inherited: 0x00)
struct FMediaIODevice {
	struct FName DeviceName; // 0x00(0x0c)
	int32_t DeviceIdentifier; // 0x0c(0x04)
};

// ScriptStruct MediaIOCore.MediaIOInputConfiguration
// Size: 0x4c (Inherited: 0x00)
struct FMediaIOInputConfiguration {
	struct FMediaIOConfiguration MediaConfiguration; // 0x00(0x44)
	enum class EMediaIOInputType inputType; // 0x44(0x04)
	int32_t KeyPortIdentifier; // 0x48(0x04)
};

