// Enum MirrorsSdk.EMirrorsRequestLogLevel
enum class EMirrorsRequestLogLevel : uint8 {
	None,
	NetworkError,
	HttpError,
	All,
	EMirrorsRequestLogLevel_MAX,
};

