// Class ModelingComponents.BaseDynamicMeshComponent
// Size: 0x4c0 (Inherited: 0x480)
struct UBaseDynamicMeshComponent : UMeshComponent {
	char pad_480[0x40]; // 0x480(0x40)
};

// Class ModelingComponents.CollectSurfacePathMechanic
// Size: 0x5b0 (Inherited: 0x38)
struct UCollectSurfacePathMechanic : UInteractionMechanic {
	char pad_38[0x578]; // 0x38(0x578)
};

// Class ModelingComponents.ConstructionPlaneMechanic
// Size: 0x100 (Inherited: 0x38)
struct UConstructionPlaneMechanic : UInteractionMechanic {
	char pad_38[0xa0]; // 0x38(0xa0)
	struct UTransformGizmo* PlaneTransformGizmo; // 0xd8(0x08)
	struct UTransformProxy* PlaneTransformProxy; // 0xe0(0x08)
	char pad_E8[0x10]; // 0xe8(0x10)
	struct USingleClickInputBehavior* ClickToSetPlaneBehavior; // 0xf8(0x08)
};

// Class ModelingComponents.DynamicMeshReplacementChangeTarget
// Size: 0x60 (Inherited: 0x30)
struct UDynamicMeshReplacementChangeTarget : UObject {
	char pad_30[0x30]; // 0x30(0x30)
};

// Class ModelingComponents.MeshCommandChangeTarget
// Size: 0x30 (Inherited: 0x30)
struct UMeshCommandChangeTarget : UInterface {
};

// Class ModelingComponents.MeshOpPreviewWithBackgroundCompute
// Size: 0x80 (Inherited: 0x30)
struct UMeshOpPreviewWithBackgroundCompute : UObject {
	char pad_30[0x18]; // 0x30(0x18)
	struct UPreviewMesh* PreviewMesh; // 0x48(0x08)
	struct TArray<struct UMaterialInterface*> StandardMaterials; // 0x50(0x10)
	struct UMaterialInterface* OverrideMaterial; // 0x60(0x08)
	struct UMaterialInterface* WorkingMaterial; // 0x68(0x08)
	char pad_70[0x10]; // 0x70(0x10)
};

// Class ModelingComponents.MeshReplacementCommandChangeTarget
// Size: 0x30 (Inherited: 0x30)
struct UMeshReplacementCommandChangeTarget : UInterface {
};

// Class ModelingComponents.MeshVertexCommandChangeTarget
// Size: 0x30 (Inherited: 0x30)
struct UMeshVertexCommandChangeTarget : UInterface {
};

// Class ModelingComponents.MultiTransformer
// Size: 0x140 (Inherited: 0x30)
struct UMultiTransformer : UObject {
	char pad_30[0xb0]; // 0x30(0xb0)
	struct UTransformGizmo* TransformGizmo; // 0xe0(0x08)
	struct UTransformProxy* TransformProxy; // 0xe8(0x08)
	char pad_F0[0x50]; // 0xf0(0x50)
};

// Class ModelingComponents.OctreeDynamicMeshComponent
// Size: 0x5d0 (Inherited: 0x4c0)
struct UOctreeDynamicMeshComponent : UBaseDynamicMeshComponent {
	char pad_4C0[0x18]; // 0x4c0(0x18)
	bool bExplicitShowWireframe; // 0x4d8(0x01)
	char pad_4D9[0xf7]; // 0x4d9(0xf7)
};

// Class ModelingComponents.PlaneDistanceFromHitMechanic
// Size: 0x480 (Inherited: 0x38)
struct UPlaneDistanceFromHitMechanic : UInteractionMechanic {
	char pad_38[0x448]; // 0x38(0x448)
};

// Class ModelingComponents.PointSetComponent
// Size: 0x4e0 (Inherited: 0x480)
struct UPointSetComponent : UMeshComponent {
	struct UMaterialInterface* PointMaterial; // 0x478(0x08)
	struct FBoxSphereBounds Bounds; // 0x480(0x1c)
	bool bBoundsDirty; // 0x49c(0x01)
	char pad_4A5[0x3b]; // 0x4a5(0x3b)
};

// Class ModelingComponents.PreviewMesh
// Size: 0x130 (Inherited: 0x30)
struct UPreviewMesh : UObject {
	char pad_30[0x18]; // 0x30(0x18)
	bool bBuildSpatialDataStructure; // 0x48(0x01)
	bool bDrawOnTop; // 0x49(0x01)
	char pad_4A[0xe]; // 0x4a(0x0e)
	struct USimpleDynamicMeshComponent* DynamicMeshComponent; // 0x58(0x08)
	char pad_60[0xd0]; // 0x60(0xd0)
};

// Class ModelingComponents.PolyEditPreviewMesh
// Size: 0x510 (Inherited: 0x130)
struct UPolyEditPreviewMesh : UPreviewMesh {
	char pad_130[0x3e0]; // 0x130(0x3e0)
};

// Class ModelingComponents.PolygonSelectionMechanicProperties
// Size: 0x60 (Inherited: 0x58)
struct UPolygonSelectionMechanicProperties : UInteractiveToolPropertySet {
	bool bSelectFaces; // 0x58(0x01)
	bool bSelectEdges; // 0x59(0x01)
	bool bSelectVertices; // 0x5a(0x01)
	char pad_5B[0x5]; // 0x5b(0x05)
};

// Class ModelingComponents.PolygonSelectionMechanic
// Size: 0x5c0 (Inherited: 0x38)
struct UPolygonSelectionMechanic : UInteractionMechanic {
	char pad_38[0x20]; // 0x38(0x20)
	struct UPolygonSelectionMechanicProperties* Properties; // 0x58(0x08)
	char pad_60[0x560]; // 0x60(0x560)
};

// Class ModelingComponents.PreviewMeshActor
// Size: 0x230 (Inherited: 0x230)
struct APreviewMeshActor : AInternalToolFrameworkActor {
};

// Class ModelingComponents.SimpleDynamicMeshComponent
// Size: 0x5e0 (Inherited: 0x4c0)
struct USimpleDynamicMeshComponent : UBaseDynamicMeshComponent {
	enum class EDynamicMeshTangentCalcType TangentsType; // 0x4c0(0x01)
	char pad_4C1[0x1f]; // 0x4c1(0x1f)
	bool bExplicitShowWireframe; // 0x4e0(0x01)
	char pad_4E1[0x4f]; // 0x4e1(0x4f)
	bool bDrawOnTop; // 0x530(0x01)
	char pad_531[0xaf]; // 0x531(0xaf)
};

// Class ModelingComponents.SpatialCurveDistanceMechanic
// Size: 0x450 (Inherited: 0x38)
struct USpatialCurveDistanceMechanic : UInteractionMechanic {
	char pad_38[0x418]; // 0x38(0x418)
};

