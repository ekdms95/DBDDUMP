// Class Niagara.NiagaraDataInterface
// Size: 0x38 (Inherited: 0x30)
struct UNiagaraDataInterface : UNiagaraDataInterfaceBase {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class Niagara.MovieSceneNiagaraTrack
// Size: 0x70 (Inherited: 0x60)
struct UMovieSceneNiagaraTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x60(0x10)
};

// Class Niagara.MovieSceneNiagaraParameterTrack
// Size: 0xa0 (Inherited: 0x70)
struct UMovieSceneNiagaraParameterTrack : UMovieSceneNiagaraTrack {
	struct FNiagaraVariable Parameter; // 0x70(0x30)
};

// Class Niagara.MovieSceneNiagaraBoolParameterTrack
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNiagaraBoolParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraColorParameterTrack
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNiagaraColorParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraFloatParameterTrack
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNiagaraFloatParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraIntegerParameterTrack
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNiagaraIntegerParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraSystemSpawnSection
// Size: 0xf8 (Inherited: 0xe8)
struct UMovieSceneNiagaraSystemSpawnSection : UMovieSceneSection {
	enum class ENiagaraSystemSpawnSectionStartBehavior SectionStartBehavior; // 0xe8(0x04)
	enum class ENiagaraSystemSpawnSectionEvaluateBehavior SectionEvaluateBehavior; // 0xec(0x04)
	enum class ENiagaraSystemSpawnSectionEndBehavior SectionEndBehavior; // 0xf0(0x04)
	enum class ENiagaraAgeUpdateMode AgeUpdateMode; // 0xf4(0x01)
	char pad_F5[0x3]; // 0xf5(0x03)
};

// Class Niagara.MovieSceneNiagaraSystemTrack
// Size: 0x70 (Inherited: 0x70)
struct UMovieSceneNiagaraSystemTrack : UMovieSceneNiagaraTrack {
};

// Class Niagara.MovieSceneNiagaraVectorParameterTrack
// Size: 0xa8 (Inherited: 0xa0)
struct UMovieSceneNiagaraVectorParameterTrack : UMovieSceneNiagaraParameterTrack {
	int32_t ChannelsUsed; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
};

// Class Niagara.NiagaraActor
// Size: 0x240 (Inherited: 0x230)
struct ANiagaraActor : AActor {
	struct UNiagaraComponent* NiagaraComponent; // 0x230(0x08)
	char bDestroyOnSystemFinish : 1; // 0x238(0x01)
	char pad_238_1 : 7; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)

	void SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish); // Function Niagara.NiagaraActor.SetDestroyOnSystemFinish // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a0de60
	void OnNiagaraSystemFinished(struct UNiagaraComponent* FinishedComponent); // Function Niagara.NiagaraActor.OnNiagaraSystemFinished // (Final|Native|Private) // @ game+0x2a0d9f0
};

// Class Niagara.NiagaraComponent
// Size: 0x5e0 (Inherited: 0x430)
struct UNiagaraComponent : UFXSystemComponent {
	struct UNiagaraSystem* Asset; // 0x428(0x08)
	enum class ENiagaraTickBehavior TickBehavior; // 0x430(0x01)
	struct FNiagaraUserRedirectionParameterStore OverrideParameters; // 0x438(0x108)
	char bForceSolo : 1; // 0x540(0x01)
	char pad_541_1 : 7; // 0x541(0x01)
	char pad_542[0x2a]; // 0x542(0x2a)
	char bAutoDestroy : 1; // 0x56c(0x01)
	char bRenderingEnabled : 1; // 0x56c(0x01)
	char bAutoManageAttachment : 1; // 0x56c(0x01)
	char bAutoAttachWeldSimulatedBodies : 1; // 0x56c(0x01)
	char pad_56C_4 : 4; // 0x56c(0x01)
	char pad_56D[0x3]; // 0x56d(0x03)
	float MaxTimeBeforeForceUpdateTransform; // 0x570(0x04)
	char pad_574[0x4]; // 0x574(0x04)
	struct FMulticastInlineDelegate OnSystemFinished; // 0x578(0x10)
	struct TWeakObjectPtr<struct USceneComponent> AutoAttachParent; // 0x588(0x08)
	struct FName AutoAttachSocketName; // 0x590(0x0c)
	enum class EAttachmentRule AutoAttachLocationRule; // 0x59c(0x01)
	enum class EAttachmentRule AutoAttachRotationRule; // 0x59d(0x01)
	enum class EAttachmentRule AutoAttachScaleRule; // 0x59e(0x01)
	char pad_59F[0x41]; // 0x59f(0x41)

	void SetVariableVec4(struct FName InVariableName, struct FVector4 InValue); // Function Niagara.NiagaraComponent.SetVariableVec4 // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0f270
	void SetVariableVec3(struct FName InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetVariableVec3 // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a0f180
	void SetVariableVec2(struct FName InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetVariableVec2 // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a0f0a0
	void SetVariableQuat(struct FName InVariableName, struct FQuat InValue); // Function Niagara.NiagaraComponent.SetVariableQuat // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0efb0
	void SetVariableObject(struct FName InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetVariableObject // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0ea60
	void SetVariableMaterial(struct FName InVariableName, struct UMaterialInterface* Object); // Function Niagara.NiagaraComponent.SetVariableMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0eed0
	void SetVariableLinearColor(struct FName InVariableName, struct FLinearColor InValue); // Function Niagara.NiagaraComponent.SetVariableLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0ede0
	void SetVariableInt(struct FName InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetVariableInt // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0ed00
	void SetVariableFloat(struct FName InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetVariableFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0ec20
	void SetVariableBool(struct FName InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetVariableBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0eb40
	void SetVariableActor(struct FName InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetVariableActor // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0ea60
	void SetSeekDelta(float InSeekDelta); // Function Niagara.NiagaraComponent.SetSeekDelta // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e9e0
	void SetRenderingEnabled(bool bInRenderingEnabled); // Function Niagara.NiagaraComponent.SetRenderingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e950
	void SetPreviewLODDistance(bool bEnablePreviewLODDistance, float PreviewLODDistance); // Function Niagara.NiagaraComponent.SetPreviewLODDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e880
	void SetPaused(bool bInPaused); // Function Niagara.NiagaraComponent.SetPaused // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e7f0
	void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4 InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec4 // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0e700
	void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec3 // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a0e610
	void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec2 // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a0e540
	void SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableQuat // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0e460
	void SetNiagaraVariableObject(struct FString InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetNiagaraVariableObject // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e000
	void SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a0e380
	void SetNiagaraVariableInt(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableInt // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e2a0
	void SetNiagaraVariableFloat(struct FString InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e1c0
	void SetNiagaraVariableBool(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e0e0
	void SetNiagaraVariableActor(struct FString InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetNiagaraVariableActor // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0e000
	void SetMaxSimTime(float InMaxTime); // Function Niagara.NiagaraComponent.SetMaxSimTime // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0df80
	void SetForceSolo(bool bInForceSolo); // Function Niagara.NiagaraComponent.SetForceSolo // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0def0
	void SetDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SetDesiredAge // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dde0
	void SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking); // Function Niagara.NiagaraComponent.SetCanRenderWhileSeeking // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dd50
	void SetAutoDestroy(bool bInAutoDestroy); // Function Niagara.NiagaraComponent.SetAutoDestroy // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dcc0
	void SetAsset(struct UNiagaraSystem* InAsset); // Function Niagara.NiagaraComponent.SetAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dc40
	void SetAllowScalability(bool bAllow); // Function Niagara.NiagaraComponent.SetAllowScalability // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dbb0
	void SetAgeUpdateMode(enum class ENiagaraAgeUpdateMode InAgeUpdateMode); // Function Niagara.NiagaraComponent.SetAgeUpdateMode // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0db30
	void SeekToDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SeekToDesiredAge // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0dab0
	void ResetSystem(); // Function Niagara.NiagaraComponent.ResetSystem // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0da90
	void ReinitializeSystem(); // Function Niagara.NiagaraComponent.ReinitializeSystem // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0da70
	bool IsPaused(); // Function Niagara.NiagaraComponent.IsPaused // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d9c0
	float GetSeekDelta(); // Function Niagara.NiagaraComponent.GetSeekDelta // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d990
	bool GetPreviewLODDistanceEnabled(); // Function Niagara.NiagaraComponent.GetPreviewLODDistanceEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d970
	int32_t GetPreviewLODDistance(); // Function Niagara.NiagaraComponent.GetPreviewLODDistance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d950
	struct TArray<struct FVector> GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValueVec3_DebugOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d6d0
	struct TArray<float> GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValues_DebugOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d810
	struct TArray<struct FVector> GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName); // Function Niagara.NiagaraComponent.GetNiagaraParticlePositions_DebugOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d5e0
	float GetMaxSimTime(); // Function Niagara.NiagaraComponent.GetMaxSimTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d5b0
	bool GetForceSolo(); // Function Niagara.NiagaraComponent.GetForceSolo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d580
	float GetDesiredAge(); // Function Niagara.NiagaraComponent.GetDesiredAge // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d550
	struct UNiagaraDataInterface* GetDataInterface(struct FString Name); // Function Niagara.NiagaraComponent.GetDataInterface // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d4a0
	struct UNiagaraSystem* GetAsset(); // Function Niagara.NiagaraComponent.GetAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d480
	enum class ENiagaraAgeUpdateMode GetAgeUpdateMode(); // Function Niagara.NiagaraComponent.GetAgeUpdateMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a0d450
	void AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulationByTime // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d390
	void AdvanceSimulation(int32_t TickCount, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulation // (Final|Native|Public|BlueprintCallable) // @ game+0x2a0d2c0
};

// Class Niagara.NiagaraComponentPool
// Size: 0x88 (Inherited: 0x30)
struct UNiagaraComponentPool : UObject {
	struct TMap<struct UNiagaraSystem*, struct FNCPool> WorldParticleSystemPools; // 0x30(0x50)
	char pad_80[0x8]; // 0x80(0x08)
};

// Class Niagara.NiagaraConvertInPlaceUtilityBase
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraConvertInPlaceUtilityBase : UObject {
};

// Class Niagara.NiagaraDataInterfaceAudioSubmix
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceAudioSubmix : UNiagaraDataInterface {
	struct USoundSubmix* Submix; // 0x38(0x08)
};

// Class Niagara.NiagaraDataInterfaceAudioOscilloscope
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceAudioOscilloscope : UNiagaraDataInterface {
	struct USoundSubmix* Submix; // 0x38(0x08)
	int32_t Resolution; // 0x40(0x04)
	float ScopeInMilliseconds; // 0x44(0x04)
};

// Class Niagara.NiagaraDataInterfaceAudioSpectrum
// Size: 0x50 (Inherited: 0x40)
struct UNiagaraDataInterfaceAudioSpectrum : UNiagaraDataInterfaceAudioSubmix {
	int32_t Resolution; // 0x40(0x04)
	float MinimumFrequency; // 0x44(0x04)
	float MaximumFrequency; // 0x48(0x04)
	float NoiseFloorDb; // 0x4c(0x04)
};

// Class Niagara.NiagaraDataInterfaceCamera
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceCamera : UNiagaraDataInterface {
	int32_t PlayerControllerIndex; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Niagara.NiagaraDataInterfaceCollisionQuery
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceCollisionQuery : UNiagaraDataInterface {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class Niagara.NiagaraDataInterfaceCurveBase
// Size: 0x60 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurveBase : UNiagaraDataInterface {
	struct TArray<float> ShaderLUT; // 0x38(0x10)
	float LUTMinTime; // 0x48(0x04)
	float LUTMaxTime; // 0x4c(0x04)
	float LUTInvTimeRange; // 0x50(0x04)
	float LUTNumSamplesMinusOne; // 0x54(0x04)
	char bUseLUT : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Niagara.NiagaraDataInterfaceColorCurve
// Size: 0x260 (Inherited: 0x60)
struct UNiagaraDataInterfaceColorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve RedCurve; // 0x60(0x80)
	struct FRichCurve GreenCurve; // 0xe0(0x80)
	struct FRichCurve BlueCurve; // 0x160(0x80)
	struct FRichCurve AlphaCurve; // 0x1e0(0x80)
};

// Class Niagara.NiagaraDataInterfaceCurlNoise
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurlNoise : UNiagaraDataInterface {
	uint32_t Seed; // 0x38(0x04)
	char pad_3C[0xc]; // 0x3c(0x0c)
};

// Class Niagara.NiagaraDataInterfaceCurve
// Size: 0xe0 (Inherited: 0x60)
struct UNiagaraDataInterfaceCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve Curve; // 0x60(0x80)
};

// Class Niagara.NiagaraParticleCallbackHandler
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraParticleCallbackHandler : UInterface {

	void ReceiveParticleData(struct TArray<struct FBasicParticleData> Data, struct UNiagaraSystem* NiagaraSystem); // Function Niagara.NiagaraParticleCallbackHandler.ReceiveParticleData // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2a13e90
};

// Class Niagara.NiagaraDataInterfaceExport
// Size: 0x68 (Inherited: 0x38)
struct UNiagaraDataInterfaceExport : UNiagaraDataInterface {
	struct FNiagaraUserParameterBinding CallbackHandlerParameter; // 0x38(0x30)
};

// Class Niagara.NiagaraDataInterfaceRWBase
// Size: 0xd8 (Inherited: 0x38)
struct UNiagaraDataInterfaceRWBase : UNiagaraDataInterface {
	struct TSet<int32_t> OutputShaderStages; // 0x38(0x50)
	struct TSet<int32_t> IterationShaderStages; // 0x88(0x50)
};

// Class Niagara.NiagaraDataInterfaceGrid2D
// Size: 0xf8 (Inherited: 0xd8)
struct UNiagaraDataInterfaceGrid2D : UNiagaraDataInterfaceRWBase {
	int32_t NumCellsX; // 0xd8(0x04)
	int32_t NumCellsY; // 0xdc(0x04)
	int32_t NumCellsMaxAxis; // 0xe0(0x04)
	int32_t NumAttributes; // 0xe4(0x04)
	bool SetGridFromMaxAxis; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct FVector2D WorldBBoxSize; // 0xec(0x08)
	char pad_F4[0x4]; // 0xf4(0x04)
};

// Class Niagara.NiagaraDataInterfaceGrid2DCollection
// Size: 0x148 (Inherited: 0xf8)
struct UNiagaraDataInterfaceGrid2DCollection : UNiagaraDataInterfaceGrid2D {
	char pad_F8[0x50]; // 0xf8(0x50)

	void GetTextureSize(struct UNiagaraComponent* Component, int32_t SizeX, int32_t SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetTextureSize // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a13d70
	void GetRawTextureSize(struct UNiagaraComponent* Component, int32_t SizeX, int32_t SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetRawTextureSize // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a13c50
	bool FillTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t AttributeIndex); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillTexture2D // (Native|Public|BlueprintCallable) // @ game+0x2a13b40
	bool FillRawTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t TilesX, int32_t TilesY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillRawTexture2D // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a139d0
};

// Class Niagara.NiagaraDataInterfaceGrid3D
// Size: 0xf8 (Inherited: 0xd8)
struct UNiagaraDataInterfaceGrid3D : UNiagaraDataInterfaceRWBase {
	struct FIntVector NumVoxels; // 0xd8(0x0c)
	float VoxelSize; // 0xe4(0x04)
	bool SetGridFromVoxelSize; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct FVector WorldBBoxSize; // 0xec(0x0c)
};

// Class Niagara.NiagaraDataInterfaceNeighborGrid3D
// Size: 0x100 (Inherited: 0xf8)
struct UNiagaraDataInterfaceNeighborGrid3D : UNiagaraDataInterfaceGrid3D {
	uint32_t MaxNeighborsPerVoxel; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// Class Niagara.NiagaraDataInterfaceOcclusion
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterfaceOcclusion : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceParticleRead
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceParticleRead : UNiagaraDataInterface {
	struct FString EmitterName; // 0x38(0x10)
};

// Class Niagara.NiagaraDataInterfaceSimpleCounter
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterfaceSimpleCounter : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceSkeletalMesh
// Size: 0xd0 (Inherited: 0x38)
struct UNiagaraDataInterfaceSkeletalMesh : UNiagaraDataInterface {
	struct AActor* Source; // 0x38(0x08)
	struct FNiagaraUserParameterBinding MeshUserParameter; // 0x40(0x30)
	struct USkeletalMeshComponent* SourceComponent; // 0x70(0x08)
	enum class ENDISkeletalMesh_SkinningMode SkinningMode; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<struct FName> SamplingRegions; // 0x80(0x10)
	int32_t WholeMeshLOD; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct TArray<struct FName> FilteredBones; // 0x98(0x10)
	struct TArray<struct FName> FilteredSockets; // 0xa8(0x10)
	struct FName ExcludeBoneName; // 0xb8(0x0c)
	char bExcludeBone : 1; // 0xc4(0x01)
	char pad_C4_1 : 7; // 0xc4(0x01)
	char pad_C5[0xb]; // 0xc5(0x0b)
};

// Class Niagara.NiagaraDataInterfaceSpline
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceSpline : UNiagaraDataInterface {
	struct AActor* Source; // 0x38(0x08)
};

// Class Niagara.NiagaraDataInterfaceStaticMesh
// Size: 0x68 (Inherited: 0x38)
struct UNiagaraDataInterfaceStaticMesh : UNiagaraDataInterface {
	struct UStaticMesh* DefaultMesh; // 0x38(0x08)
	struct AActor* Source; // 0x40(0x08)
	struct UStaticMeshComponent* SourceComponent; // 0x48(0x08)
	struct FNDIStaticMeshSectionFilter SectionFilter; // 0x50(0x10)
	char pad_60[0x8]; // 0x60(0x08)
};

// Class Niagara.NiagaraDataInterfaceTexture
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceTexture : UNiagaraDataInterface {
	struct UTexture* Texture; // 0x38(0x08)
};

// Class Niagara.NiagaraDataInterfaceVector2DCurve
// Size: 0x160 (Inherited: 0x60)
struct UNiagaraDataInterfaceVector2DCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0x60(0x80)
	struct FRichCurve YCurve; // 0xe0(0x80)
};

// Class Niagara.NiagaraDataInterfaceVector4Curve
// Size: 0x260 (Inherited: 0x60)
struct UNiagaraDataInterfaceVector4Curve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0x60(0x80)
	struct FRichCurve YCurve; // 0xe0(0x80)
	struct FRichCurve ZCurve; // 0x160(0x80)
	struct FRichCurve WCurve; // 0x1e0(0x80)
};

// Class Niagara.NiagaraDataInterfaceVectorCurve
// Size: 0x1e0 (Inherited: 0x60)
struct UNiagaraDataInterfaceVectorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0x60(0x80)
	struct FRichCurve YCurve; // 0xe0(0x80)
	struct FRichCurve ZCurve; // 0x160(0x80)
};

// Class Niagara.NiagaraDataInterfaceVectorField
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceVectorField : UNiagaraDataInterface {
	struct UVectorField* Field; // 0x38(0x08)
	bool bTileX; // 0x40(0x01)
	bool bTileY; // 0x41(0x01)
	bool bTileZ; // 0x42(0x01)
	char pad_43[0x5]; // 0x43(0x05)
};

// Class Niagara.NiagaraDataInterfaceVolumeTexture
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceVolumeTexture : UNiagaraDataInterface {
	struct UVolumeTexture* Texture; // 0x38(0x08)
};

// Class Niagara.NiagaraEditorDataBase
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraEditorDataBase : UObject {
};

// Class Niagara.NiagaraEffectType
// Size: 0x108 (Inherited: 0x30)
struct UNiagaraEffectType : UObject {
	enum class ENiagaraScalabilityUpdateFrequency UpdateFrequency; // 0x30(0x04)
	enum class ENiagaraCullReaction CullReaction; // 0x34(0x04)
	struct TArray<struct FNiagaraSystemScalabilitySettings> DetailLevelScalabilitySettings; // 0x38(0x10)
	struct FNiagaraSystemScalabilitySettingsArray SystemScalabilitySettings; // 0x48(0x10)
	struct FNiagaraEmitterScalabilitySettingsArray EmitterScalabilitySettings; // 0x58(0x10)
	char pad_68[0xa0]; // 0x68(0xa0)
};

// Class Niagara.NiagaraEmitter
// Size: 0x2b8 (Inherited: 0x30)
struct UNiagaraEmitter : UObject {
	bool bLocalSpace; // 0x30(0x01)
	bool bDeterminism; // 0x31(0x01)
	char pad_32[0x2]; // 0x32(0x02)
	int32_t RandomSeed; // 0x34(0x04)
	enum class EParticleAllocationMode AllocationMode; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t PreAllocationCount; // 0x3c(0x04)
	struct FNiagaraEmitterScriptProperties UpdateScriptProps; // 0x40(0x28)
	struct FNiagaraEmitterScriptProperties SpawnScriptProps; // 0x68(0x28)
	struct FNiagaraEmitterScriptProperties EmitterSpawnScriptProps; // 0x90(0x28)
	struct FNiagaraEmitterScriptProperties EmitterUpdateScriptProps; // 0xb8(0x28)
	enum class ENiagaraSimTarget SimTarget; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	struct FBox FixedBounds; // 0xe4(0x1c)
	int32_t MinDetailLevel; // 0x100(0x04)
	int32_t MaxDetailLevel; // 0x104(0x04)
	struct FNiagaraDetailsLevelScaleOverrides GlobalSpawnCountScaleOverrides; // 0x108(0x14)
	char pad_11C[0x4]; // 0x11c(0x04)
	struct FNiagaraPlatformSet Platforms; // 0x120(0x20)
	struct FNiagaraEmitterScalabilityOverrides ScalabilityOverrides; // 0x140(0x10)
	char bInterpolatedSpawning : 1; // 0x150(0x01)
	char bFixedBounds : 1; // 0x150(0x01)
	char bUseMinDetailLevel : 1; // 0x150(0x01)
	char bUseMaxDetailLevel : 1; // 0x150(0x01)
	char bOverrideGlobalSpawnCountScale : 1; // 0x150(0x01)
	char bRequiresPersistentIDs : 1; // 0x150(0x01)
	char pad_150_6 : 2; // 0x150(0x01)
	char pad_151[0x3]; // 0x151(0x03)
	float MaxDeltaTimePerTick; // 0x154(0x04)
	uint32_t DefaultShaderStageIndex; // 0x158(0x04)
	uint32_t MaxUpdateIterations; // 0x15c(0x04)
	struct TSet<uint32_t> SpawnStages; // 0x160(0x50)
	char bSimulationStagesEnabled : 1; // 0x1b0(0x01)
	char bDeprecatedShaderStagesEnabled : 1; // 0x1b0(0x01)
	char bLimitDeltaTime : 1; // 0x1b0(0x01)
	char pad_1B0_3 : 5; // 0x1b0(0x01)
	char pad_1B1[0x7]; // 0x1b1(0x07)
	struct FString UniqueEmitterName; // 0x1b8(0x10)
	struct TArray<struct UNiagaraRendererProperties*> RendererProperties; // 0x1c8(0x10)
	struct TArray<struct FNiagaraEventScriptProperties> EventHandlerScriptProps; // 0x1d8(0x10)
	struct TArray<struct UNiagaraSimulationStageBase*> SimulationStages; // 0x1e8(0x10)
	struct UNiagaraScript* GPUComputeScript; // 0x1f8(0x08)
	struct TArray<struct FName> SharedEventGeneratorIds; // 0x200(0x10)
	char pad_210[0xa8]; // 0x210(0xa8)
};

// Class Niagara.NiagaraEventReceiverEmitterAction
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraEventReceiverEmitterAction : UObject {
};

// Class Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles
// Size: 0x38 (Inherited: 0x30)
struct UNiagaraEventReceiverEmitterAction_SpawnParticles : UNiagaraEventReceiverEmitterAction {
	uint32_t NumParticles; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class Niagara.NiagaraFunctionLibrary
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraFunctionLibrary : UBlueprintFunctionLibrary {

	struct UNiagaraComponent* SpawnSystemAttached(struct UNiagaraSystem* SystemTemplate, struct USceneComponent* AttachToComponent, struct FName attachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bAutoDestroy, bool bAutoActivate, enum class ENCPoolMethod PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttached // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x2a17390
	struct UNiagaraComponent* SpawnSystemAtLocation(struct UObject* WorldContextObject, struct UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, struct FVector Scale, bool bAutoDestroy, bool bAutoActivate, enum class ENCPoolMethod PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x2a170e0
	void SetVolumeTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UVolumeTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetVolumeTextureObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a16fd0
	void SetTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetTextureObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a16c10
	void OverrideSystemUserVariableStaticMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMeshComponent* StaticMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMeshComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a166a0
	void OverrideSystemUserVariableStaticMesh(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMesh* StaticMesh); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMesh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a16590
	void OverrideSystemUserVariableSkeletalMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct USkeletalMeshComponent* SkeletalMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableSkeletalMeshComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a16480
	struct UNiagaraParameterCollectionInstance* GetNiagaraParameterCollection(struct UObject* WorldContextObject, struct UNiagaraParameterCollection* Collection); // Function Niagara.NiagaraFunctionLibrary.GetNiagaraParameterCollection // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a160f0
};

// Class Niagara.NiagaraRendererProperties
// Size: 0x58 (Inherited: 0x30)
struct UNiagaraRendererProperties : UNiagaraMergeable {
	int32_t SortOrderHint; // 0x30(0x04)
	bool bIsEnabled; // 0x34(0x01)
	bool bMotionBlurEnabled; // 0x35(0x01)
	char pad_36[0x22]; // 0x36(0x22)
};

// Class Niagara.NiagaraLightRendererProperties
// Size: 0x3d0 (Inherited: 0x58)
struct UNiagaraLightRendererProperties : UNiagaraRendererProperties {
	char bUseInverseSquaredFalloff : 1; // 0x58(0x01)
	char bAffectsTranslucency : 1; // 0x58(0x01)
	char bOverrideRenderingEnabled : 1; // 0x58(0x01)
	char pad_58_3 : 5; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	float RadiusScale; // 0x5c(0x04)
	struct FVector ColorAdd; // 0x60(0x0c)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FNiagaraVariableAttributeBinding LightRenderingEnabledBinding; // 0x70(0x90)
	struct FNiagaraVariableAttributeBinding LightExponentBinding; // 0x100(0x90)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x190(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x220(0x90)
	struct FNiagaraVariableAttributeBinding RadiusBinding; // 0x2b0(0x90)
	struct FNiagaraVariableAttributeBinding VolumetricScatteringBinding; // 0x340(0x90)
};

// Class Niagara.NiagaraMeshRendererProperties
// Size: 0x880 (Inherited: 0x58)
struct UNiagaraMeshRendererProperties : UNiagaraRendererProperties {
	struct UStaticMesh* ParticleMesh; // 0x58(0x08)
	enum class ENiagaraSortMode SortMode; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	char bOverrideMaterials : 1; // 0x64(0x01)
	char bSortOnlyWhenTranslucent : 1; // 0x64(0x01)
	char pad_64_2 : 6; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	struct TArray<struct FNiagaraMeshMaterialOverride> OverrideMaterials; // 0x68(0x10)
	struct FVector2D SubImageSize; // 0x78(0x08)
	char bSubImageBlend : 1; // 0x80(0x01)
	char pad_80_1 : 7; // 0x80(0x01)
	char pad_81[0x3]; // 0x81(0x03)
	enum class ENiagaraMeshFacingMode FacingMode; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
	char bLockedAxisEnable : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	struct FVector LockedAxis; // 0x8c(0x0c)
	enum class ENiagaraMeshLockedAxisSpace LockedAxisSpace; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0xa0(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x130(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x1c0(0x90)
	struct FNiagaraVariableAttributeBinding MeshOrientationBinding; // 0x250(0x90)
	struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x2e0(0x90)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x370(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x400(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x490(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x520(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x5b0(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x640(0x90)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x6d0(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x760(0x90)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x7f0(0x90)
};

// Class Niagara.NiagaraParameterCollectionInstance
// Size: 0x100 (Inherited: 0x30)
struct UNiagaraParameterCollectionInstance : UObject {
	struct UNiagaraParameterCollection* Collection; // 0x30(0x08)
	struct TArray<struct FNiagaraVariable> OverridenParameters; // 0x38(0x10)
	struct FNiagaraParameterStore ParameterStorage; // 0x48(0xb8)

	void SetVectorParameter(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a16ee0
	void SetVector4Parameter(struct FString InVariableName, struct FVector4 InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector4Parameter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a16df0
	void SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector2DParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a16d20
	void SetQuatParameter(struct FString InVariableName, struct FQuat InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetQuatParameter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2a16b30
	void SetIntParameter(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetIntParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a16a50
	void SetFloatParameter(struct FString InVariableName, float InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetFloatParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a16970
	void SetColorParameter(struct FString InVariableName, struct FLinearColor InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetColorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a16890
	void SetBoolParameter(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetBoolParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a167b0
	struct FVector GetVectorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a163c0
	struct FVector4 GetVector4Parameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector4Parameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a16310
	struct FVector2D GetVector2DParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector2DParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a16260
	struct FQuat GetQuatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetQuatParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a161b0
	int32_t GetIntParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetIntParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a16040
	float GetFloatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetFloatParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a15f90
	struct FLinearColor GetColorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetColorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2a15ee0
	bool GetBoolParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetBoolParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x2a15e30
};

// Class Niagara.NiagaraParameterCollection
// Size: 0x68 (Inherited: 0x30)
struct UNiagaraParameterCollection : UObject {
	struct FName Namespace; // 0x30(0x0c)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TArray<struct FNiagaraVariable> Parameters; // 0x40(0x10)
	struct UNiagaraParameterCollectionInstance* DefaultInstance; // 0x50(0x08)
	struct FGuid CompileId; // 0x58(0x10)
};

// Class Niagara.NiagaraPrecompileContainer
// Size: 0x48 (Inherited: 0x30)
struct UNiagaraPrecompileContainer : UObject {
	struct TArray<struct UNiagaraScript*> Scripts; // 0x30(0x10)
	struct UNiagaraSystem* System; // 0x40(0x08)
};

// Class Niagara.NiagaraPreviewBase
// Size: 0x230 (Inherited: 0x230)
struct ANiagaraPreviewBase : AActor {

	void SetSystem(struct UNiagaraSystem* InSystem); // Function Niagara.NiagaraPreviewBase.SetSystem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetLabelText(struct FText InXAxisText, struct FText InYAxisText); // Function Niagara.NiagaraPreviewBase.SetLabelText // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class Niagara.NiagaraPreviewAxis
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraPreviewAxis : UObject {

	int32_t Num(); // Function Niagara.NiagaraPreviewAxis.Num // (Native|Event|Public|BlueprintEvent) // @ game+0x2a1b370
	void ApplyToPreview(struct UNiagaraComponent* PreviewComponent, int32_t PreviewIndex, bool bIsXAxis, struct FString OutLabelText); // Function Niagara.NiagaraPreviewAxis.ApplyToPreview // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2a1b130
};

// Class Niagara.NiagaraPreviewAxis_InterpParamBase
// Size: 0x40 (Inherited: 0x30)
struct UNiagaraPreviewAxis_InterpParamBase : UNiagaraPreviewAxis {
	struct FName Param; // 0x30(0x0c)
	int32_t count; // 0x3c(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamInt32
// Size: 0x48 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamInt32 : UNiagaraPreviewAxis_InterpParamBase {
	int32_t Min; // 0x40(0x04)
	int32_t Max; // 0x44(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamFloat
// Size: 0x48 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamFloat : UNiagaraPreviewAxis_InterpParamBase {
	float Min; // 0x40(0x04)
	float Max; // 0x44(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector2D
// Size: 0x50 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector2D : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector2D Min; // 0x40(0x08)
	struct FVector2D Max; // 0x48(0x08)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector
// Size: 0x58 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector Min; // 0x40(0x0c)
	struct FVector Max; // 0x4c(0x0c)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector4
// Size: 0x60 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector4 : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector4 Min; // 0x40(0x10)
	struct FVector4 Max; // 0x50(0x10)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamLinearColor
// Size: 0x60 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamLinearColor : UNiagaraPreviewAxis_InterpParamBase {
	struct FLinearColor Min; // 0x40(0x10)
	struct FLinearColor Max; // 0x50(0x10)
};

// Class Niagara.NiagaraPreviewGrid
// Size: 0x280 (Inherited: 0x230)
struct ANiagaraPreviewGrid : AActor {
	struct UNiagaraSystem* System; // 0x230(0x08)
	enum class ENiagaraPreviewGridResetMode ResetMode; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct UNiagaraPreviewAxis* PreviewAxisX; // 0x240(0x08)
	struct UNiagaraPreviewAxis* PreviewAxisY; // 0x248(0x08)
	struct ANiagaraPreviewBase* PreviewClass; // 0x250(0x08)
	float SpacingX; // 0x258(0x04)
	float SpacingY; // 0x25c(0x04)
	int32_t NumX; // 0x260(0x04)
	int32_t NumY; // 0x264(0x04)
	struct TArray<struct UChildActorComponent*> PreviewComponents; // 0x268(0x10)
	char pad_278[0x8]; // 0x278(0x08)

	void SetPaused(bool bPaused); // Function Niagara.NiagaraPreviewGrid.SetPaused // (Final|Native|Public|BlueprintCallable) // @ game+0x2a1b3a0
	void GetPreviews(struct TArray<struct UNiagaraComponent*> OutPreviews); // Function Niagara.NiagaraPreviewGrid.GetPreviews // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a1b2c0
	void DeactivatePreviews(); // Function Niagara.NiagaraPreviewGrid.DeactivatePreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x2a1b2a0
	void ActivatePreviews(bool bReset); // Function Niagara.NiagaraPreviewGrid.ActivatePreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x2a1b0a0
};

// Class Niagara.NiagaraRibbonRendererProperties
// Size: 0x8c0 (Inherited: 0x58)
struct UNiagaraRibbonRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x58(0x08)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding; // 0x60(0x30)
	enum class ENiagaraRibbonFacingMode FacingMode; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	float UV0TilingDistance; // 0x94(0x04)
	struct FVector2D UV0Scale; // 0x98(0x08)
	struct FVector2D UV0Offset; // 0xa0(0x08)
	enum class ENiagaraRibbonAgeOffsetMode UV0AgeOffsetMode; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	float UV1TilingDistance; // 0xac(0x04)
	struct FVector2D UV1Scale; // 0xb0(0x08)
	struct FVector2D UV1Offset; // 0xb8(0x08)
	enum class ENiagaraRibbonAgeOffsetMode UV1AgeOffsetMode; // 0xc0(0x01)
	enum class ENiagaraRibbonDrawDirection DrawDirection; // 0xc1(0x01)
	char pad_C2[0x2]; // 0xc2(0x02)
	float CurveTension; // 0xc4(0x04)
	enum class ENiagaraRibbonTessellationMode TessellationMode; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	int32_t TessellationFactor; // 0xcc(0x04)
	bool bUseConstantFactor; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	float TessellationAngle; // 0xd4(0x04)
	bool bScreenSpaceTessellation; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0xe0(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x170(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x200(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x290(0x90)
	struct FNiagaraVariableAttributeBinding RibbonTwistBinding; // 0x320(0x90)
	struct FNiagaraVariableAttributeBinding RibbonWidthBinding; // 0x3b0(0x90)
	struct FNiagaraVariableAttributeBinding RibbonFacingBinding; // 0x440(0x90)
	struct FNiagaraVariableAttributeBinding RibbonIdBinding; // 0x4d0(0x90)
	struct FNiagaraVariableAttributeBinding RibbonLinkOrderBinding; // 0x560(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x5f0(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x680(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x710(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x7a0(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x830(0x90)
};

// Class Niagara.NiagaraScript
// Size: 0x528 (Inherited: 0x30)
struct UNiagaraScript : UObject {
	enum class ENiagaraScriptUsage Usage; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t UsageIndex; // 0x34(0x04)
	struct FGuid UsageId; // 0x38(0x10)
	struct FNiagaraParameterStore RapidIterationParameters; // 0x48(0xb8)
	struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStore; // 0x100(0xd8)
	struct TArray<struct FNiagaraBoundParameter> ScriptExecutionBoundParameters; // 0x1d8(0x10)
	struct FNiagaraVMExecutableDataId CachedScriptVMId; // 0x1e8(0x48)
	char pad_230[0x1b0]; // 0x230(0x1b0)
	struct FNiagaraVMExecutableData CachedScriptVM; // 0x3e0(0x128)
	struct TArray<struct UNiagaraParameterCollection*> CachedParameterCollectionReferences; // 0x508(0x10)
	struct TArray<struct FNiagaraScriptDataInterfaceInfo> CachedDefaultDataInterfaces; // 0x518(0x10)

	void RaiseOnGPUCompilationComplete(); // Function Niagara.NiagaraScript.RaiseOnGPUCompilationComplete // (Final|Native|Public) // @ game+0x25271c0
};

// Class Niagara.NiagaraScriptSourceBase
// Size: 0x50 (Inherited: 0x30)
struct UNiagaraScriptSourceBase : UObject {
	char pad_30[0x20]; // 0x30(0x20)
};

// Class Niagara.NiagaraSettings
// Size: 0xb0 (Inherited: 0x48)
struct UNiagaraSettings : UDeveloperSettings {
	struct TArray<struct FSoftObjectPath> AdditionalParameterTypes; // 0x48(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalPayloadTypes; // 0x58(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalParameterEnums; // 0x68(0x10)
	struct FSoftObjectPath DefaultEffectType; // 0x78(0x20)
	struct TArray<struct FText> QualityLevels; // 0x98(0x10)
	struct UNiagaraEffectType* DefaultEffectTypePtr; // 0xa8(0x08)
};

// Class Niagara.NiagaraSimulationStageBase
// Size: 0x48 (Inherited: 0x30)
struct UNiagaraSimulationStageBase : UNiagaraMergeable {
	struct UNiagaraScript* Script; // 0x30(0x08)
	struct FName SimulationStageName; // 0x38(0x0c)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Niagara.NiagaraSimulationStageGeneric
// Size: 0x88 (Inherited: 0x48)
struct UNiagaraSimulationStageGeneric : UNiagaraSimulationStageBase {
	enum class ENiagaraIterationSource IterationSource; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32_t Iterations; // 0x4c(0x04)
	char bSpawnOnly : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct FNiagaraVariableDataInterfaceBinding DataInterface; // 0x58(0x30)
};

// Class Niagara.NiagaraSpriteRendererProperties
// Size: 0xa58 (Inherited: 0x58)
struct UNiagaraSpriteRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x58(0x08)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding; // 0x60(0x30)
	enum class ENiagaraSpriteAlignment Alignment; // 0x90(0x01)
	enum class ENiagaraSpriteFacingMode FacingMode; // 0x91(0x01)
	char pad_92[0x2]; // 0x92(0x02)
	struct FVector2D PivotInUVSpace; // 0x94(0x08)
	enum class ENiagaraSortMode SortMode; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
	struct FVector2D SubImageSize; // 0xa0(0x08)
	char bSubImageBlend : 1; // 0xa8(0x01)
	char bRemoveHMDRollInVR : 1; // 0xa8(0x01)
	char bSortOnlyWhenTranslucent : 1; // 0xa8(0x01)
	char pad_A8_3 : 5; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	float MinFacingCameraBlendDistance; // 0xac(0x04)
	float MaxFacingCameraBlendDistance; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0xb8(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x148(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x1d8(0x90)
	struct FNiagaraVariableAttributeBinding SpriteRotationBinding; // 0x268(0x90)
	struct FNiagaraVariableAttributeBinding SpriteSizeBinding; // 0x2f8(0x90)
	struct FNiagaraVariableAttributeBinding SpriteFacingBinding; // 0x388(0x90)
	struct FNiagaraVariableAttributeBinding SpriteAlignmentBinding; // 0x418(0x90)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x4a8(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x538(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x5c8(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x658(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x6e8(0x90)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x778(0x90)
	struct FNiagaraVariableAttributeBinding UVScaleBinding; // 0x808(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x898(0x90)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x928(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x9b8(0x90)
	char pad_A48[0x10]; // 0xa48(0x10)
};

// Class Niagara.NiagaraSystem
// Size: 0x480 (Inherited: 0x38)
struct UNiagaraSystem : UFXSystemAsset {
	char pad_38[0x1]; // 0x38(0x01)
	bool bDumpDebugSystemInfo; // 0x39(0x01)
	bool bDumpDebugEmitterInfo; // 0x3a(0x01)
	char pad_3B[0x1]; // 0x3b(0x01)
	char bFixedBounds : 1; // 0x3c(0x01)
	char pad_3C_1 : 7; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct UNiagaraEffectType* EffectType; // 0x40(0x08)
	bool bOverrideScalabilitySettings; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct FNiagaraSystemScalabilityOverride> ScalabilityOverrides; // 0x50(0x10)
	struct FNiagaraSystemScalabilityOverrides SystemScalabilityOverrides; // 0x60(0x10)
	struct TArray<struct FNiagaraEmitterHandle> EmitterHandles; // 0x70(0x10)
	struct TArray<struct UNiagaraParameterCollectionInstance*> ParameterCollectionOverrides; // 0x80(0x10)
	struct UNiagaraScript* SystemSpawnScript; // 0x90(0x08)
	struct UNiagaraScript* SystemUpdateScript; // 0x98(0x08)
	char pad_A0[0x10]; // 0xa0(0x10)
	struct FNiagaraSystemCompiledData SystemCompiledData; // 0xb0(0x258)
	struct FNiagaraUserRedirectionParameterStore ExposedParameters; // 0x308(0x108)
	struct FBox FixedBounds; // 0x410(0x1c)
	bool bAutoDeactivate; // 0x42c(0x01)
	char pad_42D[0x3]; // 0x42d(0x03)
	float WarmupTime; // 0x430(0x04)
	int32_t WarmupTickCount; // 0x434(0x04)
	float WarmupTickDelta; // 0x438(0x04)
	bool bHasSystemScriptDIsWithPerInstanceData; // 0x43c(0x01)
	char pad_43D[0x3]; // 0x43d(0x03)
	struct TArray<struct FName> UserDINamesReadInSystemScripts; // 0x440(0x10)
	char pad_450[0x30]; // 0x450(0x30)
};

