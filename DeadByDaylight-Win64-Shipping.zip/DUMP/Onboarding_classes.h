// Class Onboarding.OnboardingManager
// Size: 0x1b0 (Inherited: 0x38)
struct UOnboardingManager : UGameInstanceSubsystem {
	char pad_38[0x178]; // 0x38(0x178)
};

