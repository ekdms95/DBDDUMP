// ScriptStruct Onboarding.OnboardingBotMatchDefinition
// Size: 0x70 (Inherited: 0x18)
struct FOnboardingBotMatchDefinition : FDBDTableRowBaseWithId {
	struct FText DisplayName; // 0x18(0x18)
	struct FText Description; // 0x30(0x18)
	struct FName DefaultMapId; // 0x48(0x0c)
	int32_t DefaultSurvivorId; // 0x54(0x04)
	int32_t DefaultKillerId; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TArray<int32_t> DefaultBotsId; // 0x60(0x10)
};

// ScriptStruct Onboarding.OnboardingTutorialDefinition
// Size: 0xc0 (Inherited: 0x18)
struct FOnboardingTutorialDefinition : FDBDTableRowBaseWithId {
	struct FText DisplayName; // 0x18(0x18)
	struct FText CompletedDisplayName; // 0x30(0x18)
	struct FText Description; // 0x48(0x18)
	struct FText CompletedDescription; // 0x60(0x18)
	enum class EOnboardingTutorialType TutorialType; // 0x78(0x01)
	enum class EOnboardingTutorialButtonStyle ButtonStyle; // 0x79(0x01)
	char pad_7A[0x6]; // 0x7a(0x06)
	struct FString LevelId; // 0x80(0x10)
	struct TSoftObjectPtr<struct UTexture2D> Icon; // 0x90(0x30)
};

