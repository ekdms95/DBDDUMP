// Class OnlineMessagesUtilities.OnlineMessagesContainerComponent
// Size: 0xe8 (Inherited: 0xb8)
struct UOnlineMessagesContainerComponent : UActorComponent {
	struct TArray<struct FInboxMessageData> _messages; // 0xb8(0x10)
	char pad_C8[0x20]; // 0xc8(0x20)
};

