// Enum OnlinePresence.ERichPresenceUserType
enum class ERichPresenceUserType : uint8 {
	Player,
	Server,
	ERichPresenceUserType_MAX,
};

// Enum OnlinePresence.ERichPresenceStatus
enum class ERichPresenceStatus : uint8 {
	Offline,
	Connected,
	InMenus,
	InPartyLobby,
	InOnlineLobby,
	InMatch,
	ERichPresenceStatus_MAX,
};

