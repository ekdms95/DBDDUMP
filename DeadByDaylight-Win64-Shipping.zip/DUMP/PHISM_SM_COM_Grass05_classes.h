// BlueprintGeneratedClass PHISM_SM_COM_Grass05.PHISM_SM_COM_Grass05_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_COM_Grass05_C : UPlayerOverlapHISMComponent {
};

