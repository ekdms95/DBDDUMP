// BlueprintGeneratedClass PHISM_SM_Corn02.PHISM_SM_Corn02_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_Corn02_C : UPlayerOverlapHISMComponent {
};

