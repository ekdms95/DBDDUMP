// BlueprintGeneratedClass PHISM_SM_Haiti_Bamboo01.PHISM_SM_Haiti_Bamboo01_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_Haiti_Bamboo01_C : UPlayerOverlapHISMComponent {
};

