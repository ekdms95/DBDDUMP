// BlueprintGeneratedClass PHISM_SM_Haiti_Bamboo02.PHISM_SM_Haiti_Bamboo02_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_Haiti_Bamboo02_C : UPlayerOverlapHISMComponent {
};

