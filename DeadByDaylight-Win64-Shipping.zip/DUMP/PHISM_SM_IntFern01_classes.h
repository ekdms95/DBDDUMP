// BlueprintGeneratedClass PHISM_SM_IntFern01.PHISM_SM_IntFern01_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_IntFern01_C : UPlayerOverlapHISMComponent {
};

