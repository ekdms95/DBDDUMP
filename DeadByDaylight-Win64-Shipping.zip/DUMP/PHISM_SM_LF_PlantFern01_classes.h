// BlueprintGeneratedClass PHISM_SM_LF_PlantFern01.PHISM_SM_LF_PlantFern01_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_LF_PlantFern01_C : UPlayerOverlapHISMComponent {
};

