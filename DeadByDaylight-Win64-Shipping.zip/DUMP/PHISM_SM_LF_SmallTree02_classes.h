// BlueprintGeneratedClass PHISM_SM_LF_SmallTree02.PHISM_SM_LF_SmallTree02_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_LF_SmallTree02_C : UPlayerOverlapHISMComponent {
};

