// BlueprintGeneratedClass PHISM_SM_Plant_Suburb01.PHISM_SM_Plant_Suburb01_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct UPHISM_SM_Plant_Suburb01_C : UPlayerOverlapHISMComponent {
};

