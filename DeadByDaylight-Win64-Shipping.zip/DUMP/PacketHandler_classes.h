// Class PacketHandler.HandlerComponentFactory
// Size: 0x30 (Inherited: 0x30)
struct UHandlerComponentFactory : UObject {
};

// Class PacketHandler.PacketHandlerProfileConfig
// Size: 0x40 (Inherited: 0x30)
struct UPacketHandlerProfileConfig : UObject {
	struct TArray<struct FString> Components; // 0x30(0x10)
};

