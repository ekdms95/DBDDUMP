// Class Penalty.PenaltyTracker
// Size: 0xb0 (Inherited: 0x30)
struct UPenaltyTracker : UObject {
	char pad_30[0x80]; // 0x30(0x80)
};

