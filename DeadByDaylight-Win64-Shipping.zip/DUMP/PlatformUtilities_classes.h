// Class PlatformUtilities.CrowdChoiceManager
// Size: 0x88 (Inherited: 0x38)
struct UCrowdChoiceManager : UGameInstanceSubsystem {
	char pad_38[0x50]; // 0x38(0x50)
};

// Class PlatformUtilities.CrowdPlayManager
// Size: 0x40 (Inherited: 0x38)
struct UCrowdPlayManager : UGameInstanceSubsystem {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class PlatformUtilities.PlatformSupportSubsystem
// Size: 0x68 (Inherited: 0x38)
struct UPlatformSupportSubsystem : UGameInstanceSubsystem {
	char pad_38[0x30]; // 0x38(0x30)

	void DBD_StadiaShowStreamDebug(bool bEnabled); // Function PlatformUtilities.PlatformSupportSubsystem.DBD_StadiaShowStreamDebug // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_StadiaRoleSelectPoll(); // Function PlatformUtilities.PlatformSupportSubsystem.DBD_StadiaRoleSelectPoll // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_StadiaCharacterSelectPoll(); // Function PlatformUtilities.PlatformSupportSubsystem.DBD_StadiaCharacterSelectPoll // (Final|Exec|Native|Public) // @ game+0x25271c0
};

