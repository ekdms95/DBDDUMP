// Enum PlatformsProviders.EProviderFlag
enum class EProviderFlag : uint8 {
	None,
	Google,
	DMM,
	Facebook,
	Nintendo,
	PSN,
	Steam,
	WinGDK,
	Xbox,
	Apple,
	Kraken,
	Stadia,
	GAS3,
	EProviderFlag_MAX,
};

// Enum PlatformsProviders.EPlatformFlag
enum class EPlatformFlag : uint8 {
	None,
	Android,
	DMM,
	IOS,
	Switch,
	PS4,
	Steam,
	WinGDK,
	Xbox,
	Stadia,
	PS5,
	XSX,
	EPlatformFlag_MAX,
};

