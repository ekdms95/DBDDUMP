// Class PlayerNames.PlayerNameFacade
// Size: 0x50 (Inherited: 0x38)
struct UPlayerNameFacade : UGameInstanceSubsystem {
	char pad_38[0x18]; // 0x38(0x18)
};

