// Class Projectile.BaseProjectile
// Size: 0x280 (Inherited: 0x230)
struct ABaseProjectile : AActor {
	char pad_230[0x40]; // 0x230(0x40)
	bool _multicastLaunch; // 0x270(0x01)
	bool _allowMultipleHits; // 0x271(0x01)
	bool _notifyClientOfServerHitValidationResult; // 0x272(0x01)
	char pad_273[0x5]; // 0x273(0x05)
	struct UBaseProjectileReplicationComponent* _replicationComponent; // 0x278(0x08)

	bool SphereTraceSingle(struct FVector Start, struct FVector End, struct USphereComponent* Sphere, struct FHitResult outHitResult); // Function Projectile.BaseProjectile.SphereTraceSingle // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x583a490
	void OnSetActive(bool Active); // Function Projectile.BaseProjectile.OnSetActive // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnLaunch(struct FLaunchInfo LaunchInfo, bool hasImpactOnLaunch); // Function Projectile.BaseProjectile.OnLaunch // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDetectPlayer(struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectile.OnDetectPlayer // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDetectCollision(struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectile.OnDetectCollision // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool Local_TryDetectCollision(struct FImpactInfo ImpactInfo, bool force); // Function Projectile.BaseProjectile.Local_TryDetectCollision // (Final|Native|Public|BlueprintCallable) // @ game+0x583a360
	bool Local_SweepImpactCollision(struct FVector Start, struct FVector End, struct FRotator colliderRotation, struct FHitResult OutHit); // Function Projectile.BaseProjectile.Local_SweepImpactCollision // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x583a170
	bool Local_OnPlayerDetected(struct FImpactInfo ImpactInfo, struct FVector projectileLocation); // Function Projectile.BaseProjectile.Local_OnPlayerDetected // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x583a040
	bool IsValidPlayerDetection(struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectile.IsValidPlayerDetection // (Native|Event|Protected|BlueprintEvent) // @ game+0x5839f60
	bool IsValidImpactDetection(struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectile.IsValidImpactDetection // (Native|Event|Protected|BlueprintEvent) // @ game+0x5839e80
	bool IsOwningPawnLocallyControlled(); // Function Projectile.BaseProjectile.IsOwningPawnLocallyControlled // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x5839e50
	struct UBaseProjectileLauncher* GetLauncher(); // Function Projectile.BaseProjectile.GetLauncher // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x5839e20
	struct UPrimitiveComponent* GetImpactPrimitiveComponent(); // Function Projectile.BaseProjectile.GetImpactPrimitiveComponent // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x5839df0
	float GetAddLauncherVeloctyFactor(); // Function Projectile.BaseProjectile.GetAddLauncherVeloctyFactor // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5839db0
	bool Authority_TryDetectCollision(struct FImpactInfo ImpactInfo, bool force); // Function Projectile.BaseProjectile.Authority_TryDetectCollision // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x5839c80
};

// Class Projectile.PhysicsBasedProjectile
// Size: 0x288 (Inherited: 0x280)
struct APhysicsBasedProjectile : ABaseProjectile {
	struct UPhysicsBasedProjectileMovementComponent* Movement; // 0x280(0x08)
};

// Class Projectile.BaseProjectileLauncher
// Size: 0x180 (Inherited: 0xb8)
struct UBaseProjectileLauncher : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
	bool _requireLaunchImpactDetection; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct ABaseProjectile* ProjectileClass; // 0xf0(0x08)
	int32_t _ammo; // 0xf8(0x04)
	int32_t _maxAmmo; // 0xfc(0x04)
	bool _canLaunchWhileOutOfAmmo; // 0x100(0x01)
	char pad_101[0x2f]; // 0x101(0x2f)
	struct ABaseProjectile* _debugProjectile; // 0x130(0x08)
	char pad_138[0x40]; // 0x138(0x40)
	struct UBaseProjectileReplicationComponent* _projectileReplicationComponent; // 0x178(0x08)

	void SetProjectileVar(struct FName VarName, float value); // Function Projectile.BaseProjectileLauncher.SetProjectileVar // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void SetProjectileProvider(struct TScriptInterface<None> ProjectileProvider); // Function Projectile.BaseProjectileLauncher.SetProjectileProvider // (Final|Native|Public|BlueprintCallable) // @ game+0x583b980
	void Server_LaunchWithImpact(struct FLaunchInfo LaunchInfo, struct FImpactInfo ImpactInfo, struct ABaseProjectile* Projectile); // Function Projectile.BaseProjectileLauncher.Server_LaunchWithImpact // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x583b800
	void Server_Launch(struct FLaunchInfo LaunchInfo, struct ABaseProjectile* Projectile); // Function Projectile.BaseProjectileLauncher.Server_Launch // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x583b6e0
	void OnRep_MaxAmmo(int32_t oldMaxAmmo); // Function Projectile.BaseProjectileLauncher.OnRep_MaxAmmo // (Native|Protected) // @ game+0x333a0b0
	void OnRep_Ammo(int32_t oldAmmo); // Function Projectile.BaseProjectileLauncher.OnRep_Ammo // (Native|Protected) // @ game+0x333a3e0
	void OnLaunch(struct FLaunchInfo LaunchInfo, struct ABaseProjectile* Projectile); // Function Projectile.BaseProjectileLauncher.OnLaunch // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Local_Launch(); // Function Projectile.BaseProjectileLauncher.Local_Launch // (Final|Native|Public|BlueprintCallable) // @ game+0x583b6c0
	bool IsLocallyControlled(); // Function Projectile.BaseProjectileLauncher.IsLocallyControlled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x583b690
	bool IsAmmoFull(); // Function Projectile.BaseProjectileLauncher.IsAmmoFull // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x583b660
	bool HasProjectile(); // Function Projectile.BaseProjectileLauncher.HasProjectile // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3306360
	bool HasAuthority(); // Function Projectile.BaseProjectileLauncher.HasAuthority // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x583b630
	struct ABaseProjectile* GetProjectileToLaunch(); // Function Projectile.BaseProjectileLauncher.GetProjectileToLaunch // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x583b600
	struct APawn* GetOwningPawn(); // Function Projectile.BaseProjectileLauncher.GetOwningPawn // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x583b5d0
	float GetLaunchSpeedAtThrowPowerRatio(float throwPowerRatio); // Function Projectile.BaseProjectileLauncher.GetLaunchSpeedAtThrowPowerRatio // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x583b540
	float GetLaunchSpeed(); // Function Projectile.BaseProjectileLauncher.GetLaunchSpeed // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x583b500
	struct FVector GetLaunchPosition(); // Function Projectile.BaseProjectileLauncher.GetLaunchPosition // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x583b4c0
	struct FVector GetLaunchDirectionAtViewAndThrowPowerRatio(struct FRotator ViewRotation, float throwPowerRatio); // Function Projectile.BaseProjectileLauncher.GetLaunchDirectionAtViewAndThrowPowerRatio // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x583b3d0
	struct FVector GetLaunchDirection(); // Function Projectile.BaseProjectileLauncher.GetLaunchDirection // (Native|Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x583b390
	int32_t GetAmmo(); // Function Projectile.BaseProjectileLauncher.GetAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x583b360
	void Cosmetic_OnOutOfAmmo(); // Function Projectile.BaseProjectileLauncher.Cosmetic_OnOutOfAmmo // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_SetMaxAmmo(int32_t newMaxAmmo, bool isMaxAmmoImmutable); // Function Projectile.BaseProjectileLauncher.Authority_SetMaxAmmo // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x583b2a0
	void Authority_Reload(); // Function Projectile.BaseProjectileLauncher.Authority_Reload // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x583b280
	void Authority_Launch(); // Function Projectile.BaseProjectileLauncher.Authority_Launch // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x583b260
	void Authority_AddMaxAmmo(int32_t ammoToAdd); // Function Projectile.BaseProjectileLauncher.Authority_AddMaxAmmo // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x583b1e0
};

// Class Projectile.PhysicsBasedProjectileMovementComponent
// Size: 0x250 (Inherited: 0x1e0)
struct UPhysicsBasedProjectileMovementComponent : UProjectileMovementComponent {
	char pad_1E0[0x18]; // 0x1e0(0x18)
	struct FMulticastInlineDelegate OnComponentToSweepCollisionBP; // 0x1f8(0x10)
	char pad_208[0x18]; // 0x208(0x18)
	struct TArray<struct FComponentSweepInfo> _componentsToSweep; // 0x220(0x10)
	char pad_230[0x10]; // 0x230(0x10)
	struct USceneComponent* _cachedUpdatedComponent; // 0x240(0x08)
	char pad_248[0x8]; // 0x248(0x08)

	void OnComponentToSweepCollisionBP__DelegateSignature(struct UPrimitiveComponent* PrimitiveComponent, struct FHitResult HitResult); // DelegateFunction Projectile.PhysicsBasedProjectileMovementComponent.OnComponentToSweepCollisionBP__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x3873200
	struct FVector GetPreviousLocation(); // Function Projectile.PhysicsBasedProjectileMovementComponent.GetPreviousLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x583d040
	void AddComponentToSweep(struct UPrimitiveComponent* Component); // Function Projectile.PhysicsBasedProjectileMovementComponent.AddComponentToSweep // (Final|Native|Public|BlueprintCallable) // @ game+0x583cfc0
};

// Class Projectile.SingleProjectileProviderComponent
// Size: 0xe8 (Inherited: 0xb8)
struct USingleProjectileProviderComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct ABaseProjectile* _projectileClass; // 0xc0(0x08)
	struct ABaseProjectile* _projectile; // 0xc8(0x08)
	char pad_D0[0x18]; // 0xd0(0x18)

	void OnRep_Projectile(); // Function Projectile.SingleProjectileProviderComponent.OnRep_Projectile // (Final|Native|Private) // @ game+0x583d290
};

// Class Projectile.AuthoritativePoolProjectileProviderAdapter
// Size: 0x40 (Inherited: 0x30)
struct UAuthoritativePoolProjectileProviderAdapter : UObject {
	char pad_30[0x8]; // 0x30(0x08)
	struct UAuthoritativeActorPoolComponent* _pool; // 0x38(0x08)

	void Init(struct UAuthoritativeActorPoolComponent* pool); // Function Projectile.AuthoritativePoolProjectileProviderAdapter.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x58394e0
};

// Class Projectile.BaseProjectileReplicationComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UBaseProjectileReplicationComponent : UActorComponent {

	void Server_TryDetectPlayer(struct ABaseProjectile* Projectile, struct FImpactInfo ImpactInfo, struct FVector_NetQuantize100 projectileLocation, struct FVector_NetQuantize10 projectileRotation, float TargetLocationTimestamp); // Function Projectile.BaseProjectileReplicationComponent.Server_TryDetectPlayer // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x583c5b0
	void Multicast_OnLaunchWithImpact(struct ABaseProjectile* Projectile, struct FLaunchInfo LaunchInfo, struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectileReplicationComponent.Multicast_OnLaunchWithImpact // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x583c420
	void Multicast_OnLaunch(struct ABaseProjectile* Projectile, struct FLaunchInfo LaunchInfo); // Function Projectile.BaseProjectileReplicationComponent.Multicast_OnLaunch // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x583c310
	void Multicast_DetectPlayer(struct ABaseProjectile* Projectile, struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectileReplicationComponent.Multicast_DetectPlayer // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x583c1f0
	void Multicast_DetectImpact(struct ABaseProjectile* Projectile, struct FImpactInfo ImpactInfo); // Function Projectile.BaseProjectileReplicationComponent.Multicast_DetectImpact // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x583c0d0
	void Client_ReceiveDetectPlayerValidation(struct ABaseProjectile* Projectile, bool success); // Function Projectile.BaseProjectileReplicationComponent.Client_ReceiveDetectPlayerValidation // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x33065f0
	void Client_LaunchRefusedByServer(struct ABaseProjectile* Projectile); // Function Projectile.BaseProjectileReplicationComponent.Client_LaunchRefusedByServer // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x583c040
};

// Class Projectile.ProjectileProvider
// Size: 0x30 (Inherited: 0x30)
struct UProjectileProvider : UInterface {
};

