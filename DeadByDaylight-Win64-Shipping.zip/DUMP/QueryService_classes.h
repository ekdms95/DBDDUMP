// Class QueryService.ActorPairQueryEvaluatorComponent
// Size: 0x110 (Inherited: 0xb8)
struct UActorPairQueryEvaluatorComponent : UActorComponent {
	char pad_B8[0x58]; // 0xb8(0x58)
};

// Class QueryService.ActorPairQueryEvaluatorSubscriberTest
// Size: 0x258 (Inherited: 0x230)
struct AActorPairQueryEvaluatorSubscriberTest : AActor {
	char pad_230[0x28]; // 0x230(0x28)

	void OnRangeChanged(bool InRange); // Function QueryService.ActorPairQueryEvaluatorSubscriberTest.OnRangeChanged // (Final|Native|Public) // @ game+0x58410b0
};

