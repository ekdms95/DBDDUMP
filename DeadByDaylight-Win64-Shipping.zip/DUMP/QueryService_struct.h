// ScriptStruct QueryService.ActorPairQuery
// Size: 0x68 (Inherited: 0x00)
struct FActorPairQuery {
	char pad_0[0x10]; // 0x00(0x10)
	struct TMap<uint32_t, struct FDistanceTrackerCase> _distanceTrackerCases; // 0x10(0x50)
	uint32_t _caseIndex; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct QueryService.DistanceTrackerCase
// Size: 0x20 (Inherited: 0x00)
struct FDistanceTrackerCase {
	char pad_0[0x18]; // 0x00(0x18)
	float _distanceToTrackSquared; // 0x18(0x04)
	bool _inRange; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct QueryService.ActorsInRangeBool
// Size: 0x40 (Inherited: 0x00)
struct FActorsInRangeBool {
	struct UActorPairQueryEvaluatorComponent* _actorPairQueryComponent; // 0x00(0x08)
	struct AActor* _sourceActor; // 0x08(0x08)
	struct AActor* _otherActor; // 0x10(0x08)
	float _range; // 0x18(0x04)
	bool _inRange; // 0x1c(0x01)
	char pad_1D[0x23]; // 0x1d(0x23)
};

