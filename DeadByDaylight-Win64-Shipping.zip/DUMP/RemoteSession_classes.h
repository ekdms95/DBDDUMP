// Class RemoteSession.RemoteSessionMediaOutput
// Size: 0x48 (Inherited: 0x38)
struct URemoteSessionMediaOutput : UMediaOutput {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class RemoteSession.RemoteSessionMediaCapture
// Size: 0x120 (Inherited: 0x110)
struct URemoteSessionMediaCapture : UMediaCapture {
	char pad_110[0x10]; // 0x110(0x10)
};

