// Class S3Command.AccessKeys
// Size: 0x40 (Inherited: 0x30)
struct UAccessKeys : UObject {
	struct TArray<struct FAccessKey> AccessKeys; // 0x30(0x10)
};

