// ScriptStruct S3Command.AccessKey
// Size: 0x20 (Inherited: 0x00)
struct FAccessKey {
	struct FString KeyId; // 0x00(0x10)
	struct FString Key; // 0x10(0x10)
};

