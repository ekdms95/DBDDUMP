// Class SentryIo.SentryIoSubsystem
// Size: 0x48 (Inherited: 0x38)
struct USentryIoSubsystem : UGameInstanceSubsystem {
	char pad_38[0x10]; // 0x38(0x10)
};

