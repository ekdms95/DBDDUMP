// Class SharedAuthenticationUtilities.SharedAuthenticationComponent
// Size: 0x160 (Inherited: 0xb8)
struct USharedAuthenticationComponent : UActorComponent {
	int32_t PopupZOrder; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct UUMGAutheticationProviderSelection* AuthenticationProviderSelectionWidget; // 0xc0(0x08)
	char pad_C8[0x98]; // 0xc8(0x98)
};

// Class SharedAuthenticationUtilities.UMGAutheticationProviderSelection
// Size: 0x278 (Inherited: 0x260)
struct UUMGAutheticationProviderSelection : UUserWidget {
	char pad_260[0x18]; // 0x260(0x18)

	void SetSelectedAuthenticationProvider(enum class ESharedAuthenticationProvider Provider); // Function SharedAuthenticationUtilities.UMGAutheticationProviderSelection.SetSelectedAuthenticationProvider // (Final|Native|Public|BlueprintCallable) // @ game+0x5865950
};

