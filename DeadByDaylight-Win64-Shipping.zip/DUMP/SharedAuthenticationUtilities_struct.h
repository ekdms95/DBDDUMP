// Enum SharedAuthenticationUtilities.ESharedAuthenticationProvider
enum class ESharedAuthenticationProvider : uint8 {
	None,
	Facebook,
	Google,
	NetEase,
	Kraken,
	SignInWithApple,
	ESharedAuthenticationProvider_MAX,
};

// ScriptStruct SharedAuthenticationUtilities.AuthenticationRequestState
// Size: 0x18 (Inherited: 0x00)
struct FAuthenticationRequestState {
	char pad_0[0x18]; // 0x00(0x18)
};

