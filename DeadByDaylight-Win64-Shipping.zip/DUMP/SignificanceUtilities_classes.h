// Class SignificanceUtilities.CharacterOptimizer
// Size: 0x160 (Inherited: 0xb8)
struct UCharacterOptimizer : UActorComponent {
	struct FBHVRPerDetailModeFloat _distance; // 0xb8(0xa0)
	float _characterMovementTickRateWhenInsignificant; // 0x158(0x04)
	float _skeletalMeshTickRateWhenInsignificant; // 0x15c(0x04)
};

// Class SignificanceUtilities.DistanceBasedTickDisabler
// Size: 0x180 (Inherited: 0xb8)
struct UDistanceBasedTickDisabler : UActorComponent {
	bool _autoRegisterOwner; // 0xb8(0x01)
	bool _autoRegisterTimelines; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
	struct FBHVRPerDetailModeFloat _tickDisableDistance; // 0xc0(0xa0)
	bool _insignificantWhenBehindTheCamera; // 0x160(0x01)
	char pad_161[0x7]; // 0x161(0x07)
	struct TArray<struct UActorComponent*> _components; // 0x168(0x10)
	char pad_178[0x8]; // 0x178(0x08)

	void UnregisterComponent(struct UActorComponent* Component); // Function SignificanceUtilities.DistanceBasedTickDisabler.UnregisterComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5866f30
	void RegisterComponent(struct UActorComponent* Component); // Function SignificanceUtilities.DistanceBasedTickDisabler.RegisterComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5866eb0
};

