// BlueprintGeneratedClass SkillCheckProbabilityProficiency.SkillCheckProbabilityProficiency_C
// Size: 0x48 (Inherited: 0x48)
struct USkillCheckProbabilityProficiency_C : UInteractionProficiency {

	bool GetIsActive(struct UChargeableInteractionDefinition* chargeableInteraction, struct ADBDPlayer* Player); // Function SkillCheckProbabilityProficiency.SkillCheckProbabilityProficiency_C.GetIsActive // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
	enum class EStatusEffectType GetType(float value); // Function SkillCheckProbabilityProficiency.SkillCheckProbabilityProficiency_C.GetType // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
	float GetValue(struct UChargeableInteractionDefinition* chargeableInteraction, struct ADBDPlayer* Player); // Function SkillCheckProbabilityProficiency.SkillCheckProbabilityProficiency_C.GetValue // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
};

