// Class SocialBlockList.BlockListFacade
// Size: 0xf0 (Inherited: 0x38)
struct UBlockListFacade : UGameInstanceSubsystem {
	char pad_38[0xb8]; // 0x38(0xb8)
};

