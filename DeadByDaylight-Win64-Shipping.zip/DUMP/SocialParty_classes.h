// Class SocialParty.PartyFacade
// Size: 0x450 (Inherited: 0x30)
struct UPartyFacade : UObject {
	char pad_30[0x420]; // 0x30(0x420)
};

