// Enum SocialParty.EJoinPartyMethod
enum class EJoinPartyMethod : uint8 {
	None,
	PlatformInvitation,
	InGameInvitation,
	JoinRequest,
	EJoinPartyMethod_MAX,
};

// Enum SocialParty.EPartyBusyReason
enum class EPartyBusyReason : uint8 {
	None,
	CreatingParty,
	LeavingParty,
	SyncingParty,
	DestroyingParty,
	InvitingPlayer,
	AcceptingPartyInvite,
	RejectingPartyInvite,
	CancelingPartyInvite,
	RequestingJoinParty,
	AcceptingRequestJoinParty,
	RejectingRequestJoinParty,
	CancelingRequestJoinParty,
	AcceptingPlatformInvite,
	KickingPlayerFromParty,
	LeavingPartyFromKick,
	CreatingPartyPlatformSession,
	LeavingCrossplatformPlatformSession,
	WaitingForPlatformSessionInfo,
	ProcessingPlatformSession,
	EPartyBusyReason_MAX,
};

// Enum SocialParty.EPartyError
enum class EPartyError : uint8 {
	None,
	CreatePartyFail,
	CreatePartyFail_PlayerAlreadyInParty,
	ConnectionToPartyManagementLost,
	AcceptInvitationFail,
	AcceptInvitationFail_InvitationExpired,
	AcceptInvitationFail_PartyIsFull,
	AcceptInvitationFail_PartyDoesNotExists,
	AcceptInvitationFail_VersionMismatch,
	AcceptInvitationFail_StreamingInstallationIncomplete,
	RejectInvitationFail,
	RejectInvitationFail_PartyDoesNotExists,
	InvitationFail,
	InvitationFail_PartyDoesNotExists,
	InvitationFail_PlayerAlreadyInParty,
	InvitationFail_NotFriendsWithUser,
	JoinRequestFail,
	JoinRequestFail_PartyDoesNotExists,
	JoinRequestFail_PlayerAlreadyInPartyOrPartyFull,
	JoinRequestFail_BannedFromParty,
	JoinRequestFail_FriendNotInParty,
	JoinRequestFail_PartyIsPrivate,
	JoinRequestAcceptedFail,
	JoinRequestAcceptedFail_PartyDoesNotExists,
	AcceptJoinRequestFail,
	AcceptJoinRequestFail_RequestNotFound,
	AcceptJoinRequestFail_PartyDoesNotExists,
	RejectJoinRequestFail,
	RejectJoinRequestFail_RequestNotFound,
	RejectJoinRequestFail_PartyDoesNotExists,
	CancelJoinRequestFail,
	CancelJoinRequestFail_RequestNotFound,
	RealTimeMessagingDisconnected,
	FriendBlocked_UnableToJoinParty,
	FriendBlocked_UnableToRemainInParty,
	CancelInvitationFail,
	CancelInvitationFail_PartyDoesNotExists,
	SendPartyChatMessageFail,
	SendPartyChatMessageFail_PartyDoesNotExists,
	SendPartyChatMessageFail_MessageNotAllowed,
	InvitationValidationError,
	InvitationValidationError_StandardInviteFlowButActiveCrowdPlay,
	InvitationValidationError_QueueToPlayInviteButInactiveCrowdPlay,
	InvitationValidationError_PartyIsFull,
	InvitationValidationError_PartyDoesNotExists,
	InvitationValidationError_VersionMismatch,
	InvitationValidationError_StreamingInstallationIncomplete,
	InvitationValidationError_FriendBlocked,
	InvitationValidationError_InsufficientPrivileges,
	InvitationValidationError_PlayerBanned,
	InvitationValidationError_LocalCrossplayIncompatibility,
	InvitationValidationError_RemoteCrossplayIncompatibility,
	InvitationValidationError_ListenServerCrossplayIncompatibility,
	RemovePlayerFromPartyFail,
	UnknownError,
	EPartyError_MAX,
};

// Enum SocialParty.EPartyPostMatchmakingState
enum class EPartyPostMatchmakingState : uint8 {
	None,
	InProgress,
	Completed,
	Error,
	EPartyPostMatchmakingState_MAX,
};

// Enum SocialParty.EPartyPostMatchmakingRole
enum class EPartyPostMatchmakingRole : uint8 {
	None,
	Client,
	Host,
	EPartyPostMatchmakingRole_MAX,
};

// Enum SocialParty.EMatchmakingState
enum class EMatchmakingState : uint8 {
	None,
	Searching,
	MatchFound,
	Error,
	EMatchmakingState_MAX,
};

// ScriptStruct SocialParty.SocialPartyMember
// Size: 0xa0 (Inherited: 0x00)
struct FSocialPartyMember {
	char pad_0[0x8]; // 0x00(0x08)
	struct TArray<struct FName> _customizationMesh; // 0x08(0x10)
	struct FString _playerName; // 0x18(0x10)
	struct FString _platformSessionId; // 0x28(0x10)
	struct FString _uniquePlayerId; // 0x38(0x10)
	int32_t _playerRank; // 0x48(0x04)
	int32_t _characterLevel; // 0x4c(0x04)
	int32_t _prestigeLevel; // 0x50(0x04)
	int32_t _gameRole; // 0x54(0x04)
	int32_t _characterId; // 0x58(0x04)
	struct FName _powerId; // 0x5c(0x0c)
	int32_t _location; // 0x68(0x04)
	bool _ready; // 0x6c(0x01)
	bool _crossplayAllowed; // 0x6d(0x01)
	char pad_6E[0x2]; // 0x6e(0x02)
	struct FString _playerPlatform; // 0x70(0x10)
	struct FString _playerProvider; // 0x80(0x10)
	enum class EPartyPostMatchmakingRole _postMatchmakingRole; // 0x90(0x01)
	enum class EPartyPostMatchmakingState _postMatchmakingState; // 0x91(0x01)
	bool _isStateInitialized; // 0x92(0x01)
	char pad_93[0x5]; // 0x93(0x05)
	int64_t _disconnectionPenaltyEndOfBan; // 0x98(0x08)
};

// ScriptStruct SocialParty.SocialPartyState
// Size: 0x160 (Inherited: 0x00)
struct FSocialPartyState {
	char pad_0[0x8]; // 0x00(0x08)
	struct FCustomGamePresetData _customGamePresetData; // 0x08(0x20)
	struct FPartySessionSettings _partySessionSettings; // 0x28(0x98)
	struct FPartyMatchmakingSettings _partyMatchmakingSettings; // 0xc0(0x20)
	struct TArray<struct FName> _playerJoinOrder; // 0xe0(0x10)
	struct TMap<struct FName, char> _playerChatIndices; // 0xf0(0x50)
	int32_t _gameType; // 0x140(0x04)
	bool _isCrowdPlay; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct FString _version; // 0x148(0x10)
	int32_t _lastUpdatedTime; // 0x158(0x04)
	int32_t _lastSentTime; // 0x15c(0x04)
};

// ScriptStruct SocialParty.PartyMatchmakingSettings
// Size: 0x20 (Inherited: 0x00)
struct FPartyMatchmakingSettings {
	char pad_0[0x8]; // 0x00(0x08)
	struct TArray<struct FString> _playerIds; // 0x08(0x10)
	enum class EMatchmakingState _matchmakingState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct SocialParty.PartySessionSettings
// Size: 0x98 (Inherited: 0x00)
struct FPartySessionSettings {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString _sessionId; // 0x08(0x10)
	struct TMap<struct FString, struct FString> _gameSessionInfos; // 0x18(0x50)
	struct FString _owningUserId; // 0x68(0x10)
	struct FString _owningUserName; // 0x78(0x10)
	bool _isDedicated; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	int64_t _matchmakingTimestamp; // 0x90(0x08)
};

// ScriptStruct SocialParty.CustomGamePresetData
// Size: 0x20 (Inherited: 0x00)
struct FCustomGamePresetData {
	char pad_0[0x8]; // 0x00(0x08)
	struct TArray<char> _mapAvailabilities; // 0x08(0x10)
	bool _arePerkAvailable; // 0x18(0x01)
	bool _areOfferingAvailable; // 0x19(0x01)
	bool _areItemAvailable; // 0x1a(0x01)
	bool _areItemAddonAvailable; // 0x1b(0x01)
	bool _areDlcContentAllowed; // 0x1c(0x01)
	bool _isPrivateMatch; // 0x1d(0x01)
	char pad_1E[0x2]; // 0x1e(0x02)
};

