// Class SoundFields.AmbisonicsEncodingSettings
// Size: 0x38 (Inherited: 0x30)
struct UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase {
	int32_t AmbisonicsOrder; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

