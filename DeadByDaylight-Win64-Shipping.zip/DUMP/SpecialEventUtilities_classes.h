// Class SpecialEventUtilities.RespawnableInteractable
// Size: 0x338 (Inherited: 0x310)
struct ARespawnableInteractable : AInteractable {
	struct FMulticastInlineDelegate OnInteractionEnded; // 0x310(0x10)
	struct FMulticastInlineDelegate OnIsInteractingChanged; // 0x320(0x10)
	bool _isHidden; // 0x330(0x01)
	char pad_331[0x7]; // 0x331(0x07)

	void OnUnhidden(); // Function SpecialEventUtilities.RespawnableInteractable.OnUnhidden // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRep_IsHidden(); // Function SpecialEventUtilities.RespawnableInteractable.OnRep_IsHidden // (Final|Native|Private) // @ game+0x33cf150
	void OnHidden(); // Function SpecialEventUtilities.RespawnableInteractable.OnHidden // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool IsHidden(); // Function SpecialEventUtilities.RespawnableInteractable.IsHidden // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a4d380
};

// Class SpecialEventUtilities.RespawningEventComponent
// Size: 0xc8 (Inherited: 0xb8)
struct URespawningEventComponent : UActorComponent {
	struct URespawnableStrategy* _respawnableStrategy; // 0xb8(0x08)
	struct URespawnablePositioner* _respawnablePositioner; // 0xc0(0x08)

	void DBD_ForceRespawnSpecialEventObject(); // Function SpecialEventUtilities.RespawningEventComponent.DBD_ForceRespawnSpecialEventObject // (Final|Exec|Native|Private) // @ game+0x25271c0
	void Authority_OnIsInteractingWithAnyRespawnableInteractableChanged(struct ARespawnableInteractable* RespawnableInteractable, bool IsInteracting); // Function SpecialEventUtilities.RespawningEventComponent.Authority_OnIsInteractingWithAnyRespawnableInteractableChanged // (Native|Protected) // @ game+0x33cfab0
};

// Class SpecialEventUtilities.RespawnableTrigger
// Size: 0xb8 (Inherited: 0xb8)
struct URespawnableTrigger : UActorComponent {
};

// Class SpecialEventUtilities.InteractionRespawnableTrigger
// Size: 0xc0 (Inherited: 0xb8)
struct UInteractionRespawnableTrigger : URespawnableTrigger {
	struct URespawningEventComponent* _respawningEventComponent; // 0xb8(0x08)

	void Authority_OnNewRespawnableSubscribed(struct ARespawnableInteractable* newRespawnableInteractable); // Function SpecialEventUtilities.InteractionRespawnableTrigger.Authority_OnNewRespawnableSubscribed // (Final|Native|Public) // @ game+0x33ced20
	void Authority_OnInteractionEnded(struct ARespawnableInteractable* RespawnableInteractable); // Function SpecialEventUtilities.InteractionRespawnableTrigger.Authority_OnInteractionEnded // (Final|Native|Public) // @ game+0x33ceca0
};

// Class SpecialEventUtilities.RespawnablePositioner
// Size: 0xe0 (Inherited: 0xb8)
struct URespawnablePositioner : UActorComponent {
	struct FMulticastInlineDelegate OnIsInteractingWithAnyRespawnableInteractableChangedEvent; // 0xb8(0x10)
	struct TArray<struct ARespawnableInteractable*> _respawnableInteractables; // 0xc8(0x10)
	char pad_D8[0x8]; // 0xd8(0x08)

	void Authority_OnIsInteractingChangedEvent(struct ARespawnableInteractable* RespawnableInteractable, bool IsInteracting); // Function SpecialEventUtilities.RespawnablePositioner.Authority_OnIsInteractingChangedEvent // (Final|Native|Private) // @ game+0x33cf420
	struct TArray<struct ARespawnableInteractable*> Authority_GetRespawnables(); // Function SpecialEventUtilities.RespawnablePositioner.Authority_GetRespawnables // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33cf390
};

// Class SpecialEventUtilities.RespawnableStrategy
// Size: 0xb8 (Inherited: 0xb8)
struct URespawnableStrategy : UActorComponent {
};

// Class SpecialEventUtilities.RespawnFurthestFromPlayersStrategy
// Size: 0xb8 (Inherited: 0xb8)
struct URespawnFurthestFromPlayersStrategy : URespawnableStrategy {
};

// Class SpecialEventUtilities.RespawningEventUtilities
// Size: 0x30 (Inherited: 0x30)
struct URespawningEventUtilities : UBlueprintFunctionLibrary {
};

// Class SpecialEventUtilities.TimedRespawnableTrigger
// Size: 0x100 (Inherited: 0xb8)
struct UTimedRespawnableTrigger : URespawnableTrigger {
	struct URespawningEventComponent* _respawningEventComponent; // 0xb8(0x08)
	char pad_C0[0x40]; // 0xc0(0x40)
};

