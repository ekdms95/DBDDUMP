// Class SplinteredStates.SplinteredStatesSubsystem
// Size: 0x4f0 (Inherited: 0x38)
struct USplinteredStatesSubsystem : UGameInstanceSubsystem {
	char pad_38[0x4b8]; // 0x38(0x4b8)
};

