// BlueprintGeneratedClass StartScreen.StartScreen_C
// Size: 0x260 (Inherited: 0x250)
struct AStartScreen_C : AStartScreenBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x250(0x08)
	struct AMatineeActor* MatineeActor_1_ExecuteUbergraph_StartScreen_RefProperty; // 0x258(0x08)

	void K2Node_MatineeController_1_FadedOutEvent(); // Function StartScreen.StartScreen_C.K2Node_MatineeController_1_FadedOutEvent // (BlueprintEvent) // @ game+0x3873200
	void K2Node_MatineeController_1_Finished(); // Function StartScreen.StartScreen_C.K2Node_MatineeController_1_Finished // (BlueprintEvent) // @ game+0x3873200
	void ReceiveBeginPlay(); // Function StartScreen.StartScreen_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void BeginDestroyTravelSequence(); // Function StartScreen.StartScreen_C.BeginDestroyTravelSequence // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void ExecuteUbergraph_StartScreen(int32_t EntryPoint); // Function StartScreen.StartScreen_C.ExecuteUbergraph_StartScreen // (Final|UbergraphFunction) // @ game+0x3873200
};

