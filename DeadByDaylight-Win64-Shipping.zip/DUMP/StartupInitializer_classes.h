// Class StartupInitializer.StartupInitializer
// Size: 0x70 (Inherited: 0x30)
struct UStartupInitializer : UObject {
	char pad_30[0x40]; // 0x30(0x40)
};

// Class StartupInitializer.ClientStartupInitializer
// Size: 0x168 (Inherited: 0x70)
struct UClientStartupInitializer : UStartupInitializer {
	char pad_70[0x8]; // 0x70(0x08)
	struct USharedAuthenticationComponent* _sharedAuthenticationComponent; // 0x78(0x08)
	char pad_80[0xe8]; // 0x80(0xe8)
};

// Class StartupInitializer.DedicatedServerStartupInitializer
// Size: 0xa0 (Inherited: 0x70)
struct UDedicatedServerStartupInitializer : UStartupInitializer {
	char pad_70[0x8]; // 0x70(0x08)
	struct UDBDTimeUtilities* _dbdTimeUtilities; // 0x78(0x08)
	char pad_80[0x20]; // 0x80(0x20)
};

