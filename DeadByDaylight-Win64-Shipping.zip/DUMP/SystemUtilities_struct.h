// ScriptStruct SystemUtilities.DateTimer
// Size: 0x28 (Inherited: 0x00)
struct FDateTimer {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct SystemUtilities.DateTimerHandle
// Size: 0x08 (Inherited: 0x00)
struct FDateTimerHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct SystemUtilities.DateTimerArray
// Size: 0x10 (Inherited: 0x00)
struct FDateTimerArray {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct SystemUtilities.FastTimer
// Size: 0x30 (Inherited: 0x00)
struct FFastTimer {
	char pad_0[0x30]; // 0x00(0x30)
};

