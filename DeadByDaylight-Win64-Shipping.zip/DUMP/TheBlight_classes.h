// Class TheBlight.ActivateBlightPower
// Size: 0x680 (Inherited: 0x680)
struct UActivateBlightPower : UChargeableInteractionDefinition {
};

// Class TheBlight.Addon_TheBlight_14
// Size: 0x288 (Inherited: 0x278)
struct UAddon_TheBlight_14 : UItemAddon {
	float _speedIncreasePerDash; // 0x278(0x04)
	char pad_27C[0xc]; // 0x27c(0x0c)
};

// Class TheBlight.Addon_TheBlight_15
// Size: 0x290 (Inherited: 0x288)
struct UAddon_TheBlight_15 : UOnEventBaseAddon {
	float _palletPulldownBlockRange; // 0x288(0x04)
	float _palletPulldownBlockSeconds; // 0x28c(0x04)
};

// Class TheBlight.Addon_TheBlight_18
// Size: 0x290 (Inherited: 0x288)
struct UAddon_TheBlight_18 : UOnEventBaseAddon {
	float _survivorInRangeDistance; // 0x288(0x04)
	float _hinderedSeconds; // 0x28c(0x04)

	void SpawnParticleOnSurvivor(struct ACamperPlayer* CamperPlayer); // Function TheBlight.Addon_TheBlight_18.SpawnParticleOnSurvivor // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_SpawnParticleOnSurvivors(struct TArray<struct ACamperPlayer*> survivors); // Function TheBlight.Addon_TheBlight_18.Multicast_SpawnParticleOnSurvivors // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x33f59d0
};

// Class TheBlight.Addon_TheBlight_19
// Size: 0x278 (Inherited: 0x278)
struct UAddon_TheBlight_19 : UItemAddon {
};

// Class TheBlight.Addon_TheBlight_20
// Size: 0x280 (Inherited: 0x278)
struct UAddon_TheBlight_20 : UItemAddon {
	float _survivorInRangeDistance; // 0x278(0x04)
	float _survivorRevealTime; // 0x27c(0x04)
};

// Class TheBlight.Addon_TheBlight_21
// Size: 0x280 (Inherited: 0x278)
struct UAddon_TheBlight_21 : UItemAddon {
	struct UStatusEffect* _forceKoStatusEffect; // 0x278(0x08)
};

// Class TheBlight.Addon_TheBlight_ConsecutiveDashSpeedBonus
// Size: 0x288 (Inherited: 0x278)
struct UAddon_TheBlight_ConsecutiveDashSpeedBonus : UItemAddon {
	float _speedIncreasePerDash; // 0x278(0x04)
	char pad_27C[0xc]; // 0x27c(0x0c)
};

// Class TheBlight.Addon_TheBlight_SoulChemical
// Size: 0x2e0 (Inherited: 0x278)
struct UAddon_TheBlight_SoulChemical : UItemAddon {
	float _triggerDistance; // 0x278(0x04)
	enum class ESkillCheckCustomType _skillCheckType; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	struct FGameplayTagContainer _interactionSemantics; // 0x280(0x20)
	struct FGameplayTagContainer _blightPowerStateTag; // 0x2a0(0x20)
	char pad_2C0[0x20]; // 0x2c0(0x20)
};

// Class TheBlight.BlightAnimInstance
// Size: 0x5c0 (Inherited: 0x5b0)
struct UBlightAnimInstance : UKillerAnimInstance {
	struct UBlightPowerStateComponent* _blightPowerStateComponent; // 0x5a8(0x08)
	enum class EWallGrabState _powerState; // 0x5b0(0x01)
	float _stateTimeRemaining; // 0x5b4(0x04)
	float _lookAngle; // 0x5b8(0x04)
};

// Class TheBlight.BlightAttackPicker
// Size: 0xb8 (Inherited: 0xb8)
struct UBlightAttackPicker : USlasherAttackPickerComponent {
};

// Class TheBlight.BlightDashAttack
// Size: 0x360 (Inherited: 0x360)
struct UBlightDashAttack : UPounceAttack {
};

// Class TheBlight.BlightDashAttackOpenSubstate
// Size: 0x130 (Inherited: 0x130)
struct UBlightDashAttackOpenSubstate : UPounceAttackOpenSubstate {
};

// Class TheBlight.BlightDashAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UBlightDashAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheBlight.BlightDashAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UBlightDashAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheBlight.BlightDashAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UBlightDashAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheBlight.BlightPower
// Size: 0x5f0 (Inherited: 0x498)
struct ABlightPower : ACollectable {
	struct UPowerChargeComponent* _blightPowerCharge; // 0x498(0x08)
	struct UPowerToggleComponent* _blightPowerToggle; // 0x4a0(0x08)
	struct UChargeableComponent* _blightPowerActivateChargeable; // 0x4a8(0x08)
	struct UBlightPowerStateComponent* _blightPowerStateComponent; // 0x4b0(0x08)
	struct FDBDTunableRowHandle _blightPowerActivateMaxCharge; // 0x4b8(0x28)
	struct FTunableStat _blightPowerMaxCharge; // 0x4e0(0x80)
	struct FDBDTunableRowHandle _blightPowerDechargeRate; // 0x560(0x28)
	struct FDBDTunableRowHandle _blightPowerRechargeRate; // 0x588(0x28)
	char pad_5B0[0x40]; // 0x5b0(0x40)

	void OnPowerStateChanged(enum class EWallGrabState previousState, enum class EWallGrabState newState); // Function TheBlight.BlightPower.OnPowerStateChanged // (Final|Native|Private) // @ game+0x33f5a90
};

// Class TheBlight.BlightPowerEstimatedCollisionIndicator
// Size: 0x238 (Inherited: 0x230)
struct ABlightPowerEstimatedCollisionIndicator : AActor {
	char pad_230[0x8]; // 0x230(0x08)

	void OnShowIndicator_Cosmetic(); // Function TheBlight.BlightPowerEstimatedCollisionIndicator.OnShowIndicator_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnHideIndicator_Cosmetic(); // Function TheBlight.BlightPowerEstimatedCollisionIndicator.OnHideIndicator_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheBlight.BlightPowerState
// Size: 0x180 (Inherited: 0x30)
struct UBlightPowerState : UObject {
	char pad_30[0x10]; // 0x30(0x10)
	struct UCurveFloat* _stateSpeedCurve; // 0x40(0x08)
	struct FTunableStat _stateDuration; // 0x48(0x80)
	struct FDBDTunableRowHandle _cameraPitchRecenterTime; // 0xc8(0x28)
	struct FDBDTunableRowHandle _wallDashCollisionRadius; // 0xf0(0x28)
	struct FDBDTunableRowHandle _wallDashCollisionHeight; // 0x118(0x28)
	struct FDBDTunableRowHandle _wallDashCollisionRange; // 0x140(0x28)
	bool _playerCanCancelEarly; // 0x168(0x01)
	char pad_169[0xf]; // 0x169(0x0f)
	bool _displayCollisionIndicator; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)

	float GetStateDuration(); // Function TheBlight.BlightPowerState.GetStateDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5860
};

// Class TheBlight.BlightPowerStateAdjusting
// Size: 0x1c0 (Inherited: 0x180)
struct UBlightPowerStateAdjusting : UBlightPowerState {
	bool _adjustRotationOnCollision; // 0x180(0x01)
	bool _bounceAwayFromCollision; // 0x181(0x01)
	bool _allowNavigation; // 0x182(0x01)
	bool _smashBreakables; // 0x183(0x01)
	char pad_184[0x4]; // 0x184(0x04)
	struct FDBDTunableRowHandle _maxDistanceForSurvivorFacing; // 0x188(0x28)
	char pad_1B0[0x10]; // 0x1b0(0x10)
};

// Class TheBlight.BlightPowerStateDash
// Size: 0x240 (Inherited: 0x180)
struct UBlightPowerStateDash : UBlightPowerState {
	struct FTunableStat _vectorInterpToSpeed; // 0x180(0x80)
	struct UCurveFloat* _noDashTimeLimitSpeedCurve; // 0x200(0x08)
	struct UCurveFloat* _lookAngleToTurnRateCurveController; // 0x208(0x08)
	struct UCurveFloat* _lookAngleToTurnRateCurveMouse; // 0x210(0x08)
	struct UCurveFloat* _lookAngleToMaxTurnRateCurveMouse; // 0x218(0x08)
	char pad_220[0x20]; // 0x220(0x20)
};

// Class TheBlight.BlightPowerStateAttack
// Size: 0x268 (Inherited: 0x240)
struct UBlightPowerStateAttack : UBlightPowerStateDash {
	char pad_240[0x28]; // 0x240(0x28)
};

// Class TheBlight.BlightPowerStateComponent
// Size: 0x310 (Inherited: 0xb8)
struct UBlightPowerStateComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct FMulticastInlineDelegate OnPowerCollided; // 0xd0(0x10)
	struct TArray<struct UBlightPowerState*> _blightPowerStateClasses; // 0xe0(0x10)
	struct FDBDTunableRowHandle _canDashCheckCollisionRadius; // 0xf0(0x28)
	struct FDBDTunableRowHandle _canDashCheckCollisionHeight; // 0x118(0x28)
	struct FDBDTunableRowHandle _canDashCheckCollisionRange; // 0x140(0x28)
	struct FDBDTunableRowHandle _blightLethalDashDodgeRadius; // 0x168(0x28)
	struct UInteractionDefinition* _powerInteractionDefinition; // 0x190(0x08)
	char pad_198[0x18]; // 0x198(0x18)
	struct UTimerObject* _stateTimer; // 0x1b0(0x08)
	struct TArray<struct UBlightPowerState*> _blightPowerStates; // 0x1b8(0x10)
	struct UBlightPowerState* _currentBlightPowerState; // 0x1c8(0x08)
	char _dashTokens; // 0x1d0(0x01)
	char pad_1D1[0x7]; // 0x1d1(0x07)
	struct FTunableStat _maximumDashTokens; // 0x1d8(0x80)
	struct FTunableStat _tokenChargeRate; // 0x258(0x80)
	char pad_2D8[0x38]; // 0x2d8(0x38)

	void Server_SetWallGrabState(enum class EWallGrabState newState); // Function TheBlight.BlightPowerStateComponent.Server_SetWallGrabState // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x33f5bb0
	void ResetDashTokens(); // Function TheBlight.BlightPowerStateComponent.ResetDashTokens // (Final|Native|Public|BlueprintCallable) // @ game+0x33f5b90
	void OnRep_StateTimer(); // Function TheBlight.BlightPowerStateComponent.OnRep_StateTimer // (Final|Native|Private) // @ game+0x33f5b70
	void OnRep_DashTokens(); // Function TheBlight.BlightPowerStateComponent.OnRep_DashTokens // (Final|Native|Private) // @ game+0x33f5b50
	void OnLevelReadyToPlay(); // Function TheBlight.BlightPowerStateComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x33f5a70
	void Multicast_SetWallGrabState(enum class EWallGrabState newState); // Function TheBlight.BlightPowerStateComponent.Multicast_SetWallGrabState // (Final|Net|NetReliableNative|Event|NetMulticast|Private|NetValidate) // @ game+0x33f5920
	float GetStateTimeRemaining(); // Function TheBlight.BlightPowerStateComponent.GetStateTimeRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f58d0
	struct UTimerObject* GetStateTimer(); // Function TheBlight.BlightPowerStateComponent.GetStateTimer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5900
	float GetStateTimeElapsed(); // Function TheBlight.BlightPowerStateComponent.GetStateTimeElapsed // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5890
	struct UBlightPowerState* GetPowerStateByEnum(enum class EWallGrabState StateEnum); // Function TheBlight.BlightPowerStateComponent.GetPowerStateByEnum // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f57d0
	enum class EWallGrabState GetPowerState(); // Function TheBlight.BlightPowerStateComponent.GetPowerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f57a0
	float GetLookAngleDegrees(); // Function TheBlight.BlightPowerStateComponent.GetLookAngleDegrees // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5770
	char GetDashTokensRemaining(); // Function TheBlight.BlightPowerStateComponent.GetDashTokensRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5750
	struct UBlightPowerState* GetCurrentPowerState(); // Function TheBlight.BlightPowerStateComponent.GetCurrentPowerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f5720
	bool CanDash(); // Function TheBlight.BlightPowerStateComponent.CanDash // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33f56e0
};

// Class TheBlight.BlightPowerStateCooldown
// Size: 0x180 (Inherited: 0x180)
struct UBlightPowerStateCooldown : UBlightPowerState {
};

// Class TheBlight.BlightPowerStateHolding
// Size: 0x1b8 (Inherited: 0x180)
struct UBlightPowerStateHolding : UBlightPowerState {
	struct FSecondaryInteractionProperties _secondaryInteractionProperties; // 0x180(0x30)
	bool _allowNavigation; // 0x1b0(0x01)
	char pad_1B1[0x3]; // 0x1b1(0x03)
	float _dashSpeedForProjection; // 0x1b4(0x04)
};

// Class TheBlight.BlightPowerStateInterface
// Size: 0x30 (Inherited: 0x30)
struct UBlightPowerStateInterface : UInterface {
};

// Class TheBlight.BlightPowerStateLethalDash
// Size: 0x278 (Inherited: 0x240)
struct UBlightPowerStateLethalDash : UBlightPowerStateDash {
	struct FSecondaryInteractionProperties _secondaryInteractionProperties; // 0x240(0x30)
	bool _smashBreakables; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
};

// Class TheBlight.BlightPowerStateNonLethalDash
// Size: 0x248 (Inherited: 0x240)
struct UBlightPowerStateNonLethalDash : UBlightPowerStateDash {
	bool _smashBreakables; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
};

// Class TheBlight.BlightPowerStateReady
// Size: 0x180 (Inherited: 0x180)
struct UBlightPowerStateReady : UBlightPowerState {
};

// Class TheBlight.BuiltToLast
// Size: 0x3e8 (Inherited: 0x3a8)
struct UBuiltToLast : UPerk {
	float _refillPercentage[0x3]; // 0x3a8(0x0c)
	float _depletionToRefillWaitDuration[0x3]; // 0x3b4(0x0c)
	bool _isPerkTriggeredThisTrial; // 0x3c0(0x01)
	char pad_3C1[0x7]; // 0x3c1(0x07)
	struct ACollectable* _heldItem; // 0x3c8(0x08)
	char pad_3D0[0x18]; // 0x3d0(0x18)

	void OnBuiltToLastTrigger_Cosmetic(); // Function TheBlight.BuiltToLast.OnBuiltToLastTrigger_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheBlight.DesperateMeasures
// Size: 0x3b8 (Inherited: 0x3a8)
struct UDesperateMeasures : UPerk {
	float _healAndUnhookMultiplier[0x3]; // 0x3a8(0x0c)
	int32_t _nbInjuredHookedOrDyingSurvivors; // 0x3b4(0x04)
};

// Class TheBlight.DragonsGrip
// Size: 0x408 (Inherited: 0x3a8)
struct UDragonsGrip : UPerk {
	struct AGenerator* _kickedGenerator; // 0x3a8(0x08)
	float _activationDuration[0x3]; // 0x3b0(0x0c)
	float _cooldownDuration[0x3]; // 0x3bc(0x0c)
	float _exposedEffectDuration[0x3]; // 0x3c8(0x0c)
	bool _onlyExposeFirstSurvivor; // 0x3d4(0x01)
	char pad_3D5[0xb]; // 0x3d5(0x0b)
	struct FDBDTunableRowHandle _loudNoiseRange; // 0x3e0(0x28)

	void OnRevealSurvivor(struct ADBDPlayer* Instigator); // Function TheBlight.DragonsGrip.OnRevealSurvivor // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_OnRevealSurvivor(struct ADBDPlayer* survivor); // Function TheBlight.DragonsGrip.Multicast_OnRevealSurvivor // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x32f21d0
};

// Class TheBlight.HexBloodFavor
// Size: 0x438 (Inherited: 0x408)
struct UHexBloodFavor : UHexPerk {
	float _palletInRange[0x3]; // 0x408(0x0c)
	float _palletPulldownBlockTime[0x3]; // 0x414(0x0c)
	float _cooldownDuration[0x3]; // 0x420(0x0c)
	bool _basicAttack; // 0x42c(0x01)
	char pad_42D[0xb]; // 0x42d(0x0b)
};

// Class TheBlight.HexUndying
// Size: 0x470 (Inherited: 0x408)
struct UHexUndying : UHexPerk {
	char pad_408[0x58]; // 0x408(0x58)
	int32_t _amountOfTokenRemove; // 0x460(0x04)
	float _revealAuraDistanceFromTotem[0x3]; // 0x464(0x0c)

	void Authority_UpdateHexPerkStatusView(struct UGameplayModifierContainer* GameplayModifierContainer, bool IsApplicable); // Function TheBlight.HexUndying.Authority_UpdateHexPerkStatusView // (Final|Native|Private) // @ game+0x33f5610
	void Authority_OnSurvivorAdded(struct ACamperPlayer* survivor); // Function TheBlight.HexUndying.Authority_OnSurvivorAdded // (Final|Native|Private) // @ game+0x33f5590
	void Authority_OnCamperCleansedHexPerk(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function TheBlight.HexUndying.Authority_OnCamperCleansedHexPerk // (Final|Native|Private|HasOutParms) // @ game+0x33f5480
};

// Class TheBlight.Visionary
// Size: 0x3c0 (Inherited: 0x3a8)
struct UVisionary : UPerk {
	float _auraVisibilityRange[0x3]; // 0x3a8(0x0c)
	float _cooldownDuration[0x3]; // 0x3b4(0x0c)
};

// Class TheBlight.WallGrabInteractionDefinition
// Size: 0x5a0 (Inherited: 0x560)
struct UWallGrabInteractionDefinition : UInteractionDefinition {
	struct UBlightPowerStateComponent* _blightPowerStateComponent; // 0x558(0x08)
	struct FDBDTunableRowHandle _wallDashAccelerationMultiplier; // 0x560(0x28)
	struct ABlightPowerEstimatedCollisionIndicator* _blightPowerCollisionIndicator; // 0x588(0x08)
	struct ABlightPowerEstimatedCollisionIndicator* _collisionIndicatorActorClass; // 0x590(0x08)
};

