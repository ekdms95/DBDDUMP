// Enum TheBlight.EWallGrabState
enum class EWallGrabState : uint8 {
	None,
	Charging,
	Charged,
	NonLethalCharge,
	Adjusting,
	Holding,
	LethalCharge,
	Cooldown,
	Sliding,
	Attacking,
	EWallGrabState_MAX,
};

