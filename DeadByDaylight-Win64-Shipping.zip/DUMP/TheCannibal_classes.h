// Class TheCannibal.CannibalAnalyticsComponent
// Size: 0x120 (Inherited: 0x100)
struct UCannibalAnalyticsComponent : UChainsawAnalyticsBaseComponent {
	char pad_100[0x20]; // 0x100(0x20)
};

// Class TheCannibal.CannibalChainsawAttack
// Size: 0x430 (Inherited: 0x3d0)
struct UCannibalChainsawAttack : UHillbillyChainsawAttack {
	char pad_3D0[0x10]; // 0x3d0(0x10)
	struct FTagStateBool _isInTantrum; // 0x3e0(0x30)
	char pad_410[0x20]; // 0x410(0x20)
};

// Class TheCannibal.CannibalChainsawAttackOpenSubstate
// Size: 0x180 (Inherited: 0x168)
struct UCannibalChainsawAttackOpenSubstate : UHillbillyChainsawAttackOpenSubstate {
	char pad_168[0x18]; // 0x168(0x18)
};

// Class TheCannibal.CannibalChainsawAttackHittingSubstate
// Size: 0x1a0 (Inherited: 0x1a0)
struct UCannibalChainsawAttackHittingSubstate : UHillbillyChainsawAttackHittingSubstate {
};

// Class TheCannibal.CannibalChainsawAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UCannibalChainsawAttackSuccessSubstate : UHillbillyChainsawAttackSuccessSubstate {
};

// Class TheCannibal.CannibalChainsawAttackMissSubstate
// Size: 0x130 (Inherited: 0x120)
struct UCannibalChainsawAttackMissSubstate : UHillbillyChainsawAttackMissSubstate {
	char pad_120[0x10]; // 0x120(0x10)
};

// Class TheCannibal.CannibalChainsawAttackObstructSubstate
// Size: 0x180 (Inherited: 0x128)
struct UCannibalChainsawAttackObstructSubstate : UHillbillyChainsawAttackObstructSubstate {
	struct FTagStateBool _isInTantrum; // 0x128(0x30)
	char pad_158[0x28]; // 0x158(0x28)
};

// Class TheCannibal.CannibalChainsawHitEventAddon
// Size: 0x288 (Inherited: 0x288)
struct UCannibalChainsawHitEventAddon : UOnEventBaseAddon {
};

// Class TheCannibal.CannibalChainsawPowerComponent
// Size: 0x650 (Inherited: 0xb8)
struct UCannibalChainsawPowerComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct UPowerChargeComponent* _chainsawPowerCharge; // 0xc0(0x08)
	struct UPowerChargeComponent* _chainsawPowerDischarge; // 0xc8(0x08)
	struct UPowerChargeComponent* _tantrumPowerCharge; // 0xd0(0x08)
	char pad_D8[0xc8]; // 0xd8(0xc8)
	struct FTagStateBool _isInTantrum; // 0x1a0(0x30)
	int32_t _numPowerCharges; // 0x1d0(0x04)
	int32_t _numPowerChargesConsumed; // 0x1d4(0x04)
	char pad_1D8[0x8]; // 0x1d8(0x08)
	struct FTunableStat _chainsawDashDuration; // 0x1e0(0x80)
	struct FTunableStat _chainsawPowerMaxCharge; // 0x260(0x80)
	struct FTunableStat _chainsawChargeRate; // 0x2e0(0x80)
	struct FTunableStat _chainsawMaxNumberOfCharges; // 0x360(0x80)
	struct FDBDTunableRowHandle _chainsawCooldownIncreaseRate; // 0x3e0(0x28)
	struct FTunableStat _chainsawCooldownDuration; // 0x408(0x80)
	struct FDBDTunableRowHandle _chainsawMaxCooldownDuration; // 0x488(0x28)
	struct FDBDTunableRowHandle _tantrumChargeRate; // 0x4b0(0x28)
	struct FDBDTunableRowHandle _tantrumDischargeRate; // 0x4d8(0x28)
	struct FTunableStat _tantrumMaxCharge; // 0x500(0x80)
	struct FDBDTunableRowHandle _tantrumDurationIncreaseRate; // 0x580(0x28)
	struct FTunableStat _tantrumDuration; // 0x5a8(0x80)
	struct FDBDTunableRowHandle _tantrumMaxDuration; // 0x628(0x28)

	void Server_OnTantrumPowerChargeFull(); // Function TheCannibal.CannibalChainsawPowerComponent.Server_OnTantrumPowerChargeFull // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x33fd770
	void OnRep_NumPowerCharges(int32_t previousNumPowerCharges); // Function TheCannibal.CannibalChainsawPowerComponent.OnRep_NumPowerCharges // (Final|Native|Private) // @ game+0x33fd6f0
	void OnLevelReadyToPlay(); // Function TheCannibal.CannibalChainsawPowerComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x33fd6d0
	void Multicast_OnTantrumPowerChargeFull(); // Function TheCannibal.CannibalChainsawPowerComponent.Multicast_OnTantrumPowerChargeFull // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc4840
	void Local_OnTantrumPowerChargeFull(); // Function TheCannibal.CannibalChainsawPowerComponent.Local_OnTantrumPowerChargeFull // (Final|Native|Private) // @ game+0x33fd6b0
	int32_t GetNumberOfChainsawPowerCharges(); // Function TheCannibal.CannibalChainsawPowerComponent.GetNumberOfChainsawPowerCharges // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33fd680
	void Authority_OnChainsawPowerChargeFull(); // Function TheCannibal.CannibalChainsawPowerComponent.Authority_OnChainsawPowerChargeFull // (Final|Native|Private) // @ game+0x33fd660
};

// Class TheCannibal.CannibalChainsawRevInteraction
// Size: 0x770 (Inherited: 0x6e0)
struct UCannibalChainsawRevInteraction : UChainsawRevInteraction {
	char pad_6E0[0x90]; // 0x6e0(0x90)
};

// Class TheCannibal.CannibalPowerPresentationItemProgressComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UCannibalPowerPresentationItemProgressComponent : UPresentationItemProgressComponent {
	struct UCannibalChainsawPowerComponent* _cannibalPowerChainsawComponent; // 0xb8(0x08)

	void SetCannibalChainsawPowerComponent(struct UCannibalChainsawPowerComponent* cannibalPowerChainsawComponent); // Function TheCannibal.CannibalPowerPresentationItemProgressComponent.SetCannibalChainsawPowerComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x326a960
};

// Class TheCannibal.CarburetorTuningGuideAddon
// Size: 0x298 (Inherited: 0x288)
struct UCarburetorTuningGuideAddon : UOnEventBaseAddon {
	char pad_288[0x10]; // 0x288(0x10)
};

// Class TheCannibal.IridescentLeatherAddon
// Size: 0x298 (Inherited: 0x288)
struct UIridescentLeatherAddon : UCannibalChainsawHitEventAddon {
	char pad_288[0x10]; // 0x288(0x10)
};

// Class TheCannibal.ShopLubricantAddon
// Size: 0x290 (Inherited: 0x288)
struct UShopLubricantAddon : UOnEventBaseAddon {
	float _auraBlockingDuration; // 0x288(0x04)
	float _auraVisibleDistance; // 0x28c(0x04)
};

