// Class TheClown.ActiveGasCloudTrackerComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UActiveGasCloudTrackerComponent : UActorComponent {
	struct TArray<struct ABaseGasCloudProjectile*> _activeToxinClouds; // 0xb8(0x10)
	struct TArray<struct ABaseGasCloudProjectile*> _activeAntidoteClouds; // 0xc8(0x10)
};

// Class TheClown.BaseGasCloudProjectile
// Size: 0x4b0 (Inherited: 0x288)
struct ABaseGasCloudProjectile : APhysicsBasedProjectile {
	enum class EBombType _gasType; // 0x288(0x01)
	char pad_289[0x7]; // 0x289(0x07)
	struct UPoolableProjectileComponent* _poolableProjectile; // 0x290(0x08)
	struct FDBDTunableRowHandle _gasCloudDuration; // 0x298(0x28)
	struct FDBDTunableRowHandle _gasCloudGravityScale; // 0x2c0(0x28)
	struct FDBDTunableRowHandle _gasCloudBounciness; // 0x2e8(0x28)
	struct FDBDTunableRowHandle _gasCloudFriction; // 0x310(0x28)
	struct FDBDTunableRowHandle _dissipateGasCloudTime; // 0x338(0x28)
	struct FDBDTunableRowHandle _gasCloudMinimumLifetime; // 0x360(0x28)
	struct FDBDTunableRowHandle _gasCloudSimpleCollisionRadius; // 0x388(0x28)
	struct FDBDTunableRowHandle _gasCloudComplexCollisionRadius; // 0x3b0(0x28)
	struct FDBDTunableRowHandle _gasCloudSurvivorDetectionRadius; // 0x3d8(0x28)
	struct FDBDTunableRowHandle _gasCloudDetectionDelay; // 0x400(0x28)
	struct FDBDTunableRowHandle _gasCloudCosmeticFadeDuration; // 0x428(0x28)
	float _overlappingTime; // 0x450(0x04)
	bool _dissipating; // 0x454(0x01)
	char pad_455[0x3]; // 0x455(0x03)
	struct TArray<struct ACamperPlayer*> _overlappingSurvivors; // 0x458(0x10)
	struct UParticleSystemComponent* _gasParticleSystem; // 0x468(0x08)
	struct USphereComponent* _simpleCollider; // 0x470(0x08)
	struct USphereComponent* _complexCollider; // 0x478(0x08)
	struct USpherePlayerOverlapComponent* _survivorDetector; // 0x480(0x08)
	struct UActiveGasCloudTrackerComponent* _activeGasCloudTracker; // 0x488(0x08)
	struct FGameplayTag _cloudSizeModifierTag; // 0x490(0x0c)
	char pad_49C[0x4]; // 0x49c(0x04)
	float _cumulativeLifetime; // 0x4a0(0x04)
	char pad_4A4[0xc]; // 0x4a4(0x0c)

	void SetIsDissipating(bool IsDissipating); // Function TheClown.BaseGasCloudProjectile.SetIsDissipating // (Final|Native|Public|BlueprintCallable) // @ game+0x3402c00
	void SetIgnoredActors(); // Function TheClown.BaseGasCloudProjectile.SetIgnoredActors // (Final|Native|Private) // @ game+0x3402be0
	void SetGasAudioActive(bool activated); // Function TheClown.BaseGasCloudProjectile.SetGasAudioActive // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDelayedActivationStart(float Delay); // Function TheClown.BaseGasCloudProjectile.OnDelayedActivationStart // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnActorOverlapEnd(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function TheClown.BaseGasCloudProjectile.OnActorOverlapEnd // (Final|Native|Public) // @ game+0x3402b20
	void OnActorOverlapBegin(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function TheClown.BaseGasCloudProjectile.OnActorOverlapBegin // (Final|Native|Public) // @ game+0x3402a60
	void OnAcquiredChanged(bool acquired); // Function TheClown.BaseGasCloudProjectile.OnAcquiredChanged // (Final|Native|Private) // @ game+0x34029d0
	void Multicast_DissipateGasCloud(); // Function TheClown.BaseGasCloudProjectile.Multicast_DissipateGasCloud // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x333f9d0
	bool IsSurvivorDetectionEnabled(); // Function TheClown.BaseGasCloudProjectile.IsSurvivorDetectionEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x34029a0
	bool IsDissipating(); // Function TheClown.BaseGasCloudProjectile.IsDissipating // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x3402980
	enum class EBombType GetGasType(); // Function TheClown.BaseGasCloudProjectile.GetGasType // (Final|Native|Public|BlueprintCallable) // @ game+0x3402960
	void DissipateGasCloud(); // Function TheClown.BaseGasCloudProjectile.DissipateGasCloud // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x332f2f0
	void Authority_SetCumulativeLifetime(float value); // Function TheClown.BaseGasCloudProjectile.Authority_SetCumulativeLifetime // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x34028e0
	float Authority_GetCumulativeLifetime(); // Function TheClown.BaseGasCloudProjectile.Authority_GetCumulativeLifetime // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34028b0
	void ActivateCosmetic_BP(); // Function TheClown.BaseGasCloudProjectile.ActivateCosmetic_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheClown.AntidoteCloudProjectile
// Size: 0x4b0 (Inherited: 0x4b0)
struct AAntidoteCloudProjectile : ABaseGasCloudProjectile {
};

// Class TheClown.BombLauncher
// Size: 0x198 (Inherited: 0x180)
struct UBombLauncher : UKillerProjectileLauncher {
	struct UCurveFloat* _speedCurve; // 0x180(0x08)
	struct UCurveFloat* _pitchCurve; // 0x188(0x08)
	enum class EBombType _currentBombType; // 0x190(0x01)
	char pad_191[0x7]; // 0x191(0x07)

	void SetProjectileSpeedCurve(struct UCurveFloat* newProjectileSpeedCurve); // Function TheClown.BombLauncher.SetProjectileSpeedCurve // (Final|Native|Public|BlueprintCallable) // @ game+0x3278d20
	void SetProjectilePitchCurve(struct UCurveFloat* newProjectilePitchCurve); // Function TheClown.BombLauncher.SetProjectilePitchCurve // (Final|Native|Public|BlueprintCallable) // @ game+0x3403250
	void SetPercentThrowStrength(float throwStrength); // Function TheClown.BombLauncher.SetPercentThrowStrength // (Final|Native|Public|BlueprintCallable) // @ game+0x34031d0
	void Server_SwitchBombType(); // Function TheClown.BombLauncher.Server_SwitchBombType // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x3403180
	void LocalLaunch(float percentThrowStrength); // Function TheClown.BombLauncher.LocalLaunch // (Final|Native|Public|BlueprintCallable) // @ game+0x3403100
	void Local_SwitchBombType(); // Function TheClown.BombLauncher.Local_SwitchBombType // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	bool IsBombFullyCharged(); // Function TheClown.BombLauncher.IsBombFullyCharged // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34030d0
	float GetPercentThrowStrenght(); // Function TheClown.BombLauncher.GetPercentThrowStrenght // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34030b0
	enum class EBombType GetCurrentBombType(); // Function TheClown.BombLauncher.GetCurrentBombType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3403080
};

// Class TheClown.GassedStatusEffect
// Size: 0x400 (Inherited: 0x320)
struct UGassedStatusEffect : UStatusEffect {
	struct FMulticastInlineDelegate _onIsInCloudChanged; // 0x320(0x10)
	struct FMulticastInlineDelegate _onIsInAntidoteCloudChanged; // 0x330(0x10)
	struct FMulticastInlineDelegate _onOverlappingCloudAdded; // 0x340(0x10)
	bool _isInCloud; // 0x350(0x01)
	bool _isInAntidoteCloud; // 0x351(0x01)
	char pad_352[0x6]; // 0x352(0x06)
	struct TSet<struct ABaseGasCloudProjectile*> _overlappingClouds; // 0x358(0x50)
	struct TSet<struct ABaseGasCloudProjectile*> _overlappingAntidoteClouds; // 0x3a8(0x50)
	char pad_3F8[0x8]; // 0x3f8(0x08)

	void UpdateAntidoteEffectVFX(float durationRemaining); // Function TheClown.GassedStatusEffect.UpdateAntidoteEffectVFX // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetRemainingDuration(float value); // Function TheClown.GassedStatusEffect.SetRemainingDuration // (Final|Native|Public|BlueprintCallable) // @ game+0x3404220
	void SetRemainingAntidoteDuration(float value); // Function TheClown.GassedStatusEffect.SetRemainingAntidoteDuration // (Final|Native|Public|BlueprintCallable) // @ game+0x34041a0
	void OnToxinEffectEnd(float durationSkipped); // Function TheClown.GassedStatusEffect.OnToxinEffectEnd // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnToxinEffectBegin(float effectDuration); // Function TheClown.GassedStatusEffect.OnToxinEffectBegin // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnToxinCured(); // Function TheClown.GassedStatusEffect.OnToxinCured // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRep_IsInCloud(); // Function TheClown.GassedStatusEffect.OnRep_IsInCloud // (Final|Native|Private) // @ game+0x3404180
	void OnRep_IsInAntidoteCloud(); // Function TheClown.GassedStatusEffect.OnRep_IsInAntidoteCloud // (Final|Native|Private) // @ game+0x3404160
	void OnDirectBottleHit(enum class EBombType bottleType); // Function TheClown.GassedStatusEffect.OnDirectBottleHit // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnAntidoteEffectEnd(float durationSkipped); // Function TheClown.GassedStatusEffect.OnAntidoteEffectEnd // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnAntidoteEffectBegin(float effectDuration); // Function TheClown.GassedStatusEffect.OnAntidoteEffectBegin // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool IsInCloud(); // Function TheClown.GassedStatusEffect.IsInCloud // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3404130
	bool IsInAntidoteCloud(); // Function TheClown.GassedStatusEffect.IsInAntidoteCloud // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3404100
	float GetRemainingDuration(); // Function TheClown.GassedStatusEffect.GetRemainingDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34040d0
	float GetRemainingAntidoteDuration(); // Function TheClown.GassedStatusEffect.GetRemainingAntidoteDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34040a0
	float GetCloudEffectDuration(); // Function TheClown.GassedStatusEffect.GetCloudEffectDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3404070
	float GetAntidoteCloudEffectDuration(); // Function TheClown.GassedStatusEffect.GetAntidoteCloudEffectDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3404040
	void Authority_SetIsInCloud(bool value); // Function TheClown.GassedStatusEffect.Authority_SetIsInCloud // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3403fb0
	void Authority_SetIsInAntidoteCloud(bool value); // Function TheClown.GassedStatusEffect.Authority_SetIsInAntidoteCloud // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3403f20
	void Authority_RemoveOverlappingCloud(struct ABaseGasCloudProjectile* cloud); // Function TheClown.GassedStatusEffect.Authority_RemoveOverlappingCloud // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3403ea0
	void Authority_AddOverlappingCloud(struct ABaseGasCloudProjectile* cloud); // Function TheClown.GassedStatusEffect.Authority_AddOverlappingCloud // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3403e20
};

// Class TheClown.GassedSurvivorSubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UGassedSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isGassed; // 0x4f0(0x01)
	char pad_4F1[0xf]; // 0x4f1(0x0f)
};

// Class TheClown.TheClownUtilities
// Size: 0x30 (Inherited: 0x30)
struct UTheClownUtilities : UBlueprintFunctionLibrary {

	bool IsGassed(struct ADBDPlayer* Player); // Function TheClown.TheClownUtilities.IsGassed // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3404830
	bool IsAffectedByAntidote(struct ADBDPlayer* Player); // Function TheClown.TheClownUtilities.IsAffectedByAntidote // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x34047b0
	struct UGassedStatusEffect* GetGassedStatusEffect(struct ADBDPlayer* Player); // Function TheClown.TheClownUtilities.GetGassedStatusEffect // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3404730
	struct UActiveGasCloudTrackerComponent* GetActiveGasCloudTrackerComponent(struct UObject* WorldContextObject); // Function TheClown.TheClownUtilities.GetActiveGasCloudTrackerComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x34046b0
	bool CanBeGassed(struct ADBDPlayer* Player); // Function TheClown.TheClownUtilities.CanBeGassed // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3404630
};

