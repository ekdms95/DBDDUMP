// Enum TheClown.EBombType
enum class EBombType : uint8 {
	Toxin,
	Antidote,
	EBombType_MAX,
};

