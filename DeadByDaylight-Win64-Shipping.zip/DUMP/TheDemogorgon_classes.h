// Class TheDemogorgon.DemogorgonPounceAttack
// Size: 0x3d0 (Inherited: 0x360)
struct UDemogorgonPounceAttack : UPounceAttack {
	char pad_360[0x70]; // 0x360(0x70)
};

// Class TheDemogorgon.DemogorgonPounceAttackOpenSubstate
// Size: 0x130 (Inherited: 0x130)
struct UDemogorgonPounceAttackOpenSubstate : UPounceAttackOpenSubstate {
};

// Class TheDemogorgon.DemogorgonPounceAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UDemogorgonPounceAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheDemogorgon.DemogorgonPounceAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UDemogorgonPounceAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheDemogorgon.DemogorgonPounceAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UDemogorgonPounceAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheDemogorgon.DemogorgonPounceInteraction
// Size: 0x730 (Inherited: 0x680)
struct UDemogorgonPounceInteraction : UChargeableInteractionDefinition {
	char pad_680[0x70]; // 0x680(0x70)
	struct UChargedAttackStateComponent* _chargedAttackState; // 0x6f0(0x08)
	struct ASlasherPlayer* _owningSlasher; // 0x6f8(0x08)
	char pad_700[0x30]; // 0x700(0x30)

	void TriggerHuntingAudioEvent(bool isHunting); // Function TheDemogorgon.DemogorgonPounceInteraction.TriggerHuntingAudioEvent // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void TriggerChargeCancelAudioEvent(); // Function TheDemogorgon.DemogorgonPounceInteraction.TriggerChargeCancelAudioEvent // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnChargedAttackReadyChanged(bool Ready); // Function TheDemogorgon.DemogorgonPounceInteraction.OnChargedAttackReadyChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnCancelCooldownComplete(); // Function TheDemogorgon.DemogorgonPounceInteraction.OnCancelCooldownComplete // (Native|Event|Protected|BlueprintEvent) // @ game+0x3407f30
};

// Class TheDemogorgon.DemogorgonPowerItemProgressComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UDemogorgonPowerItemProgressComponent : UPresentationItemProgressComponent {
	struct UPortalPlacerStateComponent* _portalPlacerState; // 0xb8(0x08)
};

// Class TheDemogorgon.ElevensSodaAddon
// Size: 0x290 (Inherited: 0x278)
struct UElevensSodaAddon : UItemAddon {
	char pad_278[0x18]; // 0x278(0x18)

	void Multicast_UnhighlightGenerator(struct AGenerator* Generator); // Function TheDemogorgon.ElevensSodaAddon.Multicast_UnhighlightGenerator // (Final|Net|NetReliableNative|Event|NetMulticast|Private|Const) // @ game+0x34083d0
	void Multicast_HighlightGenerator(struct AGenerator* Generator); // Function TheDemogorgon.ElevensSodaAddon.Multicast_HighlightGenerator // (Final|Net|NetReliableNative|Event|NetMulticast|Private|Const) // @ game+0x3408340
};

// Class TheDemogorgon.PortalSurvivorSubAnimInstance
// Size: 0x540 (Inherited: 0x4f0)
struct UPortalSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	char pad_4F0[0x40]; // 0x4f0(0x40)
	bool _isDestroyingPortal; // 0x530(0x01)
	bool _isSpooked; // 0x531(0x01)
	bool _hasSkillCheckFailed; // 0x532(0x01)
	char pad_533[0xd]; // 0x533(0x0d)
};

