// Class TheDoctor.DoctorAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UDoctorAnimInstance : UKillerAnimInstance {
};

// Class TheDoctor.MadnessSurvivorSubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UMadnessSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isTotallyInsane; // 0x4f0(0x01)
	char pad_4F1[0xf]; // 0x4f1(0x0f)
};

// Class TheDoctor.SurvivorMadnessEffect
// Size: 0x400 (Inherited: 0x320)
struct USurvivorMadnessEffect : UStatusEffect {
	char pad_320[0x8]; // 0x320(0x08)
	float _madness; // 0x328(0x04)
	char pad_32C[0xd4]; // 0x32c(0xd4)

	void Server_AddMadness(float madnessToAdd); // Function TheDoctor.SurvivorMadnessEffect.Server_AddMadness // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x340bec0
	void OnStaticBlastReceived_BP(); // Function TheDoctor.SurvivorMadnessEffect.OnStaticBlastReceived_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnStaticBlastReceived(); // Function TheDoctor.SurvivorMadnessEffect.OnStaticBlastReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x340bea0
	void OnSnapOutOfIt_BP(); // Function TheDoctor.SurvivorMadnessEffect.OnSnapOutOfIt_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnSnapOutOfIt(); // Function TheDoctor.SurvivorMadnessEffect.OnSnapOutOfIt // (Final|Native|Public|BlueprintCallable) // @ game+0x340be80
	void OnShockTherapyReceived_BP(); // Function TheDoctor.SurvivorMadnessEffect.OnShockTherapyReceived_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnShockTherapyReceived(); // Function TheDoctor.SurvivorMadnessEffect.OnShockTherapyReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x340be60
	void OnMadnessTierUp_BP(); // Function TheDoctor.SurvivorMadnessEffect.OnMadnessTierUp_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnMadnessTierDown_BP(); // Function TheDoctor.SurvivorMadnessEffect.OnMadnessTierDown_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_UpdateMadnessPlayerTags(int32_t newMadness); // Function TheDoctor.SurvivorMadnessEffect.Multicast_UpdateMadnessPlayerTags // (Final|Net|NetReliableNative|Event|NetMulticast|Private|NetValidate) // @ game+0x340bda0
	void Multicast_OnMadnessTierUp(); // Function TheDoctor.SurvivorMadnessEffect.Multicast_OnMadnessTierUp // (Final|Net|NetReliableNative|Event|NetMulticast|Private|NetValidate) // @ game+0x340bd50
	void Multicast_OnMadnessTierDown(); // Function TheDoctor.SurvivorMadnessEffect.Multicast_OnMadnessTierDown // (Final|Net|NetReliableNative|Event|NetMulticast|Private|NetValidate) // @ game+0x340bd00
	float GetMadnessValue(); // Function TheDoctor.SurvivorMadnessEffect.GetMadnessValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x340bce0
	int32_t GetMadnessTier(); // Function TheDoctor.SurvivorMadnessEffect.GetMadnessTier // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x340bca0
	void ChangeMadnessAudio_Cosmetic(int32_t madnessTier); // Function TheDoctor.SurvivorMadnessEffect.ChangeMadnessAudio_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void Authority_OnMadnessScreamTimerEnd_BP(); // Function TheDoctor.SurvivorMadnessEffect.Authority_OnMadnessScreamTimerEnd_BP // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheDoctor.TheDoctorUtilities
// Size: 0x30 (Inherited: 0x30)
struct UTheDoctorUtilities : UBlueprintFunctionLibrary {

	bool IsTotallyInsane(struct ADBDPlayer* Player); // Function TheDoctor.TheDoctorUtilities.IsTotallyInsane // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x340c310
	struct USurvivorMadnessEffect* GetSurvivorMadnessEffect(struct ADBDPlayer* Player); // Function TheDoctor.TheDoctorUtilities.GetSurvivorMadnessEffect // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x340c290
	int32_t GetMadnessTier(struct ADBDPlayer* Player); // Function TheDoctor.TheDoctorUtilities.GetMadnessTier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x340c210
	bool CanGainInsanity(struct ADBDPlayer* Player); // Function TheDoctor.TheDoctorUtilities.CanGainInsanity // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x340c190
};

