// Class TheExecutioner.ActivateTormentModeInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct UActivateTormentModeInteraction : UChargeableInteractionDefinition {
	char pad_680[0x20]; // 0x680(0x20)

	void SetTormentMode(struct ATormentMode* tormentModeComponent); // Function TheExecutioner.ActivateTormentModeInteraction.SetTormentMode // (Final|Native|Public|BlueprintCallable) // @ game+0x3435d10
};

// Class TheExecutioner.Addon_TormentMode_17
// Size: 0x288 (Inherited: 0x280)
struct UAddon_TormentMode_17 : USpawnEffectsOnAllSurvivorsBaseAddon {
	float _blindnessDuration; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class TheExecutioner.Addon_TormentMode_18
// Size: 0x288 (Inherited: 0x280)
struct UAddon_TormentMode_18 : USpawnEffectsOnAllSurvivorsBaseAddon {
	float _obliviousDuration; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class TheExecutioner.Addon_TormentMode_19
// Size: 0x278 (Inherited: 0x278)
struct UAddon_TormentMode_19 : UItemAddon {
};

// Class TheExecutioner.Addon_TormentMode_20
// Size: 0x280 (Inherited: 0x278)
struct UAddon_TormentMode_20 : UItemAddon {
	float _lingerDuration; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
};

// Class TheExecutioner.Addon_TormentMode_21
// Size: 0x290 (Inherited: 0x280)
struct UAddon_TormentMode_21 : USpawnEffectsOnAllSurvivorsBaseAddon {
	bool _revealSurvivorsInAgony; // 0x280(0x01)
	bool _revealSurvivorsNotInAgony; // 0x281(0x01)
	char pad_282[0x2]; // 0x282(0x02)
	float _range; // 0x284(0x04)
	float _revealDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheExecutioner.AgonyComponent
// Size: 0x2a8 (Inherited: 0xb8)
struct UAgonyComponent : UActorComponent {
	char pad_B8[0x10]; // 0xb8(0x10)
	struct FTagStateBool _isInAgony; // 0xc8(0x30)
	struct FTagStateBool _isAgonyMoriable; // 0xf8(0x30)
	struct FTunableStat _agonyNumberOfHookForMiniMori; // 0x128(0x80)
	char pad_1A8[0x38]; // 0x1a8(0x38)
	bool _inAttackTrailDamageCooldown; // 0x1e0(0x01)
	char pad_1E1[0x7]; // 0x1e1(0x07)
	struct FTunableStat _attackTrailDamageCooldownTime; // 0x1e8(0x80)
	char pad_268[0x18]; // 0x268(0x18)
	struct TArray<struct FAgonyDisplayFxEvent> _showAgonyFXEvents; // 0x280(0x10)
	struct TArray<struct FAgonyDisplayFxEvent> _hideAgonyFXEvents; // 0x290(0x10)
	char pad_2A0[0x8]; // 0x2a0(0x08)

	void ShowAgonyBarbWireFX_Cosmetic(); // Function TheExecutioner.AgonyComponent.ShowAgonyBarbWireFX_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTrailEffectStop_Cosmetic(); // Function TheExecutioner.AgonyComponent.OnTrailEffectStop_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTrailEffectStart_Cosmetic(); // Function TheExecutioner.AgonyComponent.OnTrailEffectStart_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnShowBarbWireFXOnGameEvent(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheExecutioner.AgonyComponent.OnShowBarbWireFXOnGameEvent // (Final|Native|Private|HasOutParms) // @ game+0x34356a0
	void OnRep_IsInAgony(); // Function TheExecutioner.AgonyComponent.OnRep_IsInAgony // (Final|Native|Private) // @ game+0x3435660
	void OnLocallyObservedChanged(bool IsLocallyObserved); // Function TheExecutioner.AgonyComponent.OnLocallyObservedChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnHitInAgony_Cosmetic(); // Function TheExecutioner.AgonyComponent.OnHitInAgony_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnHitByTormentAttackTrail_Cosmetic(); // Function TheExecutioner.AgonyComponent.OnHitByTormentAttackTrail_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnHideBarbWireFXOnGameEvent(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheExecutioner.AgonyComponent.OnHideBarbWireFXOnGameEvent // (Final|Native|Private|HasOutParms) // @ game+0x3435450
	void OnAgonyChanged_Cosmetic(bool IsInAgony); // Function TheExecutioner.AgonyComponent.OnAgonyChanged_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	bool IsInAgony(); // Function TheExecutioner.AgonyComponent.IsInAgony // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34351d0
	bool IsAgonyMoriable(); // Function TheExecutioner.AgonyComponent.IsAgonyMoriable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34351a0
	void HideAgonyBarbWireFX_Cosmetic(); // Function TheExecutioner.AgonyComponent.HideAgonyBarbWireFX_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnDrainStageChanged(int32_t DrainStage, struct ADBDPlayer* Target); // Function TheExecutioner.AgonyComponent.Authority_OnDrainStageChanged // (Final|Native|Private) // @ game+0x3434e60
	void Authority_OnAttackTrailDamageCooldownTimerDone(); // Function TheExecutioner.AgonyComponent.Authority_OnAttackTrailDamageCooldownTimerDone // (Final|Native|Private) // @ game+0x3434e40
};

// Class TheExecutioner.AgonyMoriInteraction
// Size: 0x6a0 (Inherited: 0x6a0)
struct UAgonyMoriInteraction : UKillInteractionDefinition {
};

// Class TheExecutioner.AgonySubAnimInstance
// Size: 0x500 (Inherited: 0x4f0)
struct UAgonySubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isInAgony; // 0x4f0(0x01)
	bool _isInTormentTrail; // 0x4f1(0x01)
	bool _isInTormentTrailEffect; // 0x4f2(0x01)
	bool _isInDeathBed; // 0x4f3(0x01)
	bool _isDeadInDeathBed; // 0x4f4(0x01)
	bool _isInStruggleInDeathBed; // 0x4f5(0x01)
	char pad_4F6[0xa]; // 0x4f6(0x0a)
};

// Class TheExecutioner.BaseTormentTrailPoint
// Size: 0x330 (Inherited: 0x230)
struct ABaseTormentTrailPoint : AActor {
	char pad_230[0x18]; // 0x230(0x18)
	struct USphereComponent* _collisionComponent; // 0x248(0x08)
	float _collisionRadius; // 0x250(0x04)
	char pad_254[0x4]; // 0x254(0x04)
	struct FTunableStat _tormentTrailAliveTime; // 0x258(0x80)
	char pad_2D8[0x30]; // 0x2d8(0x30)
	struct USplineMeshComponent* _splineMeshComponent; // 0x308(0x08)
	struct TArray<struct UStaticMesh*> _trailMeshList; // 0x310(0x10)
	char _indexInTrail; // 0x320(0x01)
	char pad_321[0xf]; // 0x321(0x0f)

	void EndOfDisapearCosmetic(); // Function TheExecutioner.BaseTormentTrailPoint.EndOfDisapearCosmetic // (Final|Native|Protected|BlueprintCallable) // @ game+0x3435070
	void DisappearCosmetic(); // Function TheExecutioner.BaseTormentTrailPoint.DisappearCosmetic // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.BloodPact
// Size: 0x420 (Inherited: 0x3a8)
struct UBloodPact : UPerk {
	char pad_3A8[0x18]; // 0x3a8(0x18)
	bool _dyingToInjured; // 0x3c0(0x01)
	bool _fullHealthStateOnly; // 0x3c1(0x01)
	char pad_3C2[0x2]; // 0x3c2(0x02)
	float _hasteEffectRange; // 0x3c4(0x04)
	float _hasteEffectMovementSpeedIncrease[0x3]; // 0x3c8(0x0c)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct UStatusEffect* _ownerStatusEffect; // 0x3d8(0x08)
	struct UStatusEffect* _obsessionStatusEffect; // 0x3e0(0x08)
	struct UStatusEffect* _ownerHasteStatusEffect; // 0x3e8(0x08)
	struct UStatusEffect* _otherPlayerHasteStatusEffect; // 0x3f0(0x08)
	struct ADBDPlayer* _otherPlayer; // 0x3f8(0x08)
	char pad_400[0x20]; // 0x400(0x20)

	void Authority_OnInRangeChanged(bool InRange); // Function TheExecutioner.BloodPact.Authority_OnInRangeChanged // (Final|Native|Private) // @ game+0x3434f20
};

// Class TheExecutioner.BloodPactEffect
// Size: 0x320 (Inherited: 0x320)
struct UBloodPactEffect : UStatusEffect {
};

// Class TheExecutioner.DeathBedAntiCampComponent
// Size: 0x190 (Inherited: 0xb8)
struct UDeathBedAntiCampComponent : UActorComponent {
	char pad_B8[0x48]; // 0xb8(0x48)
	struct FDBDTunableRowHandle _anticampZoneDistance; // 0x100(0x28)
	struct FDBDTunableRowHandle _anticampZoneTimeToTrigger; // 0x128(0x28)
	char pad_150[0x40]; // 0x150(0x40)

	void Multicast_TriggerDeathBedRelocate(); // Function TheExecutioner.DeathBedAntiCampComponent.Multicast_TriggerDeathBedRelocate // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc4840
	void Authority_OnInRangeChanged(bool InRange); // Function TheExecutioner.DeathBedAntiCampComponent.Authority_OnInRangeChanged // (Final|Native|Private) // @ game+0x3434fb0
};

// Class TheExecutioner.DeathBedInteractable
// Size: 0x448 (Inherited: 0x310)
struct ADeathBedInteractable : AInteractable {
	char pad_310[0x10]; // 0x310(0x10)
	struct USceneComponent* _root; // 0x320(0x08)
	struct ACamperPlayer* _inDeathBedCamper; // 0x328(0x08)
	struct UChargeableComponent* _rescueChargeableComponent; // 0x330(0x08)
	struct USkeletalMeshComponent* _deathBedSkeletalMesh; // 0x338(0x08)
	struct UBoxComponent* _interactionZone; // 0x340(0x08)
	struct UBoxComponent* _playerOverlapZone; // 0x348(0x08)
	struct UMontagePlayer* _montagePlayer; // 0x350(0x08)
	char pad_358[0x10]; // 0x358(0x10)
	struct UBoxComponent* _deathBedCollision; // 0x368(0x08)
	char pad_370[0x28]; // 0x370(0x28)
	struct UAnimationMontageSlave* _animationMontageSlave; // 0x398(0x08)
	struct UAnimMontage* _montageToPlay; // 0x3a0(0x08)
	char pad_3A8[0x4]; // 0x3a8(0x04)
	struct FVector _rescuerSnapPosition; // 0x3ac(0x0c)
	struct UDeathBedAntiCampComponent* _deathBedAnticampComponent; // 0x3b8(0x08)
	char pad_3C0[0x40]; // 0x3c0(0x40)
	struct FDBDTunableRowHandle _anticampDrainCooldownTime; // 0x400(0x28)
	char pad_428[0x18]; // 0x428(0x18)
	struct UAIPerceptionStimuliSourceComponent* _perceptionStimuliComponent; // 0x440(0x08)

	void TeleportCamperToDeathBed(); // Function TheExecutioner.DeathBedInteractable.TeleportCamperToDeathBed // (Final|Native|Private|BlueprintCallable) // @ game+0x3435d90
	void StartPlayerAbsorbedByGround(); // Function TheExecutioner.DeathBedInteractable.StartPlayerAbsorbedByGround // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void SetInDeathBedCamper(struct ACamperPlayer* CamperPlayer); // Function TheExecutioner.DeathBedInteractable.SetInDeathBedCamper // (Final|Native|Public|BlueprintCallable) // @ game+0x3435c90
	void PlayerOverlapZoneEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function TheExecutioner.DeathBedInteractable.PlayerOverlapZoneEndOverlap // (Final|Native|Private) // @ game+0x34359d0
	void PlayerOverlapZoneBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function TheExecutioner.DeathBedInteractable.PlayerOverlapZoneBeginOverlap // (Final|Native|Private|HasOutParms) // @ game+0x34357d0
	void OnSkillCheckFailed_Cosmetic(); // Function TheExecutioner.DeathBedInteractable.OnSkillCheckFailed_Cosmetic // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnSkillCheckFailed(); // Function TheExecutioner.DeathBedInteractable.OnSkillCheckFailed // (Final|Native|Private) // @ game+0x34357b0
	void OnRescueCancelled(); // Function TheExecutioner.DeathBedInteractable.OnRescueCancelled // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRelocateStart_Cosmetic(); // Function TheExecutioner.DeathBedInteractable.OnRelocateStart_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDeathBedDeathEnd(); // Function TheExecutioner.DeathBedInteractable.OnDeathBedDeathEnd // (Final|Native|Public|BlueprintCallable) // @ game+0x3435430
	void Multicast_RelocateToOtherDeathBed(struct ADeathBedInteractable* deathBed, struct ACamperPlayer* CamperPlayer); // Function TheExecutioner.DeathBedInteractable.Multicast_RelocateToOtherDeathBed // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x34352d0
	struct FVector GetRescuerSnapPosition(); // Function TheExecutioner.DeathBedInteractable.GetRescuerSnapPosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x34350f0
	struct UMontagePlayer* GetMontagePlayer(); // Function TheExecutioner.DeathBedInteractable.GetMontagePlayer // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x34350c0
	struct ACamperPlayer* GetInDeathBedCamper(); // Function TheExecutioner.DeathBedInteractable.GetInDeathBedCamper // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3435090
	void FX_SurvivorSavedFromDeathBed(); // Function TheExecutioner.DeathBedInteractable.FX_SurvivorSavedFromDeathBed // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void FX_DeathBedAppear(); // Function TheExecutioner.DeathBedInteractable.FX_DeathBedAppear // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void DeathBedDisappear(); // Function TheExecutioner.DeathBedInteractable.DeathBedDisappear // (Event|Public|BlueprintEvent) // @ game+0x3873200
	bool CanRescueSurvivor(); // Function TheExecutioner.DeathBedInteractable.CanRescueSurvivor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3435040
	void ActivateDeathBed(bool value); // Function TheExecutioner.DeathBedInteractable.ActivateDeathBed // (Final|Native|Private|BlueprintCallable) // @ game+0x3434db0
};

// Class TheExecutioner.DeathBedOutlineUpdateStrategy
// Size: 0x130 (Inherited: 0x130)
struct UDeathBedOutlineUpdateStrategy : USourceBasedOutlineUpdateStrategy {
};

// Class TheExecutioner.DeathBedRescueInteraction
// Size: 0x6b0 (Inherited: 0x680)
struct UDeathBedRescueInteraction : UChargeableInteractionDefinition {
	char pad_680[0x8]; // 0x680(0x08)
	struct FDBDTunableRowHandle _loudNoiseRange; // 0x688(0x28)

	struct FVector GetRescuerSnapPosition(); // Function TheExecutioner.DeathBedRescueInteraction.GetRescuerSnapPosition // (Final|Native|Private|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3435130
};

// Class TheExecutioner.Deathbound
// Size: 0x400 (Inherited: 0x3a8)
struct UDeathbound : UPerk {
	float _distanceFromRescuedSurvivorForOblivious[0x3]; // 0x3a8(0x0c)
	float _activationDuration; // 0x3b4(0x04)
	float _rescueDistanceFromKillerToActivate; // 0x3b8(0x04)
	char pad_3BC[0x4]; // 0x3bc(0x04)
	float _revealLocationDuration; // 0x3c0(0x04)
	bool _unhook; // 0x3c4(0x01)
	bool _fromDyingState; // 0x3c5(0x01)
	char pad_3C6[0x2]; // 0x3c6(0x02)
	struct TArray<struct UStatusEffect*> _obliviousStatusEffects; // 0x3c8(0x10)
	char pad_3D8[0x10]; // 0x3d8(0x10)
	struct TArray<struct ADBDPlayer*> _survivorsToReveal; // 0x3e8(0x10)
	char pad_3F8[0x8]; // 0x3f8(0x08)

	void OnRep_SurvivorsToReveal(); // Function TheExecutioner.Deathbound.OnRep_SurvivorsToReveal // (Final|Native|Private) // @ game+0x3435680
	void MakeSurvivorScream(struct ACamperPlayer* survivor); // Function TheExecutioner.Deathbound.MakeSurvivorScream // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	float GetRevealLocationDuration(); // Function TheExecutioner.Deathbound.GetRevealLocationDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3435170
};

// Class TheExecutioner.ExecutionerTormentAttack
// Size: 0x360 (Inherited: 0x360)
struct UExecutionerTormentAttack : UPounceAttack {

	void Server_TormentTryHitTargetNotInCoolDown(struct ADBDPlayer* Target); // Function TheExecutioner.ExecutionerTormentAttack.Server_TormentTryHitTargetNotInCoolDown // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3435bd0
	void Multicast_TormentHitTarget(struct ADBDPlayer* Target); // Function TheExecutioner.ExecutionerTormentAttack.Multicast_TormentHitTarget // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x34353a0
};

// Class TheExecutioner.ExecutionerTormentAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UExecutionerTormentAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheExecutioner.ExecutionerTormentAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UExecutionerTormentAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheExecutioner.ExecutionerTormentAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UExecutionerTormentAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheExecutioner.ForcedPenance
// Size: 0x3b8 (Inherited: 0x3a8)
struct UForcedPenance : UPerk {
	float _perkActivationDuration[0x3]; // 0x3a8(0x0c)
	bool _applyOblivious; // 0x3b4(0x01)
	bool _applyBroken; // 0x3b5(0x01)
	char pad_3B6[0x2]; // 0x3b6(0x02)
};

// Class TheExecutioner.MobileTormentTrailRenderer
// Size: 0x2b0 (Inherited: 0x230)
struct AMobileTormentTrailRenderer : AActor {
	struct UInstancedStaticMeshComponent* _pillarIsmComponent; // 0x230(0x08)
	struct UInstancedStaticMeshComponent* _wireIsmComponent; // 0x238(0x08)
	struct UInstancedStaticMeshComponent* _trailIsmComponent; // 0x240(0x08)
	struct UInstancedStaticMeshComponent* _pillarOutlineIsmComponent; // 0x248(0x08)
	struct UInstancedStaticMeshComponent* _wireOutlineIsmComponent; // 0x250(0x08)
	struct TMap<struct ABaseTormentTrailPoint*, struct FTormentTrailPointInfo> _instanceMap; // 0x258(0x50)
	struct UMaterialInstanceDynamic* _trailMaterialInstanceDynamic; // 0x2a8(0x08)

	void Multicast_RemoveInstance(struct ABaseTormentTrailPoint* TrailPoint); // Function TheExecutioner.MobileTormentTrailRenderer.Multicast_RemoveInstance // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x336ea90
	void Multicast_AddInstance(struct ABaseTormentTrailPoint* TrailPoint, bool isAttackTrailPoint); // Function TheExecutioner.MobileTormentTrailRenderer.Multicast_AddInstance // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x3435200
};

// Class TheExecutioner.RepressedAlliance
// Size: 0x418 (Inherited: 0x3a8)
struct URepressedAlliance : UPerk {
	struct FSecondaryInteractionProperties _secondaryActionProperties; // 0x3a8(0x30)
	float _repairTimesNeededToActivate[0x3]; // 0x3d8(0x0c)
	float _generatorBlockDuration; // 0x3e4(0x04)
	struct UInteractionDefinition* _currentRepairInteractionWithAbility; // 0x3e8(0x08)
	char pad_3F0[0x18]; // 0x3f0(0x18)
	struct AGenerator* _blockedGenerator; // 0x408(0x08)
	char pad_410[0x8]; // 0x410(0x08)

	void Server_OnActionInputPressed(struct AGenerator* Generator); // Function TheExecutioner.RepressedAlliance.Server_OnActionInputPressed // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3435b10
	void OnRep_CurrentRepairInteractionWithAbility(struct UInteractionDefinition* oldRepairInteraction); // Function TheExecutioner.RepressedAlliance.OnRep_CurrentRepairInteractionWithAbility // (Final|Native|Private) // @ game+0x34355e0
	void OnRep_BlockedGenerator(struct AGenerator* oldGenerator); // Function TheExecutioner.RepressedAlliance.OnRep_BlockedGenerator // (Final|Native|Private) // @ game+0x3435560
};

// Class TheExecutioner.SendToDeathBedInteraction
// Size: 0x690 (Inherited: 0x680)
struct USendToDeathBedInteraction : UChargeableInteractionDefinition {
	char pad_680[0x8]; // 0x680(0x08)
	struct ADeathBedInteractable* _deathBed; // 0x688(0x08)

	void Multicast_SendCamperToDeathBed(struct ADeathBedInteractable* deathBed); // Function TheExecutioner.SendToDeathBedInteraction.Multicast_SendCamperToDeathBed // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x3439200
	struct ACamperPlayer* GetOwningSurvivor(); // Function TheExecutioner.SendToDeathBedInteraction.GetOwningSurvivor // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x3438f90
	void FX_InteractionStart(); // Function TheExecutioner.SendToDeathBedInteraction.FX_InteractionStart // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void FX_InteractionCancel(); // Function TheExecutioner.SendToDeathBedInteraction.FX_InteractionCancel // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.SoulGuard
// Size: 0x3d8 (Inherited: 0x3a8)
struct USoulGuard : UPerk {
	float _cooldownLevels[0x3]; // 0x3a8(0x0c)
	bool _recover; // 0x3b4(0x01)
	char pad_3B5[0x3]; // 0x3b5(0x03)
	float _enduranceEffectDuration[0x3]; // 0x3b8(0x0c)
	char pad_3C4[0x14]; // 0x3c4(0x14)

	void Authority_ShowOnKOPreventedFX(); // Function TheExecutioner.SoulGuard.Authority_ShowOnKOPreventedFX // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnSurvivorHealed(struct FCamperHealResult healResult); // Function TheExecutioner.SoulGuard.Authority_OnSurvivorHealed // (Final|Native|Private|HasOutParms) // @ game+0x3438ec0
};

// Class TheExecutioner.TormentTrailDetectorComponent
// Size: 0x1f8 (Inherited: 0xb8)
struct UTormentTrailDetectorComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct TArray<struct ATormentTrailPoint*> _overlappedTrailPoints; // 0xd0(0x10)
	struct FTagStateBool _isInTormentTrail; // 0xe0(0x30)
	struct FTagStateBool _isInTormentTrailEffect; // 0x110(0x30)
	char pad_140[0x8]; // 0x140(0x08)
	struct FTunableStat _inTormentTrailLastingEffectTime; // 0x148(0x80)
	char pad_1C8[0x30]; // 0x1c8(0x30)
};

// Class TheExecutioner.SurvivorTormentTrailDetector
// Size: 0x210 (Inherited: 0x1f8)
struct USurvivorTormentTrailDetector : UTormentTrailDetectorComponent {
	char pad_1F8[0x18]; // 0x1f8(0x18)
};

// Class TheExecutioner.TheExecutionerAnimInstance
// Size: 0x630 (Inherited: 0x5b0)
struct UTheExecutionerAnimInstance : UKillerAnimInstance {
	bool _isInTormentMode; // 0x5a8(0x01)
	bool _isChargingTormentMode; // 0x5a9(0x01)
	bool _isTormentModeAttacking; // 0x5aa(0x01)
	float _tormentModeVerticalInput; // 0x5ac(0x04)
	float _tormentModeHorizontalInput; // 0x5b0(0x04)
	char pad_5BB[0x75]; // 0x5bb(0x75)

	void NoInputFeedbackCosmetic(); // Function TheExecutioner.TheExecutionerAnimInstance.NoInputFeedbackCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.TheExecutionerCheatComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UTheExecutionerCheatComponent : UActorComponent {

	void DBD_SetCanBeAgonyMoriedOnLocallyControlledPlayer(bool value); // Function TheExecutioner.TheExecutionerCheatComponent.DBD_SetCanBeAgonyMoriedOnLocallyControlledPlayer // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_SetAgonyOnLocallyControlledPlayer(bool value); // Function TheExecutioner.TheExecutionerCheatComponent.DBD_SetAgonyOnLocallyControlledPlayer // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_LocalKillSurvivorInDeathBed(); // Function TheExecutioner.TheExecutionerCheatComponent.DBD_LocalKillSurvivorInDeathBed // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_DisplayAllDeathBed(bool value); // Function TheExecutioner.TheExecutionerCheatComponent.DBD_DisplayAllDeathBed // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_DeathBedPlayStruggleHitReaction(); // Function TheExecutioner.TheExecutionerCheatComponent.DBD_DeathBedPlayStruggleHitReaction // (Final|Exec|Native|Public) // @ game+0x25271c0
};

// Class TheExecutioner.TrailControllerBase
// Size: 0x288 (Inherited: 0x230)
struct ATrailControllerBase : AActor {
	struct UTormentTrailPointCollectionComponent* _tormentTrailPointCollection; // 0x230(0x08)
	struct FDBDTunableRowHandle _distanceBetweenTormentTrailPoint; // 0x238(0x28)
	struct USplineComponent* _splineComponent; // 0x260(0x08)
	char pad_268[0x10]; // 0x268(0x10)
	struct UAuthoritativePoolableActorComponent* _poolableComponent; // 0x278(0x08)
	enum class ETrailType _trailType; // 0x280(0x01)
	char pad_281[0x7]; // 0x281(0x07)

	void RemoveTormentTrailController(); // Function TheExecutioner.TrailControllerBase.RemoveTormentTrailController // (Final|Native|Protected|BlueprintCallable) // @ game+0x3439880
	void OnTrailPointDeath(struct ABaseTormentTrailPoint* baseTrailPoint); // Function TheExecutioner.TrailControllerBase.OnTrailPointDeath // (Native|Protected) // @ game+0x3439760
	void OnAcquireChanged(bool acquired); // Function TheExecutioner.TrailControllerBase.OnAcquireChanged // (Native|Protected) // @ game+0x3439440
	void ActivateCosmetic(bool value); // Function TheExecutioner.TrailControllerBase.ActivateCosmetic // (Event|Public|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.TormentAttackTrailController
// Size: 0x400 (Inherited: 0x288)
struct ATormentAttackTrailController : ATrailControllerBase {
	struct ATormentAttackTrailPoint* _tormentTrailAttackPointClass; // 0x288(0x08)
	struct AActor* _tormentTrailAttackSign; // 0x290(0x08)
	struct FDBDTunableRowHandle _trailSpawnDelay; // 0x298(0x28)
	struct FDBDTunableRowHandle _timeIntervalBetweenPointsSpawn; // 0x2c0(0x28)
	struct FTunableStat _attackTrailLenght; // 0x2e8(0x80)
	struct FDBDTunableRowHandle _consideredAsSlopeAngle; // 0x368(0x28)
	struct TArray<struct FTransform> _pointsTransform; // 0x390(0x10)
	struct FVector _slopeDetectionOverGroundVector; // 0x3a0(0x0c)
	struct FVector _groundDetectionEndVector; // 0x3ac(0x0c)
	struct FVector _slopeCompensationVector; // 0x3b8(0x0c)
	char pad_3C4[0x1c]; // 0x3c4(0x1c)
	struct TArray<struct FSpawnedAttackPoint> _spawnedAttackPointList; // 0x3e0(0x10)
	bool _trailSpawnStarted; // 0x3f0(0x01)
	char pad_3F1[0x3]; // 0x3f1(0x03)
	float _soundDistanceOnTrail; // 0x3f4(0x04)
	struct AMobileTormentTrailRenderer* _mobileTormentTrailRenderer; // 0x3f8(0x08)

	void OnTrailPointRemovedCosmetic(int32_t Index); // Function TheExecutioner.TormentAttackTrailController.OnTrailPointRemovedCosmetic // (Native|Event|Protected|BlueprintEvent) // @ game+0x34397f0
	void OnStartTrailTimerDone(); // Function TheExecutioner.TormentAttackTrailController.OnStartTrailTimerDone // (Final|Native|Private) // @ game+0x3439650
	void OnIntervalBetweenPointsTimerDone(); // Function TheExecutioner.TormentAttackTrailController.OnIntervalBetweenPointsTimerDone // (Final|Native|Private) // @ game+0x3439590
	void OnAttackTrailStartCosmetic(); // Function TheExecutioner.TormentAttackTrailController.OnAttackTrailStartCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_StartAttackTrail(float serverTimeSpawn, struct FVector_NetQuantize10 Location, struct FRotator Rotation); // Function TheExecutioner.TormentAttackTrailController.Multicast_StartAttackTrail // (Final|Net|NetReliableNative|Event|NetMulticast|Private|HasDefaults) // @ game+0x3439290
	void DisplayAttackTrailSpawnSign(); // Function TheExecutioner.TormentAttackTrailController.DisplayAttackTrailSpawnSign // (Native|Event|Protected|BlueprintEvent) // @ game+0x3438f70
};

// Class TheExecutioner.TormentAttackTrailPoint
// Size: 0x388 (Inherited: 0x330)
struct ATormentAttackTrailPoint : ABaseTormentTrailPoint {
	char pad_330[0x30]; // 0x330(0x30)
	struct FDBDTunableRowHandle _attackPointDelayToEnableCollision; // 0x360(0x28)

	void DisplayTrailSplineMesh(struct USplineComponent* splinemesh, int32_t indexInTrail); // Function TheExecutioner.TormentAttackTrailPoint.DisplayTrailSplineMesh // (Event|Public|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.TormentMode
// Size: 0x8e8 (Inherited: 0x498)
struct ATormentMode : ACollectable {
	char pad_498[0x78]; // 0x498(0x78)
	struct UChargeableComponent* _activateTormentModeCharge; // 0x510(0x08)
	struct UPowerChargeComponent* _tormentModeCharge; // 0x518(0x08)
	char pad_520[0x8]; // 0x520(0x08)
	struct UPowerChargePresentationItemProgressComponent* _tormentModeChargePresentation; // 0x528(0x08)
	struct UPowerToggleComponent* _powerToggleComponent; // 0x530(0x08)
	struct UTormentTrailSpawnerComponent* _tormentTrailSpawnerComponent; // 0x538(0x08)
	struct UTormentTrailPointCollectionComponent* _tormentTrailPointCollectionComponent; // 0x540(0x08)
	struct UTormentTrailPointCollectionComponent* _restrictedTormentTrailPointCollectionComponent; // 0x548(0x08)
	struct UAuthoritativeActorPoolComponent* _tormentTrailControllerPool; // 0x550(0x08)
	struct UAuthoritativeActorPoolComponent* _tormentAttackTrailControllerPool; // 0x558(0x08)
	struct UAuthoritativeActorPoolComponent* _restrictedTormentTrailControllerPool; // 0x560(0x08)
	struct UAuthoritativeActorPoolComponent* _tormentTrailPointPool; // 0x568(0x08)
	struct UAuthoritativeActorPoolComponent* _restrictedTormentTrailPointPool; // 0x570(0x08)
	struct FDBDTunableRowHandle _activateTormentModeSecondsToCharge; // 0x578(0x28)
	struct FDBDTunableRowHandle _tormentModeMaxCharge; // 0x5a0(0x28)
	struct FTunableStat _tormentModeChargeRate; // 0x5c8(0x80)
	struct FTunableStat _tormentModeDischargeRate; // 0x648(0x80)
	struct FDBDTunableRowHandle _tormentModePauseChargeRate; // 0x6c8(0x28)
	struct FDBDTunableRowHandle _tormentModeAttackConsumePower; // 0x6f0(0x28)
	struct FDBDTunableRowHandle _tormentModeMinimumPercentToActivate; // 0x718(0x28)
	struct FDBDTunableRowHandle _tormentModeMouseYawScale; // 0x740(0x28)
	struct FDBDTunableRowHandle _tormentModeYawAdjustTime; // 0x768(0x28)
	struct FDBDTunableRowHandle _tormentModeGamePadYawScale; // 0x790(0x28)
	struct FDBDTunableRowHandle _tormentModeYawInputLimit; // 0x7b8(0x28)
	struct FDBDTunableRowHandle _tormentModeNotMovingYawScaleMultiplier; // 0x7e0(0x28)
	struct FDBDTunableRowHandle _tormentModeNotMovingYawAdjustTime; // 0x808(0x28)
	struct FDBDTunableRowHandle _tormentModeWalkSpeed; // 0x830(0x28)
	struct FDBDTunableRowHandle _normalWalkSpeed; // 0x858(0x28)
	struct FDBDTunableRowHandle _tormentModeForcedPitch; // 0x880(0x28)
	struct UAgonyComponent* _agonyComponentClass; // 0x8a8(0x08)
	char pad_8B0[0x10]; // 0x8b0(0x10)
	struct UTormentTrailDetectorComponent* _killerTormentTrailDetectorClass; // 0x8c0(0x08)
	struct UTormentTrailDetectorComponent* _survivorTormentTrailDetectorClass; // 0x8c8(0x08)
	struct UTormentModeCooldownInteraction* _tormentModeCooldownInteraction; // 0x8d0(0x08)
	struct UCurveFloat* _tormentModeChargeSpeedCurve; // 0x8d8(0x08)
	struct AMobileTormentTrailRenderer* _mobileTormentTrailRendererClass; // 0x8e0(0x08)

	void Server_RequestMoreActorInAttackPool(); // Function TheExecutioner.TormentMode.Server_RequestMoreActorInAttackPool // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x34398f0
	void OnTormentModeStop_Cosmetic(); // Function TheExecutioner.TormentMode.OnTormentModeStop_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTormentModeStart_Cosmetic(); // Function TheExecutioner.TormentMode.OnTormentModeStart_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTormentModeChargeEmpty(); // Function TheExecutioner.TormentMode.OnTormentModeChargeEmpty // (Final|Native|Private) // @ game+0x3439670
	bool IsInTormentMode(); // Function TheExecutioner.TormentMode.IsInTormentMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34391d0
};

// Class TheExecutioner.TormentModeCooldownInteraction
// Size: 0x5d0 (Inherited: 0x560)
struct UTormentModeCooldownInteraction : UInteractionDefinition {
	struct FDBDTunableRowHandle _tormentModeCooldownTime; // 0x558(0x28)
	struct FDBDTunableRowHandle _tormentModeCancelWalkSpeed; // 0x580(0x28)
	struct FDBDTunableRowHandle _normalWalkSpeed; // 0x5a8(0x28)
};

// Class TheExecutioner.Tormentor
// Size: 0x30 (Inherited: 0x30)
struct UTormentor : UInterface {

	struct FVector GetTormentTrailSpawnPoint(); // Function TheExecutioner.Tormentor.GetTormentTrailSpawnPoint // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	struct FVector GetTormentTrailAttackSpawnPoint(); // Function TheExecutioner.Tormentor.GetTormentTrailAttackSpawnPoint // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.TormentTrailController
// Size: 0x3b0 (Inherited: 0x288)
struct ATormentTrailController : ATrailControllerBase {
	struct FReplicatedTrailPointList _trailPointList; // 0x288(0x120)
	struct AMobileTormentTrailRenderer* _mobileTormentTrailRenderer; // 0x3a8(0x08)

	void Server_SpawnTormentTrailPoint(struct ATormentTrailPoint* TrailPoint, struct FVector_NetQuantize10 Location, struct FRotator Rotation); // Function TheExecutioner.TormentTrailController.Server_SpawnTormentTrailPoint // (Final|Net|NetReliableNative|Event|Private|NetServer|HasDefaults|NetValidate) // @ game+0x34399f0
};

// Class TheExecutioner.TormentTrailPoint
// Size: 0x358 (Inherited: 0x330)
struct ATormentTrailPoint : ABaseTormentTrailPoint {
	char pad_330[0x18]; // 0x330(0x18)
	struct UAuthoritativePoolableActorComponent* _poolableComponent; // 0x348(0x08)
	float _splineMeshOverlapDistance; // 0x350(0x04)
	char pad_354[0x4]; // 0x354(0x04)

	void Server_RemoveTrailPoint(); // Function TheExecutioner.TormentTrailPoint.Server_RemoveTrailPoint // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x34398a0
	void RefreshTrailPointCosmetic(enum class ETrailPointRefreshReason trailPointRefreshReason); // Function TheExecutioner.TormentTrailPoint.RefreshTrailPointCosmetic // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnAcquireChanged(bool acquired); // Function TheExecutioner.TormentTrailPoint.OnAcquireChanged // (Final|Native|Private) // @ game+0x34393b0
	void Multicast_TriggerTrailPointDisappear(); // Function TheExecutioner.TormentTrailPoint.Multicast_TriggerTrailPointDisappear // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x23370b0
	void GetTrailLocationAndTangeant(int32_t indexInTrail, struct USplineComponent* SplineComponent, struct FVector outStartLocation, struct FVector outStartTangent, struct FVector outEndLocation, struct FVector outEndTangent); // Function TheExecutioner.TormentTrailPoint.GetTrailLocationAndTangeant // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3438fc0
	void AddTrailCosmetic(struct USplineComponent* SplineComponent, char indexInTrail); // Function TheExecutioner.TormentTrailPoint.AddTrailCosmetic // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void ActivateCosmetic(bool value); // Function TheExecutioner.TormentTrailPoint.ActivateCosmetic // (Event|Public|BlueprintEvent) // @ game+0x3873200
};

// Class TheExecutioner.TormentTrailPointCollectionComponent
// Size: 0x100 (Inherited: 0xb8)
struct UTormentTrailPointCollectionComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct FDBDTunableRowHandle _maxNumberOfTrailPointInGame; // 0xd0(0x28)
	char pad_F8[0x8]; // 0xf8(0x08)

	void OnTrailAcquireChanged(struct ATormentTrailPoint* TrailPoint, bool value); // Function TheExecutioner.TormentTrailPointCollectionComponent.OnTrailAcquireChanged // (Final|Native|Private) // @ game+0x3439690
};

// Class TheExecutioner.TormentTrailSpawnerComponent
// Size: 0x248 (Inherited: 0xb8)
struct UTormentTrailSpawnerComponent : UActorComponent {
	struct ATormentTrailController* _currentTrailController; // 0xb8(0x08)
	struct FDBDTunableRowHandle _restrictionRangeToHooks; // 0xc0(0x28)
	struct FDBDTunableRowHandle _restrictionRangeToGenerators; // 0xe8(0x28)
	struct FDBDTunableRowHandle _restrictionRangeToExitSwitch; // 0x110(0x28)
	struct FDBDTunableRowHandle _maxSlopeAngleForTrail; // 0x138(0x28)
	struct FDBDTunableRowHandle _minSlopeAngleForTrail; // 0x160(0x28)
	struct FDBDTunableRowHandle _restrictionRangeToHatch; // 0x188(0x28)
	struct FDBDTunableRowHandle _restrictionMaxVerticalDistance; // 0x1b0(0x28)
	struct UTormentTrailPointCollectionComponent* _tormentTrailPointCollectionComponent; // 0x1d8(0x08)
	struct UTormentTrailPointCollectionComponent* _restrictedTormentTrailPointCollectionComponent; // 0x1e0(0x08)
	struct UAuthoritativeActorPoolComponent* _tormentTrailControllerPool; // 0x1e8(0x08)
	struct UAuthoritativeActorPoolComponent* _tormentRestrictedTrailControllerPool; // 0x1f0(0x08)
	char pad_1F8[0x18]; // 0x1f8(0x18)
	struct TArray<struct AActor*> _actorsInRange; // 0x210(0x10)
	struct FVector _slopeDetectionOverGroundVector; // 0x220(0x0c)
	struct FVector _slopeDetectionEndVector; // 0x22c(0x0c)
	float _forwardMultiplierSlopeDetection; // 0x238(0x04)
	float _epsilonToAddToSpawnLocationInZ; // 0x23c(0x04)
	char pad_240[0x8]; // 0x240(0x08)

	void Sever_SpawnTrailController(struct ATormentTrailController* trailController, struct FVector_NetQuantize10 Location, struct FRotator Rotation); // Function TheExecutioner.TormentTrailSpawnerComponent.Sever_SpawnTrailController // (Final|Net|NetReliableNative|Event|Private|NetServer|HasDefaults|NetValidate) // @ game+0x3439b60
	void Server_StopTrailController(struct ATormentTrailController* trailController); // Function TheExecutioner.TormentTrailSpawnerComponent.Server_StopTrailController // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x330ee30
	void Server_RequestMoreActorInPool(enum class ETrailType trailType); // Function TheExecutioner.TormentTrailSpawnerComponent.Server_RequestMoreActorInPool // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3439940
	void OnLevelReadyToPlay(); // Function TheExecutioner.TormentTrailSpawnerComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34395b0
	void OnInRangeChanged(bool InRange, struct AActor* Actor); // Function TheExecutioner.TormentTrailSpawnerComponent.OnInRangeChanged // (Final|Native|Private) // @ game+0x34394d0
};

// Class TheExecutioner.TrailEffectLastingTimeBaseAddon
// Size: 0x288 (Inherited: 0x280)
struct UTrailEffectLastingTimeBaseAddon : USpawnEffectsOnAllSurvivorsBaseAddon {
	float _trailEffectLastingTimeModifierValue; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class TheExecutioner.TrailOfTorment
// Size: 0x3e8 (Inherited: 0x3a8)
struct UTrailOfTorment : UPerk {
	char pad_3A8[0x18]; // 0x3a8(0x18)
	float _cooldownDuration[0x3]; // 0x3c0(0x0c)
	int32_t _highlightPriority; // 0x3cc(0x04)
	bool _isPerkActivated; // 0x3d0(0x01)
	char pad_3D1[0x7]; // 0x3d1(0x07)
	struct AGenerator* _highlightedGenerator; // 0x3d8(0x08)
	struct UStatusEffect* _statusEffect; // 0x3e0(0x08)

	void OnRep_HighlightGenerator(struct AGenerator* _oldHighlightedGenerator); // Function TheExecutioner.TrailOfTorment.OnRep_HighlightGenerator // (Final|Native|Private) // @ game+0x34395d0
};

// Class TheExecutioner.TrailPointOutlineUpdateStrategy
// Size: 0x158 (Inherited: 0x130)
struct UTrailPointOutlineUpdateStrategy : USourceBasedOutlineUpdateStrategy {
	struct FDBDTunableRowHandle _tormentTrailRevealDistance; // 0x130(0x28)
};

