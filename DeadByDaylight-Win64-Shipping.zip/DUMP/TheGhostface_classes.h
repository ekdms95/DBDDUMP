// Class TheGhostface.GhostfaceCrouchAttack
// Size: 0x360 (Inherited: 0x360)
struct UGhostfaceCrouchAttack : UPounceAttack {
};

// Class TheGhostface.GhostKillerAnalyticsComponent
// Size: 0x1c8 (Inherited: 0xb8)
struct UGhostKillerAnalyticsComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)
	struct FGhostKillerAnalytics _ghostKillerAnalytics; // 0xf0(0xb0)
	char pad_1A0[0x28]; // 0x1a0(0x28)

	void Local_OnStalkModeChanged(bool IsInStalkMode); // Function TheGhostface.GhostKillerAnalyticsComponent.Local_OnStalkModeChanged // (Final|Native|Private) // @ game+0x345fba0
	void Local_OnLeanStateChanged(enum class ELeanState leanState); // Function TheGhostface.GhostKillerAnalyticsComponent.Local_OnLeanStateChanged // (Final|Native|Private) // @ game+0x345fb20
	void Local_OnIsStealthChanged(bool IsStealth); // Function TheGhostface.GhostKillerAnalyticsComponent.Local_OnIsStealthChanged // (Final|Native|Private) // @ game+0x345fa90
	void Authority_OnStalkChargePercentChanged(struct UChargeableComponent* ChargeableComponent, float PercentCompletionChange, float TotalPercentComplete); // Function TheGhostface.GhostKillerAnalyticsComponent.Authority_OnStalkChargePercentChanged // (Final|Native|Private) // @ game+0x345f990
	void Authority_OnPreAttackSuccess(struct FGameplayTag GameplayTag, struct FGameEventData GameEventData); // Function TheGhostface.GhostKillerAnalyticsComponent.Authority_OnPreAttackSuccess // (Final|Native|Private|HasOutParms) // @ game+0x345f880
};

