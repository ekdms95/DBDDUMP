// ScriptStruct TheGhostface.GhostKillerAnalytics
// Size: 0xb0 (Inherited: 0x68)
struct FGhostKillerAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t Stalk; // 0x78(0x04)
	int32_t StalkStealth; // 0x7c(0x04)
	int32_t Stalk25; // 0x80(0x04)
	int32_t Stalk50; // 0x84(0x04)
	int32_t Stalk75; // 0x88(0x04)
	int32_t Stalk100; // 0x8c(0x04)
	int32_t StalkLean25; // 0x90(0x04)
	int32_t StalkLean50; // 0x94(0x04)
	int32_t StalkLean75; // 0x98(0x04)
	int32_t StalkLean100; // 0x9c(0x04)
	int32_t Lean; // 0xa0(0x04)
	int32_t DownExposedSurvivor; // 0xa4(0x04)
	float TimeInStealthMode; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

