// Class TheGunslinger.ChainPlayerMovementStatusEffect
// Size: 0x378 (Inherited: 0x320)
struct UChainPlayerMovementStatusEffect : UStatusEffect {
	struct FDBDTunableRowHandle _baseMovementSpeedMultiplier; // 0x320(0x28)
	struct FDBDTunableRowHandle _collisionMovementSpeedMultiplier; // 0x348(0x28)
	struct ARifleChain* _chain; // 0x370(0x08)

	void OnIsChainCollidingChanged(bool IsColliding); // Function TheGunslinger.ChainPlayerMovementStatusEffect.OnIsChainCollidingChanged // (Final|Native|Private) // @ game+0x345d110
};

// Class TheGunslinger.ChainKillerMovementStatusEffect
// Size: 0x3e0 (Inherited: 0x378)
struct UChainKillerMovementStatusEffect : UChainPlayerMovementStatusEffect {
	struct FDBDTunableRowHandle _backwardMovementSpeedMultiplier; // 0x378(0x28)
	struct FDBDTunableRowHandle _backwardMovementAngle; // 0x3a0(0x28)
	char pad_3C8[0x18]; // 0x3c8(0x18)
};

// Class TheGunslinger.ChainLinkableComponent
// Size: 0x188 (Inherited: 0xb8)
struct UChainLinkableComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct UBaseCameraTargetingStrategy* _cameraTargetingStrategyClass; // 0xd0(0x08)
	struct FName _movementStatusEffectName; // 0xd8(0x0c)
	struct FName _linkedStatusEffectName; // 0xe4(0x0c)
	struct UPlayerReelInputAccelerationConstraintStrategy* _inputAccelerationStrategy; // 0xf0(0x08)
	struct URiflePlayerLinker* _chainLink; // 0xf8(0x08)
	char pad_100[0x30]; // 0x100(0x30)
	struct FTagStateBool _isLinkedLingering; // 0x130(0x30)
	struct UChainPlayerMovementStatusEffect* _movementStatusEffect; // 0x160(0x08)
	char pad_168[0x8]; // 0x168(0x08)
	struct UBaseCameraTargetingStrategy* _cameraStrategy; // 0x170(0x08)
	char pad_178[0x10]; // 0x178(0x10)
};

// Class TheGunslinger.DeadMansSwitch
// Size: 0x3e0 (Inherited: 0x3a8)
struct UDeadMansSwitch : UPerk {
	char pad_3A8[0x8]; // 0x3a8(0x08)
	float _activationDurationByLevels[0x3]; // 0x3b0(0x0c)
	bool _anySurvivorLetGo; // 0x3bc(0x01)
	char pad_3BD[0x3]; // 0x3bd(0x03)
	struct TArray<struct AGenerator*> _blockedGenerators; // 0x3c0(0x10)
	char pad_3D0[0x10]; // 0x3d0(0x10)

	void OnRep_BlockedGenerators(); // Function TheGunslinger.DeadMansSwitch.OnRep_BlockedGenerators // (Final|Native|Private) // @ game+0x345d330
};

// Class TheGunslinger.FireHarpoonRifleInteraction
// Size: 0xa20 (Inherited: 0x560)
struct UFireHarpoonRifleInteraction : UInteractionDefinition {
	struct FMulticastInlineDelegate OnFireHarpoon; // 0x558(0x10)
	struct FMulticastInlineDelegate OnHitPlayer; // 0x568(0x10)
	struct AHarpoonProjectile* _harpoon; // 0x580(0x08)
	struct ADBDPlayer* _collector; // 0x588(0x08)
	struct FDBDTunableRowHandle _aimDownSightDuration; // 0x590(0x28)
	struct FDBDTunableRowHandle _aimDownSightZoom; // 0x5b8(0x28)
	struct FDBDTunableRowHandle _aimDownSightMousePitchScaleMultiplier; // 0x5e0(0x28)
	struct FDBDTunableRowHandle _aimDownSightMouseYawScaleMultiplier; // 0x608(0x28)
	struct FDBDTunableRowHandle _aimDownSightGamepadPitchScaleMultiplier; // 0x630(0x28)
	struct FDBDTunableRowHandle _aimDownSightGamepadYawScaleMultiplier; // 0x658(0x28)
	struct UCurveFloat* _aimDownSightGamepadPitchCurve; // 0x680(0x08)
	struct UCurveFloat* _aimDownSightGamepadYawCurve; // 0x688(0x08)
	struct FDBDTunableRowHandle _aimDownSightRotationScaleAdjustmentTime; // 0x690(0x28)
	struct FTunableStat _aimDownSightMovementSpeedMultiplier; // 0x6b8(0x80)
	struct FDBDTunableRowHandle _fireDuration; // 0x738(0x28)
	struct FDBDTunableRowHandle _fireRotationScaleMultiplier; // 0x760(0x28)
	struct FDBDTunableRowHandle _fireRotationScaleAdjustmentTime; // 0x788(0x28)
	struct FDBDTunableRowHandle _fireMovementSpeedMultiplier; // 0x7b0(0x28)
	struct FDBDTunableRowHandle _longRangeShotMinDistance; // 0x7d8(0x28)
	char pad_800[0x8]; // 0x800(0x08)
	struct FDBDTunableRowHandle _successMovementSpeedMultiplier; // 0x808(0x28)
	struct FDBDTunableRowHandle _missMovementSpeedMultiplier; // 0x830(0x28)
	struct FTunableStat _missShotCooldownDuration; // 0x858(0x80)
	struct FDBDTunableRowHandle _nearMissShotMaxDistance; // 0x8d8(0x28)
	struct FDBDTunableRowHandle _successShotDuration; // 0x900(0x28)
	char pad_928[0xf8]; // 0x928(0xf8)

	void Server_HandleMissShotScores(struct TArray<struct ADBDPlayer*> nearMissedPlayers); // Function TheGunslinger.FireHarpoonRifleInteraction.Server_HandleMissShotScores // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x345d530
	void OnHitPlayer__DelegateSignature(); // DelegateFunction TheGunslinger.FireHarpoonRifleInteraction.OnHitPlayer__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnFireHarpoon__DelegateSignature(); // DelegateFunction TheGunslinger.FireHarpoonRifleInteraction.OnFireHarpoon__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
};

// Class TheGunslinger.ForThePeople
// Size: 0x3f8 (Inherited: 0x3a8)
struct UForThePeople : UPerk {
	char pad_3A8[0xc]; // 0x3a8(0x0c)
	float _brokenEffectDurations[0x3]; // 0x3b4(0x0c)
	struct FSecondaryInteractionProperties _secondaryActionProperties; // 0x3c0(0x30)
	char pad_3F0[0x8]; // 0x3f0(0x08)

	void Server_OnActionInputPressed(); // Function TheGunslinger.ForThePeople.Server_OnActionInputPressed // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x345d5f0
	void OnHealingAbilityUsed(struct ACamperPlayer* healingSurvivor, struct ACamperPlayer* healedSurvivor); // Function TheGunslinger.ForThePeople.OnHealingAbilityUsed // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_OnHealAbilityUsed(struct ACamperPlayer* healingSurvivor, struct ACamperPlayer* healedSurvivor); // Function TheGunslinger.ForThePeople.Multicast_OnHealAbilityUsed // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x2c92350
};

// Class TheGunslinger.Gearhead
// Size: 0x450 (Inherited: 0x3a8)
struct UGearhead : UPerk {
	float _perkActivationDuration[0x3]; // 0x3a8(0x0c)
	bool _greatSkillCheck; // 0x3b4(0x01)
	bool _basicAttack; // 0x3b5(0x01)
	char pad_3B6[0x2]; // 0x3b6(0x02)
	float _minimumAuraRevealDuration; // 0x3b8(0x04)
	int32_t _attacksNeededToActivate; // 0x3bc(0x04)
	int32_t _numAttacksBeforeActivation; // 0x3c0(0x04)
	char pad_3C4[0x4]; // 0x3c4(0x04)
	struct TMap<struct AGenerator*, struct FFastTimer> _timersBeforeUnreveal; // 0x3c8(0x50)
	struct TArray<struct AGenerator*> _markedGenerators; // 0x418(0x10)
	struct TArray<struct AGenerator*> _revealedGenerators; // 0x428(0x10)
	struct TArray<struct AGenerator*> _local_revealedGenerators; // 0x438(0x10)
	char pad_448[0x8]; // 0x448(0x08)

	void OnRep_RevealedGenerators(); // Function TheGunslinger.Gearhead.OnRep_RevealedGenerators // (Final|Native|Private) // @ game+0x345d3f0
};

// Class TheGunslinger.GunslingerAnimInstance
// Size: 0x720 (Inherited: 0x5b0)
struct UGunslingerAnimInstance : UKillerAnimInstance {
	bool _isAiming; // 0x5a8(0x01)
	bool _isFiring; // 0x5a9(0x01)
	bool _isInMissShotCooldown; // 0x5aa(0x01)
	bool _isInSuccessShot; // 0x5ab(0x01)
	bool _isLinked; // 0x5ac(0x01)
	bool _isReeling; // 0x5ad(0x01)
	bool _isInGunState; // 0x5ae(0x01)
	float _fireAnimPlayRate; // 0x5b0(0x04)
	float _missShotCooldownAnimPlayRate; // 0x5b4(0x04)
	float _successShotAnimPlayRate; // 0x5b8(0x04)
	struct UAnimSequence* _fireAnim; // 0x5c0(0x08)
	struct UAnimSequence* _missShotCooldownAnim; // 0x5c8(0x08)
	struct UAnimSequence* _successShotAnim; // 0x5d0(0x08)
	struct FDBDTunableRowHandle _fireAnimDuration; // 0x5d8(0x28)
	struct FTunableStat _missShotCooldownAnimDuration; // 0x600(0x80)
	struct FDBDTunableRowHandle _successShotAnimDuration; // 0x680(0x28)
	char pad_6AB[0x75]; // 0x6ab(0x75)
};

// Class TheGunslinger.GunslingerCameraTargetingStrategy
// Size: 0x68 (Inherited: 0x50)
struct UGunslingerCameraTargetingStrategy : UBaseCameraTargetingStrategy {
	struct FName _cameraSocketName; // 0x50(0x0c)
	struct FName _survivorHarpoonSocketName; // 0x5c(0x0c)
};

// Class TheGunslinger.GunslingerEffectsComponent
// Size: 0x150 (Inherited: 0xb8)
struct UGunslingerEffectsComponent : UActorComponent {
	struct FMulticastInlineDelegate OnIsAimingChanged; // 0xb8(0x10)
	struct FMulticastInlineDelegate PlayOutOfAmmoSound; // 0xc8(0x10)
	float _minimumTimeBetweenBroadcast; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct AHarpoonRifle* _rifle; // 0xe0(0x08)
	char pad_E8[0x68]; // 0xe8(0x68)

	void PlayOutOfAmmoSound__DelegateSignature(); // DelegateFunction TheGunslinger.GunslingerEffectsComponent.PlayOutOfAmmoSound__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnItemUsedStateChanged(bool IsPressed); // Function TheGunslinger.GunslingerEffectsComponent.OnItemUsedStateChanged // (Final|Native|Private) // @ game+0x345d1a0
	void OnIsAimingChanged__DelegateSignature(bool isAiming); // DelegateFunction TheGunslinger.GunslingerEffectsComponent.OnIsAimingChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void Multicast_PlayOutOfAmmoSound(); // Function TheGunslinger.GunslingerEffectsComponent.Multicast_PlayOutOfAmmoSound // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x2cc4840
};

// Class TheGunslinger.GunslingerUtilities
// Size: 0x30 (Inherited: 0x30)
struct UGunslingerUtilities : UBlueprintFunctionLibrary {

	struct AHarpoonRifle* GetHarpoonRifle(struct ADBDPlayer* Player); // Function TheGunslinger.GunslingerUtilities.GetHarpoonRifle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x345ce60
};

// Class TheGunslinger.HarpoonChainPositioner
// Size: 0x140 (Inherited: 0xb8)
struct UHarpoonChainPositioner : UActorComponent {
	struct AHarpoonProp* _harpoonPropClass; // 0xb8(0x08)
	struct FName _survivorAttachSocket; // 0xc0(0x0c)
	struct FName _animationSocket; // 0xcc(0x0c)
	struct FDBDTunableRowHandle _reelBackToRifleSpeed; // 0xd8(0x28)
	float _harpoonMinimumSnapBackDistance; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct AHarpoonProp* _harpoonProp; // 0x108(0x08)
	struct AHarpoonProjectile* _harpoonProjectile; // 0x110(0x08)
	struct ADBDPlayer* _collector; // 0x118(0x08)
	char pad_120[0x8]; // 0x120(0x08)
	struct ARifleChain* _chain; // 0x128(0x08)
	char pad_130[0x10]; // 0x130(0x10)

	void OnOwnerCollected(struct ADBDPlayer* collector); // Function TheGunslinger.HarpoonChainPositioner.OnOwnerCollected // (Final|Native|Private) // @ game+0x345d2b0
	void OnHarpoonTravelingChanged(bool isTravelling); // Function TheGunslinger.HarpoonChainPositioner.OnHarpoonTravelingChanged // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnHarpoonLoadedOnRifle(); // Function TheGunslinger.HarpoonChainPositioner.OnHarpoonLoadedOnRifle // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnCurrentHarpoonChanged(struct AActor* currentHarpoon); // Function TheGunslinger.HarpoonChainPositioner.OnCurrentHarpoonChanged // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	struct AHarpoonProp* GetHarpoonProp(); // Function TheGunslinger.HarpoonChainPositioner.GetHarpoonProp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345ce30
	struct AActor* GetCurrentHarpoon(); // Function TheGunslinger.HarpoonChainPositioner.GetCurrentHarpoon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cd80
	void AttachToRifle(); // Function TheGunslinger.HarpoonChainPositioner.AttachToRifle // (Final|Native|Public|BlueprintCallable) // @ game+0x345cc60
	void AttachToAnimSocket(); // Function TheGunslinger.HarpoonChainPositioner.AttachToAnimSocket // (Final|Native|Public|BlueprintCallable) // @ game+0x345cc40
};

// Class TheGunslinger.HarpoonedSurvivorSubAnimInstance
// Size: 0x580 (Inherited: 0x4f0)
struct UHarpoonedSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	float _linkedMaxSpeed; // 0x4f0(0x04)
	float _timeBeforeHarpoonHitReset; // 0x4f4(0x04)
	struct FName _hitHarpoonedEnterEvent; // 0x4f8(0x0c)
	struct FName _chainBreakEnterEvent; // 0x504(0x0c)
	bool _isChainLinked; // 0x510(0x01)
	bool _isBeingReeled; // 0x511(0x01)
	bool _hasLinkInput; // 0x512(0x01)
	char pad_513[0x1]; // 0x513(0x01)
	float _linkInputX; // 0x514(0x04)
	float _linkInputY; // 0x518(0x04)
	bool _chainBreakTrigger; // 0x51c(0x01)
	bool _triggerHarpoonHit; // 0x51d(0x01)
	char pad_51E[0x2]; // 0x51e(0x02)
	float _harpoonHitTurnAnimNormalizedStartTime; // 0x520(0x04)
	bool _harpoonHitAnimTurnRight; // 0x524(0x01)
	bool _isCrawling; // 0x525(0x01)
	char pad_526[0x5a]; // 0x526(0x5a)
};

// Class TheGunslinger.HarpoonLauncher
// Size: 0x1d8 (Inherited: 0x180)
struct UHarpoonLauncher : UKillerProjectileLauncher {
	struct FDBDTunableRowHandle _launchSpeed; // 0x180(0x28)
	struct FDBDTunableRowHandle _launchDistanceFromCamera; // 0x1a8(0x28)
	float _launchZOffset; // 0x1d0(0x04)
	char pad_1D4[0x4]; // 0x1d4(0x04)
};

// Class TheGunslinger.HarpoonProjectile
// Size: 0x3d0 (Inherited: 0x300)
struct AHarpoonProjectile : AKillerProjectile {
	char pad_300[0x78]; // 0x300(0x78)
	struct FDBDTunableRowHandle _launchDistanceFromCamera; // 0x378(0x28)
	struct UHarpoonProjectileMovementComponent* _movement; // 0x3a0(0x08)
	struct UPrimitiveComponent* _environmentCollider; // 0x3a8(0x08)
	struct UPrimitiveComponent* _targetCollider; // 0x3b0(0x08)
	struct USkeletalMeshComponent* _skeletalMesh; // 0x3b8(0x08)
	struct UPoolableActorComponent* _poolableActorComponent; // 0x3c0(0x08)
	char pad_3C8[0x8]; // 0x3c8(0x08)

	void OnHarpoonStop(struct FHitResult Result); // Function TheGunslinger.HarpoonProjectile.OnHarpoonStop // (Final|Native|Private|HasOutParms) // @ game+0x345d040
};

// Class TheGunslinger.HarpoonProjectileMovementComponent
// Size: 0x2a0 (Inherited: 0x250)
struct UHarpoonProjectileMovementComponent : UPhysicsBasedProjectileMovementComponent {
	char pad_250[0x10]; // 0x250(0x10)
	struct FDBDTunableRowHandle _maxTravelDistance; // 0x260(0x28)
	char pad_288[0x18]; // 0x288(0x18)
};

// Class TheGunslinger.HarpoonProp
// Size: 0x240 (Inherited: 0x230)
struct AHarpoonProp : AActor {
	char pad_230[0x8]; // 0x230(0x08)
	struct USkeletalMeshComponent* _skeletalMesh; // 0x238(0x08)
};

// Class TheGunslinger.HarpoonProviderComponent
// Size: 0xe8 (Inherited: 0xe8)
struct UHarpoonProviderComponent : USingleProjectileProviderComponent {
};

// Class TheGunslinger.HarpoonRifle
// Size: 0x558 (Inherited: 0x498)
struct AHarpoonRifle : ACollectable {
	char pad_498[0x18]; // 0x498(0x18)
	struct UChainLinkableComponent* _survivorLinkableClass; // 0x4b0(0x08)
	struct UChainLinkableComponent* _killerLinkableClass; // 0x4b8(0x08)
	struct ARifleChain* _chainClass; // 0x4c0(0x08)
	struct FName _rifleMuzzleSocket; // 0x4c8(0x0c)
	struct FName _rifleHarpoonLoadingSocket; // 0x4d4(0x0c)
	struct FDBDTunableRowHandle _crowActiveRange; // 0x4e0(0x28)
	struct UHarpoonLauncher* _launcher; // 0x508(0x08)
	struct UHarpoonProviderComponent* _harpoonProvider; // 0x510(0x08)
	struct ARifleChain* _chain; // 0x518(0x08)
	struct URifleChainTensionComponent* _chainTensionComponent; // 0x520(0x08)
	struct UChargeableComponent* _chainTensionChargeable; // 0x528(0x08)
	struct URiflePlayerLinker* _playerLinker; // 0x530(0x08)
	struct UHarpoonChainPositioner* _harpoonChainPositioner; // 0x538(0x08)
	struct UFireHarpoonRifleInteraction* _fireInteraction; // 0x540(0x08)
	struct UTriggerableActivatorComponent* _crowsActivatorComponent; // 0x548(0x08)
	char pad_550[0x8]; // 0x550(0x08)

	struct ARifleChain* GetChain(); // Function TheGunslinger.HarpoonRifle.GetChain // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cca0
	void Authority_OnFireHarpoon(); // Function TheGunslinger.HarpoonRifle.Authority_OnFireHarpoon // (Final|Native|Private) // @ game+0x345cc80
};

// Class TheGunslinger.HarpoonRifleAnimInstance
// Size: 0x280 (Inherited: 0x270)
struct UHarpoonRifleAnimInstance : UAnimInstance {
	struct ARifleChain* _chain; // 0x270(0x08)
	float _chainUnwindingSpeed; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
};

// Class TheGunslinger.HellshireIronAddon
// Size: 0x288 (Inherited: 0x278)
struct UHellshireIronAddon : UItemAddon {
	bool _useTimedDuration; // 0x278(0x01)
	char pad_279[0x3]; // 0x279(0x03)
	float _revealDuration; // 0x27c(0x04)
	char pad_280[0x8]; // 0x280(0x08)
};

// Class TheGunslinger.HexRetribution
// Size: 0x428 (Inherited: 0x408)
struct UHexRetribution : UHexPerk {
	float _obliviousDurationByLevels[0x3]; // 0x408(0x0c)
	float _auraRevealDuration; // 0x414(0x04)
	struct TArray<struct TWeakObjectPtr<struct UStatusEffect>> _obliviousEffects; // 0x418(0x10)
};

// Class TheGunslinger.HoneyLocustThornsAddon
// Size: 0x278 (Inherited: 0x278)
struct UHoneyLocustThornsAddon : UItemAddon {
};

// Class TheGunslinger.GunslingerHarpoon
// Size: 0x30 (Inherited: 0x30)
struct UGunslingerHarpoon : UInterface {
};

// Class TheGunslinger.IridescentCoinAddon
// Size: 0x2a8 (Inherited: 0x278)
struct UIridescentCoinAddon : UItemAddon {
	struct UStatusEffect* _exposedStatusEffect; // 0x278(0x08)
	char pad_280[0x28]; // 0x280(0x28)
};

// Class TheGunslinger.KillerChainLinkableComponent
// Size: 0x198 (Inherited: 0x188)
struct UKillerChainLinkableComponent : UChainLinkableComponent {
	char pad_188[0x10]; // 0x188(0x10)
};

// Class TheGunslinger.OffTheRecord
// Size: 0x3b8 (Inherited: 0x3a8)
struct UOffTheRecord : UPerk {
	float _activationDurationLevels[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class TheGunslinger.PlayerReelInputAccelerationConstraintStrategy
// Size: 0xe8 (Inherited: 0xb8)
struct UPlayerReelInputAccelerationConstraintStrategy : UBaseInputAccelerationConstraintStrategy {
	char pad_B8[0x30]; // 0xb8(0x30)
};

// Class TheGunslinger.PrisonChainAddon
// Size: 0x2a8 (Inherited: 0x278)
struct UPrisonChainAddon : UItemAddon {
	struct FDBDTunableRowHandle _maxTensionCharge; // 0x278(0x28)
	float _tensionChargeModifier; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
};

// Class TheGunslinger.RedHerring
// Size: 0x448 (Inherited: 0x3a8)
struct URedHerring : UPerk {
	char pad_3A8[0x60]; // 0x3a8(0x60)
	struct AGenerator* _markedGenerator; // 0x408(0x08)
	float _secondsToActivatePerk; // 0x410(0x04)
	float _loudNoiseTriggeredNotifyTime; // 0x414(0x04)
	float _cooldownLevels[0x3]; // 0x418(0x0c)
	char pad_424[0x24]; // 0x424(0x24)

	void OnRep_MarkedGenerator(struct AGenerator* oldMarkedGenerator); // Function TheGunslinger.RedHerring.OnRep_MarkedGenerator // (Final|Native|Private) // @ game+0x345d370
	void OnLoudNoiseTriggered(); // Function TheGunslinger.RedHerring.OnLoudNoiseTriggered // (Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheGunslinger.ReelChainInteraction
// Size: 0x590 (Inherited: 0x560)
struct UReelChainInteraction : UInteractionDefinition {
	float _frontMovementAngle; // 0x558(0x04)
	float _minimumFrontVelocity; // 0x560(0x04)
	struct ADBDPlayer* _linkedPlayer; // 0x568(0x08)
	char pad_570[0x20]; // 0x570(0x20)
};

// Class TheGunslinger.ReloadHarpoonRifleInteraction
// Size: 0x730 (Inherited: 0x680)
struct UReloadHarpoonRifleInteraction : UChargeableInteractionDefinition {
	struct FDBDTunableRowHandle _reloadTime; // 0x680(0x28)
	struct FDBDTunableRowHandle _movementSpeedMultiplier; // 0x6a8(0x28)
	struct FDBDTunableRowHandle _rotationScaleMultiplier; // 0x6d0(0x28)
	struct FDBDTunableRowHandle _rotationScaleAdjustmentTime; // 0x6f8(0x28)
	char pad_720[0x10]; // 0x720(0x10)
};

// Class TheGunslinger.RifleChain
// Size: 0x418 (Inherited: 0x230)
struct ARifleChain : AActor {
	struct FMulticastInlineDelegate OnProjectileSet; // 0x230(0x10)
	struct FMulticastInlineDelegate OnIsCollidingChanged; // 0x240(0x10)
	struct UAkComponent* _chainCenterAkComponent; // 0x250(0x08)
	struct UAkAudioEvent* _collisionLoopStartEvent; // 0x258(0x08)
	struct UAkAudioEvent* _collisionLoopEndEvent; // 0x260(0x08)
	struct TArray<struct FAkSoundLoop> _collisionSoundLoops; // 0x268(0x10)
	float _sphereTraceRadius; // 0x278(0x04)
	float _timeBetweenTrace; // 0x27c(0x04)
	struct TScriptInterface<None> _harpoon; // 0x280(0x10)
	char pad_290[0x188]; // 0x290(0x188)

	void UpdateChainMesh(struct UInstancedStaticMeshComponent* Mesh, struct USplineComponent* spline, float alpha); // Function TheGunslinger.RifleChain.UpdateChainMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x345d930
	int32_t SpawnChainPoints(struct FVector Start, struct FVector Stop, struct UCurveFloat* influenceCurve, float pointYPosition, float pointZPosition, bool useOffset, struct USplineComponent* spline); // Function TheGunslinger.RifleChain.SpawnChainPoints // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x345d700
	void OnUnattachFromPlayer(struct ADBDPlayer* Player); // Function TheGunslinger.RifleChain.OnUnattachFromPlayer // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnReelBackToRifle(); // Function TheGunslinger.RifleChain.OnReelBackToRifle // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnProjectileSet__DelegateSignature(struct AActor* Projectile); // DelegateFunction TheGunslinger.RifleChain.OnProjectileSet__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnLaunch(); // Function TheGunslinger.RifleChain.OnLaunch // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnIsCollidingChanged__DelegateSignature(bool IsColliding); // DelegateFunction TheGunslinger.RifleChain.OnIsCollidingChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnAttachToPlayer(struct ADBDPlayer* Player); // Function TheGunslinger.RifleChain.OnAttachToPlayer // (Event|Public|BlueprintEvent) // @ game+0x3873200
	bool IsColliding(); // Function TheGunslinger.RifleChain.IsColliding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345d010
	float GetUnwindingSpeed(); // Function TheGunslinger.RifleChain.GetUnwindingSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cfb0
	struct URiflePlayerLinker* GetRiflePlayerLinker(); // Function TheGunslinger.RifleChain.GetRiflePlayerLinker // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cf80
	struct TArray<struct FHitResult> GetFirstAndLastCollisionHits(); // Function TheGunslinger.RifleChain.GetFirstAndLastCollisionHits // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cdb0
	struct URifleChainTensionComponent* GetChainTensionComponent(); // Function TheGunslinger.RifleChain.GetChainTensionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cd50
	struct FVector GetChainStart(); // Function TheGunslinger.RifleChain.GetChainStart // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cd10
	struct FVector GetChainEnd(); // Function TheGunslinger.RifleChain.GetChainEnd // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x345ccd0
};

// Class TheGunslinger.RifleChainTensionComponent
// Size: 0x2a0 (Inherited: 0xb8)
struct URifleChainTensionComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct FMulticastInlineDelegate OnIsBuildingTensionChanged; // 0xc0(0x10)
	char pad_D0[0x18]; // 0xd0(0x18)
	bool _isBuildingTension; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct USurvivorChainLinkableComponent* _targetlinkable; // 0xf0(0x08)
	char pad_F8[0x10]; // 0xf8(0x10)
	struct FDBDTunableRowHandle _maxTensionCharge; // 0x108(0x28)
	struct FDBDTunableRowHandle _baseTensionRate; // 0x130(0x28)
	struct FDBDTunableRowHandle _collisionTensionRate; // 0x158(0x28)
	struct FTunableStat _survivorPullingTensionRate; // 0x180(0x80)
	struct FNonTunableStat _currentTensionRate; // 0x200(0x60)
	enum class EProgressModifier _progressModifierForSurvivors; // 0x260(0x01)
	char pad_261[0x7]; // 0x261(0x07)
	struct FText _chargeProgressDescriptionText; // 0x268(0x18)
	char pad_280[0x10]; // 0x280(0x10)
	struct ARifleChain* _chain; // 0x290(0x08)
	char pad_298[0x8]; // 0x298(0x08)

	void OnTensionChargeableCompletionChanged(bool COMPLETED, struct TArray<struct AActor*> instigatorsForCompletion); // Function TheGunslinger.RifleChainTensionComponent.OnTensionChargeableCompletionChanged // (Final|Native|Private|HasOutParms) // @ game+0x345d430
	void OnRep_IsBuildingTension(); // Function TheGunslinger.RifleChainTensionComponent.OnRep_IsBuildingTension // (Final|Native|Private) // @ game+0x345d350
	void OnIsBuildingTensionChanged__DelegateSignature(bool IsBuildingTension); // DelegateFunction TheGunslinger.RifleChainTensionComponent.OnIsBuildingTensionChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	bool IsBuildingTension(); // Function TheGunslinger.RifleChainTensionComponent.IsBuildingTension // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cfe0
	float GetProgress(); // Function TheGunslinger.RifleChainTensionComponent.GetProgress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cf40
};

// Class TheGunslinger.RiflePlayerLinker
// Size: 0x210 (Inherited: 0xb8)
struct URiflePlayerLinker : UActorComponent {
	struct FMulticastInlineDelegate OnLinkedPlayerSet; // 0xb8(0x10)
	struct ADBDPlayer* _linkedPlayer; // 0xc8(0x08)
	struct ADBDPlayer* _linkedPlayerDuringAttack; // 0xd0(0x08)
	struct ADBDPlayer* _linkOwner; // 0xd8(0x08)
	float _desiredLinkLength; // 0xe0(0x04)
	char pad_E4[0x3c]; // 0xe4(0x3c)
	struct FDBDTunableRowHandle _elasticLength; // 0x120(0x28)
	struct FDBDTunableRowHandle _minimumLinkLength; // 0x148(0x28)
	struct FDBDTunableRowHandle _breakFreeCloseRangeMaxDistance; // 0x170(0x28)
	char pad_198[0x4]; // 0x198(0x04)
	float _movementLinkReductionThreshold; // 0x19c(0x04)
	float _movementAccelerationTreshold; // 0x1a0(0x04)
	char pad_1A4[0x6c]; // 0x1a4(0x6c)

	void Server_OnClientConfirmTensionBreakChain(struct ADBDPlayer* Player); // Function TheGunslinger.RiflePlayerLinker.Server_OnClientConfirmTensionBreakChain // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x345d640
	void OnLinkedPlayerSet__DelegateSignature(struct ADBDPlayer* linkedPlayer); // DelegateFunction TheGunslinger.RiflePlayerLinker.OnLinkedPlayerSet__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void Multicast_Unlink(); // Function TheGunslinger.RiflePlayerLinker.Multicast_Unlink // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x333a180
	void Multicast_Link(struct ADBDPlayer* linkedPlayer); // Function TheGunslinger.RiflePlayerLinker.Multicast_Link // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x32912e0
	struct ADBDPlayer* GetLinkOwner(); // Function TheGunslinger.RiflePlayerLinker.GetLinkOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cee0
	struct ADBDPlayer* GetLinkedPlayer(); // Function TheGunslinger.RiflePlayerLinker.GetLinkedPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x345cf10
	void Client_OnAuthorityTensionBreakChain(struct ADBDPlayer* Player); // Function TheGunslinger.RiflePlayerLinker.Client_OnAuthorityTensionBreakChain // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x330f190
};

// Class TheGunslinger.RustedSpikeAddon
// Size: 0x278 (Inherited: 0x278)
struct URustedSpikeAddon : UItemAddon {
};

// Class TheGunslinger.SurvivorChainLinkableComponent
// Size: 0x268 (Inherited: 0x188)
struct USurvivorChainLinkableComponent : UChainLinkableComponent {
	struct FDBDTunableRowHandle _pullbackAngle; // 0x188(0x28)
	char pad_1B0[0x8]; // 0x1b0(0x08)
	struct FDBDTunableRowHandle _immobilizationDuration; // 0x1b8(0x28)
	struct FGameplayTagContainer _linkableInteractionTags; // 0x1e0(0x20)
	struct FGameplayTagContainer _cancelableInteractionTags; // 0x200(0x20)
	struct USurvivorReelVelocityAdditiveStrategy* _velocityAdditiveStrategyClass; // 0x220(0x08)
	struct FName _immobilizationEffectName; // 0x228(0x0c)
	char pad_234[0x4]; // 0x234(0x04)
	struct FVector_NetQuantize10 _linkedMoveInput; // 0x238(0x0c)
	char pad_244[0x4]; // 0x244(0x04)
	struct UStatusEffect* _immobilizationEffect; // 0x248(0x08)
	struct USurvivorReelVelocityAdditiveStrategy* _velocityAdditiveStrategy; // 0x250(0x08)
	char pad_258[0x10]; // 0x258(0x10)

	void OnRep_VelocityAdditiveStrategy(); // Function TheGunslinger.SurvivorChainLinkableComponent.OnRep_VelocityAdditiveStrategy // (Final|Native|Private) // @ game+0x345d410
};

// Class TheGunslinger.SurvivorReelVelocityAdditiveStrategy
// Size: 0x1d0 (Inherited: 0xb8)
struct USurvivorReelVelocityAdditiveStrategy : UBaseCharacterVelocityAdditiveStrategy {
	struct FTunableStat _reelSpeed; // 0xb8(0x80)
	float _minimumLinkLengthDelta; // 0x138(0x04)
	float _maximumVelocityAdditive; // 0x13c(0x04)
	struct FTagStateBool _isBeingReeled; // 0x140(0x30)
	struct FTagStateBool _isBeingPulled; // 0x170(0x30)
	char pad_1A0[0x30]; // 0x1a0(0x30)

	void OnKillerSet(struct ASlasherPlayer* killer); // Function TheGunslinger.SurvivorReelVelocityAdditiveStrategy.OnKillerSet // (Final|Native|Private) // @ game+0x345d230
};

// Class TheGunslinger.TestDBDGameInstance
// Size: 0x980 (Inherited: 0x980)
struct UTestDBDGameInstance : UDBDGameInstance {
};

// Class TheGunslinger.TestOffTheRecord
// Size: 0x3b8 (Inherited: 0x3b8)
struct UTestOffTheRecord : UOffTheRecord {
};

// Class TheGunslinger.TestRedHerring
// Size: 0x448 (Inherited: 0x448)
struct UTestRedHerring : URedHerring {
};

