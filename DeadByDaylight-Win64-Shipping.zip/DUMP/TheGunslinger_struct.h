// Enum TheGunslinger.EFireHarpoonRifleInteractionState
enum class EFireHarpoonRifleInteractionState : uint8 {
	None,
	Aiming,
	FirePhase,
	MissPhase,
	SuccessPhase,
	EFireHarpoonRifleInteractionState_MAX,
};

// Enum TheGunslinger.EHarpoonPositionState
enum class EHarpoonPositionState : uint8 {
	None,
	LoadedInRifle,
	FollowingProjectile,
	ReelBackToRifle,
	AttachedToPlayer,
	Animated,
	EHarpoonPositionState_MAX,
};

