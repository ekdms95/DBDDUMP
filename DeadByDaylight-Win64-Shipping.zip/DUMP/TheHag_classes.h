// Class TheHag.HagAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UHagAnimInstance : UKillerAnimInstance {
};

// Class TheHag.HagSlowdownAfterTeleportEffect
// Size: 0x350 (Inherited: 0x320)
struct UHagSlowdownAfterTeleportEffect : UStatusEffect {
	struct UCurveFloat* _postTeleportSlowdownCurve; // 0x320(0x08)
	struct FDBDTunableRowHandle _slowdownTimeAfterTeleport; // 0x328(0x28)
};

// Class TheHag.PhantomTrapBurnable
// Size: 0x108 (Inherited: 0x100)
struct UPhantomTrapBurnable : ULightBurnable {
	float _traceZOffset; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
};

