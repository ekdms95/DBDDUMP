// Class TheHillbilly.ChainsawAnalyticsBaseComponent
// Size: 0x100 (Inherited: 0xb8)
struct UChainsawAnalyticsBaseComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	float _maxDistanceFromHookToBeConsideredCamping; // 0xd0(0x04)
	char pad_D4[0x2c]; // 0xd4(0x2c)
};

// Class TheHillbilly.HillbillyChainsawAttack
// Size: 0x3d0 (Inherited: 0x360)
struct UHillbillyChainsawAttack : UPounceAttack {
	char pad_360[0x58]; // 0x360(0x58)
	struct FGameplayTag _chainsawHitGameEventTag; // 0x3b8(0x0c)
	struct FGameplayTag _chainsawAttemptGameEventTag; // 0x3c4(0x0c)
};

// Class TheHillbilly.HillbillyChainsawAttackOpenSubstate
// Size: 0x168 (Inherited: 0x130)
struct UHillbillyChainsawAttackOpenSubstate : UPounceAttackOpenSubstate {
	char pad_130[0x38]; // 0x130(0x38)
};

// Class TheHillbilly.HillbillyChainsawAttackHittingSubstate
// Size: 0x1a0 (Inherited: 0x1a0)
struct UHillbillyChainsawAttackHittingSubstate : UPounceAttackHittingSubstate {
};

// Class TheHillbilly.HillbillyChainsawAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UHillbillyChainsawAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheHillbilly.HillbillyChainsawAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UHillbillyChainsawAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheHillbilly.HillbillyChainsawAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UHillbillyChainsawAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheHillbilly.ChainsawRevInteraction
// Size: 0x6e0 (Inherited: 0x680)
struct UChainsawRevInteraction : UChargeableInteractionDefinition {
	char pad_680[0x30]; // 0x680(0x30)
	struct FName _soundCueDistanceDataID; // 0x6b0(0x0c)
	char pad_6BC[0x4]; // 0x6bc(0x04)
	struct UAkAudioEvent* _chainsawRevStartAkAudioEvent; // 0x6c0(0x08)
	struct UAkAudioEvent* _chainsawRevEndAkAudioEvent; // 0x6c8(0x08)
	struct ASlasherPlayer* _owningSlasher; // 0x6d0(0x08)
	char pad_6D8[0x8]; // 0x6d8(0x08)

	void OnLevelReadyToPlay(); // Function TheHillbilly.ChainsawRevInteraction.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x3469920
};

// Class TheHillbilly.ApexMufflerAddon
// Size: 0x280 (Inherited: 0x280)
struct UApexMufflerAddon : USpawnEffectsOnAllSurvivorsBaseAddon {
};

// Class TheHillbilly.BlackGreaseAddon
// Size: 0x288 (Inherited: 0x278)
struct UBlackGreaseAddon : UItemAddon {
	char pad_278[0x10]; // 0x278(0x10)
};

// Class TheHillbilly.HillbillyAnalyticsComponent
// Size: 0x180 (Inherited: 0x100)
struct UHillbillyAnalyticsComponent : UChainsawAnalyticsBaseComponent {
	char pad_100[0x80]; // 0x100(0x80)
};

// Class TheHillbilly.HillbillyAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UHillbillyAnimInstance : UKillerAnimInstance {
};

// Class TheHillbilly.HillbillyChainsawHitEventAddon
// Size: 0x288 (Inherited: 0x288)
struct UHillbillyChainsawHitEventAddon : UOnEventBaseAddon {
};

// Class TheHillbilly.HillbillyChainsawOverheatComponent
// Size: 0x518 (Inherited: 0xb8)
struct UHillbillyChainsawOverheatComponent : UActorComponent {
	struct FMulticastInlineDelegate OnHeatChargeUpdateDelegate; // 0xb8(0x10)
	char pad_C8[0x118]; // 0xc8(0x118)
	struct FTagStateBool _isChainsawOverheating; // 0x1e0(0x30)
	struct UPowerChargeComponent* _chainsawHeatCharge; // 0x210(0x08)
	struct FTunableStat _heatMaxCharge; // 0x218(0x80)
	struct FTunableStat _heatRevStartAmount; // 0x298(0x80)
	struct FTunableStat _heatRevChargeRate; // 0x318(0x80)
	struct FTunableStat _heatDashChargeRate; // 0x398(0x80)
	struct FTunableStat _heatDischargeRate; // 0x418(0x80)
	struct FTunableStat _overheatDischargeRate; // 0x498(0x80)

	void OnRep_IsChainsawOverheating(); // Function TheHillbilly.HillbillyChainsawOverheatComponent.OnRep_IsChainsawOverheating // (Final|Native|Private) // @ game+0x346aac0
	void OnLevelReadyToPlay(); // Function TheHillbilly.HillbillyChainsawOverheatComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x346aaa0
	void OnHeatChargeUpdate(float currentCharge, float previosCharge); // Function TheHillbilly.HillbillyChainsawOverheatComponent.OnHeatChargeUpdate // (Final|Native|Private) // @ game+0x346a9e0
	bool IsChainsawOverheating(); // Function TheHillbilly.HillbillyChainsawOverheatComponent.IsChainsawOverheating // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x346a9b0
	void Authority_OnHeatChargeFull(); // Function TheHillbilly.HillbillyChainsawOverheatComponent.Authority_OnHeatChargeFull // (Final|Native|Private) // @ game+0x346a990
	void Authority_OnHeatChargeEmpty(); // Function TheHillbilly.HillbillyChainsawOverheatComponent.Authority_OnHeatChargeEmpty // (Final|Native|Private) // @ game+0x346a970
};

// Class TheHillbilly.HillbillyChainsawRevInteraction
// Size: 0x740 (Inherited: 0x6e0)
struct UHillbillyChainsawRevInteraction : UChainsawRevInteraction {
	char pad_6E0[0x60]; // 0x6e0(0x60)
};

// Class TheHillbilly.HillbillyChainsawSubAnimInstance
// Size: 0x5e0 (Inherited: 0x5c0)
struct UHillbillyChainsawSubAnimInstance : UBaseKillerAttackSubAnimInstance {
	bool _isRevvingChainsaw; // 0x5b8(0x01)
	bool _isRevvingChainsawCancelled; // 0x5b9(0x01)
	bool _isChainsawSprinting; // 0x5ba(0x01)
	bool _isWaitingForChainsaw; // 0x5bb(0x01)
	char pad_5C4[0x1c]; // 0x5c4(0x1c)
};

// Class TheHillbilly.HillbillyOverheatPresentationItemProgressComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UHillbillyOverheatPresentationItemProgressComponent : UPresentationItemProgressComponent {
	struct UHillbillyChainsawOverheatComponent* _hillbillyChainsawOverheatComponent; // 0xb8(0x08)

	void SetHillbillyChainsawOverheatComponent(struct UHillbillyChainsawOverheatComponent* HillbillyChainsawOverheatComponent); // Function TheHillbilly.HillbillyOverheatPresentationItemProgressComponent.SetHillbillyChainsawOverheatComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x326a960
};

// Class TheHillbilly.IridescentBrickAddon
// Size: 0x2b8 (Inherited: 0x288)
struct UIridescentBrickAddon : UOnEventBaseAddon {
	char pad_288[0x28]; // 0x288(0x28)
	struct UStatusEffect* _undetectableStatusEffect; // 0x2b0(0x08)
};

// Class TheHillbilly.LightbornAuraRevealEffect
// Size: 0x328 (Inherited: 0x328)
struct ULightbornAuraRevealEffect : UBaseLingeringStatusEffect {
};

// Class TheHillbilly.LightbornBlindFailedIndicatorCondition
// Size: 0x148 (Inherited: 0xe8)
struct ULightbornBlindFailedIndicatorCondition : UEventDrivenModifierCondition {
	float _conditionReevaluationTimerDurationAfterFailedBlind; // 0xe8(0x04)
	bool _replicatedIsTrue; // 0xec(0x01)
	char pad_ED[0x5b]; // 0xed(0x5b)

	void OnRep_ReplicatedIsTrue(); // Function TheHillbilly.LightbornBlindFailedIndicatorCondition.OnRep_ReplicatedIsTrue // (Final|Native|Private) // @ game+0x2c92c40
};

// Class TheHillbilly.LoProChainsAddon
// Size: 0x2d0 (Inherited: 0x278)
struct ULoProChainsAddon : UItemAddon {
	struct FAnimationMontageDescriptor _breakPalletMontage; // 0x278(0x20)
	float _halfDamageDurationAfterBreakable; // 0x298(0x04)
	bool _doesAddonIncludeBreakableWalls; // 0x29c(0x01)
	char pad_29D[0x33]; // 0x29d(0x33)
};

