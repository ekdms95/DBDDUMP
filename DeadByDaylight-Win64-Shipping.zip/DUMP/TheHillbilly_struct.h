// ScriptStruct TheHillbilly.ChainsawAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FChainsawAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	struct TArray<struct FChainsawEventWhileCamping> DownSurvivorsWithChainsawWhileCampingEvents; // 0x78(0x10)
};

// ScriptStruct TheHillbilly.ChainsawEvent
// Size: 0x04 (Inherited: 0x00)
struct FChainsawEvent {
	float ElapsedMatchTime; // 0x00(0x04)
};

// ScriptStruct TheHillbilly.ChainsawEventWhileCamping
// Size: 0x08 (Inherited: 0x04)
struct FChainsawEventWhileCamping : FChainsawEvent {
	float DistanceFromClosestHook; // 0x04(0x04)
};

// ScriptStruct TheHillbilly.HillbillyAnalytics
// Size: 0xc8 (Inherited: 0x88)
struct FHillbillyAnalytics : FChainsawAnalytics {
	struct TArray<struct FChainsawEvent> OverheatEvents; // 0x88(0x10)
	struct TArray<struct FChainsawEvent> OverheatWhileSprintingEvents; // 0x98(0x10)
	struct TArray<struct FChainsawEventWhileCamping> OverheatWhileCampingEvents; // 0xa8(0x10)
	struct TArray<struct FChainsawEvent> RevFromZeroHeatEvents; // 0xb8(0x10)
};

