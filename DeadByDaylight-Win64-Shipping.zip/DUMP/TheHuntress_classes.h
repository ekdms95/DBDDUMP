// Class TheHuntress.HatchetCooldown
// Size: 0x560 (Inherited: 0x560)
struct UHatchetCooldown : UInteractionDefinition {
};

// Class TheHuntress.HatchetLauncher
// Size: 0x2a0 (Inherited: 0x180)
struct UHatchetLauncher : UKillerProjectileLauncher {
	struct FRotator _angleOffset; // 0x180(0x0c)
	char pad_18C[0x4]; // 0x18c(0x04)
	struct UCurveFloat* _angleOffsetCurve; // 0x190(0x08)
	struct UCurveFloat* _speedCurve; // 0x198(0x08)
	float _hatchetSpeedWhenThrowFullyCharged; // 0x1a0(0x04)
	char pad_1A4[0x4]; // 0x1a4(0x04)
	struct UCurveFloat* _hatchetPitchCurve; // 0x1a8(0x08)
	struct FDBDTunableRowHandle _hatchetMinAngleOffset; // 0x1b0(0x28)
	struct FDBDTunableRowHandle _hatchetMaxAngleOffset; // 0x1d8(0x28)
	struct FDBDTunableRowHandle _hatchetMinSpeed; // 0x200(0x28)
	struct FDBDTunableRowHandle _hatchetMaxSpeed; // 0x228(0x28)
	struct FDBDTunableRowHandle _hatchetLaunchPitchMin; // 0x250(0x28)
	struct FDBDTunableRowHandle _hatchetLaunchPitchMax; // 0x278(0x28)

	bool IsLaunchedHatchetFullyCharged(); // Function TheHuntress.HatchetLauncher.IsLaunchedHatchetFullyCharged // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x346d490
};

// Class TheHuntress.HatchetProjectile
// Size: 0x300 (Inherited: 0x300)
struct AHatchetProjectile : AKillerProjectile {
};

// Class TheHuntress.HatchetRack
// Size: 0x230 (Inherited: 0x230)
struct AHatchetRack : AActor {

	void SetMovableHatchetVisibility(bool visible); // Function TheHuntress.HatchetRack.SetMovableHatchetVisibility // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class TheHuntress.HatchetThrow
// Size: 0x6c0 (Inherited: 0x690)
struct UHatchetThrow : UThrowInteraction {
	struct FDBDTunableRowHandle _hatchetThrowCancellationCooldown; // 0x690(0x28)
	char pad_6B8[0x8]; // 0x6b8(0x08)

	struct ATheHuntressPower* GetOwningHatchetSpawner(); // Function TheHuntress.HatchetThrow.GetOwningHatchetSpawner // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x346da00
};

// Class TheHuntress.ReloadHatchet
// Size: 0x560 (Inherited: 0x560)
struct UReloadHatchet : UBaseLockerInteraction {

	bool IsInteractionPossible_Shared(struct ADBDPlayer* Player); // Function TheHuntress.ReloadHatchet.IsInteractionPossible_Shared // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x346dbf0
};

// Class TheHuntress.TheHuntressPower
// Size: 0x4a0 (Inherited: 0x498)
struct ATheHuntressPower : ACollectable {
	char pad_498[0x8]; // 0x498(0x08)

	void StartHatchetShineCosmetic(); // Function TheHuntress.TheHuntressPower.StartHatchetShineCosmetic // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x346e3a0
	void SetPercentThrowStrength(float percentStrength); // Function TheHuntress.TheHuntressPower.SetPercentThrowStrength // (Final|Native|Public|BlueprintCallable) // @ game+0x346e320
	void SetHatchetVisible(bool visible); // Function TheHuntress.TheHuntressPower.SetHatchetVisible // (Final|Native|Public|BlueprintCallable) // @ game+0x346e290
	void PrintDebugThrowInfo(); // Function TheHuntress.TheHuntressPower.PrintDebugThrowInfo // (Event|Public|BlueprintEvent) // @ game+0x3873200
	bool IsHatchetThrowFullyCharged(); // Function TheHuntress.TheHuntressPower.IsHatchetThrowFullyCharged // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x346e260
	bool HasHatchet(); // Function TheHuntress.TheHuntressPower.HasHatchet // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x346e230
	struct ASlasherPlayer* GetOwningKiller(); // Function TheHuntress.TheHuntressPower.GetOwningKiller // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x346e200
	struct UBaseProjectileLauncher* GetHatchetProjectileLauncher(); // Function TheHuntress.TheHuntressPower.GetHatchetProjectileLauncher // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
	struct UHatchetCooldown* GetHatchetCooldown(); // Function TheHuntress.TheHuntressPower.GetHatchetCooldown // (Event|Public|BlueprintEvent|Const) // @ game+0x3873200
	struct UAkComponent* GetAkAudioHatchetSpawner(); // Function TheHuntress.TheHuntressPower.GetAkAudioHatchetSpawner // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
	void Cosmetic_OnThrowInteractionStart(); // Function TheHuntress.TheHuntressPower.Cosmetic_OnThrowInteractionStart // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnThrowInteractionCancelled(); // Function TheHuntress.TheHuntressPower.Cosmetic_OnThrowInteractionCancelled // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
};

