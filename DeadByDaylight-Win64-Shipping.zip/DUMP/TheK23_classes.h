// Class TheK23.ActivateSuperMode
// Size: 0x5d0 (Inherited: 0x560)
struct UActivateSuperMode : UInteractionDefinition {
	struct FAnimationMontageDescriptor _activationMontage; // 0x560(0x20)
	struct FDBDTunableRowHandle _activationDuration; // 0x580(0x28)
	struct FDBDTunableRowHandle _confirmationChargeDuration; // 0x5a8(0x28)
};

// Class TheK23.FastTrack
// Size: 0x3c0 (Inherited: 0x3a8)
struct UFastTrack : UPerk {
	int32_t _tokensToAdd[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0xc]; // 0x3b4(0x0c)

	void Cosmetic_OnTokenCountDecreased(); // Function TheK23.FastTrack.Cosmetic_OnTokenCountDecreased // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheK23.FlurryComboScoreComponent
// Size: 0x268 (Inherited: 0xb8)
struct UFlurryComboScoreComponent : UActorComponent {
	char pad_B8[0x1c]; // 0xb8(0x1c)
	float _comboScore; // 0xd4(0x04)
	struct FDBDTunableRowHandle _timeForCombo; // 0xd8(0x28)
	struct FDBDTunableRowHandle _baseKnifeComboScore; // 0x100(0x28)
	struct FDBDTunableRowHandle _maximumKnifeMultiplier; // 0x128(0x28)
	struct FDBDTunableRowHandle _fillLacerationComboScore; // 0x150(0x28)
	struct FDBDTunableRowHandle _longRangeThreshold; // 0x178(0x28)
	struct FDBDTunableRowHandle _closeRangeScoreMultiplier; // 0x1a0(0x28)
	struct FDBDTunableRowHandle _longRangeScoreMultiplier; // 0x1c8(0x28)
	struct TArray<float> _thresholds; // 0x1f0(0x10)
	struct TArray<float> _thresholdsScoreForAudio; // 0x200(0x10)
	struct TArray<struct FGameplayTag> _comboScoreEvents; // 0x210(0x10)
	char pad_220[0x48]; // 0x220(0x48)

	void OnRep_ComboScore(); // Function TheK23.FlurryComboScoreComponent.OnRep_ComboScore // (Final|Native|Private|Const) // @ game+0x3484920
};

// Class TheK23.FlurryOfKnives
// Size: 0xb50 (Inherited: 0x680)
struct UFlurryOfKnives : UChargeableInteractionDefinition {
	char pad_680[0x48]; // 0x680(0x48)
	int32_t _replicatedNumOfStacksReduction; // 0x6c8(0x04)
	bool _isSuperModeThrow; // 0x6cc(0x01)
	char pad_6CD[0x4b]; // 0x6cd(0x4b)
	struct UStatusEffect* _selfSlowEffect; // 0x718(0x08)
	struct FDBDTunableRowHandle _flurryOfKnivesEnterDuration; // 0x720(0x28)
	struct FDBDTunableRowHandle _flurryOfKnivesExitDuration; // 0x748(0x28)
	struct FDBDTunableRowHandle _chargeTime; // 0x770(0x28)
	struct FTunableStat _baseTimeBetweenThrows; // 0x798(0x80)
	struct UCurveFloat* _throwRateModifierByKnivesThrown; // 0x818(0x08)
	struct FDBDTunableRowHandle _superModeThrowRateModifier; // 0x820(0x28)
	struct FDBDTunableRowHandle _knivesLaunchSpeed; // 0x848(0x28)
	struct FDBDTunableRowHandle _convergencePointDistance; // 0x870(0x28)
	struct UCurveFloat* _coneOfFireAngleCurve; // 0x898(0x08)
	struct FDBDTunableRowHandle _consecutiveKnivesStacksDecayTime; // 0x8a0(0x28)
	struct FDBDTunableRowHandle _maxConsecutiveKnivesStacks; // 0x8c8(0x28)
	struct UCurveFloat* _movementSpeedByKnivesThrown; // 0x8f0(0x08)
	struct FDBDTunableRowHandle _superModeBaseMovementSpeed; // 0x8f8(0x28)
	struct FDBDTunableRowHandle _baseWalkSpeed; // 0x920(0x28)
	struct UCurveFloat* _recoilIntensityByKnivesThrown; // 0x948(0x08)
	struct FDBDTunableRowHandle _recoilDuration; // 0x950(0x28)
	struct FDBDTunableRowHandle _recoilAngle; // 0x978(0x28)
	struct FDBDTunableRowHandle _maximumRecoilAngleVariation; // 0x9a0(0x28)
	struct FDBDTunableRowHandle _rotationSpeedAdjustmentTime; // 0x9c8(0x28)
	struct FDBDTunableRowHandle _aimingStanceRotationYawScaleAdjustment; // 0x9f0(0x28)
	struct FDBDTunableRowHandle _aimingStanceRotationPitchScaleAdjustment; // 0xa18(0x28)
	struct FDBDTunableRowHandle _throwingRotationYawScaleAdjustment; // 0xa40(0x28)
	struct FDBDTunableRowHandle _throwingRotationPitchScaleAdjustment; // 0xa68(0x28)
	struct FDBDTunableRowHandle _aimingStanceGamepadRotationYawScaleAdjustment; // 0xa90(0x28)
	struct FDBDTunableRowHandle _aimingStanceGamepadRotationPitchScaleAdjustment; // 0xab8(0x28)
	struct FDBDTunableRowHandle _throwingGamepadRotationYawScaleAdjustment; // 0xae0(0x28)
	struct FDBDTunableRowHandle _throwingGamepadRotationPitchScaleAdjustment; // 0xb08(0x28)
	struct UCurveFloat* _aimingGamepadPitchCurve; // 0xb30(0x08)
	struct UCurveFloat* _aimingGamepadYawCurve; // 0xb38(0x08)
	struct UCurveFloat* _throwingGamepadPitchCurve; // 0xb40(0x08)
	struct UCurveFloat* _throwingGamepadYawCurve; // 0xb48(0x08)

	void Server_StartThrowing(); // Function TheK23.FlurryOfKnives.Server_StartThrowing // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3484e30
	void Server_DecreaseConsecutiveKnivesStacks(); // Function TheK23.FlurryOfKnives.Server_DecreaseConsecutiveKnivesStacks // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3484de0
	void OnRep_NumOfStacksReduction(); // Function TheK23.FlurryOfKnives.OnRep_NumOfStacksReduction // (Final|Native|Private) // @ game+0x3484dc0
	void Multicast_StartThrowing(); // Function TheK23.FlurryOfKnives.Multicast_StartThrowing // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x3407f30
};

// Class TheK23.HexCrowdControl
// Size: 0x418 (Inherited: 0x408)
struct UHexCrowdControl : UHexPerk {
	float _windowVaultBlockDuration[0x3]; // 0x408(0x0c)
	char pad_414[0x4]; // 0x414(0x04)
};

// Class TheK23.K23PowerProgressPresentationComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UK23PowerProgressPresentationComponent : UPresentationItemProgressComponent {
};

// Class TheK23.KnifeProjectile
// Size: 0x3f0 (Inherited: 0x300)
struct AKnifeProjectile : AKillerProjectile {
	struct UPrimitiveComponent* _worldCollider; // 0x300(0x08)
	struct UPrimitiveComponent* _camperDetector; // 0x308(0x08)
	char pad_310[0x10]; // 0x310(0x10)
	struct TSet<struct ADBDPlayer*> _playersAffectedSinceLastBounce; // 0x320(0x50)
	struct UPoolableProjectileComponent* _poolableActorComponent; // 0x370(0x08)
	struct FDBDTunableRowHandle _knifeMaxRange; // 0x378(0x28)
	struct FDBDTunableRowHandle _addonExplosionRadius; // 0x3a0(0x28)
	struct FDBDTunableRowHandle _numberOfAddonBounces; // 0x3c8(0x28)

	bool WasLaunchedDuringSuperMode(); // Function TheK23.KnifeProjectile.WasLaunchedDuringSuperMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34858f0
	bool ShouldPlayRicochetSound(); // Function TheK23.KnifeProjectile.ShouldPlayRicochetSound // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34858c0
	void SetKnifeAcquired(bool acquired); // Function TheK23.KnifeProjectile.SetKnifeAcquired // (Final|Native|Protected|BlueprintCallable) // @ game+0x3485830
	void OnWorldColliderHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function TheK23.KnifeProjectile.OnWorldColliderHit // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x3485660
	void OnProjectileBounce(struct FHitResult ImpactResult, struct FVector ImpactVelocity); // Function TheK23.KnifeProjectile.OnProjectileBounce // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x3485540
	float GetAddonExplosionRadius(); // Function TheK23.KnifeProjectile.GetAddonExplosionRadius // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3485510
	void BP_SetKnifeActive(bool Active); // Function TheK23.KnifeProjectile.BP_SetKnifeActive // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void BP_OnLaunchCosmetic(struct FLaunchInfo LaunchInfo, bool hasImpactOnLaunch); // Function TheK23.KnifeProjectile.BP_OnLaunchCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void BP_CosmeticOnAddonExplosion(struct FVector Location, struct FVector Normal); // Function TheK23.KnifeProjectile.BP_CosmeticOnAddonExplosion // (BlueprintCosmetic|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x3873200
};

// Class TheK23.KnifeRack
// Size: 0x230 (Inherited: 0x230)
struct AKnifeRack : AActor {

	void OnReloadMontageStarted(float actionSpeedMultiplier, struct ADBDPlayer* Player); // Function TheK23.KnifeRack.OnReloadMontageStarted // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnReloadEnded(struct ADBDPlayer* Player); // Function TheK23.KnifeRack.OnReloadEnded // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class TheK23.KnivesLauncher
// Size: 0x288 (Inherited: 0x180)
struct UKnivesLauncher : UKillerProjectileLauncher {
	struct FDBDTunableRowHandle _knifeSpawnOffset; // 0x180(0x28)
	struct FDBDTunableRowHandle _knifeSpawnForwardOffset; // 0x1a8(0x28)
	struct FDBDTunableRowHandle _launchSpeed; // 0x1d0(0x28)
	struct FTunableStat _maxAmmoTunable; // 0x1f8(0x80)
	char pad_278[0x8]; // 0x278(0x08)
	bool _isInSuperModeThrow; // 0x280(0x01)
	char pad_281[0x7]; // 0x281(0x07)

	struct AThrowingKnives* GetPower(); // Function TheK23.KnivesLauncher.GetPower // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3485f20
	int32_t GetLocallyPredictedAmmo(); // Function TheK23.KnivesLauncher.GetLocallyPredictedAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3485ef0
};

// Class TheK23.KnivesProvider
// Size: 0xf8 (Inherited: 0xf0)
struct UKnivesProvider : UAuthoritativeActorPoolComponent {
	char pad_F0[0x8]; // 0xf0(0x08)
};

// Class TheK23.LacerationComponent
// Size: 0x498 (Inherited: 0xb8)
struct ULacerationComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)
	float _laceration; // 0xf0(0x04)
	char pad_F4[0xc]; // 0xf4(0x0c)
	struct UStatusEffect* _onHitSpeedBoost; // 0x100(0x08)
	char pad_108[0x28]; // 0x108(0x28)
	struct FTunableStat _maxLaceration; // 0x130(0x80)
	struct FDBDTunableRowHandle _lacerationExplosionDamage; // 0x1b0(0x28)
	struct FTunableStat _lacerationRegressionPerSecond; // 0x1d8(0x80)
	struct FTunableStat _lacerationRegressionPerSecondWhileRunning; // 0x258(0x80)
	struct FDBDTunableRowHandle _speedBoostIntensity; // 0x2d8(0x28)
	struct FDBDTunableRowHandle _speedBoostDuration; // 0x300(0x28)
	struct FDBDTunableRowHandle _stopTickingRegressionWhileInjured; // 0x328(0x28)
	struct FDBDTunableRowHandle _stopTickingRegressionWhileInChase; // 0x350(0x28)
	struct FDBDTunableRowHandle _stopTickingRegressionWithinTerrorRadius; // 0x378(0x28)
	struct FTunableStat _timeBeforeLacerationDecayStarts; // 0x3a0(0x80)
	struct FDBDTunableRowHandle _regressionBufferTimerAlwaysTicks; // 0x420(0x28)
	struct FDBDTunableRowHandle _lacerationToRemoveOnBasicAttack; // 0x448(0x28)
	struct FDBDTunableRowHandle _thresholdForGraceTimerScoreEvent; // 0x470(0x28)

	void OnRepLaceration(float oldLaceration); // Function TheK23.LacerationComponent.OnRepLaceration // (Final|Native|Private) // @ game+0x34867e0
	void Multicast_KnifeHit(float newLaceration, bool causedDamage, bool causedKO, struct FVector impactLocation, struct FVector ImpactNormal); // Function TheK23.LacerationComponent.Multicast_KnifeHit // (Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults) // @ game+0x3486630
	void Cosmetic_OnLocallyObservedChanged(bool IsLocallyObserved, float lacerationPercent, bool isDangerous); // Function TheK23.LacerationComponent.Cosmetic_OnLocallyObservedChanged // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnLacerationChanged(float lacerationPercent, bool isDangerous); // Function TheK23.LacerationComponent.Cosmetic_OnLacerationChanged // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnKnifeHit(float lacerationPercent, bool isDangerous, bool causedDamage, bool causedKO, struct FVector ImpactNormal); // Function TheK23.LacerationComponent.Cosmetic_OnKnifeHit // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x3873200
};

// Class TheK23.BaseLacerationLevelCondition
// Size: 0xe8 (Inherited: 0xe8)
struct UBaseLacerationLevelCondition : UEventDrivenModifierCondition {
};

// Class TheK23.LacerationLevelCondition
// Size: 0xf0 (Inherited: 0xe8)
struct ULacerationLevelCondition : UBaseLacerationLevelCondition {
	float _lacerationLevelRequired; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
};

// Class TheK23.LacerationAlmostFullCondition
// Size: 0xe8 (Inherited: 0xe8)
struct ULacerationAlmostFullCondition : UBaseLacerationLevelCondition {
};

// Class TheK23.NoWayOut
// Size: 0x3e0 (Inherited: 0x3a8)
struct UNoWayOut : UPerk {
	float _exitGatePanelBlockBaseDuration[0x3]; // 0x3a8(0x0c)
	float _exitGatePanelBlockDurationPerToken[0x3]; // 0x3b4(0x0c)
	struct TArray<struct ACamperPlayer*> _hookedSurvivors; // 0x3c0(0x10)
	char pad_3D0[0x10]; // 0x3d0(0x10)
};

// Class TheK23.ReloadKnives
// Size: 0x560 (Inherited: 0x560)
struct UReloadKnives : UBaseLockerInteraction {
};

// Class TheK23.SelfPreservation
// Size: 0x3c0 (Inherited: 0x3a8)
struct USelfPreservation : UPerk {
	float _hitDistanceToTriggerPerkEffect[0x3]; // 0x3a8(0x0c)
	float _selfPreservationEffectDuration[0x3]; // 0x3b4(0x0c)
};

// Class TheK23.SmashHit
// Size: 0x3c0 (Inherited: 0x3a8)
struct USmashHit : UPerk {
	float _exhaustedTime[0x3]; // 0x3a8(0x0c)
	float _hasteTime[0x3]; // 0x3b4(0x0c)
};

// Class TheK23.Starstruck
// Size: 0x4c8 (Inherited: 0x3a8)
struct UStarstruck : UPerk {
	float _exposedEffectDuration[0x3]; // 0x3a8(0x0c)
	float _perkCooldownDuration[0x3]; // 0x3b4(0x0c)
	struct TMap<struct TWeakObjectPtr<struct ACamperPlayer>, struct TWeakObjectPtr<struct UStatusEffect>> _camperExposedEffects; // 0x3c0(0x50)
	char pad_410[0xb8]; // 0x410(0xb8)
};

// Class TheK23.SuperModeDeactivation
// Size: 0x580 (Inherited: 0x560)
struct USuperModeDeactivation : UInteractionDefinition {
	struct FDBDTunableRowHandle _deactivationDuration; // 0x558(0x28)
};

// Class TheK23.ThrowingKnives
// Size: 0x548 (Inherited: 0x498)
struct AThrowingKnives : ACollectable {
	char pad_498[0x40]; // 0x498(0x40)
	struct UFlurryComboScoreComponent* _flurryScoreComponent; // 0x4d8(0x08)
	struct UTricksterSuperModeComponent* _superModeComponent; // 0x4e0(0x08)
	struct UK23PowerProgressPresentationComponent* _superModeChargePresentationComponent; // 0x4e8(0x08)
	struct UPowerChargeComponent* _superModeChargeComponent; // 0x4f0(0x08)
	struct UKnivesProvider* _knivesProvider; // 0x4f8(0x08)
	struct UKnivesLauncher* _knivesLauncher; // 0x500(0x08)
	struct ULacerationComponent* _lacerationComponentClass; // 0x508(0x08)
	struct UReloadKnives* _reloadInteractionClass; // 0x510(0x08)
	struct AActor* _closetReloadActor; // 0x518(0x08)
	float _minimumTimeBetweenBroadcast; // 0x520(0x04)
	char pad_524[0x24]; // 0x524(0x24)

	void OnItemUsedStateChanged(bool Pressed); // Function TheK23.ThrowingKnives.OnItemUsedStateChanged // (Final|Native|Private) // @ game+0x34879e0
	void Multicast_OnUsePowerWhenOutOfAmmo(); // Function TheK23.ThrowingKnives.Multicast_OnUsePowerWhenOutOfAmmo // (Net|Native|Event|NetMulticast|Public) // @ game+0x34879c0
	void Multicast_OnUsePowerWhenInCooldown(); // Function TheK23.ThrowingKnives.Multicast_OnUsePowerWhenInCooldown // (Net|Native|Event|NetMulticast|Public) // @ game+0x346e3a0
	struct ASlasherPlayer* GetSlasher(); // Function TheK23.ThrowingKnives.GetSlasher // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3487990
	struct UKnivesLauncher* GetLauncher(); // Function TheK23.ThrowingKnives.GetLauncher // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3487960
	void Cosmetic_OnUsePowerWhenOutOfAmmo(); // Function TheK23.ThrowingKnives.Cosmetic_OnUsePowerWhenOutOfAmmo // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnUsePowerWhenInCooldown(); // Function TheK23.ThrowingKnives.Cosmetic_OnUsePowerWhenInCooldown // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnLaunch(); // Function TheK23.ThrowingKnives.Cosmetic_OnLaunch // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnComboScoreChanged(float scoreNormalizedForAudio); // Function TheK23.ThrowingKnives.Cosmetic_OnComboScoreChanged // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnComboFinished(bool isSRankCombo); // Function TheK23.ThrowingKnives.Cosmetic_OnComboFinished // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Authority_SpawnReloadInteractionOnLockers(); // Function TheK23.ThrowingKnives.Authority_SpawnReloadInteractionOnLockers // (Final|Native|Public) // @ game+0x3487940
};

// Class TheK23.ThrowingKnivesHitSubAnimInstance
// Size: 0x510 (Inherited: 0x4f0)
struct UThrowingKnivesHitSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _hitByKnifeTrigger; // 0x4f0(0x01)
	bool _knifeHitCausedKOTrigger; // 0x4f1(0x01)
	bool _knifeHitCausedDamageTrigger; // 0x4f2(0x01)
	bool _useAlternateHitReactionState; // 0x4f3(0x01)
	float _knifeHitAngle; // 0x4f4(0x04)
	float _knifeHitStateHitAngle; // 0x4f8(0x04)
	float _alternateKnifeHitStateHitAngle; // 0x4fc(0x04)
	char pad_500[0x10]; // 0x500(0x10)
};

// Class TheK23.TricksterAnimInstance
// Size: 0x620 (Inherited: 0x5b0)
struct UTricksterAnimInstance : UKillerAnimInstance {
	bool _isAiming; // 0x5a8(0x01)
	float _isThrowInputPressed; // 0x5ac(0x04)
	bool _isThrowingWithLeftArm; // 0x5b0(0x01)
	bool _isThrowingWithRightArm; // 0x5b1(0x01)
	float _throwPlayRate; // 0x5b4(0x04)
	float _baseThrowDuration; // 0x5b8(0x04)
	int32_t _consecutiveKnivesThrownStacks; // 0x5bc(0x04)
	float _timeSinceLastKnifeLaunched; // 0x5c0(0x04)
	int32_t _currentAmmoCount; // 0x5c4(0x04)
	bool _isInSuperMode; // 0x5c8(0x01)
	bool _isInActivation; // 0x5c9(0x01)
	float _activationDuration; // 0x5cc(0x04)
	bool _isInDeactivation; // 0x5d0(0x01)
	char pad_5D2[0x2]; // 0x5d2(0x02)
	float _deactivationDuration; // 0x5d4(0x04)
	char pad_5D8[0x38]; // 0x5d8(0x38)
	struct AThrowingKnives* _throwingKnives; // 0x610(0x08)
	char pad_618[0x8]; // 0x618(0x08)
};

// Class TheK23.TricksterChainedThrowsAddon
// Size: 0x290 (Inherited: 0x278)
struct UTricksterChainedThrowsAddon : UItemAddon {
	char pad_278[0x4]; // 0x278(0x04)
	bool _resetOnEnteringFlurryInteraction; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	float _lacerationPenaltyRangeThreshold; // 0x280(0x04)
	float _closeRangeLacerationPenalty; // 0x284(0x04)
	float _maximumMultiplier; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheK23.TricksterCharacterVFXInterface
// Size: 0x30 (Inherited: 0x30)
struct UTricksterCharacterVFXInterface : UInterface {

	void ShowWeapon(); // Function TheK23.TricksterCharacterVFXInterface.ShowWeapon // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetSuperModeActive(bool Active); // Function TheK23.TricksterCharacterVFXInterface.SetSuperModeActive // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetKnivesVisibility(bool leftKnife, bool rightKnife); // Function TheK23.TricksterCharacterVFXInterface.SetKnivesVisibility // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetIsSuperModeReady(bool isSuperModeReady); // Function TheK23.TricksterCharacterVFXInterface.SetIsSuperModeReady // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void SetIsInCooldown(bool isInCooldown); // Function TheK23.TricksterCharacterVFXInterface.SetIsInCooldown // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void HideWeapon(); // Function TheK23.TricksterCharacterVFXInterface.HideWeapon // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
};

// Class TheK23.TricksterSuperModeComponent
// Size: 0x228 (Inherited: 0xb8)
struct UTricksterSuperModeComponent : UActorComponent {
	bool _isInSuperMode; // 0xb8(0x01)
	bool _isSuperModeReady; // 0xb9(0x01)
	bool _isInCooldown; // 0xba(0x01)
	char pad_BB[0xd]; // 0xbb(0x0d)
	struct FDBDTunableRowHandle _chargesToAddOnKnifeHit; // 0xc8(0x28)
	struct FDBDTunableRowHandle _superModeMaxCharge; // 0xf0(0x28)
	struct FDBDTunableRowHandle _superModeReadyDepletionPerSecond; // 0x118(0x28)
	struct FTunableStat _superModeActiveDuration; // 0x140(0x80)
	struct FDBDTunableRowHandle _superModeCooldown; // 0x1c0(0x28)
	struct FDBDTunableRowHandle _shouldDisableFlurryDuringCooldown; // 0x1e8(0x28)
	char pad_210[0x18]; // 0x210(0x18)

	void OnRepIsSuperModeReady(); // Function TheK23.TricksterSuperModeComponent.OnRepIsSuperModeReady // (Final|Native|Private) // @ game+0x3488770
	void OnRepIsInSuperMode(); // Function TheK23.TricksterSuperModeComponent.OnRepIsInSuperMode // (Final|Native|Private) // @ game+0x3488750
	void OnRepIsInCooldown(); // Function TheK23.TricksterSuperModeComponent.OnRepIsInCooldown // (Final|Native|Private) // @ game+0x3488730
};

// Class TheK23.TriggerTimerOnLacerationAlmostFullEffect
// Size: 0x330 (Inherited: 0x320)
struct UTriggerTimerOnLacerationAlmostFullEffect : UStatusEffect {
	struct ULacerationComponent* _lacerationComponent; // 0x320(0x08)
	float _duration; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)
};

