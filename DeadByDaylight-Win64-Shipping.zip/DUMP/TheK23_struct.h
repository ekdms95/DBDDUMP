// Enum TheK23.EFlurryOfKnivesInteractionState
enum class EFlurryOfKnivesInteractionState : uint8 {
	Charging,
	Aiming,
	Throwing,
	Finished,
	EFlurryOfKnivesInteractionState_MAX,
};

