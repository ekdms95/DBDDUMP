// Class TheK24.ActivateK24PowerInteraction
// Size: 0x710 (Inherited: 0x680)
struct UActivateK24PowerInteraction : UChargeableInteractionDefinition {
	char pad_680[0x10]; // 0x680(0x10)
	struct FDBDTunableRowHandle _interactionViewPitchMax; // 0x690(0x28)
	struct FDBDTunableRowHandle _interactionViewPitchMin; // 0x6b8(0x28)
	struct FDBDTunableRowHandle _maximumTimeToTriggerRegularAttack; // 0x6e0(0x28)
	char pad_708[0x8]; // 0x708(0x08)

	void SetK24Power(struct AK24Power* K24Power); // Function TheK24.ActivateK24PowerInteraction.SetK24Power // (Final|Native|Public|BlueprintCallable) // @ game+0x34b2230
};

// Class TheK24.Addon_K24_04
// Size: 0x2a0 (Inherited: 0x288)
struct UAddon_K24_04 : UOnEventBaseAddon {
	float _effectTime; // 0x288(0x04)
	struct FLinearColor OutlineColor; // 0x28c(0x10)
	char pad_29C[0x4]; // 0x29c(0x04)
};

// Class TheK24.Addon_K24_19
// Size: 0x2a8 (Inherited: 0x2a0)
struct UAddon_K24_19 : UImposeStatusEffectOnEventAddon {
	struct AZombieEscapeDoorPointsActor* _zombieEscapeDoorPointsActor; // 0x2a0(0x08)
};

// Class TheK24.BiteTheBullet
// Size: 0x3b0 (Inherited: 0x3a8)
struct UBiteTheBullet : UPerk {
	struct ADBDPlayer* _server_healTarget; // 0x3a8(0x08)
};

// Class TheK24.BiteTheBulletEffect
// Size: 0x328 (Inherited: 0x328)
struct UBiteTheBulletEffect : UBaseLingeringStatusEffect {
};

// Class TheK24.BlastMine
// Size: 0x480 (Inherited: 0x3a8)
struct UBlastMine : UPerk {
	float _firecrackerHeight; // 0x3a8(0x04)
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct FSecondaryInteractionProperties _secondaryActionProperties; // 0x3b0(0x30)
	float _secondsToActivatePerk; // 0x3e0(0x04)
	float _kickChargePercentMin; // 0x3e4(0x04)
	float _kickChargePercentMax; // 0x3e8(0x04)
	float _progressPercentRequirementLevels[0x3]; // 0x3ec(0x0c)
	float __generatorTrapDurationLevels[0x3]; // 0x3f8(0x0c)
	bool _canBeReusedOnTimerExpire; // 0x404(0x01)
	bool _canBeReusedAfterTrapActivation; // 0x405(0x01)
	char pad_406[0x2]; // 0x406(0x02)
	struct UInteractionDefinition* _currentRepairInteractionWithAbility; // 0x408(0x08)
	struct AGenerator* _trappedGenerator; // 0x410(0x08)
	float _progressPercent; // 0x418(0x04)
	bool _trapActivated; // 0x41c(0x01)
	bool _repairTimerDone; // 0x41d(0x01)
	char pad_41E[0x2]; // 0x41e(0x02)
	struct ASlasherPlayer* _kickInteractionPlayerOwner; // 0x420(0x08)
	struct UChargeableInteractionDefinition* _kickInteraction; // 0x428(0x08)
	struct AGenerator* _repairProgressGenerator; // 0x430(0x08)
	char pad_438[0x48]; // 0x438(0x48)

	void TrapDettachedToGenerator_Cosmetic(struct AGenerator* trappedGenerator); // Function TheK24.BlastMine.TrapDettachedToGenerator_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void TrapAttachedToGenerator_Cosmetic(struct AGenerator* trappedGenerator); // Function TheK24.BlastMine.TrapAttachedToGenerator_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void ThrowBubbleIndicator_Cosmetic(struct FTransform Location); // Function TheK24.BlastMine.ThrowBubbleIndicator_Cosmetic // (BlueprintCosmetic|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void Server_OnActionInputPressed(struct AGenerator* Generator); // Function TheK24.BlastMine.Server_OnActionInputPressed // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x32f21d0
	void OnRep_TrappedGenerator(struct AGenerator* oldGenerator); // Function TheK24.BlastMine.OnRep_TrappedGenerator // (Final|Native|Private) // @ game+0x34b1ef0
	void OnRep_CurrentRepairInteractionWithAbility(struct UInteractionDefinition* oldRepairInteraction); // Function TheK24.BlastMine.OnRep_CurrentRepairInteractionWithAbility // (Final|Native|Private) // @ game+0x34b1df0
	void OnActivateExplosion(struct FTransform firecrackerTransform, struct AGenerator* Generator); // Function TheK24.BlastMine.OnActivateExplosion // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void Client_TrapActivatedLoudNotification(struct FTransform Location); // Function TheK24.BlastMine.Client_TrapActivatedLoudNotification // (Final|Net|NetReliableNative|Event|Private|HasDefaults|NetClient) // @ game+0x34b19e0
	void Authority_OnRepairProgress(float individualChargeAmount, float totalChargeAmount, struct AActor* chargeInstigator, bool wasCoop, float DeltaTime); // Function TheK24.BlastMine.Authority_OnRepairProgress // (Final|Native|Private) // @ game+0x34b1640
};

// Class TheK24.BlastMineTrapComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UBlastMineTrapComponent : UActorComponent {
	bool _isTrapActive; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)

	void OnRep_IsTrapActive(); // Function TheK24.BlastMineTrapComponent.OnRep_IsTrapActive // (Final|Native|Private) // @ game+0x34b1eb0
};

// Class TheK24.BlindZombieFlashlightableLightingStrategy
// Size: 0x40 (Inherited: 0x40)
struct UBlindZombieFlashlightableLightingStrategy : UFlashlightablePointsLightingStrategy {
};

// Class TheK24.BTTask_MoveToAbortIfStuck
// Size: 0xd8 (Inherited: 0xc0)
struct UBTTask_MoveToAbortIfStuck : UBTTask_MoveTo {
	char pad_C0[0x4]; // 0xc0(0x04)
	float _deltaConsideredStuck; // 0xc4(0x04)
	char pad_C8[0xc]; // 0xc8(0x0c)
	float _maxTimeStuck; // 0xd4(0x04)
};

// Class TheK24.ChangeZombieStateBTTask
// Size: 0xb8 (Inherited: 0xb0)
struct UChangeZombieStateBTTask : UBTTask_BlueprintBase {
	enum class EZombieState _zombieState; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class TheK24.CollectSerumInCrateInteraction
// Size: 0x5a0 (Inherited: 0x580)
struct UCollectSerumInCrateInteraction : UCollectItemInteraction {
	struct ASupplyCrateInteractable* _owningSupplyCrate; // 0x580(0x08)
	char pad_588[0x18]; // 0x588(0x18)
};

// Class TheK24.ContaminationSerumCollectable
// Size: 0x4f8 (Inherited: 0x4e0)
struct AContaminationSerumCollectable : ABaseCamperCollectable {
	char pad_4E0[0x18]; // 0x4e0(0x18)
};

// Class TheK24.ContaminationSubAnimInstance
// Size: 0x520 (Inherited: 0x4f0)
struct UContaminationSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isContaminated; // 0x4f0(0x01)
	bool _isInjectingSerumSelf; // 0x4f1(0x01)
	bool _isInjectingSerumOther; // 0x4f2(0x01)
	bool _isBeingInjectedWithSerum; // 0x4f3(0x01)
	bool _isBeingHealed; // 0x4f4(0x01)
	bool _isFirstContaminationHit; // 0x4f5(0x01)
	char pad_4F6[0x2a]; // 0x4f6(0x2a)
};

// Class TheK24.Counterforce
// Size: 0x3d0 (Inherited: 0x3a8)
struct UCounterforce : UPerk {
	char pad_3A8[0x4]; // 0x3a8(0x04)
	float _totemAuraVisibleDuration[0x3]; // 0x3ac(0x0c)
	float _startingTotemCleanseSpeedBonus[0x3]; // 0x3b8(0x0c)
	float _stackableTotemCleanseSpeedBonus[0x3]; // 0x3c4(0x0c)

	void Multicast_ShowTotemAura(struct ATotem* Totem); // Function TheK24.Counterforce.Multicast_ShowTotemAura // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x32f21d0
};

// Class TheK24.EnvQueryContext_ZombiePatrolAreaPoint
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryContext_ZombiePatrolAreaPoint : UEnvQueryContext {
};

// Class TheK24.Eruption
// Size: 0x3f0 (Inherited: 0x3a8)
struct UEruption : UPerk {
	struct TArray<struct AGenerator*> _server_highlightedGenerators; // 0x3a8(0x10)
	bool _isPerkEnabled; // 0x3b8(0x01)
	char pad_3B9[0x3]; // 0x3b9(0x03)
	float _generatorRegressPercentage[0x3]; // 0x3bc(0x0c)
	float _survivorImposedStatusEffectDuration[0x3]; // 0x3c8(0x0c)
	float _perkCooldownDuration[0x3]; // 0x3d4(0x0c)
	float _screamRevealLocationDuration; // 0x3e0(0x04)
	char pad_3E4[0xc]; // 0x3e4(0x0c)

	void OnRep_IsPerkEnabled(); // Function TheK24.Eruption.OnRep_IsPerkEnabled // (Final|Native|Private) // @ game+0x34b1e90
	void Multicast_TriggerPerk(struct TArray<struct AGenerator*> explodingGenerators); // Function TheK24.Eruption.Multicast_TriggerPerk // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2c98120
	void Multicast_HighlightGenerator(struct AGenerator* Generator); // Function TheK24.Eruption.Multicast_HighlightGenerator // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x32f2140
	void MakeSurvivorScreamCosmetic(struct ADBDPlayer* screamingSurvivor); // Function TheK24.Eruption.MakeSurvivorScreamCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	float GetScreamRevealLocationDuration(); // Function TheK24.Eruption.GetScreamRevealLocationDuration // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b1b50
	void Cosmetic_OnGeneratorHighlightStart(struct AGenerator* highlightedGenerator); // Function TheK24.Eruption.Cosmetic_OnGeneratorHighlightStart // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnGeneratorHighlightEnd(struct AGenerator* highlightedGenerator); // Function TheK24.Eruption.Cosmetic_OnGeneratorHighlightEnd // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheK24.Flashbang
// Size: 0x3c8 (Inherited: 0x3a8)
struct UFlashbang : UPerk {
	char pad_3A8[0x8]; // 0x3a8(0x08)
	struct AGenerator* _generatorBeingRepaired; // 0x3b0(0x08)
	float _generatorsRepairTargetProgression; // 0x3b8(0x04)
	float _generatorRepairPercentToCraftFlashbang[0x3]; // 0x3bc(0x0c)

	void OnRep_GeneratorsRepairProgress(); // Function TheK24.Flashbang.OnRep_GeneratorsRepairProgress // (Final|Native|Private) // @ game+0x34b1e70
	void Cosmetic_OnGeneratorRepairProgressionTargetAchieved(); // Function TheK24.Flashbang.Cosmetic_OnGeneratorRepairProgressionTargetAchieved // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Client_OnGeneratorRepairProgressionTargetAchieved(); // Function TheK24.Flashbang.Client_OnGeneratorRepairProgressionTargetAchieved // (Final|Net|Native|Event|Private|NetClient) // @ game+0x2c98470
	void Authority_OnRepairProgressApplied(float individualChargeAmount, float totalChargeAmount, struct AActor* chargeInstigator, bool wasCoop, float DeltaTime); // Function TheK24.Flashbang.Authority_OnRepairProgressApplied // (Final|Native|Private) // @ game+0x34b17d0
};

// Class TheK24.Hysteria
// Size: 0x3c0 (Inherited: 0x3a8)
struct UHysteria : UPerk {
	float _obliviousEffectDuration[0x3]; // 0x3a8(0x0c)
	float _perkCooldownDuration[0x3]; // 0x3b4(0x0c)
};

// Class TheK24.IncreaseZombiesSpeedStatusEffect
// Size: 0x328 (Inherited: 0x320)
struct UIncreaseZombiesSpeedStatusEffect : UStatusEffect {
	float _zombieSpeedAdditive; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
};

// Class TheK24.InjectSerumInteraction
// Size: 0x740 (Inherited: 0x680)
struct UInjectSerumInteraction : UChargeableInteractionDefinition {
	struct FTunableStat _injectSerumKillerInstinctTime; // 0x680(0x80)
	char pad_700[0x8]; // 0x700(0x08)
	struct FGameplayTag _scoreEvent; // 0x708(0x0c)
	char pad_714[0x4]; // 0x714(0x04)
	struct FDBDTunableRowHandle _serumApplyHeal; // 0x718(0x28)

	void OnSurvivorCured_Cosmetic(); // Function TheK24.InjectSerumInteraction.OnSurvivorCured_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnKillerSet(struct ASlasherPlayer* killer); // Function TheK24.InjectSerumInteraction.OnKillerSet // (Final|Native|Private) // @ game+0x34b1d70
	struct ACamperPlayer* GetInjectionTarget(); // Function TheK24.InjectSerumInteraction.GetInjectionTarget // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b1af0
	void Authority_CureSurvivor(struct ACamperPlayer* CamperPlayer); // Function TheK24.InjectSerumInteraction.Authority_CureSurvivor // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x34b15c0
};

// Class TheK24.K24AnimInstance
// Size: 0x5c0 (Inherited: 0x5b0)
struct UK24AnimInstance : UKillerAnimInstance {
	bool _isInPowerMode; // 0x5a8(0x01)
	bool _isChargingPower; // 0x5a9(0x01)
	bool _isK24PowerAttacking; // 0x5aa(0x01)
	bool _isRequestingPowerAttack; // 0x5ab(0x01)
	int32_t _powerLevel; // 0x5ac(0x04)
	char pad_5B8[0x8]; // 0x5b8(0x08)

	void OnKillerPowerLevelChanged(int32_t powerlevel); // Function TheK24.K24AnimInstance.OnKillerPowerLevelChanged // (Final|Native|Private) // @ game+0x34b1cf0
};

// Class TheK24.K24CharacterFXComponent
// Size: 0x110 (Inherited: 0xb8)
struct UK24CharacterFXComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPowerLevelChangedFx; // 0xb8(0x10)
	struct FMulticastInlineDelegate Local_OnKillerHitZombie; // 0xc8(0x10)
	struct FMulticastInlineDelegate Local_OnKillerContaminatedSurvivor; // 0xd8(0x10)
	char pad_E8[0x28]; // 0xe8(0x28)

	void Local_OnKillerPowerLevelChanged(int32_t powerlevel); // Function TheK24.K24CharacterFXComponent.Local_OnKillerPowerLevelChanged // (Final|Native|Private) // @ game+0x34b1be0
};

// Class TheK24.K24CheatComponent
// Size: 0xc8 (Inherited: 0xb8)
struct UK24CheatComponent : UActorComponent {
	struct AZombiesManagement* _zombieManagementClass; // 0xb8(0x08)
	struct AZombiesManagement* _zombiesManagement; // 0xc0(0x08)

	void DBD_TeleportZombiesTo(float X, float Y, float Z); // Function TheK24.K24CheatComponent.DBD_TeleportZombiesTo // (Final|Exec|Native|Public) // @ game+0x32af210
	void DBD_K24ZombieFall(float Zvalue); // Function TheK24.K24CheatComponent.DBD_K24ZombieFall // (Final|Exec|Native|Public) // @ game+0x26e6b50
	void DBD_K24StopAllZombies(); // Function TheK24.K24CheatComponent.DBD_K24StopAllZombies // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_K24StartAllZombies(); // Function TheK24.K24CheatComponent.DBD_K24StartAllZombies // (Final|Exec|Native|Public) // @ game+0x25271c0
	void DBD_K24SpawnZombieOnKiller(); // Function TheK24.K24CheatComponent.DBD_K24SpawnZombieOnKiller // (Final|Exec|Native|Public) // @ game+0x34b1ad0
	void DBD_K24SetPowerLevelPoints(float value); // Function TheK24.K24CheatComponent.DBD_K24SetPowerLevelPoints // (Final|Exec|Native|Public) // @ game+0x26e6b50
	void DBD_K24SetContaminationOnSurvivor(bool value); // Function TheK24.K24CheatComponent.DBD_K24SetContaminationOnSurvivor // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	void DBD_K24ComeToMeMyZombies(); // Function TheK24.K24CheatComponent.DBD_K24ComeToMeMyZombies // (Final|Exec|Native|Public) // @ game+0x25271c0
};

// Class TheK24.K24PounceAttack
// Size: 0x360 (Inherited: 0x360)
struct UK24PounceAttack : UPounceAttack {

	void Server_HitZombie(struct AZombieCharacter* zombie, float TargetLocationTimestamp); // Function TheK24.K24PounceAttack.Server_HitZombie // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x34b1f70
};

// Class TheK24.K24Power
// Size: 0x8a0 (Inherited: 0x498)
struct AK24Power : ACollectable {
	char pad_498[0x88]; // 0x498(0x88)
	struct FDBDTunableRowHandle _powerWalkSpeed; // 0x520(0x28)
	struct FDBDTunableRowHandle _normalWalkSpeed; // 0x548(0x28)
	struct FDBDTunableRowHandle _powerMouseYawScale; // 0x570(0x28)
	struct FDBDTunableRowHandle _powerYawAdjustTime; // 0x598(0x28)
	struct FDBDTunableRowHandle _powerGamePadYawScale; // 0x5c0(0x28)
	struct UChargeableComponent* _activateK24PowerCharge; // 0x5e8(0x08)
	struct FDBDTunableRowHandle _activateK24PowerSecondsToCharge; // 0x5f0(0x28)
	struct UCurveFloat* _activatePowerChargeSpeedCurve; // 0x618(0x08)
	struct UCurveFloat* _activatePowerChargeLvl3SpeedCurve; // 0x620(0x08)
	char pad_628[0x8]; // 0x628(0x08)
	struct UInteractionDefinition* _k24PowerCooldownInteraction; // 0x630(0x08)
	struct FDBDTunableRowHandle _whipLengthLevel1; // 0x638(0x28)
	struct FDBDTunableRowHandle _whipLengthLevel2; // 0x660(0x28)
	struct FDBDTunableRowHandle _whipLengthLevel3; // 0x688(0x28)
	struct USurvivorContaminationComponent* _contaminationComponentBP; // 0x6b0(0x08)
	char pad_6B8[0x8]; // 0x6b8(0x08)
	struct FTunableStat _powerChargeSurvivorContaminatedPoint; // 0x6c0(0x80)
	struct FTunableStat _powerChargeZombieKilledPoint; // 0x740(0x80)
	struct FTunableStat _powerChargeSurvivorHitPoint; // 0x7c0(0x80)
	float _powerLevelPoints; // 0x840(0x04)
	char pad_844[0x4]; // 0x844(0x04)
	struct FDBDTunableRowHandle _powerLevelPointsToLevel2; // 0x848(0x28)
	struct FDBDTunableRowHandle _powerLevelPointsToLevel3; // 0x870(0x28)
	char pad_898[0x8]; // 0x898(0x08)

	void WhipAttackStart_Cosmetic(); // Function TheK24.K24Power.WhipAttackStart_Cosmetic // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void WhipAttackMove_Cosmetic(struct FVector whipStartLocation, struct FVector whipEndLocation, bool isFirstRayCast); // Function TheK24.K24Power.WhipAttackMove_Cosmetic // (BlueprintCosmetic|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void WhipAttackHit_Cosmetic(struct FVector whipStartLocation, struct FVector impactPointLocation, struct FVector whipEndLocation, bool isFirstHit, struct FVector ImpactNormal, struct FName phyMaterial, bool hitACharacter); // Function TheK24.K24Power.WhipAttackHit_Cosmetic // (BlueprintCosmetic|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void WhipAttackEnd_Cosmetic(); // Function TheK24.K24Power.WhipAttackEnd_Cosmetic // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Server_PowerDestroyPallet(struct APallet* Pallet); // Function TheK24.K24Power.Server_PowerDestroyPallet // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x34b21a0
	void Server_PowerDestroyBreakable(struct ABreakableBase* breakable); // Function TheK24.K24Power.Server_PowerDestroyBreakable // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x34b2110
	void Server_KillAZombie(struct AZombieCharacter* zombie, enum class EAttackType attackType); // Function TheK24.K24Power.Server_KillAZombie // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x34b2040
	void PowerHitStateEnd_Cosmetic(struct FVector whipStartLocation, struct FVector whipEndLocation); // Function TheK24.K24Power.PowerHitStateEnd_Cosmetic // (BlueprintCosmetic|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void PowerCooldownEnd_Cosmetic(); // Function TheK24.K24Power.PowerCooldownEnd_Cosmetic // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void OnRep_PowerLevelPoints(); // Function TheK24.K24Power.OnRep_PowerLevelPoints // (Final|Native|Private) // @ game+0x34b1ed0
	void OnPowerStop_Cosmetic(); // Function TheK24.K24Power.OnPowerStop_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnPowerStartCharge_Cosmetic(); // Function TheK24.K24Power.OnPowerStartCharge_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnPowerLevelChanged_Cosmetic(int32_t powerlevel); // Function TheK24.K24Power.OnPowerLevelChanged_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_PowerDestroyPallet(struct APallet* Pallet); // Function TheK24.K24Power.Multicast_PowerDestroyPallet // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x34b1c60
	void Multicast_PowerDestroyBreakable(struct ABreakableBase* breakable); // Function TheK24.K24Power.Multicast_PowerDestroyBreakable // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc3fb0
	bool IsInPower(); // Function TheK24.K24Power.IsInPower // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b1bb0
	float GetWhipLength(); // Function TheK24.K24Power.GetWhipLength // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b1b80
	int32_t GetPowerLevel(); // Function TheK24.K24Power.GetPowerLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b1b20
	void Authority_OnSurvivorContaminated(enum class EContaminator contaminator); // Function TheK24.K24Power.Authority_OnSurvivorContaminated // (Final|Native|Public) // @ game+0x34b1960
};

// Class TheK24.K24PowerAnimInstance
// Size: 0x2a0 (Inherited: 0x270)
struct UK24PowerAnimInstance : UAnimInstance {
	struct AK24Power* _k24Power; // 0x270(0x08)
	struct ASlasherPlayer* _owningKiller; // 0x278(0x08)
	bool _isInPowerMode; // 0x280(0x01)
	bool _isChargingPower; // 0x281(0x01)
	bool _isK24PowerAttacking; // 0x282(0x01)
	bool _isRequestingPowerAttack; // 0x283(0x01)
	float _tentacleLength; // 0x284(0x04)
	bool _isFirstPersonView; // 0x288(0x01)
	enum class EAttackSubstate _attackSubstate; // 0x289(0x01)
	bool _isIntroCompleted; // 0x28a(0x01)
	char pad_28B[0x1]; // 0x28b(0x01)
	int32_t _powerLevel; // 0x28c(0x04)
	float _forwardVelocity; // 0x290(0x04)
	float _lateralVelocity; // 0x294(0x04)
	bool _isKilling; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)

	void OnKillerPowerLevelChanged(int32_t powerlevel); // Function TheK24.K24PowerAnimInstance.OnKillerPowerLevelChanged // (Final|Native|Private) // @ game+0x34b67c0
	void OnIntroCompleted(); // Function TheK24.K24PowerAnimInstance.OnIntroCompleted // (Final|Native|Private) // @ game+0x34b67a0
};

// Class TheK24.k24PowerCooldownInteraction
// Size: 0x5a0 (Inherited: 0x560)
struct Uk24PowerCooldownInteraction : UInteractionDefinition {
	struct FDBDTunableRowHandle _k24PowerCooldownTime; // 0x558(0x28)
	struct UCurveFloat* _cooldownSpeedCurve; // 0x580(0x08)
	struct UCurveFloat* _cooldownLvl3SpeedCurve; // 0x588(0x08)
	struct UCurveFloat* _playedCooldownSpeedCurve; // 0x590(0x08)

	void SetK24Power(struct AK24Power* K24Power); // Function TheK24.k24PowerCooldownInteraction.SetK24Power // (Final|Native|Public|BlueprintCallable) // @ game+0x34b6c70
};

// Class TheK24.K24PowerPresentationItemProgressComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UK24PowerPresentationItemProgressComponent : UPresentationItemProgressComponent {
	char pad_B8[0x8]; // 0xb8(0x08)

	void SetK24Power(struct AK24Power* K24Power); // Function TheK24.K24PowerPresentationItemProgressComponent.SetK24Power // (Final|Native|Public|BlueprintCallable) // @ game+0x326a960
};

// Class TheK24.K24SlashAttack
// Size: 0x360 (Inherited: 0x360)
struct UK24SlashAttack : UK24PounceAttack {
};

// Class TheK24.K24WhipAttack
// Size: 0x370 (Inherited: 0x360)
struct UK24WhipAttack : UPounceAttack {
	char pad_360[0x10]; // 0x360(0x10)

	void Server_ContaminatePlayer(struct ACamperPlayer* Target, float TargetLocationTimestamp); // Function TheK24.K24WhipAttack.Server_ContaminatePlayer // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x34b6aa0
	void Client_ContaminationResult(struct ADBDPlayer* Target, bool IsValid); // Function TheK24.K24WhipAttack.Client_ContaminationResult // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x34b6020
};

// Class TheK24.K24WhipAttackOpenSubstate
// Size: 0x138 (Inherited: 0x130)
struct UK24WhipAttackOpenSubstate : UPounceAttackOpenSubstate {
	struct UCurveFloat* _lvl3SpeedCurve; // 0x130(0x08)
};

// Class TheK24.K24WhipAttackHittingSubstate
// Size: 0x260 (Inherited: 0x1a0)
struct UK24WhipAttackHittingSubstate : UPounceAttackHittingSubstate {
	struct FDBDTunableRowHandle _attackSphereTraceRadius; // 0x1a0(0x28)
	struct FDBDTunableRowHandle _powerAttackBreakObjectLevel; // 0x1c8(0x28)
	struct FDBDTunableRowHandle _powerCanBreakObjectAfterAPlayerDamage; // 0x1f0(0x28)
	struct FVector _whipMovementFromOffset; // 0x218(0x0c)
	struct FVector _whipMovementToOffset; // 0x224(0x0c)
	struct UCurveFloat* _whipMovementCurve; // 0x230(0x08)
	struct UCurveFloat* _lvl3SpeedCurve; // 0x238(0x08)
	float _whipGroundDetectionOffset; // 0x240(0x04)
	char pad_244[0x1c]; // 0x244(0x1c)
};

// Class TheK24.K24WhipAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UK24WhipAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheK24.K24WhipAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UK24WhipAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheK24.K24WhipAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UK24WhipAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheK24.LethalPursuer
// Size: 0x3b8 (Inherited: 0x3a8)
struct ULethalPursuer : UPerk {
	float _survivorRevealDuration[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)

	void Server_ActivatePerk(); // Function TheK24.LethalPursuer.Server_ActivatePerk // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2c98470
	void Local_OnIntroCompleted(); // Function TheK24.LethalPursuer.Local_OnIntroCompleted // (Final|Native|Private) // @ game+0x34b62f0
};

// Class TheK24.OpenSupplyCrateInteraction
// Size: 0x6a0 (Inherited: 0x680)
struct UOpenSupplyCrateInteraction : UChargeableInteractionDefinition {
	struct ASupplyCrateInteractable* _owningSupplyCrate; // 0x680(0x08)
	bool _interactionWasComplete; // 0x688(0x01)
	char pad_689[0x7]; // 0x689(0x07)
	struct UAnimSequence* _successExitTimeAnimSequenceReference; // 0x690(0x08)
	char pad_698[0x8]; // 0x698(0x08)
};

// Class TheK24.Resurgence
// Size: 0x3b8 (Inherited: 0x3a8)
struct UResurgence : UPerk {
	float _healRegainPercentage[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class TheK24.RookieSpirit
// Size: 0x3b8 (Inherited: 0x3a8)
struct URookieSpirit : UPerk {
	int32_t _numberOfGreatSkillChecksOnGeneratorRepair; // 0x3a8(0x04)
	int32_t _numberOfGeneratorRepairGreatSkillChecksRequired[0x3]; // 0x3ac(0x0c)

	void OnRep_NumberOfGreatSkillChecksOnGeneratorRepair(); // Function TheK24.RookieSpirit.OnRep_NumberOfGreatSkillChecksOnGeneratorRepair // (Final|Native|Private) // @ game+0x34b68e0
	void HandleGeneratorIsDamagedChanged(struct AGenerator* Generator, struct ADBDPlayer* Player); // Function TheK24.RookieSpirit.HandleGeneratorIsDamagedChanged // (Final|Native|Private) // @ game+0x34b6200
};

// Class TheK24.SerumOutlineUpdateStrategy
// Size: 0xe0 (Inherited: 0xe0)
struct USerumOutlineUpdateStrategy : UDefaultOutlineUpdateStrategy {
};

// Class TheK24.SupplyCrateAnimInstance
// Size: 0x290 (Inherited: 0x280)
struct USupplyCrateAnimInstance : USleepingAnimInstance {
	struct ASupplyCrateInteractable* _owningSupplyCrate; // 0x280(0x08)
	bool _isOpen; // 0x288(0x01)
	bool _isBeingPriedOpen; // 0x289(0x01)
	bool _isAutoClosing; // 0x28a(0x01)
	char pad_28B[0x5]; // 0x28b(0x05)
};

// Class TheK24.SupplyCrateInteractable
// Size: 0x428 (Inherited: 0x310)
struct ASupplyCrateInteractable : AInteractable {
	char pad_310[0x38]; // 0x310(0x38)
	struct UChargeableComponent* _chargeableComponent; // 0x348(0x08)
	struct ACollectable* _contamainationSerumCollectable; // 0x350(0x08)
	struct FDBDTunableRowHandle _openInteractionSecondsToCharge; // 0x358(0x28)
	struct ACollectable* _itemInSupplyCrate; // 0x380(0x08)
	struct USceneComponent* _itemSpawnPoint; // 0x388(0x08)
	struct USceneComponent* _itemDropPoint; // 0x390(0x08)
	bool _isOpen; // 0x398(0x01)
	bool _isAutoClosing; // 0x399(0x01)
	char pad_39A[0x3e]; // 0x39a(0x3e)
	struct FDBDTunableRowHandle _crateSelfClosingTime; // 0x3d8(0x28)
	struct FDBDTunableRowHandle _crateAutoCloseAnimationTime; // 0x400(0x28)

	void OnRep_IsOpen(); // Function TheK24.SupplyCrateInteractable.OnRep_IsOpen // (Final|Native|Private) // @ game+0x34b68c0
	void OnRep_IsAutoClosing(); // Function TheK24.SupplyCrateInteractable.OnRep_IsAutoClosing // (Final|Native|Private) // @ game+0x34b6880
};

// Class TheK24.SupplyCrateOutlineUpdateStrategy
// Size: 0xe0 (Inherited: 0xe0)
struct USupplyCrateOutlineUpdateStrategy : UDefaultOutlineUpdateStrategy {
};

// Class TheK24.SurvivorContaminationComponent
// Size: 0x1e0 (Inherited: 0xb8)
struct USurvivorContaminationComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct FTagStateBool _isContaminated; // 0xd0(0x30)
	struct UChargeableComponent* _injectSerumChargeable; // 0x100(0x08)
	struct FDBDTunableRowHandle _injectSerumSecondsToCharge; // 0x108(0x28)
	struct FTunableStat _contaminationHinderedSeconds; // 0x130(0x80)
	struct FDBDTunableRowHandle _contaminationHinderedValue; // 0x1b0(0x28)
	char pad_1D8[0x8]; // 0x1d8(0x08)

	void Server_SetContaminatedValue(bool value, enum class EContaminator contaminator); // Function TheK24.SurvivorContaminationComponent.Server_SetContaminatedValue // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x34b6b70
	void OnRep_IsContaminated(); // Function TheK24.SurvivorContaminationComponent.OnRep_IsContaminated // (Final|Native|Private) // @ game+0x34b68a0
	void OnRep_InjectionSerumInteraction(); // Function TheK24.SurvivorContaminationComponent.OnRep_InjectionSerumInteraction // (Final|Native|Private) // @ game+0x34b6860
	void OnPlayerInteractableSet(); // Function TheK24.SurvivorContaminationComponent.OnPlayerInteractableSet // (Final|Native|Private) // @ game+0x34b6840
	void OnContaminationCured_Cosmetic(); // Function TheK24.SurvivorContaminationComponent.OnContaminationCured_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnContaminated_SFX_Stinger_Cosmetic(); // Function TheK24.SurvivorContaminationComponent.OnContaminated_SFX_Stinger_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnContaminated_Cosmetic(enum class EContaminator contaminator); // Function TheK24.SurvivorContaminationComponent.OnContaminated_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Multicast_OnContaminated_Cosmetic(enum class EContaminator contaminator); // Function TheK24.SurvivorContaminationComponent.Multicast_OnContaminated_Cosmetic // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x32a0980
	bool IsContaminated(); // Function TheK24.SurvivorContaminationComponent.IsContaminated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b62c0
};

// Class TheK24.TheK24Utilities
// Size: 0x30 (Inherited: 0x30)
struct UTheK24Utilities : UBlueprintFunctionLibrary {
};

// Class TheK24.ZombieAcquirePatrolAreaBTService
// Size: 0xa0 (Inherited: 0xa0)
struct UZombieAcquirePatrolAreaBTService : UBTService_BlueprintBase {
};

// Class TheK24.ZombieAcquireTargetBTService
// Size: 0xa0 (Inherited: 0xa0)
struct UZombieAcquireTargetBTService : UBTService_BlueprintBase {
};

// Class TheK24.ZombieAIController
// Size: 0x620 (Inherited: 0x340)
struct AZombieAIController : AAIController {
	char pad_340[0x18]; // 0x340(0x18)
	struct UBehaviorTree* _zombieBehaviorTree; // 0x358(0x08)
	struct UAIPerceptionComponent* _aiPerceptionComponent; // 0x360(0x08)
	char pad_368[0x8]; // 0x368(0x08)
	struct TArray<struct ACamperPlayer*> _survivorInVision; // 0x370(0x10)
	struct ACamperPlayer* _chaseTargetSurvivor; // 0x380(0x08)
	struct FVector _goToLocation; // 0x388(0x0c)
	char pad_394[0xc]; // 0x394(0x0c)
	struct TArray<struct ACamperPlayer*> _survivorsInAttackDetector; // 0x3a0(0x10)
	struct FDBDTunableRowHandle _zombieAttackHitTime; // 0x3b0(0x28)
	struct FDBDTunableRowHandle _zombieAttackOpenTime; // 0x3d8(0x28)
	struct FDBDTunableRowHandle _zombieAnimSpawnTime; // 0x400(0x28)
	struct FDBDTunableRowHandle _zombieAnimDyingTime; // 0x428(0x28)
	struct FTunableStat _zombieSightRadius; // 0x450(0x80)
	struct FTunableStat _zombieLoseSightRadius; // 0x4d0(0x80)
	struct FTunableStat _zombieVisionHalfAngle; // 0x550(0x80)
	struct FDBDTunableRowHandle _zombieFallSmashTime; // 0x5d0(0x28)
	struct FDBDTunableRowHandle _zombieAttackCooldownTime; // 0x5f8(0x28)

	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function TheK24.ZombieAIController.OnSlasherSet // (Final|Native|Private) // @ game+0x34b69a0
	void Authority_OnTargetPerceptionUpdated(struct AActor* Actor, struct FAIStimulus Stimulus); // Function TheK24.ZombieAIController.Authority_OnTargetPerceptionUpdated // (Final|Native|Private) // @ game+0x34b5e10
};

// Class TheK24.ZombieAnimInstance
// Size: 0x290 (Inherited: 0x270)
struct UZombieAnimInstance : UAnimInstance {
	float _speed; // 0x270(0x04)
	enum class EZombieState _zombieState; // 0x274(0x01)
	char pad_275[0x3]; // 0x275(0x03)
	struct AZombieCharacter* _zombieCharacter; // 0x278(0x08)
	bool _isFalling; // 0x280(0x01)
	enum class EZombieGender _zombieGender; // 0x281(0x01)
	char pad_282[0xe]; // 0x282(0x0e)
};

// Class TheK24.ZombieAttackSurvivorBTTask
// Size: 0xb0 (Inherited: 0xb0)
struct UZombieAttackSurvivorBTTask : UBTTask_BlueprintBase {
};

// Class TheK24.ZombieAttractedByGeneratorBTService
// Size: 0xd0 (Inherited: 0xa0)
struct UZombieAttractedByGeneratorBTService : UBTService_BlueprintBase {
	float _genRepairingHearingRange; // 0xa0(0x04)
	char pad_A4[0x2c]; // 0xa4(0x2c)

	void OnInRangeChanged(bool InRange, struct AGenerator* Generator); // Function TheK24.ZombieAttractedByGeneratorBTService.OnInRangeChanged // (Final|Native|Private) // @ game+0x34b66e0
};

// Class TheK24.ZombieBlindableComponent
// Size: 0x248 (Inherited: 0x240)
struct UZombieBlindableComponent : UBlindableBaseComponent {
	struct UGameplayTagContainerComponent* _ownerObjectState; // 0x240(0x08)
};

// Class TheK24.ZombieBlindingFXComponent
// Size: 0x150 (Inherited: 0x150)
struct UZombieBlindingFXComponent : UKillerBlindingFXComponent {
};

// Class TheK24.ZombieCharacter
// Size: 0x7f0 (Inherited: 0x4d0)
struct AZombieCharacter : ACharacter {
	char pad_4D0[0x10]; // 0x4d0(0x10)
	struct FTunableStat _zombieWalkSpeed; // 0x4e0(0x80)
	char pad_560[0x8]; // 0x560(0x08)
	struct UAuthoritativePoolableActorComponent* _poolableComponent; // 0x568(0x08)
	struct USphereComponent* _zombieAttackDetector; // 0x570(0x08)
	struct UStaticMeshComponent* _attackDamageZone; // 0x578(0x08)
	enum class EZombieState _zombieState; // 0x580(0x01)
	char pad_581[0x3f]; // 0x581(0x3f)
	struct FTunableStat _zombieRespawnTimeKilledBySlasher; // 0x5c0(0x80)
	struct FTunableStat _zombieRespawnTimeKilledBySurvivor; // 0x640(0x80)
	char pad_6C0[0x10]; // 0x6c0(0x10)
	struct FTransform _respawnPositionBehindGate; // 0x6d0(0x30)
	enum class EZombieGender _zombieGender; // 0x700(0x01)
	char pad_701[0x7]; // 0x701(0x07)
	struct USkeletalMesh* _femaleSkeletalMesh; // 0x708(0x08)
	struct FString _audioSwitchState; // 0x710(0x10)
	struct UZombieBlindableComponent* _blindableComponent; // 0x720(0x08)
	struct UChargeableComponent* _blindingChargeableComponent; // 0x728(0x08)
	struct UFirecrackerEffectHandlerComponent* _firecrackerEffectHandlerComponent; // 0x730(0x08)
	struct UFlashlightableComponent* _flashLightableComponent; // 0x738(0x08)
	char pad_740[0x38]; // 0x740(0x38)
	struct FDBDTunableRowHandle _zombieStunBaseTime; // 0x778(0x28)
	struct UGameplayTagContainerComponent* _objectState; // 0x7a0(0x08)
	char pad_7A8[0x8]; // 0x7a8(0x08)
	struct UCharacterPositionRecorderComponent* _positionRecorder; // 0x7b0(0x08)
	struct UAuthoritativeMovementComponent* _authoritativeMovementComponent; // 0x7b8(0x08)
	struct UOtherCharactersVerticalCollisionsHandler* _otherCharactersVerticalCollisionsHandler; // 0x7c0(0x08)
	struct TArray<struct AActor*> _ignoreActors; // 0x7c8(0x10)
	char pad_7D8[0x4]; // 0x7d8(0x04)
	float _zombieStunnedCapsuleRadius; // 0x7dc(0x04)
	float _minFallHeight; // 0x7e0(0x04)
	char pad_7E4[0x8]; // 0x7e4(0x08)
	float _afterInAirAttackCooldown; // 0x7ec(0x04)

	void ZombieKilledByKiller_Cosmetic(enum class EAttackType attackType); // Function TheK24.ZombieCharacter.ZombieKilledByKiller_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void SetCharacterActive_Cosmetic(bool value); // Function TheK24.ZombieCharacter.SetCharacterActive_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnZombieStateChanged_Cosmetic(enum class EZombieState ZombieState); // Function TheK24.ZombieCharacter.OnZombieStateChanged_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function TheK24.ZombieCharacter.OnSlasherSet // (Final|Native|Private) // @ game+0x34b6a20
	void OnRep_ZombieState(enum class EZombieState previousState); // Function TheK24.ZombieCharacter.OnRep_ZombieState // (Final|Native|Private) // @ game+0x34b6920
	void OnRep_ZombieGender(); // Function TheK24.ZombieCharacter.OnRep_ZombieGender // (Final|Native|Private) // @ game+0x34b6900
	void OnFemaleGenderSet_Cosmetic(); // Function TheK24.ZombieCharacter.OnFemaleGenderSet_Cosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnEndOverlapZombieAttackDetector(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function TheK24.ZombieCharacter.OnEndOverlapZombieAttackDetector // (Final|Native|Private) // @ game+0x34b65a0
	void OnBeginOverlapZombieAttackDetector(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function TheK24.ZombieCharacter.OnBeginOverlapZombieAttackDetector // (Final|Native|Private|HasOutParms) // @ game+0x34b6390
	void Multicast_ZombieKilledByKillerCosmetic(enum class EAttackType attackType); // Function TheK24.ZombieCharacter.Multicast_ZombieKilledByKillerCosmetic // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x34b6310
	enum class EZombieGender GetZombieGender(); // Function TheK24.ZombieCharacter.GetZombieGender // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b61d0
	struct UOtherCharactersVerticalCollisionsHandler* GetOtherCharactersVerticalCollisionsHandler(); // Function TheK24.ZombieCharacter.GetOtherCharactersVerticalCollisionsHandler // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b61b0
	struct UAuthoritativeMovementComponent* GetAuthoritativeMovementComponent(); // Function TheK24.ZombieCharacter.GetAuthoritativeMovementComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b6170
	struct FString GetAudioSwitchState(); // Function TheK24.ZombieCharacter.GetAudioSwitchState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b60f0
	void Authority_OnZombieStateChanged(enum class EZombieState ZombieState); // Function TheK24.ZombieCharacter.Authority_OnZombieStateChanged // (Final|Native|Private) // @ game+0x34b5fa0
	void Authority_OnFlashlightRemoved(struct UFlashlightComponent* Flashlight); // Function TheK24.ZombieCharacter.Authority_OnFlashlightRemoved // (Final|Native|Private) // @ game+0x34b5d90
	void Authority_OnFlashlightAdded(struct UFlashlightComponent* Flashlight); // Function TheK24.ZombieCharacter.Authority_OnFlashlightAdded // (Final|Native|Private) // @ game+0x34b5d10
	void Authority_OnFirecrackerInRangeBegin(struct FFirecrackerEffectData effectData); // Function TheK24.ZombieCharacter.Authority_OnFirecrackerInRangeBegin // (Final|Native|Private|HasOutParms) // @ game+0x34b5c70
	void Authority_DeactivateZombieAndStartRespawnTimer(); // Function TheK24.ZombieCharacter.Authority_DeactivateZombieAndStartRespawnTimer // (Final|Native|Private) // @ game+0x34b5c50
};

// Class TheK24.ZombieChaseStateBTService
// Size: 0xa0 (Inherited: 0xa0)
struct UZombieChaseStateBTService : UBTService_BlueprintBase {
};

// Class TheK24.ZombieChaseSurvivorTargetBTTask
// Size: 0xb0 (Inherited: 0xb0)
struct UZombieChaseSurvivorTargetBTTask : UBTTask_BlueprintBase {
};

// Class TheK24.ZombieCustomizationComponent
// Size: 0x218 (Inherited: 0x210)
struct UZombieCustomizationComponent : UCustomizedSkeletalMesh {
	struct TWeakObjectPtr<struct ACamperPlayer> _survivorSource; // 0x210(0x08)

	void Multicast_SetZombieCustomization(struct ACamperPlayer* survivor); // Function TheK24.ZombieCustomizationComponent.Multicast_SetZombieCustomization // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x3278430
};

// Class TheK24.ZombieEscapeDoorPointsActor
// Size: 0x240 (Inherited: 0x230)
struct AZombieEscapeDoorPointsActor : AActor {
	struct TArray<struct UArrowComponent*> _availablePoints; // 0x230(0x10)
};

// Class TheK24.ZombieEvaluateEnterChaseBTService
// Size: 0xa0 (Inherited: 0xa0)
struct UZombieEvaluateEnterChaseBTService : UBTService_BlueprintBase {
};

// Class TheK24.ZombieEvaluteEnterAttackBTService
// Size: 0xa0 (Inherited: 0xa0)
struct UZombieEvaluteEnterAttackBTService : UBTService_BlueprintBase {
};

// Class TheK24.ZombieFallDetectorComponent
// Size: 0xf0 (Inherited: 0xb8)
struct UZombieFallDetectorComponent : UActorComponent {
	struct FDBDTunableRowHandle _zombieDistanceConsideredSmashFall; // 0xb8(0x28)
	char pad_E0[0x10]; // 0xe0(0x10)

	void Authority_OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function TheK24.ZombieFallDetectorComponent.Authority_OnMovementModeChange // (Final|Native|Private) // @ game+0x34b8230
};

// Class TheK24.ZombieOutlineUpdateStrategy
// Size: 0x138 (Inherited: 0x130)
struct UZombieOutlineUpdateStrategy : USourceBasedOutlineUpdateStrategy {
	struct AZombieCharacter* _zombieCharacter; // 0x130(0x08)
};

// Class TheK24.ZombieResurrector
// Size: 0x120 (Inherited: 0xb8)
struct UZombieResurrector : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct FDBDTunableRowHandle _powerLevelToSpawnZombie; // 0xd0(0x28)
	char pad_F8[0x10]; // 0xf8(0x10)
	struct TArray<struct AZombieCharacter*> _delayedSpawnZombies; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)

	void Authority_OnKillerPowerLevelChanged(int32_t powerlevel); // Function TheK24.ZombieResurrector.Authority_OnKillerPowerLevelChanged // (Final|Native|Private) // @ game+0x34b7fc0
};

// Class TheK24.ZombieRotateTowardsTargetBTTask
// Size: 0xb0 (Inherited: 0xb0)
struct UZombieRotateTowardsTargetBTTask : UBTTask_BlueprintBase {
};

// Class TheK24.ZombiesInterestEventManager
// Size: 0xe8 (Inherited: 0xb8)
struct UZombiesInterestEventManager : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
	struct TArray<struct FGameplayTag> _zombieInterestEvents; // 0xd0(0x10)
	char pad_E0[0x8]; // 0xe0(0x08)

	void Authority_OnLoudNoiseTriggered(struct AActor* originator, struct AActor* instigatingActor, struct FVector Location, bool shouldTrack, float audibleRange, bool isQuickAction); // Function TheK24.ZombiesInterestEventManager.Authority_OnLoudNoiseTriggered // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x34b8040
};

// Class TheK24.ZombiesManagement
// Size: 0x2e8 (Inherited: 0x230)
struct AZombiesManagement : AActor {
	char pad_230[0x8]; // 0x230(0x08)
	struct UAuthoritativeActorPoolComponent* _zombiePool; // 0x238(0x08)
	struct UZombiesPatrolAreaManager* _zombiesPatrolAreaManager; // 0x240(0x08)
	struct TArray<struct AZombieCharacter*> _spawnedZombiesArray; // 0x248(0x10)
	char pad_258[0x30]; // 0x258(0x30)
	struct FDBDTunableRowHandle _firstZombieSpawnTime; // 0x288(0x28)
	struct FDBDTunableRowHandle _numberOfZombieToSpawnAtStart; // 0x2b0(0x28)
	struct TArray<struct AZombieEscapeDoorPointsActor*> _zombieEscapeDoorPoints; // 0x2d8(0x10)

	void Authority_OnIntroComplete(); // Function TheK24.ZombiesManagement.Authority_OnIntroComplete // (Final|Native|Private) // @ game+0x34b7fa0
};

// Class TheK24.ZombiesPatrolAreaManager
// Size: 0xe0 (Inherited: 0xb8)
struct UZombiesPatrolAreaManager : UActorComponent {
	struct TArray<struct AMeatHook*> _availablePatrolAreas; // 0xb8(0x10)
	struct TArray<struct AMeatHook*> _usedPatrolAreas; // 0xc8(0x10)
	float _maxDistanceBetweenMeatHookAndPlayers; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class TheK24.ZombieStunnableComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UZombieStunnableComponent : UStunnableComponent {
};

