// Enum TheK24.EContaminator
enum class EContaminator : uint8 {
	Zombie,
	Killer,
	Mori,
	EContaminator_MAX,
};

// Enum TheK24.EZombieState
enum class EZombieState : uint8 {
	InPool,
	Spawn,
	Patrolling,
	Searching,
	Chase,
	Attack,
	Dying,
	Dead,
	ChaseSearching,
	InPlaceIdle,
	Stunned,
	FallSmash,
	AttackCooldown,
	Stop,
	EZombieState_MAX,
};

// Enum TheK24.EZombieGender
enum class EZombieGender : uint8 {
	Male,
	Female,
	EZombieGender_MAX,
};

