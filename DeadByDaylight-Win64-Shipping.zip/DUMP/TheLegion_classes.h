// Class TheLegion.FrenzyAttack
// Size: 0x370 (Inherited: 0x360)
struct UFrenzyAttack : UPounceAttack {
	char pad_360[0x10]; // 0x360(0x10)
};

// Class TheLegion.FrenzyAttackHittingSubstate
// Size: 0x1a0 (Inherited: 0x1a0)
struct UFrenzyAttackHittingSubstate : UPounceAttackHittingSubstate {
};

// Class TheLegion.FrenzyAttackSuccessSubstate
// Size: 0x2c8 (Inherited: 0x118)
struct UFrenzyAttackSuccessSubstate : UPounceAttackSuccessSubstate {
	struct FStatProperty _healthyTime; // 0x118(0x88)
	struct FStatProperty _injuredTime; // 0x1a0(0x88)
	struct FStatProperty _bleedoutTime; // 0x228(0x88)
	struct UCurveFloat* _healthyCurve; // 0x2b0(0x08)
	struct UCurveFloat* _injuredCurve; // 0x2b8(0x08)
	struct UCurveFloat* _bleedoutCurve; // 0x2c0(0x08)
};

// Class TheLegion.LegionKillerAnalyticsComponent
// Size: 0xf0 (Inherited: 0xb8)
struct ULegionKillerAnalyticsComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)

	void SetGameEventDispatcher(struct UGameEventDispatcher* GameEventDispatcher); // Function TheLegion.LegionKillerAnalyticsComponent.SetGameEventDispatcher // (Final|Native|Public|BlueprintCallable) // @ game+0x34ba840
};

// Class TheLegion.LegionSurvivorAnalyticsComponent
// Size: 0x110 (Inherited: 0xb8)
struct ULegionSurvivorAnalyticsComponent : UActorComponent {
	char pad_B8[0x58]; // 0xb8(0x58)

	void SetGameEventDispatcher(struct UGameEventDispatcher* GameEventDispatcher); // Function TheLegion.LegionSurvivorAnalyticsComponent.SetGameEventDispatcher // (Final|Native|Public|BlueprintCallable) // @ game+0x34bab70
	void OnGameEventDispatched(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheLegion.LegionSurvivorAnalyticsComponent.OnGameEventDispatched // (Final|Native|Private|HasOutParms) // @ game+0x34baa60
};

// Class TheLegion.Madgrit
// Size: 0x3b0 (Inherited: 0x3a8)
struct UMadgrit : UPerk {
	struct UCurveFloat* _slashHittingSpeedCurve; // 0x3a8(0x08)
};

