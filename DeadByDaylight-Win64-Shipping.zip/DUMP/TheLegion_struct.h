// ScriptStruct TheLegion.LegionSurvivorAnalytics
// Size: 0x88 (Inherited: 0x68)
struct FLegionSurvivorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t DeepWoundCount; // 0x78(0x04)
	int32_t FrenzyEffectivements; // 0x7c(0x04)
	int32_t DeepWoundDying; // 0x80(0x04)
	bool DeepWoundEscape; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
};

// ScriptStruct TheLegion.LegionKillerAnalytics
// Size: 0x80 (Inherited: 0x68)
struct FLegionKillerAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t Pallet; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

