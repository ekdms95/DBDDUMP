// Class TheNightmare.BlackBox
// Size: 0x2b8 (Inherited: 0x278)
struct UBlackBox : UItemAddon {
	struct FDBDTunableRowHandle _blockDuration; // 0x278(0x28)
	char pad_2A0[0x18]; // 0x2a0(0x18)
};

// Class TheNightmare.DreamInducerComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UDreamInducerComponent : UActorComponent {
	struct UActorComponent* _generatorDreamworldClass; // 0xb8(0x08)

	void Authority_OnLevelReadyToPlay(); // Function TheNightmare.DreamInducerComponent.Authority_OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34bf940
};

// Class TheNightmare.DreamSnare
// Size: 0x230 (Inherited: 0x230)
struct ADreamSnare : AActor {
};

// Class TheNightmare.GeneratorDreamworldComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UGeneratorDreamworldComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TArray<struct FName> _beamSocketsForBloodEffect; // 0xc0(0x10)

	void OnRepairSkillCheckFailed(bool success, bool Bonus, struct ADBDPlayer* Player, bool TriggerLoudNoise, bool hadInput, enum class ESkillCheckCustomType Type, float ChargeChange); // Function TheNightmare.GeneratorDreamworldComponent.OnRepairSkillCheckFailed // (Final|Native|Private) // @ game+0x34bfc60
	void Cosmetic_OnPlayerFailSkillCheck(struct ADBDPlayer* Player); // Function TheNightmare.GeneratorDreamworldComponent.Cosmetic_OnPlayerFailSkillCheck // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheNightmare.GeneratorTeleportInteraction
// Size: 0x740 (Inherited: 0x680)
struct UGeneratorTeleportInteraction : UChargeableInteractionDefinition {
	float OnBloodSpurtsAINoiseEventRange; // 0x680(0x04)
	char pad_684[0x4]; // 0x684(0x04)
	struct UTimerObject* _teleportCooldownTimer; // 0x688(0x08)
	char pad_690[0x40]; // 0x690(0x40)
	struct AGenerator* _selectedGenerator; // 0x6d0(0x08)
	struct AGenerator* _locallySelectedGenerator; // 0x6d8(0x08)
	struct FTransform _selectedTeleportLocation; // 0x6e0(0x30)
	bool _isInteractionOngoing; // 0x710(0x01)
	bool _teleportFailed; // 0x711(0x01)
	char pad_712[0x2]; // 0x712(0x02)
	float _bloodSpurtInterval; // 0x714(0x04)
	float _collisionCheckCapsuleHalfHeight; // 0x718(0x04)
	float _collisionCheckCapsuleRadius; // 0x71c(0x04)
	struct FVector _collisionCheckLocationOffset; // 0x720(0x0c)
	float _capsuleTraceAngleIncrement; // 0x72c(0x04)
	float _generatorTeleportMaxAngle; // 0x730(0x04)
	float _downRaycastLength; // 0x734(0x04)
	char pad_738[0x8]; // 0x738(0x08)

	bool TeleportPlayerToLocation(struct ADBDPlayer* teleportingPlayer, struct FVector Location, struct FRotator Rotation); // Function TheNightmare.GeneratorTeleportInteraction.TeleportPlayerToLocation // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x34c0fe0
	void StopBloodSpurts(); // Function TheNightmare.GeneratorTeleportInteraction.StopBloodSpurts // (Final|Native|Protected|BlueprintCallable) // @ game+0x34c0fc0
	void StartBloodSpurts(); // Function TheNightmare.GeneratorTeleportInteraction.StartBloodSpurts // (Final|Native|Protected|BlueprintCallable) // @ game+0x34c0fa0
	void ShowBloodSpurtsVFX(); // Function TheNightmare.GeneratorTeleportInteraction.ShowBloodSpurtsVFX // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Server_SetSelectedGenerator(struct AGenerator* Generator); // Function TheNightmare.GeneratorTeleportInteraction.Server_SetSelectedGenerator // (Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable|NetValidate) // @ game+0x34c0ee0
	void OnTeleportReady(); // Function TheNightmare.GeneratorTeleportInteraction.OnTeleportReady // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnTeleportLocationChosen(struct AGenerator* Generator, struct FTransform Location); // Function TheNightmare.GeneratorTeleportInteraction.OnTeleportLocationChosen // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void OnTeleported(struct FTransform transformBeforeTeleport); // Function TheNightmare.GeneratorTeleportInteraction.OnTeleported // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void OnSelectedGeneratorSet(struct AGenerator* selectedGenerator); // Function TheNightmare.GeneratorTeleportInteraction.OnSelectedGeneratorSet // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnRep_TeleportCooldownTimer(); // Function TheNightmare.GeneratorTeleportInteraction.OnRep_TeleportCooldownTimer // (Final|Native|Private) // @ game+0x34c0ec0
	void OnRep_SelectedGenerator(); // Function TheNightmare.GeneratorTeleportInteraction.OnRep_SelectedGenerator // (Final|Native|Private) // @ game+0x34c0ea0
	void OnLocallySelectedGeneratorSet(struct AGenerator* selectedGenerator); // Function TheNightmare.GeneratorTeleportInteraction.OnLocallySelectedGeneratorSet // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnIntroCompleted(); // Function TheNightmare.GeneratorTeleportInteraction.OnIntroCompleted // (Final|Native|Protected) // @ game+0x34c0e80
	void OnBloodSpurts(); // Function TheNightmare.GeneratorTeleportInteraction.OnBloodSpurts // (Final|Native|Protected) // @ game+0x34c0e60
	void Multicast_TeleportPlayer(struct FVector Location, struct FRotator Rotation); // Function TheNightmare.GeneratorTeleportInteraction.Multicast_TeleportPlayer // (Net|NetReliableNative|Event|NetMulticast|Protected|HasDefaults) // @ game+0x34c0d80
	void Multicast_OnTeleportLocationChosen(struct AGenerator* Generator, struct FTransform Location); // Function TheNightmare.GeneratorTeleportInteraction.Multicast_OnTeleportLocationChosen // (Net|NetReliableNative|Event|NetMulticast|Protected|HasDefaults) // @ game+0x34c0c40
	bool IsTeleportAvailable(); // Function TheNightmare.GeneratorTeleportInteraction.IsTeleportAvailable // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c0c10
	void InitializeTunableValues(struct ASlasherPlayer* killer); // Function TheNightmare.GeneratorTeleportInteraction.InitializeTunableValues // (Final|Native|Private) // @ game+0x34c0b90
	struct ADBDPlayer* GetOwningPlayer(); // Function TheNightmare.GeneratorTeleportInteraction.GetOwningPlayer // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c0b60
	struct AGenerator* GetInlineGenerator(struct ADBDPlayer* Player); // Function TheNightmare.GeneratorTeleportInteraction.GetInlineGenerator // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c0ad0
	bool CanTeleportAtGenerator(struct AGenerator* Generator); // Function TheNightmare.GeneratorTeleportInteraction.CanTeleportAtGenerator // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c0a40
	bool Authority_TeleportPlayerToGenerator(struct ADBDPlayer* playerToTeleport, struct AGenerator* Generator); // Function TheNightmare.GeneratorTeleportInteraction.Authority_TeleportPlayerToGenerator // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x34c0980
	void Authority_StartTeleportCooldown(bool teleported); // Function TheNightmare.GeneratorTeleportInteraction.Authority_StartTeleportCooldown // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x34c08f0
};

// Class TheNightmare.InDreamSurvivorSubAnimInstance
// Size: 0x510 (Inherited: 0x4f0)
struct UInDreamSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _shouldLookSleepy; // 0x4f0(0x01)
	char pad_4F1[0x1f]; // 0x4f1(0x1f)
};

// Class TheNightmare.NightmareAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UNightmareAnimInstance : UKillerAnimInstance {
};

// Class TheNightmare.PlaceDreamPalletInteraction
// Size: 0x580 (Inherited: 0x560)
struct UPlaceDreamPalletInteraction : UInteractionDefinition {
	struct TArray<struct APalletTracker*> _palletTrackers; // 0x558(0x10)
	struct APalletTracker* _closestTracker; // 0x570(0x08)
	char pad_578[0x8]; // 0x578(0x08)

	void SpawnDreamPallet(struct APalletTracker* trackerAtLocation); // Function TheNightmare.PlaceDreamPalletInteraction.SpawnDreamPallet // (Event|Public|BlueprintEvent) // @ game+0x3873200
	void InitializeTunableValues(struct ASlasherPlayer* killer); // Function TheNightmare.PlaceDreamPalletInteraction.InitializeTunableValues // (Final|Native|Private) // @ game+0x34c16b0
	struct APalletTracker* GetTargetedPallet(); // Function TheNightmare.PlaceDreamPalletInteraction.GetTargetedPallet // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c1680
	bool CanSpawnDreamPalletAtTracker(struct APalletTracker* tracker); // Function TheNightmare.PlaceDreamPalletInteraction.CanSpawnDreamPalletAtTracker // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c15f0
};

// Class TheNightmare.PresentationGeneratorTeleportProgressComponent
// Size: 0xc8 (Inherited: 0xb8)
struct UPresentationGeneratorTeleportProgressComponent : UPresentationItemProgressComponent {
	char pad_B8[0x10]; // 0xb8(0x10)
};

// Class TheNightmare.SetDreamSnareInteraction
// Size: 0x690 (Inherited: 0x680)
struct USetDreamSnareInteraction : UChargeableInteractionDefinition {
	float MinPitch; // 0x680(0x04)
	float MinPlacementDistance; // 0x684(0x04)
	float MaxPlacementDistance; // 0x688(0x04)
	char pad_68C[0x4]; // 0x68c(0x04)

	bool HasCancelledDreamSnare(); // Function TheNightmare.SetDreamSnareInteraction.HasCancelledDreamSnare // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cd79d0
	float GetTrapDistanceFromControlRotation(); // Function TheNightmare.SetDreamSnareInteraction.GetTrapDistanceFromControlRotation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34c1a40
};

