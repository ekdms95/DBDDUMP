// Class TheNurse.BlinkAttack
// Size: 0x360 (Inherited: 0x360)
struct UBlinkAttack : UPounceAttack {
};

// Class TheNurse.BlinkAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UBlinkAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheNurse.NurseAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UNurseAnimInstance : UKillerAnimInstance {
};

// Class TheNurse.NurseBurnable
// Size: 0x100 (Inherited: 0x100)
struct UNurseBurnable : UPlayerLightBurnable {
};

