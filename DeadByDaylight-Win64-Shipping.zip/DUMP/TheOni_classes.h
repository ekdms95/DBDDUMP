// Class TheOni.AbsorbBloodOrbsInteraction
// Size: 0x590 (Inherited: 0x560)
struct UAbsorbBloodOrbsInteraction : UInteractionDefinition {
	char pad_560[0x30]; // 0x560(0x30)

	void SetPlayerOwner(struct ADBDPlayer* Player); // Function TheOni.AbsorbBloodOrbsInteraction.SetPlayerOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x34d7d70
};

// Class TheOni.BloodOrb
// Size: 0x290 (Inherited: 0x230)
struct ABloodOrb : AActor {
	struct FFloatInterval _randomMoveDelayInterval; // 0x230(0x08)
	struct USceneComponent* _absorbReference; // 0x238(0x08)
	struct UDBDOutlineComponent* _outlineComponent; // 0x240(0x08)
	float _despawnDelay; // 0x248(0x04)
	char pad_24C[0x4]; // 0x24c(0x04)
	struct TWeakObjectPtr<struct ADBDPlayer> _droppingPlayer; // 0x250(0x08)
	enum class EBloodOrbState _state; // 0x258(0x01)
	char pad_259[0x7]; // 0x259(0x07)
	struct UBloodOrbFadeComponent* _fadeComponent; // 0x260(0x08)
	char pad_268[0x28]; // 0x268(0x28)

	void UpdateAttracted_Cosmetic(struct FVector destination, struct ADBDPlayer* absorber, float DeltaTime); // Function TheOni.BloodOrb.UpdateAttracted_Cosmetic // (BlueprintCosmetic|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void UpdateAbsorbed_Cosmetic(struct FVector destination, struct ADBDPlayer* absorber, float DeltaTime); // Function TheOni.BloodOrb.UpdateAbsorbed_Cosmetic // (BlueprintCosmetic|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void OnRep_State(enum class EBloodOrbState oldState); // Function TheOni.BloodOrb.OnRep_State // (Final|Native|Private) // @ game+0x34d86e0
	void OnIsAttractedChangedCosmetic(bool isAttracted); // Function TheOni.BloodOrb.OnIsAttractedChangedCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDestroyedCosmetic(); // Function TheOni.BloodOrb.OnDestroyedCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnAbsorbedCosmetic(); // Function TheOni.BloodOrb.OnAbsorbedCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	struct ADBDPlayer* GetDroppingPlayer(); // Function TheOni.BloodOrb.GetDroppingPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d86b0
	void Authority_OnDropped(struct ADBDPlayer* droppedBy, float ImpulseFactor); // Function TheOni.BloodOrb.Authority_OnDropped // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Authority_OnDropFinished(); // Function TheOni.BloodOrb.Authority_OnDropFinished // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34d8690
	void Authority_DestroyBloodOrb(); // Function TheOni.BloodOrb.Authority_DestroyBloodOrb // (Final|Native|Private) // @ game+0x34d8670
	void Authority_Despawn(); // Function TheOni.BloodOrb.Authority_Despawn // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34d8650
};

// Class TheOni.BloodOrbAbsorberComponent
// Size: 0x110 (Inherited: 0xb8)
struct UBloodOrbAbsorberComponent : UActorComponent {
	struct FMulticastInlineDelegate Authority_OnBloodOrbAbsorbed; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnIsAbsorbingChanged; // 0xc8(0x10)
	struct FVector AbsorbLocationOffset; // 0xd8(0x0c)
	char pad_E4[0x1c]; // 0xe4(0x1c)
	struct TArray<struct UBloodOrbDropperComponent*> _camperBloodOrbDropperComponents; // 0x100(0x10)

	void SetInAbsorbMode(bool inAbsorptionMode); // Function TheOni.BloodOrbAbsorberComponent.SetInAbsorbMode // (Final|Native|Public|BlueprintCallable) // @ game+0x34d8990
	bool IsInAbsorbMode(); // Function TheOni.BloodOrbAbsorberComponent.IsInAbsorbMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d8960
};

// Class TheOni.BloodOrbCollection
// Size: 0x100 (Inherited: 0xb8)
struct UBloodOrbCollection : UActorComponent {
	struct TArray<struct ABloodOrb*> _bloodOrbs; // 0xb8(0x10)
	char pad_C8[0x38]; // 0xc8(0x38)
};

// Class TheOni.BloodOrbConfiguratorComponent
// Size: 0x128 (Inherited: 0xb8)
struct UBloodOrbConfiguratorComponent : UActorComponent {
	struct ABloodOrb* _bloodOrbClass; // 0xb8(0x08)
	struct TArray<struct FGameEventBloodOrbDropParams> _bloodOrbDropGameEvents; // 0xc0(0x10)
	float _fadeDuration; // 0xd0(0x04)
	float _initialFadeOutDelay; // 0xd4(0x04)
	struct FLinearColor _bloodOrbAuraColor; // 0xd8(0x10)
	struct FLinearColor _bloodOrbAttractedAuraColor; // 0xe8(0x10)
	float _bloodOrbVisibilityRangeInterpolationSpeed; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct AMobileBloodOrbRenderer* _mobileBloodOrbRendererClass; // 0x100(0x08)
	char pad_108[0x20]; // 0x108(0x20)

	void UpdateSurvivorBloodOrbVisibilityRange(struct UBloodOrbVisibilityComponent* BloodOrbVisibilityComponent, struct ADBDPlayer* killer); // Function TheOni.BloodOrbConfiguratorComponent.UpdateSurvivorBloodOrbVisibilityRange // (Final|Native|Private|Const) // @ game+0x34d91b0
	void UpdateKillerBloodOrbVisiblityRanges(struct UBloodOrbVisibilityComponent* BloodOrbVisibilityComponent, struct ADBDPlayer* killer); // Function TheOni.BloodOrbConfiguratorComponent.UpdateKillerBloodOrbVisiblityRanges // (Final|Native|Private|Const) // @ game+0x34d90f0
	void UpdateBloodOrbAttractSpeed(struct UBloodOrbAbsorberComponent* BloodOrbAbsorberComponent, struct ADBDPlayer* killer); // Function TheOni.BloodOrbConfiguratorComponent.UpdateBloodOrbAttractSpeed // (Final|Native|Private|Const) // @ game+0x34d9030
	void OnLevelReadyToPlay(); // Function TheOni.BloodOrbConfiguratorComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34d9010
	void Authority_UpdateSurvivorBloodOrbDropperOnCrouchModifier(struct ADBDPlayer* killer); // Function TheOni.BloodOrbConfiguratorComponent.Authority_UpdateSurvivorBloodOrbDropperOnCrouchModifier // (Final|Native|Private|Const) // @ game+0x34d8f90
};

// Class TheOni.BloodOrbDropperComponent
// Size: 0x138 (Inherited: 0xb8)
struct UBloodOrbDropperComponent : UActorComponent {
	char pad_B8[0x80]; // 0xb8(0x80)

	void DBD_DropBloodOrbs(int32_t numOrbs); // Function TheOni.BloodOrbDropperComponent.DBD_DropBloodOrbs // (Final|Exec|Native|Private|Const) // @ game+0x2b49820
	void Authority_SetPaused(bool paused); // Function TheOni.BloodOrbDropperComponent.Authority_SetPaused // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34d9b60
	void Authority_OnOwningCamperDamageStateChanged(enum class ECamperDamageState oldState, enum class ECamperDamageState newState); // Function TheOni.BloodOrbDropperComponent.Authority_OnOwningCamperDamageStateChanged // (Final|Native|Private) // @ game+0x34d9aa0
	void Authority_OnDropOrbsGameEvent(struct FGameplayTag GameEvent, struct FGameEventData GameEventData, struct FBloodOrbDropParams dropParams); // Function TheOni.BloodOrbDropperComponent.Authority_OnDropOrbsGameEvent // (Final|Native|Private|HasOutParms|Const) // @ game+0x34d9930
	void Authority_OnCamperUnhooked(struct FGameplayTag GameEvent, struct FGameEventData GameEventData); // Function TheOni.BloodOrbDropperComponent.Authority_OnCamperUnhooked // (Final|Native|Private|HasOutParms) // @ game+0x34d9820
	void Authority_OnCamperHooked(struct FGameplayTag GameEvent, struct FGameEventData GameEventData); // Function TheOni.BloodOrbDropperComponent.Authority_OnCamperHooked // (Final|Native|Private|HasOutParms|Const) // @ game+0x34d9710
	void Authority_OnCamperCrouched(struct FGameplayTag GameEvent, struct FGameEventData GameEventData); // Function TheOni.BloodOrbDropperComponent.Authority_OnCamperCrouched // (Final|Native|Private|HasOutParms) // @ game+0x34d9600
};

// Class TheOni.BloodOrbFadeComponent
// Size: 0xe0 (Inherited: 0xd8)
struct UBloodOrbFadeComponent : UFadeComponent {
	char pad_D8[0x8]; // 0xd8(0x08)
};

// Class TheOni.BloodOrbOverlapComponent
// Size: 0xf8 (Inherited: 0xb8)
struct UBloodOrbOverlapComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	int32_t _currentOverlappingOrbs; // 0xc0(0x04)
	char pad_C4[0x34]; // 0xc4(0x34)

	void OnRep_CurrentOverlappingOrbs(int32_t previousOverlappingOrbs); // Function TheOni.BloodOrbOverlapComponent.OnRep_CurrentOverlappingOrbs // (Final|Native|Private) // @ game+0x34da4a0
	void Authority_OnDestroyedBloodOrb(struct AActor* DestroyedActor); // Function TheOni.BloodOrbOverlapComponent.Authority_OnDestroyedBloodOrb // (Final|Native|Private) // @ game+0x34da420
	void Authority_OnBloodOrbVisibilityModeChanged(enum class EBloodOrbVisibilityMode visibilityMode); // Function TheOni.BloodOrbOverlapComponent.Authority_OnBloodOrbVisibilityModeChanged // (Final|Native|Private) // @ game+0x34da3a0
	void Authority_OnBloodOrbEndOverlap(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function TheOni.BloodOrbOverlapComponent.Authority_OnBloodOrbEndOverlap // (Final|Native|Private) // @ game+0x34da260
	void Authority_OnBloodOrbBeginOverlap(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function TheOni.BloodOrbOverlapComponent.Authority_OnBloodOrbBeginOverlap // (Final|Native|Private|HasOutParms) // @ game+0x34da050
};

// Class TheOni.BloodOrbOverlapRevealToKiller
// Size: 0x350 (Inherited: 0x320)
struct UBloodOrbOverlapRevealToKiller : UStatusEffect {
	char pad_320[0x28]; // 0x320(0x28)
	struct UTimerObject* _revealTimer; // 0x348(0x08)

	struct UTimerObject* GetRevealTimer(); // Function TheOni.BloodOrbOverlapRevealToKiller.GetRevealTimer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34da7a0
};

// Class TheOni.BloodOrbStateMonitorComponent
// Size: 0x128 (Inherited: 0xb8)
struct UBloodOrbStateMonitorComponent : UActorComponent {
	struct FMulticastInlineDelegate OnBloodOrbAbsorbedCosmetic; // 0xb8(0x10)
	char pad_C8[0x60]; // 0xc8(0x60)

	void OnBloodOrbStateChanged(enum class EBloodOrbState oldState, enum class EBloodOrbState newState, struct ABloodOrb* BloodOrb); // Function TheOni.BloodOrbStateMonitorComponent.OnBloodOrbStateChanged // (Final|Native|Private|Const) // @ game+0x34dac10
	void OnBloodOrbSpawned(struct ABloodOrb* BloodOrb); // Function TheOni.BloodOrbStateMonitorComponent.OnBloodOrbSpawned // (Final|Native|Private) // @ game+0x34dab90
	void OnBloodOrbDestroyed(struct ABloodOrb* BloodOrb); // Function TheOni.BloodOrbStateMonitorComponent.OnBloodOrbDestroyed // (Final|Native|Private) // @ game+0x34dab10
};

// Class TheOni.BloodOrbUtilities
// Size: 0x30 (Inherited: 0x30)
struct UBloodOrbUtilities : UBlueprintFunctionLibrary {

	struct TArray<struct ABloodOrb*> GetAllBloodOrbs(struct UObject* WorldContextObject); // Function TheOni.BloodOrbUtilities.GetAllBloodOrbs // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x34dae80
};

// Class TheOni.BloodOrbVisibilityComponent
// Size: 0xf0 (Inherited: 0xb8)
struct UBloodOrbVisibilityComponent : UActorComponent {
	char pad_B8[0x38]; // 0xb8(0x38)

	void SetVisibilityRange(float visibilityRange); // Function TheOni.BloodOrbVisibilityComponent.SetVisibilityRange // (Final|Native|Public|BlueprintCallable) // @ game+0x2cbf6a0
	void SetVisibilityMode(enum class EBloodOrbVisibilityMode visibilityMode); // Function TheOni.BloodOrbVisibilityComponent.SetVisibilityMode // (Final|Native|Public|BlueprintCallable) // @ game+0x34db300
	void SetShowAttractedBloodOrbsAuras(bool show); // Function TheOni.BloodOrbVisibilityComponent.SetShowAttractedBloodOrbsAuras // (Final|Native|Public|BlueprintCallable) // @ game+0x34db270
	void SetAuraVisibilityRange(float auraVisibilityRange); // Function TheOni.BloodOrbVisibilityComponent.SetAuraVisibilityRange // (Final|Native|Public|BlueprintCallable) // @ game+0x2c98010
	void OnBloodOrbSpawned(struct ABloodOrb* BloodOrb); // Function TheOni.BloodOrbVisibilityComponent.OnBloodOrbSpawned // (Final|Native|Private|Const) // @ game+0x34db1f0
};

// Class TheOni.DemonModeComponent
// Size: 0x1d0 (Inherited: 0xb8)
struct UDemonModeComponent : UActorComponent {
	struct FMulticastInlineDelegate OnDemonModeReady; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnDemonModeStarted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnDemonModeEnded; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnDemonModeInterruptedDuringStartup; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnDemonModeInterruptedDuringEnding; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnChargeGainedAfterAttackCosmetic; // 0x108(0x10)
	struct FMulticastInlineDelegate OnChargeGainedAfterLockerGrabCosmetic; // 0x118(0x10)
	struct UPowerChargeComponent* _powerChargeComponent; // 0x128(0x08)
	struct UPowerToggleComponent* _powerToggleComponent; // 0x130(0x08)
	struct UInteractionStarterComponent* _authority_demonModeCooldownStarterComponent; // 0x138(0x08)
	struct UInteractionDefinition* _demonModeCooldownInteraction; // 0x140(0x08)
	char pad_148[0x34]; // 0x148(0x34)
	enum class EDemonModeState _demonModeState; // 0x17c(0x01)
	char pad_17D[0x53]; // 0x17d(0x53)

	bool ShouldLoseDemonModeOnStun(); // Function TheOni.DemonModeComponent.ShouldLoseDemonModeOnStun // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbf60
	void OnPowerChargeFull(); // Function TheOni.DemonModeComponent.OnPowerChargeFull // (Final|Native|Private|Const) // @ game+0x34dbf40
	void OnPowerChargeEmpty(); // Function TheOni.DemonModeComponent.OnPowerChargeEmpty // (Final|Native|Private|Const) // @ game+0x34dbf20
	void OnIsPowerChanged(bool IsInPower); // Function TheOni.DemonModeComponent.OnIsPowerChanged // (Final|Native|Private|Const) // @ game+0x34dbe90
	void Multicast_DemonModeInterruptedOnStartup(); // Function TheOni.DemonModeComponent.Multicast_DemonModeInterruptedOnStartup // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x3288980
	void Multicast_DemonModeInterruptedOnEnding(); // Function TheOni.DemonModeComponent.Multicast_DemonModeInterruptedOnEnding // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc4840
	bool IsInDemonMode(); // Function TheOni.DemonModeComponent.IsInDemonMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbe60
	enum class EDemonModeState GetDemonModeState(); // Function TheOni.DemonModeComponent.GetDemonModeState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbe30
	float GetCurrentCharge(); // Function TheOni.DemonModeComponent.GetCurrentCharge // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbe00
	float GetChargePercent(); // Function TheOni.DemonModeComponent.GetChargePercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbdd0
	void DBD_DemonModeForever(bool forever); // Function TheOni.DemonModeComponent.DBD_DemonModeForever // (Final|Exec|Native|Public) // @ game+0x26e6bd0
	bool CanStartDemonMode(); // Function TheOni.DemonModeComponent.CanStartDemonMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34dbda0
	void Authority_SetDemonModeCooldownInteraction(struct UInteractionDefinition* Interaction); // Function TheOni.DemonModeComponent.Authority_SetDemonModeCooldownInteraction // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34dbd20
	void Authority_OnLevelReadyToPlay(); // Function TheOni.DemonModeComponent.Authority_OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34dbd00
	void Authority_OnChargeChanged(float currentChargePercent); // Function TheOni.DemonModeComponent.Authority_OnChargeChanged // (Final|Native|Private) // @ game+0x34dbc80
	void Authority_InterruptedMontage(struct FAnimationMontageDescriptor Montage, bool interrupted); // Function TheOni.DemonModeComponent.Authority_InterruptedMontage // (Final|Native|Private) // @ game+0x34dbb40
	void Authority_AddCharge(float ChargeAmount); // Function TheOni.DemonModeComponent.Authority_AddCharge // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34dbac0
};

// Class TheOni.DemonModeCooldownInteraction
// Size: 0x580 (Inherited: 0x560)
struct UDemonModeCooldownInteraction : UInteractionDefinition {
	char pad_560[0x20]; // 0x560(0x20)

	void SetPlayerOwner(struct ADBDPlayer* Owner); // Function TheOni.DemonModeCooldownInteraction.SetPlayerOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x34dc150
	void OnLevelReadyToPlay(); // Function TheOni.DemonModeCooldownInteraction.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34dc130
};

// Class TheOni.DemonModeMenuComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UDemonModeMenuComponent : UActorComponent {
	char pad_B8[0x20]; // 0xb8(0x20)

	void SetInMenuDemonMode(bool inMenuDemonMode); // Function TheOni.DemonModeMenuComponent.SetInMenuDemonMode // (Final|Native|Public|BlueprintCallable) // @ game+0x34dc390
};

// Class TheOni.IsPlayerAbsorbingBloodOrbsCondition
// Size: 0x128 (Inherited: 0x128)
struct UIsPlayerAbsorbingBloodOrbsCondition : UIsPlayerPerformingInteraction {
};

// Class TheOni.MobileBloodOrbRenderer
// Size: 0x2c0 (Inherited: 0x230)
struct AMobileBloodOrbRenderer : AActor {
	struct UMaterialInstance* OrbMaterialInstance; // 0x230(0x08)
	struct UMaterialInstance* OutlineMaterialInstance; // 0x238(0x08)
	float CullInterval; // 0x240(0x04)
	char pad_244[0x4]; // 0x244(0x04)
	struct UInstancedStaticMeshComponent* _ismComponent; // 0x248(0x08)
	struct UInstancedStaticMeshComponent* _outlineIsmComponent; // 0x250(0x08)
	struct TMap<struct ABloodOrb*, struct FBloodOrbInfo> _instanceMap; // 0x258(0x50)
	struct UMaterialInstanceDynamic* _outlineMaterialInstanceDynamic; // 0x2a8(0x08)
	struct UMaterialInstanceDynamic* _orbMaterialInstanceDynamic; // 0x2b0(0x08)
	struct UBloodOrbVisibilityComponent* _bloodOrbVisibilityComponent; // 0x2b8(0x08)
};

// Class TheOni.OniAttackPicker
// Size: 0xc8 (Inherited: 0xb8)
struct UOniAttackPicker : USlasherAttackPickerComponent {
	char pad_B8[0x10]; // 0xb8(0x10)
};

// Class TheOni.OniBasicAttack
// Size: 0x370 (Inherited: 0x360)
struct UOniBasicAttack : UPounceAttack {
	char pad_360[0x10]; // 0x360(0x10)
};

// Class TheOni.OniBasicAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UOniBasicAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class TheOni.OniCustomizationItemAnimInstance
// Size: 0x290 (Inherited: 0x270)
struct UOniCustomizationItemAnimInstance : UAnimInstance {
	bool _isInDemonMode; // 0x270(0x01)
	char pad_271[0x1f]; // 0x271(0x1f)

	void SetIsInDemonMode(bool IsInDemonMode); // Function TheOni.OniCustomizationItemAnimInstance.SetIsInDemonMode // (Final|Native|Private) // @ game+0x34dcbd0
};

// Class TheOni.OniDashInteraction
// Size: 0x6d0 (Inherited: 0x680)
struct UOniDashInteraction : UChargeableInteractionDefinition {
	struct UCurveFloat* _chargingSpeedCurve; // 0x680(0x08)
	struct UCurveFloat* _dashingSpeedCurve; // 0x688(0x08)
	float _yawAdjustTime; // 0x690(0x04)
	char pad_694[0x4]; // 0x694(0x04)
	struct UCurveFloat* _cooldownSpeedCurve; // 0x698(0x08)
	char pad_6A0[0x30]; // 0x6a0(0x30)

	void SetPlayerOwner(struct ADBDPlayer* Player); // Function TheOni.OniDashInteraction.SetPlayerOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x34dd060
	void OnLevelReadyToPlay(); // Function TheOni.OniDashInteraction.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34dd040
	void OnDashEnd(struct ADBDPlayer* Player); // Function TheOni.OniDashInteraction.OnDashEnd // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDashBegin(struct ADBDPlayer* Player); // Function TheOni.OniDashInteraction.OnDashBegin // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnChargeEnd(struct ADBDPlayer* Player, bool chargeCompleted); // Function TheOni.OniDashInteraction.OnChargeEnd // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnChargeBegin(struct ADBDPlayer* Player); // Function TheOni.OniDashInteraction.OnChargeBegin // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheOni.OniDemonBasicAttack
// Size: 0x360 (Inherited: 0x360)
struct UOniDemonBasicAttack : UPounceAttack {
};

// Class TheOni.OniDemonPowerAttack
// Size: 0x380 (Inherited: 0x360)
struct UOniDemonPowerAttack : UPounceAttack {
	char pad_360[0x20]; // 0x360(0x20)
};

// Class TheOni.OniDemonDashAttack
// Size: 0x380 (Inherited: 0x380)
struct UOniDemonDashAttack : UOniDemonPowerAttack {
};

// Class TheOni.OniDemonPowerAttackOpenSubstate
// Size: 0x140 (Inherited: 0x130)
struct UOniDemonPowerAttackOpenSubstate : UPounceAttackOpenSubstate {
	char pad_130[0x10]; // 0x130(0x10)
};

// Class TheOni.OniDemonDashAttackOpenSubstate
// Size: 0x140 (Inherited: 0x140)
struct UOniDemonDashAttackOpenSubstate : UOniDemonPowerAttackOpenSubstate {
};

// Class TheOni.OniDemonPowerAttackHittingSubstate
// Size: 0x1a0 (Inherited: 0x1a0)
struct UOniDemonPowerAttackHittingSubstate : UPounceAttackHittingSubstate {
};

// Class TheOni.OniDemonPowerAttackSuccessSubstate
// Size: 0x148 (Inherited: 0x118)
struct UOniDemonPowerAttackSuccessSubstate : UPounceAttackSuccessSubstate {
	char pad_118[0x30]; // 0x118(0x30)
};

// Class TheOni.OniDemonPowerAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UOniDemonPowerAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheOni.OniDemonPowerAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UOniDemonPowerAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheOni.OniPounceInteraction
// Size: 0x6b0 (Inherited: 0x680)
struct UOniPounceInteraction : UChargeableInteractionDefinition {
	char pad_680[0x10]; // 0x680(0x10)
	struct UOniDemonModeAttackStateComponent* _chargedAttackState; // 0x690(0x08)
	struct UDemonModeComponent* _demonModeComponent; // 0x698(0x08)
	struct ASlasherPlayer* _owningSlasher; // 0x6a0(0x08)
	char pad_6A8[0x8]; // 0x6a8(0x08)
};

// Class TheOni.RenjirosBloodyGlove
// Size: 0x328 (Inherited: 0x278)
struct URenjirosBloodyGlove : UItemAddon {
	char pad_278[0x8]; // 0x278(0x08)
	float _revealTime; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
	struct TMap<struct ACamperPlayer*, struct UBloodOrbOverlapRevealToKiller*> _revealEffectPerCamper; // 0x288(0x50)
	char pad_2D8[0x50]; // 0x2d8(0x50)

	void Authority_OnBloodOrbOverlapBegin(struct AActor* overlappingActor, struct ABloodOrb* BloodOrb); // Function TheOni.RenjirosBloodyGlove.Authority_OnBloodOrbOverlapBegin // (Final|Native|Private) // @ game+0x34de120
};

// Class TheOni.StartDemonModeInteraction
// Size: 0x6d0 (Inherited: 0x680)
struct UStartDemonModeInteraction : UChargeableInteractionDefinition {
	float YawAdjustTime; // 0x680(0x04)
	char pad_684[0x4]; // 0x684(0x04)
	struct FAnimationMontageDescriptor DemonModeActivationMontage; // 0x688(0x20)
	char pad_6A8[0x28]; // 0x6a8(0x28)

	void SetPlayerOwner(struct ADBDPlayer* Owner); // Function TheOni.StartDemonModeInteraction.SetPlayerOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x34de3a0
	void OnLevelReadyToPlay(); // Function TheOni.StartDemonModeInteraction.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x34de380
};

