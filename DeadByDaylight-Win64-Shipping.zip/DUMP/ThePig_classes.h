// Class ThePig.PigAmbushAttack
// Size: 0x370 (Inherited: 0x360)
struct UPigAmbushAttack : UPounceAttack {
	char pad_360[0x10]; // 0x360(0x10)
};

// Class ThePig.PigAmbushAttackOpenSubstate
// Size: 0x138 (Inherited: 0x130)
struct UPigAmbushAttackOpenSubstate : UPounceAttackOpenSubstate {
	char pad_130[0x8]; // 0x130(0x08)
};

// Class ThePig.PigAmbushAttackHittingSubstate
// Size: 0x1a0 (Inherited: 0x1a0)
struct UPigAmbushAttackHittingSubstate : UPounceAttackHittingSubstate {
};

// Class ThePig.PigAmbushAttackSuccessSubstate
// Size: 0x118 (Inherited: 0x118)
struct UPigAmbushAttackSuccessSubstate : UPounceAttackSuccessSubstate {
};

// Class ThePig.PigAmbushAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UPigAmbushAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class ThePig.PigAmbushAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UPigAmbushAttackObstructSubstate : UPounceAttackObstructSubstate {
};

