// Class ThePlague.PlagueSurvivorAnalyticsComponent
// Size: 0x160 (Inherited: 0xb8)
struct UPlagueSurvivorAnalyticsComponent : UActorComponent {
	uint32_t _replicatedRegularVomitHits; // 0xb8(0x04)
	char pad_BC[0xa4]; // 0xbc(0xa4)
};

// Class ThePlague.SicknessSurvivorSubAnimInstance
// Size: 0x560 (Inherited: 0x4f0)
struct USicknessSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	struct FString _vomitingEnteredStatEvent; // 0x4f0(0x10)
	float _hitByVomitTime; // 0x500(0x04)
	bool _isSick; // 0x504(0x01)
	bool _isVomiting; // 0x505(0x01)
	bool _hasRecentlyBeenHitByVomit; // 0x506(0x01)
	bool _isOpeningExitGate; // 0x507(0x01)
	char pad_508[0x58]; // 0x508(0x58)
};

