// ScriptStruct ThePlague.PlagueSurvivorAnalytics
// Size: 0x98 (Inherited: 0x68)
struct FPlagueSurvivorAnalytics : FUniquelyIdentifiedAnalytic {
	struct FString MatchID; // 0x68(0x10)
	int32_t BecomeInfectCount; // 0x78(0x04)
	int32_t RegularVomitHits; // 0x7c(0x04)
	int32_t SuperVomitHits; // 0x80(0x04)
	int32_t CleanSicknessCount; // 0x84(0x04)
	float TimeWithSickness; // 0x88(0x04)
	float TimeWithMaximumSickness; // 0x8c(0x04)
	float TimeInSuperMode; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

