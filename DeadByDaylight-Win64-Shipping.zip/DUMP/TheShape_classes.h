// Class TheShape.KillStandingInteractionDefinition
// Size: 0x560 (Inherited: 0x560)
struct UKillStandingInteractionDefinition : UInteractionDefinition {
};

// Class TheShape.ShapeAnimInstance
// Size: 0x5c0 (Inherited: 0x5b0)
struct UShapeAnimInstance : UKillerAnimInstance {
	bool _isTier3Active; // 0x5a8(0x01)
	struct UEvilWithinComponent* _evilWithinComponent; // 0x5b0(0x08)
	char pad_5B9[0x7]; // 0x5b9(0x07)
};

// Class TheShape.ShapePounceAttackOpenSubstate
// Size: 0x140 (Inherited: 0x130)
struct UShapePounceAttackOpenSubstate : UPounceAttackOpenSubstate {
	struct TArray<struct FDBDTunableRowHandle> _tierDurations; // 0x130(0x10)
};

