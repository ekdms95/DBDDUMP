// Class TheSpirit.SpiritHuskOutlineUpdateStrategy
// Size: 0xe8 (Inherited: 0xc0)
struct USpiritHuskOutlineUpdateStrategy : UOutlineUpdateStrategy {
	char pad_C0[0x28]; // 0xc0(0x28)

	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function TheSpirit.SpiritHuskOutlineUpdateStrategy.OnSlasherSet // (Final|Native|Private) // @ game+0x34e39d0
};

