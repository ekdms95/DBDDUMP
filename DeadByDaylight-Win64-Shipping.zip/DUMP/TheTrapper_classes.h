// Class TheTrapper.BearTrap
// Size: 0x540 (Inherited: 0x4a0)
struct ABearTrap : ABaseTrap {
	struct UBoxPlayerOverlapComponent* _interactionVolume; // 0x4a0(0x08)
	struct USpherePlayerOverlapComponent* _pickTrapZone; // 0x4a8(0x08)
	struct FMulticastInlineDelegate _onIsTrapSetChanged; // 0x4b0(0x10)
	struct ADBDPlayer* _ownerPlayer; // 0x4c0(0x08)
	struct UInteractor* _collectInteractor; // 0x4c8(0x08)
	struct UDBDNavModifierComponent* _dangerNavModifierComponent; // 0x4d0(0x08)
	bool _isTrapperOutOfSafetyZone; // 0x4d8(0x01)
	char pad_4D9[0x3]; // 0x4d9(0x03)
	int32_t _maximumAttemptsForSelfUntrap; // 0x4dc(0x04)
	int32_t _selfUntrapAttemptsRemaining; // 0x4e0(0x04)
	char pad_4E4[0x4]; // 0x4e4(0x04)
	struct UPrimitiveComponent* _safetyZone; // 0x4e8(0x08)
	struct UPrimitiveComponent* _trapZone; // 0x4f0(0x08)
	struct UInteractionDefinition* _trapSurvivor; // 0x4f8(0x08)
	struct UInteractionDefinition* _trapKiller; // 0x500(0x08)
	struct ADBDPlayer* _trappedPlayer; // 0x508(0x08)
	struct UAnimationMontageSlave* _animationMontageSlave; // 0x510(0x08)
	struct UInteractor* _mainInteractor; // 0x518(0x08)
	char pad_520[0x20]; // 0x520(0x20)

	void TrySetTrappedPlayer(struct ADBDPlayer* Player); // Function TheTrapper.BearTrap.TrySetTrappedPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7a90
	void SetTrappedPlayerSinceMoved(bool didTrap); // Function TheTrapper.BearTrap.SetTrappedPlayerSinceMoved // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7a00
	void SetTrappedPlayer(struct ADBDPlayer* trappedPlayer); // Function TheTrapper.BearTrap.SetTrappedPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x34e7980
	void PlayMontage(struct UAnimMontage* Montage); // Function TheTrapper.BearTrap.PlayMontage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	void OnTrappedSurvivorEndGameSacrificed(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheTrapper.BearTrap.OnTrappedSurvivorEndGameSacrificed // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x3873200
	void OnSlasherSet(struct ASlasherPlayer* Slasher); // Function TheTrapper.BearTrap.OnSlasherSet // (Final|Native|Protected) // @ game+0x34e7900
	void OnSafetyZoneEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function TheTrapper.BearTrap.OnSafetyZoneEndOverlap // (Final|Native|Private) // @ game+0x34e77c0
	void OnPlayerLeft(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheTrapper.BearTrap.OnPlayerLeft // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x3873200
	void OnDamageStateChanged(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheTrapper.BearTrap.OnDamageStateChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x3873200
	bool IsTrapperOutOfSafetyZone(); // Function TheTrapper.BearTrap.IsTrapperOutOfSafetyZone // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e7790
	void InitializeTrapZone(struct UPrimitiveComponent* Primitive); // Function TheTrapper.BearTrap.InitializeTrapZone // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7710
	void InitializeTrapSurvivorInteraction(struct UInteractionDefinition* Interaction); // Function TheTrapper.BearTrap.InitializeTrapSurvivorInteraction // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7690
	void InitializeTrapKillerInteraction(struct UInteractionDefinition* Interaction); // Function TheTrapper.BearTrap.InitializeTrapKillerInteraction // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7610
	void InitializeSafetyZone(struct UPrimitiveComponent* Primitive); // Function TheTrapper.BearTrap.InitializeSafetyZone // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7590
	void InitializeMainInteractor(struct UInteractor* Interactor); // Function TheTrapper.BearTrap.InitializeMainInteractor // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7510
	bool HasTrappedPlayerSinceMoved(); // Function TheTrapper.BearTrap.HasTrappedPlayerSinceMoved // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e74e0
	bool HasTrappedPlayer(); // Function TheTrapper.BearTrap.HasTrappedPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e74b0
	struct ADBDPlayer* GetTrappedPlayer(); // Function TheTrapper.BearTrap.GetTrappedPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e7480
	struct UBearTrapAnimInstance* GetAnimInstance(); // Function TheTrapper.BearTrap.GetAnimInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e7450
	void DetachTrappedPlayer(); // Function TheTrapper.BearTrap.DetachTrappedPlayer // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3873200
	bool CanTrap(); // Function TheTrapper.BearTrap.CanTrap // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3873200
};

// Class TheTrapper.BearTrapAnimInstance
// Size: 0x290 (Inherited: 0x280)
struct UBearTrapAnimInstance : USleepingAnimInstance {
	bool _isBroken; // 0x280(0x01)
	bool _isBeingCollected; // 0x281(0x01)
	bool _containsSurvivor; // 0x282(0x01)
	bool _isTrapSet; // 0x283(0x01)
	bool _wasJustDisarmed; // 0x284(0x01)
	char pad_285[0xb]; // 0x285(0x0b)

	void SetWasJustDisarmed(bool wasJustDisarmed); // Function TheTrapper.BearTrapAnimInstance.SetWasJustDisarmed // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7f40
	void SetIsTrapSet(bool IsTrapSet); // Function TheTrapper.BearTrapAnimInstance.SetIsTrapSet // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7eb0
	void SetIsBroken(bool IsBroken); // Function TheTrapper.BearTrapAnimInstance.SetIsBroken // (Final|Native|Public|BlueprintCallable) // @ game+0x32fe120
	void SetIsBeingCollected(bool isBeingCollected); // Function TheTrapper.BearTrapAnimInstance.SetIsBeingCollected // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7e20
	void SetContainsSurvivor(bool containsSurvivor); // Function TheTrapper.BearTrapAnimInstance.SetContainsSurvivor // (Final|Native|Public|BlueprintCallable) // @ game+0x34e7d90
};

// Class TheTrapper.IridescentStone
// Size: 0x278 (Inherited: 0x278)
struct UIridescentStone : UItemAddon {
};

// Class TheTrapper.RemoveOnOriginatingSurvivorGoneStatusEffect
// Size: 0x328 (Inherited: 0x320)
struct URemoveOnOriginatingSurvivorGoneStatusEffect : UStatusEffect {
	char pad_320[0x8]; // 0x320(0x08)

	void Authority_OnSurvivorRemoved(struct ACamperPlayer* survivor); // Function TheTrapper.RemoveOnOriginatingSurvivorGoneStatusEffect.Authority_OnSurvivorRemoved // (Final|Native|Protected) // @ game+0x34e82c0
};

// Class TheTrapper.SelfUntrap
// Size: 0x740 (Inherited: 0x680)
struct USelfUntrap : UChargeableInteractionDefinition {
	struct FDBDTunableRowHandle _trapImmunityDuration; // 0x680(0x28)
	struct UAnimMontage* _untrapMontage; // 0x6a8(0x08)
	struct FAnimationMontageDescriptor _successfulEscapeHealthy; // 0x6b0(0x20)
	struct FAnimationMontageDescriptor _successfulEscapeInjured; // 0x6d0(0x20)
	struct FAnimationMontageDescriptor _successfulEscapeCrawling; // 0x6f0(0x20)
	struct FAnimationMontageDescriptor _failedEscape; // 0x710(0x20)
	char pad_730[0x1]; // 0x730(0x01)
	bool _canEscape; // 0x731(0x01)
	char pad_732[0xe]; // 0x732(0x0e)
};

// Class TheTrapper.TrapperAnimInstance
// Size: 0x5b0 (Inherited: 0x5b0)
struct UTrapperAnimInstance : UKillerAnimInstance {
};

// Class TheTrapper.Untrap
// Size: 0x680 (Inherited: 0x680)
struct UUntrap : UChargeableInteractionDefinition {

	struct ABearTrap* GetTrap(); // Function TheTrapper.Untrap.GetTrap // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x34e87b0
};

