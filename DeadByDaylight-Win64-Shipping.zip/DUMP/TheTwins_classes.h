// Class TheTwins.Addon_K22Power_11
// Size: 0x288 (Inherited: 0x288)
struct UAddon_K22Power_11 : UOnEventBaseAddon {
};

// Class TheTwins.Addon_K22Power_12
// Size: 0x288 (Inherited: 0x280)
struct UAddon_K22Power_12 : USpawnEffectsOnAllSurvivorsBaseAddon {
	float _increaseRemoveTwinTime; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class TheTwins.Addon_K22Power_15
// Size: 0x290 (Inherited: 0x288)
struct UAddon_K22Power_15 : UOnEventBaseAddon {
	float _brokenDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheTwins.Addon_K22Power_17
// Size: 0x288 (Inherited: 0x288)
struct UAddon_K22Power_17 : UOnEventBaseAddon {
};

// Class TheTwins.Addon_K22Power_18
// Size: 0x2b0 (Inherited: 0x280)
struct UAddon_K22Power_18 : USpawnEffectsOnAllSurvivorsBaseAddon {
	char pad_280[0x8]; // 0x280(0x08)
	struct FDBDTunableRowHandle _lingerDuration; // 0x288(0x28)

	void Authority_OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.Addon_K22Power_18.Authority_OnTwinSet // (Final|Native|Private) // @ game+0x3516640
};

// Class TheTwins.Addon_K22Power_19
// Size: 0x290 (Inherited: 0x288)
struct UAddon_K22Power_19 : UOnEventBaseAddon {
	float _auraRevealedDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheTwins.Addon_K22Power_20
// Size: 0x290 (Inherited: 0x288)
struct UAddon_K22Power_20 : UOnEventBaseAddon {
	float _undetectableDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheTwins.Addon_K22Power_21
// Size: 0x290 (Inherited: 0x288)
struct UAddon_K22Power_21 : UOnEventBaseAddon {
	float _exposedDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheTwins.Addon_K22Power_9
// Size: 0x288 (Inherited: 0x280)
struct UAddon_K22Power_9 : USpawnEffectsOnAllSurvivorsBaseAddon {
	float _increaseDestroyTwinTime; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class TheTwins.Addon_K22Power_10
// Size: 0x290 (Inherited: 0x288)
struct UAddon_K22Power_10 : UOnEventBaseAddon {
	float _blindnessDuration; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
};

// Class TheTwins.Appraisal
// Size: 0x3b8 (Inherited: 0x3a8)
struct UAppraisal : UPerk {
	float _chestSearchSpeedMultiplier[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class TheTwins.PossessPlayer
// Size: 0x6b0 (Inherited: 0x680)
struct UPossessPlayer : UChargeableInteractionDefinition {
	struct FDBDTunableRowHandle _possessThePlayerMaxCharge; // 0x680(0x28)
	char pad_6A8[0x8]; // 0x6a8(0x08)

	void Cosmetic_OnPossessStart(struct ADBDPlayer* Player); // Function TheTwins.PossessPlayer.Cosmetic_OnPossessStart // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnPossessCancelled(struct ADBDPlayer* Player); // Function TheTwins.PossessPlayer.Cosmetic_OnPossessCancelled // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheTwins.PossessTheConjoinedTwin
// Size: 0x710 (Inherited: 0x6b0)
struct UPossessTheConjoinedTwin : UPossessPlayer {
	char pad_6B0[0x60]; // 0x6b0(0x60)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.PossessTheConjoinedTwin.OnTwinSet // (Final|Native|Private) // @ game+0x351c440
	void OnPowerCollected(struct ADBDPlayer* collector); // Function TheTwins.PossessTheConjoinedTwin.OnPowerCollected // (Final|Native|Private) // @ game+0x351c0f0
};

// Class TheTwins.AutoPossessTheConjoinedTwin
// Size: 0x710 (Inherited: 0x710)
struct UAutoPossessTheConjoinedTwin : UPossessTheConjoinedTwin {
};

// Class TheTwins.BaseTwinInspectLocker
// Size: 0x590 (Inherited: 0x560)
struct UBaseTwinInspectLocker : UBaseLockerInteraction {
	struct FDBDTunableRowHandle _inspectInteractionTime; // 0x560(0x28)
	char pad_588[0x8]; // 0x588(0x08)
};

// Class TheTwins.BeingPossessedInteraction
// Size: 0x5e0 (Inherited: 0x560)
struct UBeingPossessedInteraction : UInteractionDefinition {
	struct FTunableStat _beingPossessedMaxCharge; // 0x558(0x80)

	void OnLevelReadyToPlay(); // Function TheTwins.BeingPossessedInteraction.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x3516940
};

// Class TheTwins.BrotherBlindFlashlightableLightingStrategy
// Size: 0x50 (Inherited: 0x40)
struct UBrotherBlindFlashlightableLightingStrategy : UBlindFlashlightableLightingStrategy {
	char pad_40[0x10]; // 0x40(0x10)
};

// Class TheTwins.ChargeTwinJumpInteraction
// Size: 0x7d0 (Inherited: 0x680)
struct UChargeTwinJumpInteraction : UChargeableInteractionDefinition {
	char pad_680[0x48]; // 0x680(0x48)
	struct FDBDTunableRowHandle _chargeJumpMaxCharge; // 0x6c8(0x28)
	struct FDBDTunableRowHandle _interactionViewPitchMax; // 0x6f0(0x28)
	struct FDBDTunableRowHandle _interactionViewPitchMin; // 0x718(0x28)
	char pad_740[0x28]; // 0x740(0x28)
	struct FDBDTunableRowHandle _cancelCooldownTime; // 0x768(0x28)
	char pad_790[0x40]; // 0x790(0x40)

	void Cosmetic_OnJumpReadyChanged(struct ADBDPlayer* twin, bool Ready); // Function TheTwins.ChargeTwinJumpInteraction.Cosmetic_OnJumpReadyChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheTwins.ConjoinedTwin
// Size: 0x11b0 (Inherited: 0x1040)
struct AConjoinedTwin : ADBDPlayer {
	struct URangeToActorsTrackerComponent* _restrictedPossessionAreaTracker; // 0x1038(0x08)
	struct UTwinOutlineUpdateStrategy* _twinOutlineUpdateStrategy; // 0x1040(0x08)
	struct UAkComponent* _twinLullabyAudioComponent; // 0x1048(0x08)
	struct UKillerBlindingFXComponent* _twinBlindingFX; // 0x1050(0x08)
	struct UCustomizedAudioComponent* _customizedAudio; // 0x1058(0x08)
	struct UDBDAttackerComponent* _attackerComponent; // 0x1060(0x08)
	struct FDBDTunableRowHandle _maxWalkSpeed; // 0x1068(0x28)
	struct UHitValidatorComponent* _hitValidator; // 0x1090(0x08)
	struct UHitValidatorConfigurator* _hitValidationConfigurator; // 0x1098(0x08)
	struct FDBDTunableRowHandle _gravityScale; // 0x10a0(0x28)
	struct UAnimationMontageSlave* _animationFollower; // 0x10c8(0x08)
	char pad_10D8[0x10]; // 0x10d8(0x10)
	struct FDBDTunableRowHandle _revealDurationOnAttached; // 0x10e8(0x28)
	struct UTwinFirstPersonViewComponent* _firstPersonViewComponent; // 0x1110(0x08)
	struct UFlashlightableComponent* _eyesFlashlightable; // 0x1118(0x08)
	struct UBlindFlashlightTargetFXComponent* _blindFlashlightTargetFXComponent; // 0x1120(0x08)
	struct UFirecrackerEffectHandlerComponent* _firecrackerEffectHandlerComponent; // 0x1128(0x08)
	char pad_1130[0x8]; // 0x1130(0x08)
	struct FFastTimer _flashlightBlindEvasionScoreTimer; // 0x1138(0x30)
	struct FDBDTunableRowHandle _flashlightEvasionScoreCooldown; // 0x1168(0x28)
	struct UTwinPossessNegationEffectComponent* _twinPossessNegationEffectComponent; // 0x1190(0x08)
	char pad_1198[0x18]; // 0x1198(0x18)

	void Server_SendAttackInput(bool Pressed); // Function TheTwins.ConjoinedTwin.Server_SendAttackInput // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x3516b50
	void OnFinishedPlayingEvent(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheTwins.ConjoinedTwin.OnFinishedPlayingEvent // (Final|Native|Private|HasOutParms) // @ game+0x3516810
	void Cosmetic_OnOnGroundUncontrolledChanged(bool onGroundAndUncontrolled); // Function TheTwins.ConjoinedTwin.Cosmetic_OnOnGroundUncontrolledChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnFirecrackerInRangeBegin(struct FFirecrackerEffectData effectData); // Function TheTwins.ConjoinedTwin.Authority_OnFirecrackerInRangeBegin // (Final|Native|Protected|HasOutParms) // @ game+0x35164a0
};

// Class TheTwins.ConjoinedTwinAnimInstance
// Size: 0x5a0 (Inherited: 0x4f0)
struct UConjoinedTwinAnimInstance : UPlayerAnimInstance {
	struct AConjoinedTwin* _owningConjoinedTwin; // 0x4e8(0x08)
	bool _firstPersonView; // 0x4f0(0x01)
	float _forwardVelocity; // 0x4f4(0x04)
	float _lateralVelocity; // 0x4f8(0x04)
	enum class EInteractionAnimation _interactionType; // 0x4fc(0x01)
	bool _isInAir; // 0x4fd(0x01)
	bool _isIdle; // 0x4fe(0x01)
	float _idleTime; // 0x500(0x04)
	bool _isAttacking; // 0x504(0x01)
	struct UDBDAttackerComponent* _attackerComponent; // 0x508(0x08)
	struct UTwinAttachmentComponent* _twinAttachmentComponent; // 0x510(0x08)
	struct UTwinLockerBlockerComponent* _twinLockerBlockerComponent; // 0x518(0x08)
	float _animYaw; // 0x520(0x04)
	float _animPitch; // 0x524(0x04)
	bool _isSpectator; // 0x528(0x01)
	char pad_52A[0x2]; // 0x52a(0x02)
	float _animDirection; // 0x52c(0x04)
	float _animSpeed; // 0x530(0x04)
	bool _isAttachedToSister; // 0x534(0x01)
	bool _isAttachedToSurvivor; // 0x535(0x01)
	bool _isAttachedToFemaleSurvivor; // 0x536(0x01)
	bool _isChargingTwinJump; // 0x537(0x01)
	bool _isPossessing; // 0x538(0x01)
	bool _isWakingUpFromPossess; // 0x539(0x01)
	bool _isDormant; // 0x53a(0x01)
	bool _isBeingAutoPossessedAfterRelease; // 0x53b(0x01)
	bool _isAttachedToLocker; // 0x53c(0x01)
	enum class EAttackSubstate _attackState; // 0x53d(0x01)
	char pad_53E[0x62]; // 0x53e(0x62)

	struct AConjoinedTwin* GetOwningConjoinedTwin(); // Function TheTwins.ConjoinedTwinAnimInstance.GetOwningConjoinedTwin // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3516720
};

// Class TheTwins.ConjoinedTwinInteractable
// Size: 0x330 (Inherited: 0x310)
struct AConjoinedTwinInteractable : APlayerInteractable {
	struct UChargeableComponent* _possessKillerChargeable; // 0x310(0x08)
	struct UChargeableComponent* _chargeTwinJumpChargeable; // 0x318(0x08)
	struct UChargeableComponent* _removeTwinChargeable; // 0x320(0x08)
	struct UChargeableComponent* _destroyTwinChargeable; // 0x328(0x08)
};

// Class TheTwins.ConjoinedTwinStateMachine
// Size: 0x130 (Inherited: 0x130)
struct UConjoinedTwinStateMachine : UPlayerStateMachine {
};

// Class TheTwins.CoupDeGrace
// Size: 0x3b8 (Inherited: 0x3a8)
struct UCoupDeGrace : UPerk {
	float _lungeAttackAddDurationMultiplier[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class TheTwins.Deception
// Size: 0x3e0 (Inherited: 0x3a8)
struct UDeception : UPerk {
	float _noScratchMarksDuration[0x3]; // 0x3a8(0x0c)
	float _perkCooldownDuration[0x3]; // 0x3b4(0x0c)
	struct UStatusEffect* _statusEffect; // 0x3c0(0x08)
	char pad_3C8[0x8]; // 0x3c8(0x08)
	struct UManualIconStrategy* _iconStrategy; // 0x3d0(0x08)
	char pad_3D8[0x8]; // 0x3d8(0x08)

	void OnOwningPlayerFakedEnteringLockerCosmetic(); // Function TheTwins.Deception.OnOwningPlayerFakedEnteringLockerCosmetic // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheTwins.DestroyTwin
// Size: 0x6f0 (Inherited: 0x680)
struct UDestroyTwin : UChargeableInteractionDefinition {
	char pad_680[0x40]; // 0x680(0x40)
	struct FDBDTunableRowHandle _destroyTwinMaxCharge; // 0x6c0(0x28)
	char pad_6E8[0x8]; // 0x6e8(0x08)
};

// Class TheTwins.Hoarder
// Size: 0x3f8 (Inherited: 0x3a8)
struct UHoarder : UPerk {
	char pad_3A8[0x8]; // 0x3a8(0x08)
	struct TArray<struct ASearchable*> _chests; // 0x3b0(0x10)
	float _camperInteractItemPickupRevealRange[0x3]; // 0x3c0(0x0c)
	int32_t _extraChestsSpawned[0x3]; // 0x3cc(0x0c)
	float _bubbleIndicatorLifetime[0x3]; // 0x3d8(0x0c)
	bool _showUniqueChestVisualPerState; // 0x3e4(0x01)
	char pad_3E5[0x13]; // 0x3e5(0x13)

	void Local_ThrowBubbleIndicator(enum class EPerkInteractionObjectType camperInteractionType, struct AActor* objectActor, struct ACamperPlayer* interactingCamperPlayer); // Function TheTwins.Hoarder.Local_ThrowBubbleIndicator // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	float GetBubbleIndicatorLifetime(); // Function TheTwins.Hoarder.GetBubbleIndicatorLifetime // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x35166c0
};

// Class TheTwins.IsTwinRecallReady
// Size: 0xf0 (Inherited: 0xe8)
struct UIsTwinRecallReady : UEventDrivenModifierCondition {
	char pad_E8[0x8]; // 0xe8(0x08)

	void OnLevelReadyToPlay(); // Function TheTwins.IsTwinRecallReady.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x3516960
};

// Class TheTwins.K22AchievementTagTeam
// Size: 0xd0 (Inherited: 0xb8)
struct UK22AchievementTagTeam : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
};

// Class TheTwins.K22Power
// Size: 0x600 (Inherited: 0x498)
struct AK22Power : ACollectable {
	char pad_498[0x18]; // 0x498(0x18)
	struct UChargeableComponent* _releaseConjoinedTwinChargeable; // 0x4b0(0x08)
	struct UChargeableComponent* _possessConjoinedTwinChargeable; // 0x4b8(0x08)
	char pad_4C0[0x18]; // 0x4c0(0x18)
	struct AConjoinedTwin* _conjoinedTwin; // 0x4d8(0x08)
	struct AConjoinedTwin* _conjoinedTwinParadise; // 0x4e0(0x08)
	struct UPowerChargeComponent* _powerCharge; // 0x4e8(0x08)
	struct UK22PowerChargePresentationItemProgressComponent* _powerChargePresentationItemProgress; // 0x4f0(0x08)
	struct FDBDTunableRowHandle _powerMaxCharge; // 0x4f8(0x28)
	struct AConjoinedTwin* _conjoinedTwinClass; // 0x520(0x08)
	char pad_528[0x18]; // 0x528(0x18)
	struct FDBDTunableRowHandle _powerRechargeRate; // 0x540(0x28)
	struct FDBDTunableRowHandle _timeBeforeAutoDestroy; // 0x568(0x28)
	struct FDBDTunableRowHandle _timeBeforeRecallAvailable; // 0x590(0x28)
	char pad_5B8[0x48]; // 0x5b8(0x48)

	void OnRep_ConjoinedTwin(); // Function TheTwins.K22Power.OnRep_ConjoinedTwin // (Final|Native|Private) // @ game+0x35169c0
	void OnPowerChargeEmpty(); // Function TheTwins.K22Power.OnPowerChargeEmpty // (Final|Native|Private) // @ game+0x35169a0
	void OnFirstAttachmentToSister(); // Function TheTwins.K22Power.OnFirstAttachmentToSister // (Final|Native|Private) // @ game+0x3516920
	struct AConjoinedTwin* GetConjoinedTwin(); // Function TheTwins.K22Power.GetConjoinedTwin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35166f0
	void Authority_OnPossessTwinChargePercentChanged(struct UChargeableComponent* ChargeableComponent, float PercentCompletionChange, float TotalPercentComplete); // Function TheTwins.K22Power.Authority_OnPossessTwinChargePercentChanged // (Final|Native|Private) // @ game+0x3516540
	void Authority_OnDestroyTwinChargePercentChanged(struct UChargeableComponent* ChargeableComponent, float PercentCompletionChange, float TotalPercentComplete); // Function TheTwins.K22Power.Authority_OnDestroyTwinChargePercentChanged // (Final|Native|Private) // @ game+0x35163a0
};

// Class TheTwins.K22PowerChargePresentationItemProgressComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UK22PowerChargePresentationItemProgressComponent : UPresentationItemProgressComponent {
	struct UPowerChargeComponent* _powerChargeComponent; // 0xb8(0x08)
	char pad_C0[0x10]; // 0xc0(0x10)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.K22PowerChargePresentationItemProgressComponent.OnTwinSet // (Final|Native|Private) // @ game+0x3516a00
};

// Class TheTwins.K22ScoreComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UK22ScoreComponent : UActorComponent {
	char pad_B8[0x18]; // 0xb8(0x18)
};

// Class TheTwins.KillerBeingPossessedInteraction
// Size: 0x5e0 (Inherited: 0x5e0)
struct UKillerBeingPossessedInteraction : UBeingPossessedInteraction {
	struct UCurveFloat* _wakeUpSpeedCurve; // 0x5d8(0x08)
};

// Class TheTwins.PossessionComponent
// Size: 0x140 (Inherited: 0xb8)
struct UPossessionComponent : UActorComponent {
	char pad_B8[0x61]; // 0xb8(0x61)
	bool _startPossessed; // 0x119(0x01)
	char pad_11A[0x6]; // 0x11a(0x06)
	struct AAIController* _emptyController; // 0x120(0x08)
	char pad_128[0x18]; // 0x128(0x18)

	void Server_StartPossessionOf(struct ADBDPlayer* playerToPossess, bool shouldStartBeingPossessedInteraction); // Function TheTwins.PossessionComponent.Server_StartPossessionOf // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3516c10
	void Server_NotifyPossessionDone(); // Function TheTwins.PossessionComponent.Server_NotifyPossessionDone // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x3516b00
	void OnLevelReadyToPlay(); // Function TheTwins.PossessionComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x3516980
	void Multicast_StartPossessionOf(struct ADBDPlayer* playerToPossess); // Function TheTwins.PossessionComponent.Multicast_StartPossessionOf // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x3516780
	void Multicast_NotifyPossessionDone(); // Function TheTwins.PossessionComponent.Multicast_NotifyPossessionDone // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc4840
	bool IsPossessed(); // Function TheTwins.PossessionComponent.IsPossessed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3516750
	bool IsDormant(); // Function TheTwins.PossessionComponent.IsDormant // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3377dd0
	void CosmeticLocal_OnUncontrolled(struct ADBDPlayer* Player); // Function TheTwins.PossessionComponent.CosmeticLocal_OnUncontrolled // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void CosmeticLocal_OnControlled(struct ADBDPlayer* Player); // Function TheTwins.PossessionComponent.CosmeticLocal_OnControlled // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnControlledChanged(struct ADBDPlayer* Player, bool IsControlled); // Function TheTwins.PossessionComponent.Cosmetic_OnControlledChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Client_StartStateMachineDriverChangeProcess(); // Function TheTwins.PossessionComponent.Client_StartStateMachineDriverChangeProcess // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x3278c40
};

// Class TheTwins.KillerPossessionComponent
// Size: 0x1a0 (Inherited: 0x140)
struct UKillerPossessionComponent : UPossessionComponent {
	bool _shouldDeactivateCollisionsWithSurvivors; // 0x140(0x01)
	char pad_141[0x37]; // 0x141(0x37)
	struct FDBDTunableRowHandle _timeBeforeCollisionsDeactivation; // 0x178(0x28)

	void OnRep_ShouldDeactivateCollisionsWithSurvivors(); // Function TheTwins.KillerPossessionComponent.OnRep_ShouldDeactivateCollisionsWithSurvivors // (Final|Native|Private) // @ game+0x35169e0
};

// Class TheTwins.PossessNegationEffectComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UPossessNegationEffectComponent : UActorComponent {
	struct FMulticastInlineDelegate PlayCantPossessSound; // 0xb8(0x10)
	char pad_C8[0x8]; // 0xc8(0x08)

	void PlayCantPossessSound__DelegateSignature(); // DelegateFunction TheTwins.PossessNegationEffectComponent.PlayCantPossessSound__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x3873200
	void OnLevelReadyToPlay(); // Function TheTwins.PossessNegationEffectComponent.OnLevelReadyToPlay // (Native|Protected) // @ game+0x2cc4840
};

// Class TheTwins.KillerPossessNegationEffectComponent
// Size: 0xf0 (Inherited: 0xd0)
struct UKillerPossessNegationEffectComponent : UPossessNegationEffectComponent {
	char pad_D0[0x20]; // 0xd0(0x20)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.KillerPossessNegationEffectComponent.OnTwinSet // (Final|Native|Private) // @ game+0x3516a80
};

// Class TheTwins.Oppression
// Size: 0x3c0 (Inherited: 0x3a8)
struct UOppression : UPerk {
	int32_t _nbGeneratorsAffectedByPerk[0x3]; // 0x3a8(0x0c)
	int32_t _perkCooldown[0x3]; // 0x3b4(0x0c)
};

// Class TheTwins.PossessTheKiller
// Size: 0x6e0 (Inherited: 0x6b0)
struct UPossessTheKiller : UPossessPlayer {
	char pad_6B0[0x30]; // 0x6b0(0x30)
};

// Class TheTwins.PowerStruggle
// Size: 0x3b8 (Inherited: 0x3a8)
struct UPowerStruggle : UPerk {
	float _wigglePercentToActivatePerk[0x3]; // 0x3a8(0x0c)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class TheTwins.PushTwinOnLockerInteraction
// Size: 0x6e0 (Inherited: 0x680)
struct UPushTwinOnLockerInteraction : UChargeableInteractionDefinition {
	struct UChargeableComponent* _pushTwinOnLockerChargeable; // 0x680(0x08)
	struct FDBDTunableRowHandle _pushTwinOnLockerMaxCharge; // 0x688(0x28)
	char pad_6B0[0x30]; // 0x6b0(0x30)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.PushTwinOnLockerInteraction.OnTwinSet // (Final|Native|Private) // @ game+0x351c4c0
	void OnRep_PushTwinOnLockerChargeable(); // Function TheTwins.PushTwinOnLockerInteraction.OnRep_PushTwinOnLockerChargeable // (Final|Native|Private) // @ game+0x351c3e0
	void Authority_OnSurvivorInLockerChanged(struct ADBDPlayer* oldSurvivor, struct ADBDPlayer* newSurvivor); // Function TheTwins.PushTwinOnLockerInteraction.Authority_OnSurvivorInLockerChanged // (Final|Native|Private) // @ game+0x351b3f0
};

// Class TheTwins.RecallTwin
// Size: 0x580 (Inherited: 0x560)
struct URecallTwin : UInteractionDefinition {
	char pad_560[0x20]; // 0x560(0x20)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.RecallTwin.OnTwinSet // (Final|Native|Private) // @ game+0x351c540
};

// Class TheTwins.ReleaseConjoinedTwin
// Size: 0x7f0 (Inherited: 0x680)
struct UReleaseConjoinedTwin : UChargeableInteractionDefinition {
	struct FDBDTunableRowHandle _releaseMaxCharge; // 0x680(0x28)
	struct FTunableStat _releaseExitTime; // 0x6a8(0x80)
	char pad_728[0x34]; // 0x728(0x34)
	bool _releaseAnimationWentToTheEnd; // 0x75c(0x01)
	char pad_75D[0x93]; // 0x75d(0x93)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.ReleaseConjoinedTwin.OnTwinSet // (Final|Native|Private) // @ game+0x351c5c0
	void OnRep_ReleaseAnimationWentToTheEnd(); // Function TheTwins.ReleaseConjoinedTwin.OnRep_ReleaseAnimationWentToTheEnd // (Final|Native|Private) // @ game+0x351c400
	void OnPowerCollected(struct ADBDPlayer* collector); // Function TheTwins.ReleaseConjoinedTwin.OnPowerCollected // (Final|Native|Private) // @ game+0x351c170
	void OnKillerStunned(struct FGameplayTag gameEventType, struct FGameEventData GameEventData); // Function TheTwins.ReleaseConjoinedTwin.OnKillerStunned // (Final|Native|Private|HasOutParms) // @ game+0x351be80
	void Cosmetic_OnReleaseTwinInteractionUpdateStart(struct ADBDPlayer* sister, struct AConjoinedTwin* brother); // Function TheTwins.ReleaseConjoinedTwin.Cosmetic_OnReleaseTwinInteractionUpdateStart // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnReleaseTwinInteractionUpdate(struct ADBDPlayer* sister, struct AConjoinedTwin* brother, float DeltaTime); // Function TheTwins.ReleaseConjoinedTwin.Cosmetic_OnReleaseTwinInteractionUpdate // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnReleaseChargeComplete(struct ADBDPlayer* sister, struct AConjoinedTwin* brother); // Function TheTwins.ReleaseConjoinedTwin.Cosmetic_OnReleaseChargeComplete // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnReleaseCancelled(struct ADBDPlayer* sister, struct AConjoinedTwin* brother); // Function TheTwins.ReleaseConjoinedTwin.Cosmetic_OnReleaseCancelled // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheTwins.RemoveTwin
// Size: 0x710 (Inherited: 0x680)
struct URemoveTwin : UChargeableInteractionDefinition {
	char pad_680[0x30]; // 0x680(0x30)
	struct FDBDTunableRowHandle _removeTwinMaxCharge; // 0x6b0(0x28)
	struct FDBDTunableRowHandle _removeTwinExitTime; // 0x6d8(0x28)
	float _brotherRemoveDistanceFromSurvivor; // 0x700(0x04)
	char pad_704[0xc]; // 0x704(0x0c)

	void OnRemoveMontageEnd(struct FAnimationMontageDescriptor Montage, bool interrupted, struct ADBDPlayer* destroyingPlayer); // Function TheTwins.RemoveTwin.OnRemoveMontageEnd // (Final|Native|Private) // @ game+0x351c1f0
};

// Class TheTwins.SisterBlindFlashlightableLightingStrategy
// Size: 0x70 (Inherited: 0x40)
struct USisterBlindFlashlightableLightingStrategy : UBlindFlashlightableLightingStrategy {
	char pad_40[0x30]; // 0x40(0x30)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.SisterBlindFlashlightableLightingStrategy.OnTwinSet // (Final|Native|Private) // @ game+0x351c640
};

// Class TheTwins.TheTwinsCheatComponent
// Size: 0xb8 (Inherited: 0xb8)
struct UTheTwinsCheatComponent : UActorComponent {

	void Multicast_TrySendThePlayerBackInKiller(struct UTwinPossessionComponent* TwinPossessionComponent); // Function TheTwins.TheTwinsCheatComponent.Multicast_TrySendThePlayerBackInKiller // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x330ee30
	void DBD_TwinDestroyTheTwin(); // Function TheTwins.TheTwinsCheatComponent.DBD_TwinDestroyTheTwin // (Final|Exec|Native|Public) // @ game+0x25271c0
};

// Class TheTwins.TwinAOELingeringStatusEffect
// Size: 0x3c8 (Inherited: 0x328)
struct UTwinAOELingeringStatusEffect : UBaseLingeringStatusEffect {
	struct FTunableStat _shriekingRange; // 0x328(0x80)
	char pad_3A8[0x20]; // 0x3a8(0x20)

	float GetShriekingRange(); // Function TheTwins.TwinAOELingeringStatusEffect.GetShriekingRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x351b610
	void Authority_OnInRangeChanged(bool InRange); // Function TheTwins.TwinAOELingeringStatusEffect.Authority_OnInRangeChanged // (Final|Native|Private) // @ game+0x351b1d0
};

// Class TheTwins.TwinAttachmentComponent
// Size: 0x1f8 (Inherited: 0xb8)
struct UTwinAttachmentComponent : UActorComponent {
	char pad_B8[0x48]; // 0xb8(0x48)
	struct ADBDPlayer* _attachedPlayer; // 0x100(0x08)
	char pad_108[0x58]; // 0x108(0x58)
	struct UStatusEffect* _gateBlockerStatusEffect; // 0x160(0x08)
	char pad_168[0x12]; // 0x168(0x12)
	bool _hasBeenDetachedBySurvivorDamageChanged; // 0x17a(0x01)
	char pad_17B[0x5]; // 0x17b(0x05)
	struct FDBDTunableRowHandle _cantEscapeByGateLingerDuration; // 0x180(0x28)
	struct TMap<struct ADBDPlayer*, struct FFastTimer> _escapeBlockerLingerTimers; // 0x1a8(0x50)

	void OnRep_AttachedPlayer(struct ADBDPlayer* oldAttachedPlayer); // Function TheTwins.TwinAttachmentComponent.OnRep_AttachedPlayer // (Final|Native|Private) // @ game+0x351c360
	void OnMoriMontageEnd(struct FAnimationMontageDescriptor Montage, bool interrupted); // Function TheTwins.TwinAttachmentComponent.OnMoriMontageEnd // (Final|Native|Private) // @ game+0x351bfb0
	void OnLevelReadyToPlay(); // Function TheTwins.TwinAttachmentComponent.OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x351bf90
	void OnImmobilizedStateChanged(enum class ECamperImmobilizeState oldImmobilizeState, enum class ECamperImmobilizeState newImmobilizeState); // Function TheTwins.TwinAttachmentComponent.OnImmobilizedStateChanged // (Final|Native|Private) // @ game+0x351bdc0
	void OnAttachedSurvivorDamageStateChanged(enum class ECamperDamageState oldState, enum class ECamperDamageState newState); // Function TheTwins.TwinAttachmentComponent.OnAttachedSurvivorDamageStateChanged // (Final|Native|Private) // @ game+0x351bbc0
	void Multicast_QuickDestroyTwin(); // Function TheTwins.TwinAttachmentComponent.Multicast_QuickDestroyTwin // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2cc4840
	bool IsAttachedToSurvivor(); // Function TheTwins.TwinAttachmentComponent.IsAttachedToSurvivor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x351b670
	bool IsAttachedToSister(); // Function TheTwins.TwinAttachmentComponent.IsAttachedToSister // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x351b640
	void Cosmetic_OnTwinDetachedFromSurvivor(struct ADBDPlayer* survivor, struct ADBDPlayer* brother); // Function TheTwins.TwinAttachmentComponent.Cosmetic_OnTwinDetachedFromSurvivor // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnTwinDetachedFromSister(struct ADBDPlayer* sister, struct ADBDPlayer* brother); // Function TheTwins.TwinAttachmentComponent.Cosmetic_OnTwinDetachedFromSister // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnTwinAttachedToSurvivor(struct ADBDPlayer* survivor, struct ADBDPlayer* brother); // Function TheTwins.TwinAttachmentComponent.Cosmetic_OnTwinAttachedToSurvivor // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnTwinAttachedToSister(struct ADBDPlayer* sister, struct ADBDPlayer* brother, bool isFirstAttachment); // Function TheTwins.TwinAttachmentComponent.Cosmetic_OnTwinAttachedToSister // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnRemoveTwinChargePercentChanged(struct UChargeableComponent* ChargeableComponent, float PercentCompletionChange, float TotalPercentComplete); // Function TheTwins.TwinAttachmentComponent.Authority_OnRemoveTwinChargePercentChanged // (Final|Native|Private) // @ game+0x351b2f0
};

// Class TheTwins.TwinBaseAddon
// Size: 0x288 (Inherited: 0x278)
struct UTwinBaseAddon : UItemAddon {
	struct FName _statusEffectId; // 0x278(0x0c)
	float _customParam; // 0x284(0x04)

	void Authority_OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.TwinBaseAddon.Authority_OnTwinSet // (Final|Native|Private) // @ game+0x351b4d0
};

// Class TheTwins.TwinBaseKillerInstinctEffect
// Size: 0x468 (Inherited: 0x320)
struct UTwinBaseKillerInstinctEffect : UStatusEffect {
	struct FTunableStat _lullabyRange; // 0x320(0x80)
	struct FDBDTunableRowHandle _lingerDuration; // 0x3a0(0x28)
	char pad_3C8[0xa0]; // 0x3c8(0xa0)

	float GetLullabyRange(); // Function TheTwins.TwinBaseKillerInstinctEffect.GetLullabyRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x351b5e0
	void Authority_OnInRangeChanged(bool InRange); // Function TheTwins.TwinBaseKillerInstinctEffect.Authority_OnInRangeChanged // (Final|Native|Private) // @ game+0x351b260
};

// Class TheTwins.TwinBeingPossessedInteraction
// Size: 0x5e0 (Inherited: 0x5e0)
struct UTwinBeingPossessedInteraction : UBeingPossessedInteraction {
};

// Class TheTwins.TwinCharacterMovementComponent
// Size: 0x8e0 (Inherited: 0x8d0)
struct UTwinCharacterMovementComponent : UDBDCharacterMovementComponent {
	char pad_8D0[0x10]; // 0x8d0(0x10)
};

// Class TheTwins.TwinDestructionComponent
// Size: 0x1a0 (Inherited: 0xb8)
struct UTwinDestructionComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
	struct AActor* _huskClass; // 0xe8(0x08)
	struct FTransform _dyingTransform; // 0xf0(0x30)
	char pad_120[0x18]; // 0x120(0x18)
	bool _diedFromSurvivorRemovingTwin; // 0x138(0x01)
	char pad_139[0x57]; // 0x139(0x57)
	float _dyingFromSurvivorTranslation; // 0x190(0x04)
	char pad_194[0xc]; // 0x194(0x0c)

	void OnTwinQuickDestroy(struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinDestructionComponent.OnTwinQuickDestroy // (Event|Protected|BlueprintEvent) // @ game+0x3873200
	void OnDyingMontageEnd(struct FAnimationMontageDescriptor Montage, bool interrupted); // Function TheTwins.TwinDestructionComponent.OnDyingMontageEnd // (Final|Native|Private) // @ game+0x351bc80
	void Cosmetic_OnTwinDestroyedFromSurvivorRemove(struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinDestructionComponent.Cosmetic_OnTwinDestroyedFromSurvivorRemove // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnTwinDestroyedFromKick(struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinDestructionComponent.Cosmetic_OnTwinDestroyedFromKick // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnTwinQuickDestroyOver(); // Function TheTwins.TwinDestructionComponent.Authority_OnTwinQuickDestroyOver // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x351b4b0
};

// Class TheTwins.TwinFirstPersonViewComponent
// Size: 0xf0 (Inherited: 0xc8)
struct UTwinFirstPersonViewComponent : UFirstPersonViewComponent {
	char pad_C8[0x28]; // 0xc8(0x28)
};

// Class TheTwins.TwinHuskAnimInstance
// Size: 0x290 (Inherited: 0x270)
struct UTwinHuskAnimInstance : UAnimInstance {
	bool _isDeadFromSurvivorBack; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct APawn* _owningPawn; // 0x278(0x08)
	struct UTwinHuskStateComponent* _twinHuskStateComponent; // 0x280(0x08)
	char pad_288[0x8]; // 0x288(0x08)
};

// Class TheTwins.TwinHuskStateComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UTwinHuskStateComponent : UActorComponent {
	char pad_B8[0x8]; // 0xb8(0x08)

	bool IsDeadFromSurvivorBack(); // Function TheTwins.TwinHuskStateComponent.IsDeadFromSurvivorBack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x32ed890
};

// Class TheTwins.TwinInspectEmptyLocker
// Size: 0x590 (Inherited: 0x590)
struct UTwinInspectEmptyLocker : UBaseTwinInspectLocker {
};

// Class TheTwins.TwinInspectOccupiedLocker
// Size: 0x590 (Inherited: 0x590)
struct UTwinInspectOccupiedLocker : UBaseTwinInspectLocker {
};

// Class TheTwins.TwinJumpAttack
// Size: 0x450 (Inherited: 0x360)
struct UTwinJumpAttack : UPounceAttack {
	struct FDBDTunableRowHandle _jumpVelocity; // 0x360(0x28)
	struct UCurveFloat* _jumpAngleCurve; // 0x388(0x08)
	char pad_390[0x30]; // 0x390(0x30)
	struct FDBDTunableRowHandle _upDownObstructionAnglePrecision; // 0x3c0(0x28)
	struct FDBDTunableRowHandle _leftRightObstructionAnglePrecision; // 0x3e8(0x28)
	struct FDBDTunableRowHandle _authorizedLandingHeight; // 0x410(0x28)
	char pad_438[0x9]; // 0x438(0x09)
	bool _shouldTwinHaveJumpObjectType; // 0x441(0x01)
	char pad_442[0xe]; // 0x442(0x0e)

	void Server_StopJump(); // Function TheTwins.TwinJumpAttack.Server_StopJump // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x351c710
	void Server_OnJumpStartTwin(); // Function TheTwins.TwinJumpAttack.Server_OnJumpStartTwin // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x351c6c0
	void OnRep_ShouldTwinHaveJumpObjectType(); // Function TheTwins.TwinJumpAttack.OnRep_ShouldTwinHaveJumpObjectType // (Final|Native|Private) // @ game+0x351c420
	void Multicast_SetIsForbiddenLandingLocation(bool isForbiddenLocation); // Function TheTwins.TwinJumpAttack.Multicast_SetIsForbiddenLandingLocation // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x351bb30
	void Multicast_DestroyTwinOnWrongLanding(); // Function TheTwins.TwinJumpAttack.Multicast_DestroyTwinOnWrongLanding // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x351bb10
	void Multicast_AttachToSurvivor(struct ADBDPlayer* survivorToAttachTo); // Function TheTwins.TwinJumpAttack.Multicast_AttachToSurvivor // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x351ba80
	void Cosmetic_OnJumpStarted(struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinJumpAttack.Cosmetic_OnJumpStarted // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnJumpObstructed(struct AConjoinedTwin* owningTwin, struct UPhysicalMaterial* PhysicalMaterial, struct FVector Position, struct FVector Normal); // Function TheTwins.TwinJumpAttack.Cosmetic_OnJumpObstructed // (BlueprintCosmetic|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnJumpLanded(struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinJumpAttack.Cosmetic_OnJumpLanded // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnJumpCooldownChanged(bool isInJumpCooldown, struct AConjoinedTwin* owningTwin); // Function TheTwins.TwinJumpAttack.Cosmetic_OnJumpCooldownChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnIsForbiddenLandingLocationChanged(bool isForbiddenLocation, struct AConjoinedTwin* twin); // Function TheTwins.TwinJumpAttack.Cosmetic_OnIsForbiddenLandingLocationChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Client_Debug_PrintFinalDecisionOnScreen(bool foundPath); // Function TheTwins.TwinJumpAttack.Client_Debug_PrintFinalDecisionOnScreen // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x351b550
};

// Class TheTwins.TwinJumpAttackOpenSubstate
// Size: 0x1d0 (Inherited: 0x130)
struct UTwinJumpAttackOpenSubstate : UPounceAttackOpenSubstate {
	char pad_130[0xa0]; // 0x130(0xa0)

	void Local_OnTwinOverlapEnter(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult Hit); // Function TheTwins.TwinJumpAttackOpenSubstate.Local_OnTwinOverlapEnter // (Final|Native|Private|HasOutParms) // @ game+0x351b870
	void Local_OnTwinCapsuleHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function TheTwins.TwinJumpAttackOpenSubstate.Local_OnTwinCapsuleHit // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x351b6a0
};

// Class TheTwins.TwinJumpAttackSuccessSubstate
// Size: 0x168 (Inherited: 0x118)
struct UTwinJumpAttackSuccessSubstate : UPounceAttackSuccessSubstate {
	struct FDBDTunableRowHandle _jumpSucceedAttachedCooldownTime; // 0x118(0x28)
	struct FDBDTunableRowHandle _jumpSucceedNotAttachedCooldownTime; // 0x140(0x28)
};

// Class TheTwins.TwinJumpAttackMissSubstate
// Size: 0x120 (Inherited: 0x120)
struct UTwinJumpAttackMissSubstate : UPounceAttackMissSubstate {
};

// Class TheTwins.TwinJumpAttackObstructSubstate
// Size: 0x128 (Inherited: 0x128)
struct UTwinJumpAttackObstructSubstate : UPounceAttackObstructSubstate {
};

// Class TheTwins.TwinJumpAudioMutedEffect
// Size: 0x320 (Inherited: 0x320)
struct UTwinJumpAudioMutedEffect : UStatusEffect {

	void Cosmetic_OnTwinUnmuted(); // Function TheTwins.TwinJumpAudioMutedEffect.Cosmetic_OnTwinUnmuted // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Cosmetic_OnTwinMuted(); // Function TheTwins.TwinJumpAudioMutedEffect.Cosmetic_OnTwinMuted // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
};

// Class TheTwins.TwinJumpTargetVisibleEffect
// Size: 0x338 (Inherited: 0x320)
struct UTwinJumpTargetVisibleEffect : UStatusEffect {
	struct AActor* _twinJumpTargetObject; // 0x320(0x08)
	struct AActor* _twinJumpTarget; // 0x328(0x08)
	struct USelectiveVisibilityComponent* _jumpTargetVisibility; // 0x330(0x08)

	void OnJumpTargetTick(struct FVector Location); // Function TheTwins.TwinJumpTargetVisibleEffect.OnJumpTargetTick // (Final|Native|Private|HasDefaults) // @ game+0x351dd20
	void OnHideTargetPosition(); // Function TheTwins.TwinJumpTargetVisibleEffect.OnHideTargetPosition // (Final|Native|Private) // @ game+0x351dd00
};

// Class TheTwins.TwinLockerBlockerComponent
// Size: 0x128 (Inherited: 0xb8)
struct UTwinLockerBlockerComponent : UActorComponent {
	struct TArray<struct UInteractionDefinition*> _interactionClasses; // 0xb8(0x10)
	char pad_C8[0x10]; // 0xc8(0x10)
	struct TArray<struct UInteractionDefinition*> _interactionsToDisableOnLockerClasses; // 0xd8(0x10)
	char pad_E8[0x40]; // 0xe8(0x40)

	void OnPushedMontageStopped(struct FAnimationMontageDescriptor montageDescriptor); // Function TheTwins.TwinLockerBlockerComponent.OnPushedMontageStopped // (Final|Native|Private) // @ game+0x351e020
	void OnPushedMontageStarted(struct FAnimationMontageDescriptor montageDescriptor, float Rate); // Function TheTwins.TwinLockerBlockerComponent.OnPushedMontageStarted // (Final|Native|Private) // @ game+0x351def0
	void OnPushedMontageEnded(struct FAnimationMontageDescriptor montageDescriptor, bool interrupted); // Function TheTwins.TwinLockerBlockerComponent.OnPushedMontageEnded // (Final|Native|Private) // @ game+0x351ddb0
	bool IsTwinAttachedToLocker(); // Function TheTwins.TwinLockerBlockerComponent.IsTwinAttachedToLocker // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x326f610
	void Cosmetic_OnTwinOnLockerChanged(bool isOnLocker); // Function TheTwins.TwinLockerBlockerComponent.Cosmetic_OnTwinOnLockerChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3873200
	void Authority_OnLevelReadyToPlay(); // Function TheTwins.TwinLockerBlockerComponent.Authority_OnLevelReadyToPlay // (Final|Native|Private) // @ game+0x351dc60
};

// Class TheTwins.TwinLullabyRangeAdditiveEffect
// Size: 0x470 (Inherited: 0x320)
struct UTwinLullabyRangeAdditiveEffect : UStatusEffect {
	struct FDBDTunableRowHandle _defaultTwinLullabyDormantRange; // 0x320(0x28)
	struct FTunableStat _twinLullabyDormantRange; // 0x348(0x80)
	struct FTunableStat _twinLullabyAttachedRange; // 0x3c8(0x80)
	char pad_448[0x28]; // 0x448(0x28)
};

// Class TheTwins.TwinOutlineUpdateStrategy
// Size: 0x110 (Inherited: 0xc0)
struct UTwinOutlineUpdateStrategy : UOutlineUpdateStrategy {
	struct FLinearColor _visibleColorForKiller; // 0xc0(0x10)
	char pad_D0[0x40]; // 0xd0(0x40)
};

// Class TheTwins.TwinPlacerComponent
// Size: 0x270 (Inherited: 0x260)
struct UTwinPlacerComponent : UObjectPlacerComponent {
	char pad_260[0x10]; // 0x260(0x10)
};

// Class TheTwins.TwinPossessionComponent
// Size: 0x160 (Inherited: 0x140)
struct UTwinPossessionComponent : UPossessionComponent {
	char pad_140[0x20]; // 0x140(0x20)
};

// Class TheTwins.TwinPossessNegationEffectComponent
// Size: 0xf0 (Inherited: 0xd0)
struct UTwinPossessNegationEffectComponent : UPossessNegationEffectComponent {
	char pad_D0[0x20]; // 0xd0(0x20)
};

// Class TheTwins.TwinsAnimInstance
// Size: 0x640 (Inherited: 0x5b0)
struct UTwinsAnimInstance : UKillerAnimInstance {
	bool _isDormant; // 0x5a8(0x01)
	bool _hasBrotherAttached; // 0x5a9(0x01)
	bool _isPossessing; // 0x5aa(0x01)
	bool _isWakingUpFromPossess; // 0x5ab(0x01)
	bool _isAutoPossessingAfterRelease; // 0x5ac(0x01)
	char pad_5B5[0x8b]; // 0x5b5(0x8b)
};

// Class TheTwins.TwinsSurvivorSubAnimInstance
// Size: 0x530 (Inherited: 0x4f0)
struct UTwinsSurvivorSubAnimInstance : UBaseSurvivorAnimInstance {
	bool _isRemovingTwin; // 0x4f0(0x01)
	char pad_4F1[0x3f]; // 0x4f1(0x3f)
};

// Class TheTwins.TwinStateHelperComponent
// Size: 0xe8 (Inherited: 0xb8)
struct UTwinStateHelperComponent : UActorComponent {
	char pad_B8[0x30]; // 0xb8(0x30)
};

// Class TheTwins.TwinStunnableComponent
// Size: 0xd8 (Inherited: 0xb8)
struct UTwinStunnableComponent : UStunnableComponent {
	char pad_B8[0x20]; // 0xb8(0x20)
};

// Class TheTwins.TwinSubjectProvider
// Size: 0x50 (Inherited: 0x48)
struct UTwinSubjectProvider : UModifierSubjectProvider {
	char pad_48[0x8]; // 0x48(0x08)

	void OnTwinSet(struct AConjoinedTwin* twin); // Function TheTwins.TwinSubjectProvider.OnTwinSet // (Final|Native|Private) // @ game+0x2c92fb0
	void ListenToTwinSet(struct ASlasherPlayer* killer); // Function TheTwins.TwinSubjectProvider.ListenToTwinSet // (Final|Native|Private) // @ game+0x351dc80
};

