// Enum TheTwins.EPerkInteractionObjectType
enum class EPerkInteractionObjectType : uint8 {
	Item,
	ChestClosed,
	ChestOpen,
	EPerkInteractionObjectType_MAX,
};

// Enum TheTwins.EPossessionState
enum class EPossessionState : uint8 {
	NotPossessed,
	BeingPossessed,
	Possessed,
	EPossessionState_MAX,
};

