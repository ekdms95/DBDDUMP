// Class TheWraith.WraithAnimInstance
// Size: 0x650 (Inherited: 0x5b0)
struct UWraithAnimInstance : UKillerAnimInstance {
	bool _isRingingBell; // 0x5a8(0x01)
	bool _isCloaking; // 0x5a9(0x01)
	bool _isUncloaking; // 0x5aa(0x01)
	struct FPerspectiveDependentAnimSequenceSelector _cloakingInSelector; // 0x5b0(0x18)
	struct FPerspectiveDependentAnimSequenceSelector _cloakingSelector; // 0x5c8(0x18)
	struct FPerspectiveDependentAnimSequenceSelector _cloakingOutSelector; // 0x5e0(0x18)
	struct FPerspectiveDependentAnimSequenceSelector _uncloakingInSelector; // 0x5f8(0x18)
	struct FPerspectiveDependentAnimSequenceSelector _uncloakingSelector; // 0x610(0x18)
	struct FPerspectiveDependentAnimSequenceSelector _uncloakingOutSelector; // 0x628(0x18)
	float _cloakingPlayRate; // 0x640(0x04)
	char pad_647[0x9]; // 0x647(0x09)
};

// Class TheWraith.WraithBurnable
// Size: 0x190 (Inherited: 0x100)
struct UWraithBurnable : UPlayerLightBurnable {
	struct FDBDTunableRowHandle _flashlightEvasionScoreCooldown; // 0x100(0x28)
	char pad_128[0x68]; // 0x128(0x68)
};

