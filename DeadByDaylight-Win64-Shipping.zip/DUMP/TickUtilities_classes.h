// Class TickUtilities.RoundRobinTicker
// Size: 0x88 (Inherited: 0x38)
struct URoundRobinTicker : UWorldSubsystem {
	char pad_38[0x50]; // 0x38(0x50)
};

