// Class TimeUtilities.DBDTimeUtilities
// Size: 0x60 (Inherited: 0x38)
struct UDBDTimeUtilities : UGameInstanceSubsystem {
	char pad_38[0x28]; // 0x38(0x28)
};

