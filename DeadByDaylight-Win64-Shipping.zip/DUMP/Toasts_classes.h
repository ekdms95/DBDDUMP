// Class Toasts.ToastManager
// Size: 0x98 (Inherited: 0x30)
struct UToastManager : UObject {
	char pad_30[0x68]; // 0x30(0x68)
};

