// Class UIBackendData.UIBackendDataAccessor
// Size: 0xb0 (Inherited: 0x38)
struct UUIBackendDataAccessor : UGameInstanceSubsystem {
	char pad_38[0x70]; // 0x38(0x70)
	struct USplinteredStatesSubsystem* _splinteredStateSubsystem; // 0xa8(0x08)
};

