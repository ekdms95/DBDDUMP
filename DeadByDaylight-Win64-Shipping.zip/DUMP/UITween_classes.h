// Class UITween.UITween
// Size: 0x30 (Inherited: 0x30)
struct UUITween : UObject {
};

