// Enum UITween.EEasingType
enum class EEasingType : uint8 {
	Linear,
	SineIn,
	SineOut,
	SineInOut,
	QuadIn,
	QuadOut,
	QuadInOut,
	CubicIn,
	CubicOut,
	CubicInOut,
	QuartIn,
	QuartOut,
	QuartInOut,
	QuintIn,
	QuintOut,
	QuintInOut,
	ExpoIn,
	ExpoOut,
	ExpoInOut,
	CircIn,
	CircOut,
	CircInOut,
	ElasticIn,
	ElasticOut,
	ElasticInOut,
	BackIn,
	BackOut,
	BackInOut,
	EEasingType_MAX,
};

// ScriptStruct UITween.UITweenInstance
// Size: 0xc8 (Inherited: 0x00)
struct FUITweenInstance {
	char pad_0[0xc8]; // 0x00(0xc8)
};

