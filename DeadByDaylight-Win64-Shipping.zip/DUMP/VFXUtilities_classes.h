// Class VFXUtilities.BaseVFX
// Size: 0x238 (Inherited: 0x230)
struct ABaseVFX : AActor {
	bool _shouldLoadOnServer; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
};

// Class VFXUtilities.DBDDecalComponent
// Size: 0x250 (Inherited: 0x250)
struct UDBDDecalComponent : UDecalComponent {
};

// Class VFXUtilities.DecalCollection
// Size: 0x48 (Inherited: 0x30)
struct UDecalCollection : UObject {
	struct TArray<struct UDecalComponent*> _decalComponents; // 0x30(0x10)
	char pad_40[0x8]; // 0x40(0x08)
};

// Class VFXUtilities.DecalSpawner
// Size: 0x48 (Inherited: 0x30)
struct UDecalSpawner : UObject {
	struct UDecalCollection* _decalCollection; // 0x30(0x08)
	struct USpawnerStrategy* _spawnerStrategy; // 0x38(0x08)
	char pad_40[0x8]; // 0x40(0x08)
};

// Class VFXUtilities.DecalSpawnerCollection
// Size: 0x80 (Inherited: 0x30)
struct UDecalSpawnerCollection : UObject {
	struct TMap<struct FName, struct UDecalSpawner*> _decalSpawners; // 0x30(0x50)

	struct UDecalComponent* SpawnDecalAtLocation(struct FName decalSpawnerName, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, float LifeSpan); // Function VFXUtilities.DecalSpawnerCollection.SpawnDecalAtLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x587ff80
	void ReleaseDecalSpawner(struct FName decalSpawnerName); // Function VFXUtilities.DecalSpawnerCollection.ReleaseDecalSpawner // (Final|Native|Public|BlueprintCallable) // @ game+0x587fee0
	struct UDecalSpawner* CreateDecalSpawner(struct UObject* WorldContextObject, struct FName decalSpawnerName, struct UMaterialInterface* DecalMaterial, int32_t PoolSize, enum class ESpawnerStrategyType spawnerStrateryType); // Function VFXUtilities.DecalSpawnerCollection.CreateDecalSpawner // (Final|Native|Public|BlueprintCallable) // @ game+0x587fd50
};

// Class VFXUtilities.SpawnerStrategy
// Size: 0x30 (Inherited: 0x30)
struct USpawnerStrategy : UObject {
};

// Class VFXUtilities.LimitAccumulationSpawnerStrategy
// Size: 0x40 (Inherited: 0x30)
struct ULimitAccumulationSpawnerStrategy : USpawnerStrategy {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class VFXUtilities.NoAccumulationSpawnerStrategy
// Size: 0x30 (Inherited: 0x30)
struct UNoAccumulationSpawnerStrategy : USpawnerStrategy {
};

// Class VFXUtilities.VFXUtilities
// Size: 0x30 (Inherited: 0x30)
struct UVFXUtilities : UBlueprintFunctionLibrary {

	void SetParticleSystemsActive(struct TSet<struct UParticleSystemComponent*> particleSystems, bool Active, bool Reset); // Function VFXUtilities.VFXUtilities.SetParticleSystemsActive // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5880820
	void SetParticleSystemActive(struct UParticleSystemComponent* ParticleSystem, bool Active, bool Reset); // Function VFXUtilities.VFXUtilities.SetParticleSystemActive // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5880710
};

