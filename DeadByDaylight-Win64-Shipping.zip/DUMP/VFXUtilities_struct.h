// Enum VFXUtilities.ESpawnerStrategyType
enum class ESpawnerStrategyType : uint8 {
	None,
	NoAccumulation,
	LimitAccumulation,
	ESpawnerStrategyType_MAX,
};

