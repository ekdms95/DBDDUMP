// Class WwiseUtilities.WwiseUtilities
// Size: 0x40 (Inherited: 0x38)
struct UWwiseUtilities : UGameInstanceSubsystem {
	char pad_38[0x8]; // 0x38(0x08)
};

